export const MStoreConstants = {
  LocalStorageKeys: {
    LastSelectedWorkflowQueue: 'lastSelectedWorkflowQueue',
    IsAppIdleOnAnotherTab: 'isAppIdleOnAnotherTab',
    IsAppIdleExtended: 'isExtended',
    VuexPersistedState: 'vuex',
    IsApplicationDirtyOnAnotherTab: 'isApplicationDirtyOnAnotherTab',
    IsApplicationLoggedOutOnAnotherTab: 'isApplicationLoggedOutOnAnotherTab',
    IsApplicationDirty: 'isApplicationDirty'
  }
};
