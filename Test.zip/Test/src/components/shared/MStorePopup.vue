<template>
  <div>
    <b-modal
      size="lg"
      id="modal"
      :visible="this.showModal"
      :no-close-on-backdrop="true"
      :no-close-on-esc="true"
      :hide-header-close="true"
      :centered="true"
      :hide-header="true"
      :hide-footer="true"
    >
      <component v-if="!isNullOrEmpty(componentName)" :is="componentName" :showModal="showModal" :title="title" />
      <div v-else class="card">
        <div class="card-header">
          <h6>
            <slot name="header" />
          </h6>
        </div>
        <div class="card-body">
          <slot name="default" />
        </div>
        <div v-if="showFooter" class="card-footer">
          <slot name="footer" />
        </div>
      </div>
    </b-modal>
  </div>
</template>

<script lang="ts">
  import { Component, Vue } from 'vue-property-decorator';
  import { ObjectHelper, MStorePopupHelper } from '@/mixins';

  export default Vue.extend({
    name: 'MStorePopup',
    mixins: [ObjectHelper, MStorePopupHelper],
    computed: {
      showHeader(this: any) {
        return !this.isNullOrEmpty(this.title);
      }
    },
    components: {
      Feedback: () => import('./Feedback.vue'),
      WorkflowKanbanPopupFields: () => import('../workflow/kanban/WorkflowKanbanPopupFields.vue')
    }
  });
</script>
