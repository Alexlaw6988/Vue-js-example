export interface DocuSignTemplateAdditionalDocumentSearchModel {
    documentTypeId: number;
    templateId: number;
    templateAdditionalDocumentId: number | null;
}