import { RouteHelpers } from '@/mixins';
import { Configuration } from '@/types';
import ConfigurationTreeView from '@/components/configuration/TreeView.vue';

const RoleManagement = () =>
  import(
    /* webpackChunkName: "RoleManagement" */
    '@/views/configuration/role/RoleManagement.vue'
  );

const ViewRole = () => import(/* webpackChunkName: "ViewRole" */ '@/views/configuration/role/ViewRole.vue');
const AddRole = () => import(/* webpackChunkName: "AddRole" */ '@/views/configuration/role/AddRole.vue');
const EditRole = () => import(/* webpackChunkName: "EditRole" */ '@/views/configuration/role/EditRole.vue');

const meta = {
  layout: 'TreeView',
  treePath: 'roles'
};

const metaWithModel = {
  ...meta,
  model: 'role'
};

export const RoleManagementRoutes = [
  {
    ...Configuration.Role.Management,
    components: {
      default: RoleManagement,
      treeView: ConfigurationTreeView
    },
    meta
  },
  {
    ...Configuration.Role.Add,
    components: {
      default: AddRole,
      treeView: ConfigurationTreeView
    },
    meta
  },
  {
    ...Configuration.Role.View,
    components: {
      default: ViewRole,
      treeView: ConfigurationTreeView
    },
    meta: metaWithModel,
    beforeEnter: (to: any, from: any, next: any) => {
      RouteHelpers.setErrorPageRedirect(Configuration.Role.Management.name);
      RouteHelpers.beforeEnterCheckRouteParamAsNumeric(to, from, next, ['id']);
    }
  },
  {
    ...Configuration.Role.Edit,
    components: {
      default: EditRole,
      treeView: ConfigurationTreeView
    },
    meta: metaWithModel,
    beforeEnter: (to: any, from: any, next: any) => {
      RouteHelpers.setErrorPageRedirect(Configuration.Role.Management.name);
      RouteHelpers.beforeEnterCheckRouteParamAsNumeric(to, from, next, ['id']);
    }
  },
  {
    ...Configuration.Role.Copy,
    props: {
      default: true
    },
    components: {
      default: AddRole,
      treeView: ConfigurationTreeView
    },
    meta
  }
];
