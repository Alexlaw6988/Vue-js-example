export enum WorkflowDataSourceFieldListType {
  None = 0,
  Sql = 1,
  Maf = 2,
  Unsupported = 3
}
