<template>
  <div class="splitWrapper flex-fill w-100">
    <splitpanes watch-slots class="default-theme" @resize="onResize" @resized="onResized">
      <div
        v-if="hasVerticalJobTabs"
        :splitpanes-size="leftPaneSize"
        splitpanes-min="15"
        splitpanes-max="25"
        class="vertical-tabs overflow-y-auto"
      >
        <div @mouseover="userActivity" @touchstart="userActivity">
          <VerticalWorkflowJobTabs :processingAction="processingAction" :isLoading="isLoading" />
        </div>
      </div>
      <div
        :splitpanes-size="rightPaneSize"
        :class="`d-flex flex-column h-100 position-relative ${hasVerticalJobTabs ? 'w-100' : ''}`"
      >
        <div class="flex-1 overflow-hidden" @mouseover="userActivity" @touchstart="userActivity">
          <DocumentViewer :load-first-page="false" />
        </div>
        <div @mouseover="userActivity" @touchstart="userActivity">
          <HorizontalWorkflowJobTabs
            v-if="hasHorizontalJobTabs"
            :processingAction="processingAction"
            :isLoading="isLoading"
          />
        </div>
        <div @mouseover="userActivity" @touchstart="userActivity">
          <div title="Automatically open the next available job after processing the current job">
            <b-form-checkbox
              v-if="workflowJob.canGetNextJob"
              @input="setCanGetNextJobforCurrentQueue"
              class="float-left mt-2 ml-3 custom-switch"
              v-model="getNextJob"
            >
              <div class="mt-05">Automatically open the next job</div>
            </b-form-checkbox>
          </div>
          <WorkflowButtons
            :buttons="workflowQueueConfiguration.workflowJobButtons"
            :isLoading="isLoading"
            @close-button-clicked="closeWorkflowJobAsync"
            @process-button-clicked="onProcessButtonClickedAsync"
            @return-button-clicked="onProcessButtonClickedAsync"
            @cancel-job-button-clicked="onProcessButtonClickedAsync"
            @exception-button-clicked="onProcessButtonClickedAsync"
          >
            <template slot="processButtonText">Save</template>
            <template slot="cancel-jobButtonText">Cancel Document</template>
          </WorkflowButtons>
        </div>
        <WorkflowJobLock
          v-if="workflowJob.canProcess"
          @buttonClicked="expiryModalButtonClicked"
          :lastActivity="lastActivity"
        />
      </div>
    </splitpanes>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  import { mapActions, mapGetters } from 'vuex';
  import DefaultWorkflowJob from '@/components/workflow/DefaultWorkflowJob.vue';
  import {
    JobTabStateModel,
    WorkflowJobTabsToHideModel,
    TabStateModel,
    FieldUpdateModel,
    WorkflowJobButtonModel,
    WorkflowStandardProcessingAction,
    WorkflowJobTabModel
  } from '@/types';
  import { SignersTabService } from '@/services/docuSign/SignersTabService';
  import { EventBus } from '@/classes/EventBus';
  import { DocuSignWorkflowJob, ObjectHelper } from '@/mixins';
  import LoadingSpinner from '@/components/shared/LoadingSpinner.vue';

  export default Vue.extend({
    name: 'DocuSignWorkflowJob',
    mixins: [DefaultWorkflowJob, DocuSignWorkflowJob, ObjectHelper],
    data() {
      return {
        leftPaneSize: 0,
        rightPaneSize: 0
      };
    },
    methods: {
      ...mapActions('docuSignWorkflowJobStore', ['unloadDocuSignWorkflowJob'])
    },
    computed: {
      ...mapGetters('workflowJobStore', ['workflowDataSourceField', 'jobTabState']),
      ...mapGetters('docuSignWorkflowJobStore', ['signersTab'])
    },
    mounted(this: any) {
      this.initializeCanGetNextJob();
    },
    beforeDestroy(this: any) {
      this.unloadDocuSignWorkflowJob();
    },
    components: {
      LoadingSpinner
    }
  });
</script>
