import AxiosConfiguration from '@/classes/AxiosConfiguration';
import { DocumentToStoreUploadModel, DocumentToStoreUploadResultModel } from '@/types/models/documentsToStore';

const DocumentsToStoreApiUrl = 'DocumentsToStore';
const GetMyDocumentsApiUrl = `${DocumentsToStoreApiUrl}/myDocuments`;
const GetEveryOnesDocumentsApiUrl = `${DocumentsToStoreApiUrl}/everyonesDocuments`;
const GetDocumentsByDocumentTypeApiUrl = `${DocumentsToStoreApiUrl}/documents`;
const UploadDocumentsToStoreUrl = `${DocumentsToStoreApiUrl}/document`;

export const DocumentsToStoreService = {
  async getDocumentsToStoreAsync() {
    const response = await AxiosConfiguration.axiosWithErrorPage.get(DocumentsToStoreApiUrl);
    return response.data;
  },
  async getMyDocumentsAsync(): Promise<any> {
    const response = await AxiosConfiguration.axiosWithoutNotification.get(GetMyDocumentsApiUrl);
    return response.data;
  },
  async getEveryonesDocumentsAsync(): Promise<any> {
    const response = await AxiosConfiguration.axiosWithoutNotification.get(GetEveryOnesDocumentsApiUrl);
    return response.data;
  },
  async getDocumentsByDocumentTypeAsync(documentType: number): Promise<any> {
    const response = await AxiosConfiguration.axiosWithoutNotification.get(
      `${GetDocumentsByDocumentTypeApiUrl}/${documentType}`
    );
    return response.data;
  },
  async uploadDocumentsToStoreAsync(
    documentToStoreUploadModel: DocumentToStoreUploadModel,
    onUploadProgress: any
  ): Promise<DocumentToStoreUploadResultModel> {
    let formData = new FormData();

    Object.entries(documentToStoreUploadModel).forEach(([key, value]) => {
      formData.append(key, value);
    });

    const response = await AxiosConfiguration.axiosWithoutNotification.post(UploadDocumentsToStoreUrl, formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      },
      onUploadProgress
    });
    return response.data;
  }
};
