<template>
  <div class="w-100">
    <m-table
      class="mb-3 mh-100 min-h-100 w-100 mstore-grouped-table"
      :table-id="tableId"
      :header-text="headerText"
      :items="groupItems"
      :fields="groupFields"
      :is-loading="isLoading"
      :can-hover-on-table-row="canHoverOnTableRow"
      :empty-text="emptyText"
      :empty-html="emptyHtml"
      :show-hide-filters="showHideFilters"
      :emit-filters="emitFilters"
      :show-filters="showFilters"
      :current-page="currentPage"
      :items-per-page="itemsPerPage"
      :search-query="searchQuery"
      :sort-by="sortBy"
      :sort-desc="sortDesc"
      :selected-pk="selectedPk"
      :allow-wallboard-mode="allowWallboardMode"
      :wallboard-refresh-interval-in-seconds="wallboardRefreshIntervalInSeconds"
      @update:show-filters="$emit('update:show-filters', arguments[0], arguments[1])"
      @update:current-page="$emit('update:current-page', arguments[0], arguments[1])"
      @update:items-per-page="$emit('update:items-per-page', arguments[0], arguments[1])"
      @update:search-query="$emit('update:search-query', arguments[0], arguments[1])"
      @update:sort-by="$emit('update:sort-by', arguments[0], arguments[1])"
      @update:sort-desc="$emit('update:sort-desc', arguments[0], arguments[1])"
      @update:filtered-items="$emit('update:filtered-items', arguments[0], arguments[1])"
      @update:selected-pk="$emit('update:selected-pk', arguments[0], arguments[1])"
      @refresh-clicked="$emit('refresh-clicked', $event)"
      @on-filtered-or-sorted="$emit('on-filtered-or-sorted', $event)"
      @on-items-changed="$emit('on-items-changed', $event)"
    >
      <template slot="cell(rowExpand)" slot-scope="row">
        <b-button :variant="row.detailsShowing ? 'danger' : 'primary'" size="sm" @click="toggleDetails(row)">
          <font-awesome-icon :icon="row.detailsShowing ? 'chevron-down' : 'chevron-right'" />
        </b-button>
      </template>
      <template slot="row-details" slot-scope="row">
        <ul class="list-group list-group-flush">
          <li class="list-group-item list-group-item-action bg-light-gray">
            <b-row>
              <b-col v-if="multiSelect" sm="1" class="text-sm-left">
                <b-checkbox
                  @click.native.stop
                  @change="onRowSelectionChanged($event, row.item.childRows)"
                  :checked="allChildRowsSelectedWithinGroup(row)"
                />
              </b-col>
              <b-col v-for="column in detailFieldColumns" :key="column.key" class="text-sm-left">
                <b>{{ column.label }}</b>
              </b-col>
            </b-row>
          </li>
          <li
            v-for="childRow in row.item.childRows"
            :key="childRow[pkField]"
            class="list-group-item list-group-item-action"
          >
            <b-row @click="$emit('row-clicked', childRow)">
              <b-col v-if="multiSelect" sm="1" class="text-sm-left">
                <b-checkbox
                  @click.native.stop
                  @change="onRowSelect($event, childRow, row.item.childRows)"
                  :checked="isRowSelected(childRow)"
                />
              </b-col>
              <b-col v-for="field in detailColumns" :key="field" class="text-sm-left">{{ childRow[field] }}</b-col>
            </b-row>
          </li>
        </ul>
      </template>
      <template slot="cell(actions)" slot-scope="row" class="p-0">
        <m-buttons :isLoading="isLoading" :disabled="isFullscreen" :buttons="actions" @click="onButtonClicked($event, row)"></m-buttons>
      </template>
      <template v-for="(value, slot) in $scopedSlots" :slot="slot" slot-scope="slotData">
        <slot :name="slot" v-bind="slotData" />
      </template>
    </m-table>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  import { mapActions, mapGetters } from 'vuex';
  import { ColumnsModel } from '@/types/models/table/ColumnsModel';
  import LoadingSpinner from '@/components/shared/LoadingSpinner.vue';
  import MStoreTable from '@/components/shared/Table/MStoreTable.vue';
  import MStoreButtons from '@/components/shared/MStoreButtons.vue';
  import { Fullscreen } from '@/utils';

  export default Vue.extend({
    name: 'm-grouped-table',
    props: {
      headerText: {
        type: String,
        required: true
      },
      errorMessage: {
        type: String,
        required: false
      },
      hasError: {
        type: Boolean,
        required: false
      },
      showHideFilters: {
        type: Boolean,
        required: false,
        default: false
      },
      items: {
        type: Array,
        required: true
      },
      fields: {
        type: Array,
        required: true
      },
      isLoading: {
        type: Boolean,
        required: true
      },
      emptyText: {
        type: String,
        required: false
      },
      canHoverOnTableRow: {
        type: Boolean,
        required: false,
        default: true
      },
      rowClass: {
        type: Function,
        required: false
      },
      theadClass: {
        type: String,
        required: false,
        default: 'text-no-wrap'
      },
      tableId: {
        type: String,
        required: false
      },
      emitFilters: {
        type: Boolean,
        required: false,
        default: false
      },
      showFilters: {
        type: Boolean,
        required: false,
        default: false
      },
      currentPage: {
        type: Number,
        required: false,
        default: 1
      },
      itemsPerPage: {
        type: Number,
        required: false,
        default: 10
      },
      searchQuery: {
        type: String,
        required: false,
        default: ''
      },
      sortBy: {
        type: String,
        required: false,
        default: ''
      },
      sortDesc: {
        type: Boolean,
        required: false,
        default: false
      },
      emptyHtml: {
        type: String,
        required: false,
        default: ''
      },
      pkField: {
        type: String,
        required: false
      },
      selectedPk: {
        required: false
      },
      groupByField: {
        type: String,
        required: true
      },
      groupColumns: {
        type: Array,
        required: false
      },
      detailColumns: {
        type: Array,
        required: true
      },
      actions: {
        type: Array,
        required: false
      },
      multiSelect: {
        type: Boolean,
        required: false,
        default: false
      },
      addActionHeader: {
        type: Boolean,
        required: false,
        default: false
      },
      selectAllRowsInitially: {
        type: Boolean,
        required: false,
        default: false
      },
      allowWallboardMode: {
        type: Boolean,
        default: false
      },
      wallboardRefreshIntervalInSeconds: {
        type: Number,
        default: 0
      }
    },
    data() {
      return {
        showModal: false,
        postIsLoading: false,
        selectedRows: [] as any,
        isFullscreen: false
      };
    },
    computed: {
      ...mapGetters('mGroupedTableStore', ['getExpandedGroups']),
      groupItems(this: any) {
        const groupedData = this.items.reduce((itemGroups: any, item: any) => {
          itemGroups[item[this.groupByField].toLowerCase()] = itemGroups[item[this.groupByField].toLowerCase()] || [];
          itemGroups[item[this.groupByField].toLowerCase()].push(item);
          return itemGroups;
        }, {});
        return Object.keys(groupedData).map((key: any) => {
          return Object.assign(
            {
              childRows: groupedData[key],
              _showDetails: this.getExpandedGroups(this.tableId)?.includes(key)
            },
            groupedData[key][0]
          );
        });
      },
      groupFields(this: any): ColumnsModel[] {
        const columns = this.fields.filter((x: ColumnsModel) =>
          this.groupColumns?.length > 0 ? this.groupColumns.includes(x.key) : !this.detailColumns.includes(x.key)
        ) as ColumnsModel[];

        columns.unshift({
          key: 'rowExpand',
          label: '',
          sortable: false,
          thStyle: 'width: 2%'
        } as ColumnsModel);

        const ifActionColumn = columns.some((x: ColumnsModel) => x.key === 'actions');
        if ((this.actions?.length > 0 && !ifActionColumn) || this.addActionHeader) {
          columns.push({
            key: 'actions',
            label: '',
            sortable: false,
            thStyle: 'width: 20%'
          } as ColumnsModel);
        }

        return columns;
      },
      detailFieldColumns(this: any): ColumnsModel[] {
        return this.fields.filter((x: ColumnsModel) => this.detailColumns.indexOf(x.key) !== -1) as ColumnsModel[];
      }
    },
    methods: {
      ...mapActions('mGroupedTableStore', ['addExpandedGroup', 'removeExpandedGroup']),
      onButtonClicked(this: any, event: any, row: any) {
        const selectedRows = !this.multiSelect
          ? row.item.childRows
          : this.selectedRows.filter((childRow: any) => childRow[this.groupByField] === row.item[this.groupByField]);
        if (selectedRows?.length > 0) {
          this.$emit('group-action', event, selectedRows);
        }
      },
      onRowSelect(this: any, checked: any, row: any, rows: any[]) {
        if (checked) {
          this.selectedRows.push(row);
        } else {
          const index = this.selectedRows.findIndex((childRow: any) => childRow[this.pkField] === row[this.pkField]);
          this.selectedRows.splice(index, 1);
        }
      },
      initialize(this: any) {
        this.selectedRows = [] as any;
        if (this.selectAllRowsInitially) {
          this.groupItems.forEach((group: any) => {
            this.selectedRows = [...this.selectedRows, ...group.childRows];
          });
        }
      },
      isRowSelected(this: any, row: any): boolean {
        return this.containsRow(this.selectedRows, row);
      },
      toggleDetails(row: any) {
        const value = row.item[this.groupByField].toLowerCase();
        if (row.item._showDetails === true) {
          this.removeExpandedGroup({ stateKey: this.tableId, value });
        } else {
          this.addExpandedGroup({ stateKey: this.tableId, value });
        }
        row.toggleDetails();
      },
      onRowSelectionChanged(this: any, checked: any, rows: any[]) {
        this.deselectRows(rows);
        if (checked) {
          this.selectedRows = [...this.selectedRows, ...rows];
        }
      },
      allChildRowsSelectedWithinGroup(this: any, row: any): boolean {
        return row.item.childRows.every((childRow: any) => this.containsRow(this.selectedRows, childRow));
      },
      deselectRows(this: any, rows: any[]) {
        this.selectedRows = this.selectedRows.filter((childRow: any) => !this.containsRow(rows, childRow));
      },
      containsRow(rows: any[], row: any): boolean {
        return rows.some((childRow: any) => childRow[this.pkField] === row[this.pkField]);
      },
      handleOnFullscreenChange(this: any) {
        this.isFullscreen = Fullscreen.isFullscreen();
      }
    },
    watch: {
      items(this: any) {
        this.initialize();
      }
    },
    mounted(this: any) {
      this.initialize();
    },
    components: {
      LoadingSpinner,
      'm-buttons': MStoreButtons,
      'm-table': MStoreTable
    },
    created() {
      Fullscreen.registerFullscreenChange(this.handleOnFullscreenChange);
    },
    beforeDestroy() {
      Fullscreen.removeFullscreenChange(this.handleOnFullscreenChange);
    },
  });
</script>
