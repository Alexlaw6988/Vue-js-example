import { actions } from './actions';
import { getters } from './getters';
import { mutations } from './mutations';
import { DocuSignTemplateManagementState, TableStateModel } from '@/types';

export function defaultTemplateManagementState() {
    return {
        tableState: {
            stateKey: '',
            showFilters: false,
            currentPage: 1,
            itemsPerPage: 10,
            searchQuery: '',
            sortBy: '',
            sortDesc: false,
            selectedPk: '',
            filteredItems: []
        } as TableStateModel,
        documentTypeId: null
    } as DocuSignTemplateManagementState;
}

export const state: DocuSignTemplateManagementState = defaultTemplateManagementState();

const namespaced: boolean = true;

export const docuSignTemplateManagement = {
    namespaced,
    state,
    actions,
    getters,
    mutations,
    defaultTemplateManagementState
};