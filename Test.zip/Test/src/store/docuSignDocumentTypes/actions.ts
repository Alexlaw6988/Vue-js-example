import { DocuSignDocumentTypesState, RootState, DocuSignDocumentTypesMutationTypes } from '@/types';
import { ActionTree } from 'vuex';

export const actions: ActionTree<DocuSignDocumentTypesState, RootState> = {
    resetDocumentTypesState({ commit }) {
        commit(DocuSignDocumentTypesMutationTypes.ResetState);
    },
    setDocumentTypeId({ commit, state }, documentTypeId: number) {
        commit(DocuSignDocumentTypesMutationTypes.SetDocumentType, documentTypeId);
    }
};