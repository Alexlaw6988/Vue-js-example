<template>
  <div id="m-defaultLayout" class="h-100">
    <LoadingSpinner v-bind:isLoading.sync="loading" class="h-100">
      <slot />
    </LoadingSpinner>
  </div>
</template>

<script lang="ts">
  import { Component, Vue } from 'vue-property-decorator';
  import LoadingSpinner from '@/components/shared/LoadingSpinner.vue';

  export default Vue.extend({
    name: 'DefaultLayout',
    data() {
      return {
        loading: false
      };
    },
    computed: {
      isLoadingCssClass(): string {
        return this.loading ? 'isLoading' : '';
      }
    },
    components: {
      LoadingSpinner
    }
  });
</script>
