import {
  RelatedDocumentViewModel,
  FieldActionButtonStateModel,
  ViewRelatedDocumentActionButtonPropertiesModel
} from '@/types/models';
import IActionButtonHandler from '@/classes/interfaces/IActionButtonHandler';
import store from '@/store';
import { ObjectHelper } from '@/mixins/objectHelper';
import { WorkflowJobTabModel } from '@/types';

export default class ViewRelatedDocumentActionButtonHandler implements IActionButtonHandler {
  public getActionButtonState(
    this: any,
    actionButtonProperties: ViewRelatedDocumentActionButtonPropertiesModel
  ): FieldActionButtonStateModel {
    const relatedDocument: RelatedDocumentViewModel = this.getLatestRelatedDocument(actionButtonProperties);
    const relatedDocumentIsBeingViewed: boolean = this.relatedDocumentIsBeingViewed(relatedDocument);

    if (relatedDocument) {
      return {
        icon: relatedDocumentIsBeingViewed
          ? actionButtonProperties.showOriginalIcon
          : actionButtonProperties.showRelatedIcon,
        tooltip: relatedDocumentIsBeingViewed
          ? actionButtonProperties.showOriginalTooltip
          : actionButtonProperties.showRelatedTooltip,
        disabled: false,
        variant: relatedDocumentIsBeingViewed
          ? actionButtonProperties.showOriginalVariant
          : actionButtonProperties.showRelatedVariant,
        data: relatedDocument
      } as FieldActionButtonStateModel;
    }

    return {
      icon: actionButtonProperties.noDocumentIcon,
      tooltip: actionButtonProperties.showRelatedTooltip,
      disabled: true,
      variant: actionButtonProperties.noDocumentVariant,
      data: {} as RelatedDocumentViewModel
    } as FieldActionButtonStateModel;
  }

  public performButtonClick(this: any, actionButtonState: FieldActionButtonStateModel): void {
    if (this.relatedDocumentIsBeingViewed(actionButtonState.data as RelatedDocumentViewModel)) {
      store.dispatch('documentViewStore/setRelatedDocumentBeingViewed', {} as RelatedDocumentViewModel);
      return;
    }
    store.dispatch('documentViewStore/setRelatedDocumentBeingViewed', actionButtonState.data);

    this.setRelatedDocumentsTabActive();
    const relatedDocumentInformation = actionButtonState.data as RelatedDocumentViewModel;
    this.setRelationshipBeingViewed(relatedDocumentInformation.linkId);
  }

  private getLatestRelatedDocument(
    actionButtonProperties: ViewRelatedDocumentActionButtonPropertiesModel
  ): RelatedDocumentViewModel {
    if (
      actionButtonProperties.matchRelatedDocumentReferenceKey ||
      (actionButtonProperties.matchRelatedDocumentReferenceValues &&
        Object.keys(actionButtonProperties.matchRelatedDocumentReferenceValues).length > 0)
    ) {
      return store.getters['relatedDocumentsStore/getLatestRelatedDocumentByLinkIdAndReferences'](
        Number(actionButtonProperties.linkId),
        actionButtonProperties.matchRelatedDocumentReferenceKey,
        actionButtonProperties.matchDataSourceKey,
        actionButtonProperties.matchDataSourceFieldKey,
        actionButtonProperties.matchRelatedDocumentReferenceValues
      );
    }
    return store.getters['relatedDocumentsStore/getLatestRelatedDocumentByLinkId'](
      Number(actionButtonProperties.linkId)
    );
  }

  private relatedDocumentIsBeingViewed(relatedDocument: RelatedDocumentViewModel): boolean {
    const relatedDocumentBeingViewed: RelatedDocumentViewModel =
      store.getters['documentViewStore/relatedDocumentBeingViewed'];

    return (
      !ObjectHelper.methods.isNullOrEmpty(relatedDocumentBeingViewed) &&
      !ObjectHelper.methods.isNullOrEmpty(relatedDocument) &&
      relatedDocumentBeingViewed.documentSearchModel.documentId === relatedDocument.documentSearchModel.documentId
    );
  }

  private setRelatedDocumentsTabActive(): void {
    const activeTab: WorkflowJobTabModel = store.getters['workflowJobStore/activeHorizontalTab'];
    if (!activeTab || activeTab.key !== 'RelatedDocuments') {
      store.dispatch('workflowJobStore/setActiveHorizontalTab', 'RelatedDocuments');
    }
  }

  private setRelationshipBeingViewed(linkId: number): void {
    store.dispatch('relatedDocumentsStore/setRelationshipBeingViewed', linkId);
  }
}
