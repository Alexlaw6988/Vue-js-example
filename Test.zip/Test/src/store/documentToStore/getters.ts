import { RootState, DocumentToStoreState, DocumentToStoreViewModel } from '@/types';
import { GetterTree } from 'vuex';

export const getters: GetterTree<DocumentToStoreState, RootState> = {
  getDocumentToStoreView(state): DocumentToStoreViewModel {
    return state.documentToStoreView;
  }
};
