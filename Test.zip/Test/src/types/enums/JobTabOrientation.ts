export enum JobTabOrientation {
  Horizontal = 1,
  Vertical = 2
}
