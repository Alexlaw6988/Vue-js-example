import { DocuSignTemplateModel, DocumentTypeModel } from '@/types';

export interface DocuSignTemplateConfigurationModel {
    templateId: number | null;
    keyBusinessReferenceField: string;
    documentType: DocumentTypeModel;
    template: DocuSignTemplateModel;
}