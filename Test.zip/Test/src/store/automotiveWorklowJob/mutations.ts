import {
  AutomotiveWorkflowJobState,
  AutomotiveWorkflowJobMutationTypes,
  ManufacturerTabModel,
  FieldUpdateModel
} from '@/types';
import { MutationTree } from 'vuex';

export const mutations: MutationTree<AutomotiveWorkflowJobState> = {
  [AutomotiveWorkflowJobMutationTypes.SetIsManufacturerTabLoading](state, isLoading: boolean) {
    state.isManufacturerTabLoading = isLoading;
  },
  [AutomotiveWorkflowJobMutationTypes.ManufacturerTabLoaded](state, payload: ManufacturerTabModel) {
    state.errorMessage = '';
    state.error = false;
    state.manufacturerTab = payload;
    state.isManufacturerTabLoading = false;
  },
  [AutomotiveWorkflowJobMutationTypes.ManufacturerTabError](state, payload: any) {
    state.errorMessage = JSON.stringify(payload);
    state.error = true;
    state.manufacturerTab = {} as ManufacturerTabModel;
    state.isManufacturerTabLoading = false;
  },
  [AutomotiveWorkflowJobMutationTypes.UpdateManufacturerDataSourceFieldValue](state, payload: FieldUpdateModel) {
    if (state.manufacturerTab && state.manufacturerTab.manufacturerDataSource) {
      (state.manufacturerTab.manufacturerDataSource.fields as any)[payload.fieldName] = payload.value;
    }
  },
  [AutomotiveWorkflowJobMutationTypes.UnloadAutomotiveWorkflowJob](state, payload) {
    const initState = {
      manufacturerTab: {} as ManufacturerTabModel,
      isManufacturerTabLoading: true,
      isLoading: false,
      error: false,
      errorMessage: ''
    } as AutomotiveWorkflowJobState;
    Object.assign(state, initState);
  }
};
