<template>
  <div>
    <div v-if="signatureTemplateModel.canSign">
      <div v-for="signatureSetting in signatureTemplateModel.signatureSettings" :key="signatureSetting.id">
        <b-form-group :label="signatureSetting.label" :label-for="signatureSetting.label">
          <b-input-group>
            <b-form-input
              :id="signatureSetting.label"
              :name="signatureSetting.label"
              :readonly="true"
              :state="signatureSetting.isSigned"
              :value="getInputValue(signatureSetting.isSigned)"
              :class="getInputCssClass(signatureSetting.isSigned)"
              @click="openSignatureModal(signatureSetting.id)"
              class="pointer"
              :disabled="isDisabled"
            />
            <b-input-group-append>
              <b-button
                :variant="getInputGroupButtonVariant(signatureSetting.isSigned)"
                @click="loadPageWithSignature(signatureSetting.id)"
                :disabled="isDisabled"
              >
                <font-awesome-icon icon="file-signature" />
              </b-button>
            </b-input-group-append>
          </b-input-group>
        </b-form-group>
        <b-modal
          :ref="getModalId(signatureSetting.id)"
          @shown="setupSignaturePad(signatureSetting.id)"
          :id="getModalId(signatureSetting.id)"
          :title="`${signatureSetting.label} Signature`"
          :no-close-on-backdrop="true"
          :no-close-on-esc="true"
          :hide-header-close="true"
          size="lg"
        >
          <b-card v-if="processingExternalPad" class="border-0">
            <loading-spinner :isLoading="processingExternalPad" cssPositioning="unset" />
          </b-card>
          <div v-else>
            <div v-if="!isIpad() && !isIOS() && !isAndroid() && appSettings.externalSignaturePadEnabled">
              <b-row>
                <b-col>
                  <b-alert :show="showExternalPadAlert" dismissible @dismissed="externalPadAlertDismissed" class="mb-2">
                    <h6 class="alert-heading">Information</h6>
                    <hr class="my-2" />
                    The Signature pad window is loading, if it doesn't load please check that you have completed the
                    following:
                    <br />
                    - Installed the EPadLink SDK
                    <br />
                    - Added the EPadLink Chrome extension to your browser
                  </b-alert>
                </b-col>
              </b-row>
              <b-row>
                <b-col>
                  <div>
                    <label v-if="!usingExternalPad" for="ePadLink">
                      Please use the signature pad below to sign. If you have an external pad you wish to use, you can
                      click the 'Use External Pad' button
                    </label>
                    <label v-else for="ePadLink">Please sign on the external pad once the window has opened</label>
                  </div>
                </b-col>
              </b-row>
              <b-row align-content="center">
                <b-col align-self="center">
                  <div v-if="!usingExternalPad" class="p-3 d-flex flex-row justify-content-center">
                    <VueSignaturePad
                      :height="`${signatureSetting.height}px`"
                      :width="`${signatureSetting.width}px`"
                      class="border border-dark rounded"
                      :ref="getSignaturePadRef(signatureSetting.id)"
                      :options="{ onEnd }"
                    />
                  </div>
                </b-col>
              </b-row>
            </div>
            <div v-else class="p-3 d-flex flex-row justify-content-center">
              <VueSignaturePad
                :height="`${signatureSetting.height}px`"
                :width="`${signatureSetting.width}px`"
                class="border border-dark rounded"
                :ref="getSignaturePadRef(signatureSetting.id)"
                :options="{ onEnd }"
              />
            </div>
          </div>
          <template slot="modal-footer">
            <div class="w-100">
              <div class="row">
                <div class="col-6">
                  <div class="float-left">
                    <b-button
                      variant="danger"
                      class="mr-1"
                      :disabled="postIsLoading"
                      @click="closeModal(signatureSetting.id)"
                    >
                      Cancel
                    </b-button>
                    <b-button
                      variant="info"
                      class="mr-1"
                      :disabled="postIsLoading || !isValid"
                      @click="undoSignature(signatureSetting.id)"
                    >
                      <font-awesome-icon icon="undo" />
                    </b-button>
                    <b-button
                      v-if="!isIpad() && !isIOS() && !isAndroid() && appSettings.externalSignaturePadEnabled"
                      variant="primary"
                      :disabled="(postIsLoading || usingExternalPad) && !externalPadErrored"
                      @click="useExternalPad(signatureSetting.height, signatureSetting.width)"
                    >
                      Use External Pad
                    </b-button>
                  </div>
                </div>
                <div class="col-6">
                  <div class="float-right">
                    <b-button variant="primary" :disabled="postIsLoading || !isValid" @click="processSignaturePad()">
                      OK
                      <font-awesome-icon icon="spinner" size="sm" class="ml-2" :hidden="!postIsLoading" spin />
                    </b-button>
                  </div>
                </div>
              </div>
            </div>
          </template>
        </b-modal>
      </div>
    </div>
    <WorkflowUnsupportedInput
      v-else
      :inputProperties="inputProperties"
      :data="data"
      message="You do not have permission to sign this document"
    />
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  import { SignatureService } from '@/services/SignatureService';
  import {
    BaseDocumentSearchModel,
    SignatureTemplateModel,
    SignatureCreateModel,
    DocumentSearchModel,
    SignatureSettingModel
  } from '@/types';
  import { mapActions } from 'vuex';
  import LoadingSpinner from '@/components/shared/LoadingSpinner.vue';
  import WorkflowUnsupportedInput from '@/components/workflow/WorkflowUnsupportedInput.vue';
  import { DeviceHelper, SignaturePadHelpers, AppSettingsHelper } from '@/mixins';

  export default Vue.extend({
    name: 'WorkflowSignaturePad',
    mixins: [SignaturePadHelpers, DeviceHelper, AppSettingsHelper],
    props: {
      documentSearchModel: {
        type: Object as () => BaseDocumentSearchModel,
        required: true
      },
      inputProperties: {
        type: Object,
        required: true
      },
      data: {
        required: true
      },
      isDisabled: {
        type: Boolean,
        default: false
      }
    },
    data() {
      return {
        signatureTemplateModel: {} as SignatureTemplateModel,
        localDocumentSearchModel: {
          documentId: this.documentSearchModel.documentId,
          cabinetId: this.documentSearchModel.cabinetId,
          documentTypeId: 0,
          page: 1
        } as DocumentSearchModel,
        getIsLoading: false,
        postIsLoading: false,
        isValid: false,
        signatureSettingId: 0,
        showExternalPadAlert: false,
        usingExternalPad: false,
        processingExternalPad: false,
        externalPadErrored: false
      };
    },
    methods: {
      ...mapActions('documentViewStore', ['loadPage', 'setDocumentSearchModel']),
      async getData() {
        this.getIsLoading = true;
        this.signatureTemplateModel = await SignatureService.getSignatureTemplateAsync(
          this.localDocumentSearchModel.cabinetId,
          this.localDocumentSearchModel.documentId
        );
        this.getIsLoading = false;
      },
      async processSignaturePad(this: any) {
        const { isEmpty, data } = this.$refs[this.getSignaturePadRef(this.signatureSettingId)][0].saveSignature();
        if (!isEmpty) {
          await this.postData(data);
        }
      },
      async postData(this: any, signatureBase64: string) {
        this.postIsLoading = true;
        await SignatureService.postSignatureAsync(
          this.localDocumentSearchModel.cabinetId,
          this.localDocumentSearchModel.documentId,
          {
            signatureSettingId: this.signatureSettingId,
            signatureBase64
          } as SignatureCreateModel
        )
          .then((result) => {
            this.localDocumentSearchModel = result;
            this.setDocumentSearchModel(this.localDocumentSearchModel);
            this.loadPage(this.localDocumentSearchModel.page);
            this.closeModal(this.signatureSettingId);
            this.postIsLoading = false;
            this.getData();
          })
          .catch((error) => {
            this.postIsLoading = false;
          })
          .finally(() => {
            this.processingExternalPad = false;
          });
      },
      undoSignature(this: any, signatureSettingId: number) {
        this.$refs[this.getSignaturePadRef(signatureSettingId)][0].undoSignature();
        if (this.$refs[this.getSignaturePadRef(signatureSettingId)][0].isEmpty()) {
          this.isValid = false;
        }
      },
      closeModal(this: any, signatureSettingId: number) {
        this.$refs[this.getModalId(signatureSettingId)][0]?.hide();
        this.$refs[this.getSignaturePadRef(this.signatureSettingId)][0]?.clearSignature();
        this.isValid = false;
      },
      setupSignaturePad(this: any, signatureSettingId: number) {
        this.$refs[this.getSignaturePadRef(signatureSettingId)][0].resizeCanvas();
      },
      getModalId(signatureSettingId: number): string {
        return `signature-setting-${signatureSettingId}-modal`;
      },
      getSignaturePadRef(signatureSettingId: number): string {
        return `signature-pad-${signatureSettingId}`;
      },
      getInputValue(isSigned: boolean): string {
        return isSigned ? 'Signed' : 'Unsigned';
      },
      getInputCssClass(isSigned: boolean): string {
        return isSigned ? 'text-success' : 'text-danger';
      },
      getInputGroupButtonVariant(isSigned: boolean): string {
        return isSigned ? 'success' : 'danger';
      },
      openSignatureModal(this: any, signatureSettingId: number) {
        this.showExternalPadAlert = false;
        this.usingExternalPad = false;
        this.signatureSettingId = signatureSettingId;
        const signatureSetting = this.signatureTemplateModel.signatureSettings.find(
          (x: SignatureSettingModel) => x.id === signatureSettingId
        ) as SignatureSettingModel;

        this.loadPage(signatureSetting.pageNumber);

        if (!signatureSetting.isSigned) {
          this.$refs[this.getModalId(signatureSettingId)][0].show();
        }
      },
      loadPageWithSignature(this: any, signatureSettingId: number) {
        const signatureSetting = this.signatureTemplateModel.signatureSettings.find(
          (x: SignatureSettingModel) => x.id === signatureSettingId
        ) as SignatureSettingModel;
        this.loadPage(signatureSetting.pageNumber);
      },
      onEnd(this: any) {
        this.isValid = true;
      },
      async processExternalPadSignature(this: any, signaturePadResponse: any) {
        this.externalPadErrored = signaturePadResponse.errorMsg as boolean;
        if (!this.externalPadErrored) {
          this.processingExternalPad = true;
          await this.postData(`data:image/png;base64,${String(signaturePadResponse.imageData)}`);
        }
      },
      useExternalPad(this: any, height: number, width: number) {
        this.isValid = false;
        this.externalPadErrored = false;
        this.showExternalPadAlert = true;
        this.usingExternalPad = true;
        this.startSignaturePad(this.processExternalPadSignature, height, width);
      },
      externalPadAlertDismissed(this: any) {
        this.showExternalPadAlert = false;
      }
    },
    async mounted() {
      this.getData();
    },
    components: {
      LoadingSpinner,
      WorkflowUnsupportedInput
    }
  });
</script>
