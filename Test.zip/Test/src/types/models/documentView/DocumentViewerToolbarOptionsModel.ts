export interface DocumentViewerToolbarOptionsModel {
  allowPageNavigation: boolean;
}