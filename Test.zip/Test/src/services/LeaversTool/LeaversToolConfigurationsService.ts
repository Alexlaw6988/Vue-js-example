import axios from 'axios';
import {
  LeaversToolConfigurationsModel,
  LeaversToolConfigurationModel,
  LeaversToolConfigurationCreateModel
} from '@/types';

const LeaversToolConfigurationsApiUrl = 'leaverstoolconfigurations/';

export const LeaversToolConfigurationsService = {
  async getAllAsync(withLeaverLists: boolean = false): Promise<LeaversToolConfigurationsModel> {
    const response = await axios.get(LeaversToolConfigurationsApiUrl + '?withLeaverLists=' + withLeaverLists);
    return response.data;
  },
  async getAsync(id: number): Promise<LeaversToolConfigurationModel> {
    const response = await axios.get(LeaversToolConfigurationsApiUrl + id);
    return response.data;
  },
  async createAsync(leaversToolConfigurationCreateModel: LeaversToolConfigurationCreateModel): Promise<number> {
    const response = await axios.post(LeaversToolConfigurationsApiUrl, leaversToolConfigurationCreateModel);
    return response.data;
  }
};
