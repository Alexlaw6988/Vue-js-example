import { ObjectUtils } from '@/utils/objectUtils';

export const ObjectHelper = {
  methods: {
    isNullOrEmpty(object: object) {
      return ObjectUtils.isNullOrEmpty(object);
    },
    getNestedPropertyValue(propertyArray: any, parentObject: any): any {
      return ObjectUtils.getNestedPropertyValue(propertyArray, parentObject);
    },
    isNaN(value: any): boolean {
      return !value || Number.isNaN(+value);
    }
  }
};
