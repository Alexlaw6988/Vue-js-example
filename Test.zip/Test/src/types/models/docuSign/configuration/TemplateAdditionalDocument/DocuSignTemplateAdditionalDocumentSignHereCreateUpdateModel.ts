export interface DocuSignTemplateAdditionalDocumentSignHereCreateUpdateModel {
    additionalDocumentSignTabId: number;
    signerRoleId: number;
}

