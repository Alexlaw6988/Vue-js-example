import jQuery from 'jquery';
import axios from 'axios';
import { AppStartSettingsModel, AppSettingsModel } from '@/types';
import { Logger } from '@/classes/Logger';

const AppSettingsApiUrl = 'appSettings/';
const AppStartSettingsApiUrl = `${AppSettingsApiUrl}getappstartsettings`;

export const AppSettingsService = {
  getAppStartSettings(baseUrl?: string): AppStartSettingsModel {
    const url = baseUrl === undefined ? AppStartSettingsApiUrl : baseUrl.concat(AppStartSettingsApiUrl);
    let appSettings: AppStartSettingsModel = {
      baseUrl: '',
      authServerAuthority: '',
      sessionId: '',
      idleTimeout: 60,
      maximumNumberOfPagesToCache: 15
    };
    jQuery.ajax({
      type: 'GET',
      url,
      headers: {
        Pragma: 'no-cache'
      },
      async: false,
      success(response: AppStartSettingsModel) {
        appSettings = response;
      },
      error(response: any) {
        Logger.$log(`Failed to get app settings. Error: ${JSON.stringify(response)}`);
      }
    });

    return appSettings;
  },
  getAppSettings(baseUrl?: string): AppStartSettingsModel {
    const url = baseUrl === undefined ? AppSettingsApiUrl : baseUrl.concat(AppSettingsApiUrl);
    let appSettings: AppStartSettingsModel = {
      baseUrl: '',
      authServerAuthority: '',
      sessionId: '',
      idleTimeout: 60,
      maximumNumberOfPagesToCache: 15
    };
    jQuery.ajax({
      type: 'GET',
      url,
      headers: {
        Pragma: 'no-cache'
      },
      async: false,
      success(response: AppStartSettingsModel) {
        appSettings = response;
      },
      error(response: any) {
        Logger.$log(`Failed to get app settings. Error: ${JSON.stringify(response)}`);
      }
    });

    return appSettings;
  },
  async getAppSettingsAsync(): Promise<AppSettingsModel> {
    const response = await axios.get(AppSettingsApiUrl);
    return response.data;
  }
};
