import { MutationTree } from 'vuex';
import {
  WorkflowJobModel,
  WorkflowJobState,
  FieldUpdateModel,
  WorkflowDataSourceModel,
  WorkflowJobTabModel,
  JobTabStateModel,
  JobTabOrientation,
  LockModel,
  ErrorModel,
  TabStateModel,
  DynamicFormValidationModel,
  WorkflowJobMutationTypes,
  CustomTabDynamicFormUpdateModel
} from '@/types';
import { ObjectUtils } from '@/utils/objectUtils';

export const mutations: MutationTree<WorkflowJobState> = {
  [WorkflowJobMutationTypes.SetIsLoading](state, isLoading: boolean) {
    state.isLoading = isLoading;
  },
  [WorkflowJobMutationTypes.SetIsAwaitingProcessing](state, isAwaitingProcessing: boolean) {
    state.isAwaitingProcessing = isAwaitingProcessing;
  },
  [WorkflowJobMutationTypes.SetIsDirty](state, isDirty: boolean) {
    state.isDirty = isDirty;
  },
  [WorkflowJobMutationTypes.SetErrorMessage](state, payload: any) {
    state.errorMessage = payload;
  },
  [WorkflowJobMutationTypes.WorkflowJobLoaded](state, payload: WorkflowJobModel) {
    state.workflowJob = payload;
    state.isLoading = false;
    state.error = false;
  },
  [WorkflowJobMutationTypes.WorkflowJobError](state, payload: any) {
    state.errorMessage = JSON.stringify(payload);
    state.workflowJob = {} as WorkflowJobModel;
    state.isLoading = false;
    state.error = true;
  },
  [WorkflowJobMutationTypes.PopulateHorizontalJobTabStates](state, payload: WorkflowJobTabModel[]) {
    payload.forEach((tab: WorkflowJobTabModel) => {
      state.jobTabStates.push({
        key: tab.key,
        itemCount: 0,
        showCount: false,
        isDirty: false,
        hidden: false,
        jobTabOrientation: JobTabOrientation.Horizontal
      } as JobTabStateModel);
    });
  },
  [WorkflowJobMutationTypes.PopulateVerticalJobTabStates](state, payload: WorkflowJobTabModel[]) {
    payload.forEach((tab: WorkflowJobTabModel) => {
      state.jobTabStates.push({
        key: tab.key,
        itemCount: 0,
        showCount: false,
        isDirty: false,
        hidden: false,
        jobTabOrientation: JobTabOrientation.Vertical
      } as JobTabStateModel);
    });
  },
  [WorkflowJobMutationTypes.SetJobTabStateCount](state, payload: TabStateModel) {
    const jobTabState = state.jobTabStates.find((x: JobTabStateModel) => x.key === payload.key);
    if (jobTabState) {
      jobTabState.itemCount = payload.itemCount;
      jobTabState.showCount = payload.itemCount > 0;
    }
  },
  [WorkflowJobMutationTypes.SetJobTabStateDirty](state, payload: TabStateModel) {
    const jobTabState = state.jobTabStates.find((x: JobTabStateModel) => x.key === payload.key);
    if (jobTabState) {
      jobTabState.isDirty = payload.isDirty;
    }
  },
  [WorkflowJobMutationTypes.SetJobTabStateHidden](state, payload: TabStateModel) {
    const jobTabState = state.jobTabStates.find((x: JobTabStateModel) => x.key === payload.key);
    if (jobTabState) {
      jobTabState.hidden = payload.hidden;
    }
  },
  [WorkflowJobMutationTypes.UpdateWorkflowDataSourceField](state, payload: FieldUpdateModel) {
    const dataSource = state.workflowJob.workflowDataSources.find(
      (x: WorkflowDataSourceModel) => x.key.toLowerCase() === payload.dataSourceKey.toLowerCase()
    ) as any | undefined;

    if (dataSource) {
      const fieldKey = ObjectUtils.getFieldKeyIgnoreCase(dataSource.fields, payload.fieldName);
      if (fieldKey) {
        dataSource.fields[fieldKey] = payload.value;
      }
    }
  },
  [WorkflowJobMutationTypes.SetActiveHorizontalTab](state, payload: WorkflowJobTabModel) {
    if (payload) {
      state.activeHorizontalTab = payload;
    }
  },
  [WorkflowJobMutationTypes.SetActiveVerticalTab](state, payload: WorkflowJobTabModel) {
    if (payload) {
      state.activeVerticalTab = payload;
    }
  },
  [WorkflowJobMutationTypes.SetExtendingWorkflowJobLock](state, payload: boolean) {
    state.extendingWorkflowJobLock = payload;
  },
  [WorkflowJobMutationTypes.ExtendWorkflowJobLock](state, payload: LockModel) {
    state.workflowJob.lockModel = payload;
  },
  [WorkflowJobMutationTypes.ExpireWorkflowJobLock](state, payload: any) {
    if (payload) {
      state.errorMessage = payload;
    }
    state.workflowJob.lockModel = {} as LockModel;
  },
  [WorkflowJobMutationTypes.SetJobComponentName](state, componentName: string) {
    state.workflowJob.jobComponentName = componentName;
  },
  [WorkflowJobMutationTypes.SetJobErrorModel](state, errorModel: ErrorModel) {
    state.workflowJob.errorModel = errorModel;
  },
  [WorkflowJobMutationTypes.SetDynamicFormValidationModel](state, validationModel: DynamicFormValidationModel) {
    const dynamicFormValidationModel = state.dynamicFormValidationModels.find(
      (x: DynamicFormValidationModel) => x.formId === validationModel.formId
    ) as DynamicFormValidationModel | undefined;
    if (dynamicFormValidationModel) {
      state.dynamicFormValidationModels.splice(
        state.dynamicFormValidationModels.indexOf(dynamicFormValidationModel),
        1,
        validationModel
      );
    } else {
      state.dynamicFormValidationModels.push(validationModel);
    }
  },
  [WorkflowJobMutationTypes.UnloadWorkflowJob](state, payload) {
    const initState = {
      workflowJob: {} as WorkflowJobModel,
      isLoading: false,
      error: false,
      isDirty: false,
      errorMessage: '',
      activeHorizontalTab: {} as WorkflowJobTabModel,
      activeVerticalTab: {} as WorkflowJobTabModel,
      jobTabStates: [] as JobTabStateModel[],
      extendingWorkflowJobLock: false,
      dynamicFormValidationModels: [] as DynamicFormValidationModel[]
    } as WorkflowJobState;
    Object.assign(state, initState);
  },
  [WorkflowJobMutationTypes.AddDynamicFormModelToCustomJobTab](state, payload: CustomTabDynamicFormUpdateModel) {
    const workflowJobTab = state.workflowJob.workflowQueueConfiguration.customJobTabs.find(
      (x: WorkflowJobTabModel) => x.key === payload.key
    );
    if (workflowJobTab) {
      workflowJobTab.dynamicFormModel = payload.dynamicForm;
    }
  },
  [WorkflowJobMutationTypes.InvalidateAllDynamicForms](state) {
    state.dynamicFormValidationModels.forEach((x) => {
      x.validated = false;
    });
  }
};
