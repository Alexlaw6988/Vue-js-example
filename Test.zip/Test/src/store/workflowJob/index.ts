import { actions } from './actions';
import { getters } from './getters';
import { mutations } from './mutations';
import {
  WorkflowJobState,
  WorkflowJobModel,
  WorkflowJobTabModel,
  JobTabStateModel,
  DynamicFormValidationModel
} from '@/types';

export const state: WorkflowJobState = {
  workflowJob: {} as WorkflowJobModel,
  isLoading: true,
  isDirty: false,
  error: false,
  errorMessage: '',
  activeHorizontalTab: {} as WorkflowJobTabModel,
  activeVerticalTab: {} as WorkflowJobTabModel,
  jobTabStates: [] as JobTabStateModel[],
  extendingWorkflowJobLock: false,
  dynamicFormValidationModels: [] as DynamicFormValidationModel[],
  isAwaitingProcessing: false
};

const namespaced: boolean = true;

export const workflowJob = {
  namespaced,
  state,
  actions,
  getters,
  mutations
};
