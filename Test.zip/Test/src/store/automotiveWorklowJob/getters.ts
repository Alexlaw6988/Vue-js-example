import { AutomotiveWorkflowJobState, RootState, ManufacturerTabModel } from '@/types';
import { GetterTree } from 'vuex';

export const getters: GetterTree<AutomotiveWorkflowJobState, RootState> = {
  isManufacturerTabLoading(state): boolean {
    return state.isManufacturerTabLoading;
  },
  manufacturerTab(state): ManufacturerTabModel {
    return state.manufacturerTab;
  },
  manufacturerTabFieldValue: (state) => (dataSourceKey: string, fieldName: string): object | undefined => {
    if (state.manufacturerTab?.manufacturerDataSource?.fields) {
      return (state.manufacturerTab.manufacturerDataSource.fields as any)[fieldName];
    }
    return undefined;
  }
};
