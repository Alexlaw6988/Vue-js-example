import axios from 'axios';
import { ConfigurationModel } from '@/types';

const ConfigurationApiUrl = 'configuration';

export const ConfigurationService = {
  async getConfigurationAsync(): Promise<ConfigurationModel> {
    const response = await axios.get(`${ConfigurationApiUrl}`);
    return response.data;
  }
};
