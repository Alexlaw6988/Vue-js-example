import { RelatedDocumentsState } from '@/types/store/RelatedDocumentsState';
import { GetterTree } from 'vuex';
import {
  RootState,
  RelatedDocumentModel,
  DocumentDataModel,
  RelatedDocumentViewModel,
  RelatedDocumentsModel
} from '@/types';

function getNewestDocument(documents: DocumentDataModel[], linkId: number): RelatedDocumentViewModel | undefined {
  if (!documents || documents.length === 0) {
    return undefined;
  }
  const documentDataModel = documents
    .slice()
    .sort((a: DocumentDataModel, b: DocumentDataModel) => {
      const documentDateDiff = new Date(a.documentDate).getTime() - new Date(b.documentDate).getTime();
      if (documentDateDiff) {
        return documentDateDiff;
      }
      return a.id - b.id;
    })
    .reverse()[0];

  return {
    linkId,
    documentSearchModel: {
      documentId: documentDataModel.id,
      cabinetId: documentDataModel.cabinet.id,
      documentTypeId: documentDataModel.documentType.id
    },
    documentType: documentDataModel.documentType
  } as RelatedDocumentViewModel;
}

function getPropertyCaseInsensitive(propertyName: any, model: any): any {
  const modelKeys = Object.getOwnPropertyNames(model);
  const keyLookup = {} as any;
  modelKeys.forEach((k: string) => {
    keyLookup[k.toLowerCase()] = k;
  });
  return model[keyLookup[propertyName.toLowerCase()]];
}

export const getters: GetterTree<RelatedDocumentsState, RootState> = {
  isLoading(state): boolean {
    return state.isLoading;
  },
  totalDocumentsCount(state): number {
    return state.relatedDocumentsModel.count;
  },
  relatedDocumentsModel(state): RelatedDocumentsModel {
    return state.relatedDocumentsModel;
  },
  getRelatedDocumentByLinkId: (state) => (linkId: number): RelatedDocumentModel | undefined => {
    return state.relatedDocumentsModel.relatedDocuments.find((x: RelatedDocumentModel) => x.linkId === linkId);
  },
  getLatestRelatedDocumentByLinkId: (state) => (linkId: number): RelatedDocumentViewModel | undefined => {
    if (!state.relatedDocumentsModel.relatedDocuments) {
      return undefined;
    }
    const relatedDocument = state.relatedDocumentsModel.relatedDocuments.find(
      (x: RelatedDocumentModel) => x.linkId === linkId
    );

    return relatedDocument ? getNewestDocument(relatedDocument.documents, linkId) : undefined;
  },
  getLatestRelatedDocumentByLinkIdAndReferences: (state, getters, rootState: any, rootGetters) => (
    linkId: number,
    matchRelatedDocumentReferenceKey: string,
    matchDataSourceKey: string,
    matchDataSourceFieldKey: string,
    matchRelatedDocumentReferenceValues: { [key: string]: string }
  ): RelatedDocumentViewModel | undefined => {
    if (!state.relatedDocumentsModel.relatedDocuments) {
      return undefined;
    }

    const relatedDocuments = state.relatedDocumentsModel.relatedDocuments.find(
      (x: RelatedDocumentModel) => x.linkId === linkId
    );

    function filterOnDataSourceFieldValue(documents: DocumentDataModel[]): DocumentDataModel[] {
      if (!matchRelatedDocumentReferenceKey) {
        return documents;
      }
      const dataSourceJob = rootState.workflowJobStore.workflowJob;
      const dataSource = dataSourceJob.workflowDataSources.find(
        (x: any) => x.key.toLowerCase() === matchDataSourceKey.toLowerCase()
      ) as any;

      const dataField = getPropertyCaseInsensitive(matchDataSourceFieldKey, dataSource.fields);

      const matchingRelatedDocuments = documents.filter((x: any) =>
        x.references.some(
          (y: any) =>
            y.cabinetReferenceModel.fieldKey.toLowerCase() === matchRelatedDocumentReferenceKey &&
            String(y.value).toLowerCase() === String(dataField).toLowerCase()
        )
      ) as DocumentDataModel[];

      return matchingRelatedDocuments;
    }

    function filterOnReferenceValues(documents: DocumentDataModel[]): DocumentDataModel[] {
      if (Object.keys(matchRelatedDocumentReferenceValues).length === 0) {
        return documents;
      }

      function isReferenceValueMatch(document: any): boolean {
        for (const key in matchRelatedDocumentReferenceValues) {
          if (matchRelatedDocumentReferenceValues.hasOwnProperty(key)) {
            const matchValue = matchRelatedDocumentReferenceValues[key];
            const isMatch = document.references.some(
              (y: any) =>
                y.cabinetReferenceModel.fieldKey.toLowerCase() === key &&
                String(y.value).toLowerCase() === String(matchValue).toLowerCase()
            );
            if (!isMatch) {
              return false;
            }
          }
        }
        return true;
      }

      const matchingRelatedDocuments = documents.filter((x: any) => isReferenceValueMatch(x)) as DocumentDataModel[];

      return matchingRelatedDocuments;
    }

    if (relatedDocuments) {
      let matchingRelatedDocuments = relatedDocuments.documents;
      matchingRelatedDocuments = filterOnDataSourceFieldValue(matchingRelatedDocuments);
      matchingRelatedDocuments = filterOnReferenceValues(matchingRelatedDocuments);

      const newestMatchingRelatedDocument = matchingRelatedDocuments
        ? getNewestDocument(matchingRelatedDocuments, linkId)
        : undefined;

      return newestMatchingRelatedDocument;
    }

    return undefined;
  }
};
