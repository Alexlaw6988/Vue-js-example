import { actions } from './actions';
import { getters } from './getters';
import { mutations } from './mutations';
import { DocuSignSignerRoleManagementState, TableStateModel } from '@/types';

export function defaultDocuSignSignerRoleManagementState() {
  return {
    tableState: {
      stateKey: '',
      showFilters: false,
      currentPage: 1,
      itemsPerPage: 10,
      searchQuery: '',
      sortBy: '',
      sortDesc: false,
      selectedPk: '',
      filteredItems: []
    } as TableStateModel,
    documentTypeId: null
  } as DocuSignSignerRoleManagementState;
}

export const state: DocuSignSignerRoleManagementState = defaultDocuSignSignerRoleManagementState();

const namespaced: boolean = true;

export const docuSignSignerRoleManagement = {
  namespaced,
  state,
  actions,
  getters,
  mutations,
  defaultDocuSignSignerRoleManagementState
};
