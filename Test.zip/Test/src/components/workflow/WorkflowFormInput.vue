<template>
  <div>
    <WorkflowUnsupportedInput
      v-if="inputProperties.additionalProperties.unsupportedMessage"
      :inputProperties="inputProperties"
      :data="data"
    ></WorkflowUnsupportedInput>
    <m-store-form-input
      v-else
      :id="inputProperties.htmlElementId"
      :name="inputProperties.fieldLabel"
      :label="inputProperties.fieldLabel"
      :type="inputProperties.additionalProperties.type"
      :readonly="inputProperties.isReadonly || isDisabled"
      v-model="inputValue"
      :validation="validationRule"
      lazy-formatter
      @keypress.enter.prevent.self
      autocomplete="off"
    >
      <template slot="append" v-if="!isNullOrEmpty(actionButtonState)">
        <component
          :is="inputProperties.additionalProperties.actionButtonComponent"
          :buttonId="inputProperties.htmlElementId"
          :actionButtonState="actionButtonState"
          @actionButtonClicked="onActionButtonClicked"
          :isDisabled="isDisabled"
        ></component>
      </template>
    </m-store-form-input>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  import { WorkflowDataSourceFieldDataType, ActionButtonType, ValueType } from '@/types/enums';
  import { WorkflowFormValidation, FormFieldValidation, ObjectHelper } from '@/mixins';
  import FieldActionButton from '@/components/shared/FieldActionButton.vue';
  import FieldTooltip from '@/components/shared/FieldTooltip.vue';
  import WorkflowUnsupportedInput from '@/components/workflow/WorkflowUnsupportedInput.vue';
  import MStoreFormInput from '@/components/shared/MStoreFormInput.vue';
  import { ActionButtonHandler } from '@/mixins/actionButtonHandler';
  import { ValidationModel } from '@/types/models/validation';

  export default Vue.extend({
    name: 'WorkflowFormInput',
    mixins: [WorkflowFormValidation, FormFieldValidation, ObjectHelper, ActionButtonHandler],
    props: {
      inputProperties: {
        type: Object,
        required: true
      },
      data: {
        required: true
      },
      ignoreIsRequired: {
        type: Boolean,
        default: false
      },
      isDisabled: {
        type: Boolean,
        default: false
      }
    },
    computed: {
      inputValue: {
        get(this: any) {
          return this.data;
        },
        set(this: any, value: string) {
          if (value !== this.data?.toString() && (value || this.data)) {
            this.$emit('update:data', value);
          }
        }
      },
      validationRule(this: any): ValidationModel {
        let type = null;

        if (this.inputProperties.additionalProperties.email) {
          type = ValueType.Email;
        } else if (this.inputProperties.dataType === WorkflowDataSourceFieldDataType.Integer) {
          type = ValueType.Integer;
        } else if (this.isDoubleOrDecimal(this.inputProperties.dataType)) {
          type = ValueType.Decimal;
        }

        return {
          required: this.inputProperties.isRequired && !this.ignoreIsRequired,
          valueType: type,
          maxLength: this.inputProperties.additionalProperties.maxLength,
          minLength: this.inputProperties.additionalProperties.minLength,
          fixedLength: this.inputProperties.additionalProperties.fixedLength,
          minValue: this.inputProperties.additionalProperties.minimumValue,
          maxValue: this.inputProperties.additionalProperties.maximumValue,
          upperCase: this.inputProperties.additionalProperties.upperCase
        } as ValidationModel;
      },
      actionButtonType(this: any): ActionButtonType {
        return this.inputProperties.additionalProperties.actionButtonType
          ? (this.inputProperties.additionalProperties.actionButtonType as ActionButtonType)
          : ActionButtonType.None;
      },
      actionButtonState(this: any): any {
        if (this.actionButtonType === ActionButtonType.None) {
          return {};
        }
        const state = this.getActionButtonState(
          this.actionButtonType,
          this.inputProperties.additionalProperties.actionButtonProperties
        );
        return state;
      }
    },
    methods: {
      isDoubleOrDecimal(dataType: WorkflowDataSourceFieldDataType): boolean {
        return (
          dataType === WorkflowDataSourceFieldDataType.Decimal || dataType === WorkflowDataSourceFieldDataType.Double
        );
      },
      onActionButtonClicked(this: any) {
        this.performButtonClick(this.actionButtonType, this.actionButtonState);
      }
    },
    components: { WorkflowUnsupportedInput, FieldActionButton, FieldTooltip, MStoreFormInput }
  });
</script>
