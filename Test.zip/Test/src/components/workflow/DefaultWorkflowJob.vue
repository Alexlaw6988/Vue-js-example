<template>
  <div class="splitWrapper flex-fill w-100">
    <splitpanes watch-slots class="default-theme" @resize="onResize" @resized="onResized">
      <div
        v-if="hasVerticalJobTabs"
        :splitpanes-size="leftPaneSize"
        splitpanes-min="15"
        splitpanes-max="25"
        class="vertical-tabs overflow-y-auto"
      >
        <div @mouseover="userActivity" @touchstart="userActivity">
          <VerticalWorkflowJobTabs
            :processingAction="processingAction"
            :isLoading="isLoading || isDocumentLoadingOrBeingConverted"
          />
        </div>
      </div>
      <div
        :splitpanes-size="rightPaneSize"
        :class="`d-flex flex-column h-100 position-relative ${hasVerticalJobTabs ? 'w-100' : ''}`"
      >
        <div class="flex-1 overflow-hidden" @mouseover="userActivity" @touchstart="userActivity">
          <DocumentViewer :loadFirstPage="false" />
        </div>
        <div @mouseover="userActivity" @touchstart="userActivity">
          <HorizontalWorkflowJobTabs
            v-if="hasHorizontalJobTabs"
            :processingAction="processingAction"
            :isLoading="isLoading || isDocumentLoadingOrBeingConverted"
          />
        </div>
        <div @mouseover="userActivity" @touchstart="userActivity">
          <div title="Automatically open the next available job after processing the current job">
            <b-form-checkbox
              v-if="workflowJob.canGetNextJob"
              @input="setCanGetNextJobforCurrentQueue"
              class="float-left mt-2 ml-3 custom-switch"
              v-model="getNextJob"
            >
              <div class="mt-05">Automatically open the next job</div>
            </b-form-checkbox>
          </div>
          <WorkflowButtons
            :buttons="workflowQueueConfiguration.workflowJobButtons"
            :isLoading="isLoading"
            v-on:close-button-clicked="closeWorkflowJobAsync"
            v-on:process-button-clicked="onProcessButtonClickedAsync"
            v-on:return-button-clicked="onProcessButtonClickedAsync"
            v-on:cancel-job-button-clicked="onProcessButtonClickedAsync"
            v-on:exception-button-clicked="onProcessButtonClickedAsync"
          />
        </div>
        <WorkflowJobLock
          v-if="workflowJob.canProcess"
          @buttonClicked="expiryModalButtonClicked"
          :lastActivity="lastActivity"
        />
      </div>
    </splitpanes>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  import { mapActions, mapGetters } from 'vuex';
  import HorizontalWorkflowJobTabs from '@/components/workflow/HorizontalWorkflowJobTabs.vue';
  import VerticalWorkflowJobTabs from '@/components/workflow/VerticalWorkflowJobTabs.vue';
  import WorkflowButtons from '@/components/workflow/WorkflowButtons.vue';
  import DocumentViewer from '@/components/shared/DocumentViewer.vue';
  import {
    WorkflowJobModel,
    WorkflowJobTabType,
    WorkflowJobProcessModel,
    WorkflowJobButtonModel,
    WorkflowJobTabModel,
    DynamicFormValidationModel,
    JobTabOrientation,
    JobTabStateModel,
    WorkflowStandardProcessingAction
  } from '@/types';
  import { WorkflowJobService } from '@/services/WorkflowJobService';
  import { LockService } from '@/services/LockService';
  import Toast from '@/classes/SnotifyConfiguration';
  import WorkflowJobLock from '@/components/workflow/WorkflowJobLock.vue';
  import Splitpanes from 'splitpanes';
  import 'splitpanes/dist/splitpanes.css';
  import { Dictionary } from 'vue-router/types/router';
  import { ModalHelpers, ArrayHelper, DefaultWorkflowJob, GetNextJobs } from '@/mixins';
  import { EventBus } from '@/classes/EventBus';
  import { WorkflowJobPreference } from '@/types/store/userPreferences';
  import store from '@/store';

  export default Vue.extend({
    name: 'DefaultWorkflowJob',
    mixins: [ModalHelpers, ArrayHelper, DefaultWorkflowJob, GetNextJobs],
    data() {
      return {
        isLoading: false,
        leftPaneSize: 0,
        rightPaneSize: 0,
        lastActivity: new Date(),
        processingAction: WorkflowStandardProcessingAction.ProcessJob
      };
    },
    methods: {
      ...mapActions('workflowJobStore', [
        'setActiveHorizontalTab',
        'setActiveVerticalTab',
        'setDynamicFormValidationModel',
        'setIsAwaitingProcessing'
      ]),
      ...mapActions('userPreferencesStore', ['setJobVerticalSlider', 'setCanGetNextJob']),
      ...mapActions('workflowQueueStore', ['setNextJobsList']),
      userActivity(this: any) {
        this.lastActivity = new Date();
      }
    },
    watch: {
      awaitingProcessing(this: any, value: boolean) {
        if (value) {
          this.setIsAwaitingProcessing(false);
          this.processWorkflowJob();
        }
      },
      invalidWorkflowTabs(this: any, tabs: WorkflowJobTabModel[]) {
        if (tabs.length > 0) {
          this.isLoading = false;
          const firstInvalidHorizontalTab = tabs.find(
            (x: WorkflowJobTabModel) => x.jobTabOrientation === JobTabOrientation.Horizontal
          );
          if (firstInvalidHorizontalTab && this.activeHorizontalTab.key !== firstInvalidHorizontalTab.key) {
            this.setActiveHorizontalTab(firstInvalidHorizontalTab.key);
          }
          const firstInvalidVerticalTab = tabs.find(
            (x: WorkflowJobTabModel) => x.jobTabOrientation === JobTabOrientation.Vertical
          );
          if (firstInvalidVerticalTab && this.activeVerticalTab.key !== firstInvalidVerticalTab.key) {
            this.setActiveVerticalTab(firstInvalidVerticalTab.key);
          }
        }
        this.setFocusOnInvalidField();
      }
    },
    created(this: any) {
      this.initializePaneSize();
      this.initializeCanGetNextJob();
      this.initializeTheTabs();
      EventBus.$on('dynamic-form-validated', (dynamicFormValidationModel: DynamicFormValidationModel) => {
        this.setDynamicFormValidationModel(dynamicFormValidationModel);
      });
    },
    beforeDestroy() {
      EventBus.$off('dynamic-form-validated');
    },
    computed: {
      ...mapGetters('workflowJobStore', [
        'workflowJob',
        'isDirty',
        'workflowQueueConfiguration',
        'hasHorizontalWorkflowJobTabs',
        'hasVerticalWorkflowJobTabs',
        'workflowJobTabsByOrientation',
        'hasWorkflowTabs',
        'activeHorizontalTab',
        'activeVerticalTab',
        'allJobTabsByOrientation',
        'hasHorizontalJobTabs',
        'hasVerticalJobTabs',
        'dirtyJobTabStates',
        'dirtyHorizontalJobTabStates',
        'dirtyVerticalJobTabStates',
        'invalidWorkflowTabs',
        'validWorkflowTabs',
        'workflowJobTabs',
        'visibleWorkflowJobTabs',
        'hasVisibleWorkflowTabs',
        'visibleCustomJobTabsThatNeedValidating',
        'dynamicFormValidationModel',
        'allTabsValid',
        'isAwaitingProcessing',
        'isWorkFlowJobDirty'
      ]),
      ...mapGetters('userPreferencesStore', ['getWorkflowJobPreferences']),
      ...mapGetters('workflowQueueStore', ['getNextJobsLists', 'getTableStateField']),
      awaitingProcessing(this: any) {
        if (this.allTabsValid && this.isAwaitingProcessing) {
          return true;
        }
        return false;
      },
      isDocumentLoadingOrBeingConverted(this: any) {
        return (
          store.getters['documentViewStore/document'].isBeingConverted ||
          store.getters['documentViewStore/isPageLoading']
        );
      }
    },
    components: {
      HorizontalWorkflowJobTabs,
      VerticalWorkflowJobTabs,
      DocumentViewer,
      WorkflowButtons,
      WorkflowJobLock,
      Splitpanes
    }
  });
</script>
