declare module 'vee-validate';
