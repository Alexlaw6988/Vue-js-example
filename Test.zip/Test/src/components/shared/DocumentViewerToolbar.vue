<template>
  <div id="m-documentviewertoolbar" class="bg-light-gray border-bottom">
    <div class="form-inline ml-1">
      <b-dropdown
        v-if="!isIpad()"
        :disabled="isPageLoading || !this.totalPages"
        variant="primary"
        size="sm"
        class="icon-reorder mr-2"
        title="Actions"
      >
        <template slot="button-content">
          <font-awesome-icon icon="bars" class="mr-2" />
        </template>
        <div id="exportButton">
          <b-dropdown-item-button
            v-if="!isIpad()"
            @click="exportDocument"
            :disabled="!documentActions.export || exportPending"
            title="Export"
          >
            <font-awesome-icon :hidden="!exportPending" size="sm" class="mr-2" icon="spinner" spin />
            <font-awesome-icon icon="download" class="mr-2" />
            Export
          </b-dropdown-item-button>
        </div>
        <b-tooltip target="exportButton" :disabled="documentActions.export" placement="right">
          You don't have permission to export documents of this file type
        </b-tooltip>
      </b-dropdown>
      <button
        v-show="toolOptions.allowPageNavigation"
        @click="firstPage"
        :disabled="this.currentPage === 1 || isPageLoading"
        class="btn btn-primary btn-sm mr-2 mt-1 mb-1 ml-4 button-document-viewer-toolbar"
        title="First Page"
        data-testid="first-page-button"
      >
        <font-awesome-icon icon="step-backward" />
      </button>
      <b-button
        v-show="toolOptions.allowPageNavigation"
        v-on-longPress="skipPreviousPages"
        :disabled="this.currentPage === 1 || isPageLoading"
        class="btn btn-primary btn-sm mr-2 mt-1 mb-1"
        title="Previous Page"
        :variant="this.skippingPreviousPages ? 'dark' : 'primary'"
        data-testid="previous-page-button"
      >
        <font-awesome-icon icon="arrow-left" />
      </b-button>
      <b-input-group :append="totalPagesAppendText" size="sm" class="mr-2 mt-1 mb-1">
        <b-form-input
          autocomplete="off"
          v-model="gotoPageNumber"
          type="text"
          size="sm"
          class="gotoPageInput"
          :readonly="isPageLoading || !toolOptions.allowPageNavigation"
          @keypress.enter="navigateToPage"
          @blur="gotoPageNumber = currentPage"
          @keydown="validatePageNumber"
          data-testid="goto-page-input"
        />
      </b-input-group>
      <b-button
        v-show="toolOptions.allowPageNavigation"
        v-on-longPress="skipNextPages"
        :disabled="this.currentPage === totalPages || isPageLoading || !this.totalPages"
        class="btn btn-primary btn-sm mr-2 mt-1 mb-1"
        title="Next Page"
        :variant="this.skippingNextPages ? 'dark' : 'primary'"
        data-testid="next-page-button"
      >
        <font-awesome-icon icon="arrow-right" />
      </b-button>
      <button
        v-show="toolOptions.allowPageNavigation"
        @click="lastPage"
        :disabled="this.currentPage === totalPages || isPageLoading || !this.totalPages"
        mt-2
        class="btn btn-primary btn-sm mt-1 mb-1 mr-2 button-document-viewer-toolbar"
        title="Last Page"
        data-testid="last-page-button"
      >
        <font-awesome-icon icon="step-forward" />
      </button>
      <button
        @click="rotateAntiClockwise"
        :disabled="isPageLoading || !this.totalPages"
        mt-2
        class="btn btn-primary btn-sm mt-1 mb-1 ml-4 mr-2 button-document-viewer-toolbar"
        title="Rotate Left (Anti Clockwise)"
      >
        <font-awesome-icon icon="undo-alt" />
      </button>
      <button
        @click="rotateClockwise"
        :disabled="isPageLoading || !this.totalPages"
        mt-2
        class="btn btn-primary btn-sm mt-1 mb-1 mr-2 button-document-viewer-toolbar"
        title="Rotate Right (Clockwise)"
      >
        <font-awesome-icon icon="redo-alt" />
      </button>
      <button
        @click="zoomIn"
        :disabled="isMaxScale || isPageLoading || !this.totalPages"
        mt-2
        class="btn btn-primary btn-sm mt-1 mb-1 ml-4 mr-2 button-document-viewer-toolbar"
        title="Zoom In"
      >
        <font-awesome-icon icon="plus-circle" />
      </button>
      <button
        @click="zoomOut"
        :disabled="isMinScale || isPageLoading || !this.totalPages"
        mt-2
        class="btn btn-primary btn-sm mt-1 mb-1 mr-2 button-document-viewer-toolbar"
        title="Zoom Out"
      >
        <font-awesome-icon icon="minus-circle" />
      </button>
      <button
        @click="fitHeight"
        :disabled="isPageLoading || !this.totalPages"
        mt-2
        :class="
          `btn btn-primary btn-sm mt-1 mb-1 mr-2 button-document-viewer-toolbar ${
            this.activeScaleOption === 3 ? 'active' : ''
          }`
        "
        title="Fit To Height"
      >
        <font-awesome-icon icon="arrows-alt-v" />
      </button>
      <button
        @click="fitWidth"
        :disabled="isPageLoading || !this.totalPages"
        mt-2
        :class="
          `btn btn-primary btn-sm mt-1 mb-1 mr-2 button-document-viewer-toolbar ${
            this.activeScaleOption === 2 ? 'active' : ''
          }`
        "
        title="Fit To Width"
      >
        <font-awesome-icon icon="arrows-alt-h" />
      </button>
      <button
        @click="fitWithin"
        :disabled="isPageLoading || !this.totalPages"
        mt-2
        :class="
          `btn btn-primary btn-sm mt-1 mb-1 mr-2 button-document-viewer-toolbar ${
            this.activeScaleOption === 1 ? 'active' : ''
          }`
        "
        title="Fit Within"
      >
        <font-awesome-icon icon="expand-arrows-alt" />
      </button>
      <label>{{ scalePercentageLabel }}</label>
      <h6 v-if="showVersionNumber" class="ml-3">
        <b-badge>Version {{ versionBeingViewed.number }}</b-badge>
      </h6>
      <h6 v-if="showRelatedDocumentInfo" class="ml-3">
        <b-badge>
          Related Document -
          {{ relatedDocumentBeingViewed.documentType.description }}
        </b-badge>
      </h6>
    </div>
    <slot name="after-toolbar"></slot>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  import { mapActions, mapGetters } from 'vuex';
  import {
    DocumentActionsModel,
    DocumentViewerScaleType,
    DocumentVersionType,
    KeyboardKeyCode,
    DocumentViewerToolbarOptionsModel
  } from '@/types';
  import { DocumentService } from '@/services/DocumentService';
  import { DeviceHelper } from '@/mixins/deviceHelper';
  import { LongPressEventType } from '@/types/enums/LongPressEventType';

  export default Vue.extend({
    name: 'DocumentViewerToolbar',
    mixins: [DeviceHelper],
    props: {
      totalPages: {
        type: Number,
        required: true
      },
      imageProperties: {
        type: Object,
        required: true
      },
      imageLoaded: {
        type: String,
        required: true
      },
      documentActions: {
        type: Object as () => DocumentActionsModel,
        required: true
      },
      exportPending: {
        type: Boolean,
        required: true
      },
      toolOptions: {
        type: Object as () => DocumentViewerToolbarOptionsModel,
        required: true
      }
    },
    data() {
      return {
        scales: [0.12, 0.25, 0.37, 0.5, 0.62, 0.75, 0.87, 1, 1.25, 1.5, 1.75, 2, 2.5, 3, 3.5, 4, 4.5, 5],
        scale: 0,
        activeScaleOption: DocumentViewerScaleType.None as DocumentViewerScaleType,
        gotoPageNumber: 1,
        skipToPage: null,
        skipPagesIntervalId: null,
        skippingNextPages: false,
        skippingPreviousPages: false,
        skipPagesDelay: 170
      };
    },
    methods: {
      ...mapActions('documentViewStore', ['loadPage']),
      previousPage(this: any) {
        clearInterval(this.skipPagesIntervalId);
        this.skippingPreviousPages = false;
        if (this.currentPage === 1) {
          return;
        }
        if (this.skipToPage) {
          this.getPage(this.skipToPage);
          this.skipToPage = null;
          return;
        }
        this.getPage(this.currentPage - 1);
      },
      nextPage(this: any) {
        clearInterval(this.skipPagesIntervalId);
        this.skippingNextPages = false;
        if (this.currentPage === this.totalPages) {
          return;
        }
        if (this.skipToPage) {
          this.getPage(this.skipToPage);
          this.skipToPage = null;
          return;
        }
        this.getPage(this.currentPage + 1);
      },
      firstPage(this: any) {
        this.getPage(1);
      },
      lastPage(this: any) {
        this.getPage(this.totalPages);
      },
      navigateToPage(this: any) {
        this.gotoPageNumber = this.validateGotoPageNumber(this.gotoPageNumber);
      },
      validateGotoPageNumber(this: any, gotoPage: any, event: any) {
        if (isNaN(gotoPage)) {
          return this.currentPage;
        }
        const gotoPageNumber = Math.floor(Number(gotoPage));
        if (gotoPageNumber < 1 || gotoPageNumber > this.totalPages || this.currentPage === gotoPageNumber) {
          return this.currentPage;
        }
        this.getPage(gotoPageNumber);

        return gotoPageNumber;
      },
      getPage(this: any, pageNumber: number) {
        this.loadPage(pageNumber);
      },
      zoomIn() {
        if (this.isMaxScale) {
          return;
        }
        this.setActiveScaleOption(DocumentViewerScaleType.ZoomIn);
        this.scale = this.getValidScale(this.nextScaleUp);
        this.setimageProperties();
      },
      zoomOut() {
        if (this.isMinScale) {
          return;
        }
        this.setActiveScaleOption(DocumentViewerScaleType.ZoomOut);
        this.scale = this.getValidScale(this.nextScaleDown);
        this.setimageProperties();
      },
      fitWidth() {
        this.setActiveScaleOption(DocumentViewerScaleType.FitWidth);
        this.scale = this.widthScale;
        this.setimageProperties();
      },
      fitHeight() {
        this.setActiveScaleOption(DocumentViewerScaleType.FitHeight);
        this.scale = this.heightScale;
        this.setimageProperties();
      },
      fitWithin() {
        this.setActiveScaleOption(DocumentViewerScaleType.FitWithin);
        if (this.widthScale > this.heightScale) {
          this.scale = this.heightScale;
        } else {
          this.scale = this.widthScale;
        }
        this.setimageProperties();
      },
      maximiseWidthWhilstStillSeeingTwoThirdsOfDocument() {
        this.setActiveScaleOption(DocumentViewerScaleType.None);

        const originalImageWidthToHeightRatio =
          this.imageProperties.originalWidth / this.imageProperties.originalHeight;

        const imageHeightIfFitWidth = this.imageProperties.containerWidth / originalImageWidthToHeightRatio;

        const twoThirdsOriginalImageHeight = (this.imageProperties.originalHeight * 2) / 3;

        if ((imageHeightIfFitWidth * 2) / 3 < this.imageProperties.containerHeight) {
          this.fitWidth();
          this.callDocumentViewerScaleMethod();
        } else {
          this.scale = this.getValidScale(this.imageProperties.containerHeight / twoThirdsOriginalImageHeight);
          this.setimageProperties();
        }
      },
      maximiseHeightWhilstStillSeeingTwoThirdsOfDocument() {
        this.setActiveScaleOption(DocumentViewerScaleType.None);

        const originalImageHeightToWidthRatio =
          this.imageProperties.originalHeight / this.imageProperties.originalWidth;

        const imageWidthIfFitHeight = this.imageProperties.containerHeight / originalImageHeightToWidthRatio;

        const twoThirdsOriginalImageWidth = (this.imageProperties.originalWidth * 2) / 3;

        if ((imageWidthIfFitHeight * 2) / 3 < this.imageProperties.containerWidth) {
          this.fitHeight();
        } else {
          this.scale = this.getValidScale(this.imageProperties.containerWidth / twoThirdsOriginalImageWidth);
          this.setimageProperties();
        }
      },
      rotateClockwise() {
        const degrees = (this.imageProperties.rotationDegrees + 90) % 360;
        this.imageProperties.rotationDegrees = degrees;
        this.callDocumentViewerScaleMethod();
      },
      rotateAntiClockwise() {
        const degrees = (this.imageProperties.rotationDegrees + 270) % 360;
        this.imageProperties.rotationDegrees = degrees;
        this.callDocumentViewerScaleMethod();
      },
      setActiveScaleOption(scaleOption: DocumentViewerScaleType) {
        this.activeScaleOption = scaleOption;
      },
      getValidScale(scale: number): number {
        if (scale < this.minScale) {
          return this.minScale;
        } else if (scale > this.maxScale) {
          return this.maxScale;
        } else {
          return scale;
        }
      },
      setimageProperties() {
        this.imageProperties.width = this.imageProperties.originalWidth * this.scale;
        this.imageProperties.height = this.imageProperties.originalHeight * this.scale;
        this.imageProperties.marginTop = this.marginTop;
        this.imageProperties.marginBottom = this.marginBottom;
        this.imageProperties.marginLeft = this.marginLeft;
        this.imageProperties.marginRight = this.marginRight;
        this.$emit('update:imageProperties', this.imageProperties);
      },
      callDocumentViewerScaleMethod() {
        switch (this.activeScaleOption) {
          case DocumentViewerScaleType.FitWithin:
            this.fitWithin();
            break;
          case DocumentViewerScaleType.FitWidth:
            this.fitWidth();
            break;
          case DocumentViewerScaleType.FitHeight:
            this.fitHeight();
            break;
          case DocumentViewerScaleType.ZoomIn:
          case DocumentViewerScaleType.ZoomOut:
            this.setimageProperties();
            break;
          case DocumentViewerScaleType.None:
          default:
            this.setInitialScale();
            break;
        }
      },
      exportDocument() {
        this.$emit('exportDocument');
      },
      validatePageNumber(this: any, event: any) {
        if (KeyboardKeyCode[event.keyCode]) {
          return;
        }

        const isTextSelected = window.getSelection();

        const newPageNumber = Number(isTextSelected?.type === 'Range' ? event.key : this.gotoPageNumber + event.key);
        if (
          Number.isNaN(newPageNumber) ||
          newPageNumber > this.totalPages ||
          newPageNumber < 1 ||
          newPageNumber?.toString()?.length > this.totalPages?.toString()?.length
        ) {
          event.preventDefault();
        }
      },
      skipNextPages(this: any, eventType: LongPressEventType) {
        if (eventType === LongPressEventType.Click || eventType === LongPressEventType.Release) {
          this.nextPage();
          return;
        }
        this.skippingNextPages = true;
        this.skipToPage = this.currentPage;
        const skipPages = (self: any) => {
          if (self.skipToPage < self.totalPages) {
            self.skipToPage = self.skipToPage + 1;
            self.gotoPageNumber = self.skipToPage;
          }
        };
        this.skipPagesIntervalId = setInterval(() => skipPages(this), this.skipPagesDelay);
      },
      skipPreviousPages(this: any, eventType: LongPressEventType) {
        if (eventType === LongPressEventType.Click || eventType === LongPressEventType.Release) {
          this.previousPage();
          return;
        }
        this.skippingPreviousPages = true;
        this.skipToPage = this.currentPage;
        const skipPages = (self: any) => {
          if (self.skipToPage > 1) {
            self.skipToPage = self.skipToPage - 1;
            self.gotoPageNumber = self.skipToPage;
          }
        };
        this.skipPagesIntervalId = setInterval(() => skipPages(this), this.skipPagesDelay);
      },
      setInitialScale() {
        if (this.imageProperties.originalHeight > this.imageProperties.originalWidth) {
          if (this.imageProperties.originalHeight < this.imageProperties.containerHeight) {
            this.fitHeight();
          } else {
            this.maximiseWidthWhilstStillSeeingTwoThirdsOfDocument();
          }
        } else {
          if (
            this.imageProperties.originalWidth < this.imageProperties.containerWidth &&
            this.imageProperties.containerHeight > this.imageProperties.containerWidth
          ) {
            this.fitWidth();
          } else {
            this.maximiseHeightWhilstStillSeeingTwoThirdsOfDocument();
          }
        }
      }
    },
    computed: {
      ...mapGetters('documentViewStore', [
        'currentPage',
        'isPageLoading',
        'versionBeingViewed',
        'relatedDocumentBeingViewed'
      ]),
      totalPagesAppendText(): string {
        return `of ${this.totalPages > 0 ? this.totalPages : '?'}`;
      },
      scalePercentage(this: any): number {
        return Math.floor(this.scale * 100);
      },
      scalePercentageLabel(): string {
        return this.scalePercentage === 0 ? '' : `${this.scalePercentage}%`;
      },
      widthScale(): number {
        const value =
          this.imageProperties.rotationDegrees % 180 === 0
            ? this.imageProperties.originalWidth
            : this.imageProperties.originalHeight;
        return this.getValidScale(this.imageProperties.containerWidth / value);
      },
      heightScale(): number {
        const value =
          this.imageProperties.rotationDegrees % 180 === 0
            ? this.imageProperties.originalHeight
            : this.imageProperties.originalWidth;
        return this.getValidScale(this.imageProperties.containerHeight / value);
      },
      nextScaleUp(): number {
        for (let i = 0; i < this.scales.length - 1; i++) {
          if (this.scale >= this.scales[i] && this.scale < this.scales[i + 1]) {
            return this.scales[i + 1];
          }
        }
        return this.maxScale;
      },
      nextScaleDown(): number {
        for (let i = 0; i < this.scales.length - 1; i++) {
          if (this.scale <= this.scales[i + 1] && this.scale > this.scales[i]) {
            return this.scales[i];
          }
        }
        return this.minScale;
      },
      maxScale(): number {
        return this.scales[this.scales.length - 1];
      },
      minScale(): number {
        return this.scales[0];
      },
      isMaxScale(): boolean {
        if (this.scale >= this.maxScale) {
          return true;
        }
        return false;
      },
      isMinScale(): boolean {
        if (this.scale <= this.minScale) {
          return true;
        }
        return false;
      },
      marginTop(): number {
        return -(this.imageProperties.rotationDegrees % 180 === 0
          ? 0
          : (this.imageProperties.height - this.imageProperties.width) / 2);
      },
      marginBottom(): number {
        return -(this.imageProperties.rotationDegrees % 180 === 0
          ? 0
          : (this.imageProperties.height - this.imageProperties.width) / 2);
      },
      marginLeft(): number {
        return -(this.imageProperties.rotationDegrees % 180 === 0
          ? 0
          : (this.imageProperties.width - this.imageProperties.height) / 2);
      },
      marginRight(): number {
        return -(this.imageProperties.rotationDegrees % 180 === 0
          ? 0
          : (this.imageProperties.width - this.imageProperties.height) / 2);
      },
      showVersionNumber(this: any): boolean {
        return this.versionBeingViewed.number && this.versionBeingViewed.type !== DocumentVersionType.Current;
      },
      showRelatedDocumentInfo(this: any): boolean {
        return this.relatedDocumentBeingViewed.documentSearchModel;
      }
    },
    watch: {
      imageProperties: {
        deep: true,
        handler() {
          this.callDocumentViewerScaleMethod();
        }
      },
      imageLoaded() {
        this.setInitialScale();
        this.gotoPageNumber = this.currentPage;
      },
      currentPage(this: any) {
        this.gotoPageNumber = this.currentPage;
      }
    },
    destroyed(this: any) {
      if (this.skipPagesIntervalId) {
        clearInterval(this.skipPagesIntervalId);
      }
    }
  });
</script>
