export interface DocuSignTestResponseModel {
  isError: boolean;
  responseMessage: string;
  userMessage: string;
}
