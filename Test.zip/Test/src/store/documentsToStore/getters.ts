import { RootState, DocumentsToStoreState } from '@/types';
import { GetterTree } from 'vuex';

export const getters: GetterTree<DocumentsToStoreState, RootState> = {
  cabinetId(state) {
    return state.cabinetId;
  },
  documentId(state) {
    return state.documentId;
  },
  pagesToIndex(state) {
    return state.pagesToIndex;
  },
  thumbnails(state) {
    return state.thumbnails;
  },
  error(state) {
    return state.error;
  },
  errorMessage(state) {
    return state.errorMessage;
  },
  isLoading(state) {
    return state.isLoading;
  },
  showNoDocumentNotification(state) {
    return state.showNoDocumentNotification;
  }
};