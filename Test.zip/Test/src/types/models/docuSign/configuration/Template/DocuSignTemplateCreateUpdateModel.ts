export interface DocuSignTemplateCreateUpdateModel {
    documentTypeId: number;
    template: string;
}