<template>
  <ValidationProvider :rules="veeValidateRule" :name="fieldLabel" ref="ValidationProvider" slim>
    <m-form-group
      v-on-event:blur="closeList"
      v-on-event:keydown.Esc="onEscape"
      v-on-event:keydown.Up.Down="onArrowKey"
      :label="fieldLabel"
      :labelFor="elementId"
      :isRequired="validation.required"
      slot-scope="{ flags, errors }"
    >
      <b-input-group :id="fieldId">
        <b-form-input
          ref="mstoreSelectTableInput"
          :id="elementId"
          :name="fieldLabel"
          :readonly="isFilterDisabledOrReadOnly"
          :state="getInputState(flags, errors)"
          v-model="filter"
          lazy-formatter
          v-debounce:600="filterList"
          @focus="onfilterFocus"
          :class="isFilterDisabledAndNotReadOnly ? 'mstore-form-lookup-filter-disabled' : ''"
          @keydown.enter.prevent.self="onEnter()"
        />

        <b-input-group-append>
          <b-button
            ref="mstoreSelectTableButton"
            variant="primary"
            class="mstore-form-select-button"
            :disabled="isReadonly || isLoading"
            :id="`mstoreSelectTableButton-${elementId}`"
            @click="onFilterButtonClicked"
            @mousedown="onMStoreSelectTableButtonClick($event)"
          >
            <font-awesome-icon :icon="mstoreSelectTableButtonIcon" :spin="isLoading" />
          </b-button>
          <component
            :id="`actionButtonComponent-${elementId}`"
            :is="actionButtonComponentName"
            v-if="!isNullOrEmpty(actionButtonState)"
            :buttonId="fieldId"
            :actionButtonState="actionButtonState"
            @actionButtonClicked="onActionButtonClicked"
            :isDisabled="isActionButtonDisabled"
          ></component>
        </b-input-group-append>
      </b-input-group>
      <div
        tabindex="-1"
        v-show="tableOpen"
        ref="mstoreSelectTableDiv"
        :id="`mstoreSelectTableDiv-${elementId}`"
        :class="
          `table-dropdown-container table-box-shadow w-400 ${tableOpen && (listDataEmpty || isLoading) ? 'w-100' : ''}`
        "
      >
        <b-table
          ref="mstoreSelectTable"
          :class="`table table-sm table-bordered mb-0 ${listDataEmpty ? '' : 'table-hover'}`"
          small
          bordered
          show-empty
          :sticky-header="stickyHeaderHeight"
          :items="listData"
          :fields="listHeaders"
          @row-clicked="onRowClicked"
          @head-clicked="onHeadClicked"
          hover
          :busy="isLoading"
          :id="`mstoreSelectTable-${elementId}`"
          primary-key="index"
        >
          <template v-for="header in listHeaders" v-slot:[getSlotName(header)]>{{ header.title }}</template>
          <template slot="empty">
            <LoadingSpinner class="p-3" v-if="isLoading" :isLoading="isLoading" cssPositioning="unset" />
            <div v-else>{{ listResultMessage }}</div>
          </template>
        </b-table>
      </div>
      <b-form-invalid-feedback :state="getInputState(flags, errors)">{{ errors[0] }}</b-form-invalid-feedback>
    </m-form-group>
  </ValidationProvider>
</template>

<script lang="ts">
  import Vue from 'vue';
  import { mapActions, mapGetters } from 'vuex';
  import { WorkflowDataSourceFieldDataType } from '@/types/enums';
  import { FormFieldValidation, ObjectHelper, FormSelectHelper } from '@/mixins';
  import { ListService } from '@/services/ListService';
  import { ListModel, ListDataResultType, FilteredListModel, ListHeaderModel, KeyboardKeyCode } from '@/types';
  import FieldActionButton from '@/components/shared/FieldActionButton.vue';
  import FieldTooltip from '@/components/shared/FieldTooltip.vue';
  import LoadingSpinner from '@/components/shared/LoadingSpinner.vue';
  import { ValidationModel } from '@/types/models/validation';

  export default Vue.extend({
    name: 'm-form-lookup',
    mixins: [FormFieldValidation, ObjectHelper, FormSelectHelper],
    props: {
      data: {
        required: true
      },
      actionButtonState: {
        type: Object,
        required: false
      },
      fieldId: {
        type: String,
        required: true
      },
      fieldLabel: {
        type: String,
        required: true
      },
      isReadonly: {
        type: Boolean,
        required: true
      },
      formId: {
        type: String,
        required: true
      },
      actionButtonComponentName: {
        type: String,
        required: true
      },
      listId: {
        type: Number,
        required: true
      },
      hasInitialList: {
        type: Boolean,
        required: true
      },
      filterDisabled: {
        type: Boolean,
        default: false
      },
      isActionButtonDisabled: {
        type: Boolean,
        default: false
      },
      validation: {
        type: Object as () => ValidationModel,
        required: true
      }
    },
    data() {
      return {
        isLoading: false,
        filter: this.data,
        lastSelectedValue: this.data,
        lastFilterValue: null,
        listModel: {} as ListModel
      };
    },
    computed: {
      ...mapGetters('listStore', {
        listById: 'listById',
        listStoreLoading: 'isLoading'
      }),
      listDataEmpty(this: any): boolean {
        return !this.listData || this.listData.length === 0;
      },
      inputValue: {
        get(this: any) {
          return this.data;
        },
        set(this: any, value: string) {
          const flags = this.$refs.ValidationProvider.flags;
          this.$refs.ValidationProvider.setFlags({ ...flags, dirty: true });
          this.$emit('update:data', value);
        }
      },
      listResultMessage(): string {
        return this.listModel &&
          (this.listModel.resultType === ListDataResultType.NoRecords ||
            this.listModel.resultType === ListDataResultType.ManyRecords)
          ? this.listModel.listDataResultTypeMessage
          : 'Start typing to filter out list items.';
      },
      isLoadingbyId(this: any): boolean {
        return this.listById(this.listId) === undefined;
      },
      primaryKey(this: any) {
        if (this.listModel) {
          return this.listModel.key;
        }
      }
    },
    methods: {
      ...mapActions('listStore', ['loadList']),
      async getList(this: any, searchText: string) {
        this.clearListModel();
        if (this.isFilterDisabledOrReadOnly) {
          this.isLoading = this.isLoadingbyId;
          this.loadList(this.listId);
          this.listModel = this.listById(this.listId);
        } else {
          this.isLoading = true;
          try {
            this.listModel = await ListService.getListAsync(this.listId, searchText, false);
          } catch (error) {
            this.$log(error);
          } finally {
            this.isLoading = false;
            if (this.tableOpen) {
              this.initPopper();
            }
          }
        }
        this.setSelectedRowOnNextTick();
        this.lastFilterValue = searchText;
      },
      async loadListModel(this: any) {
        if (this.filter && !this.filterDisabled) {
          await this.getList(this.filter);
        } else {
          await this.getList('');
        }
      },
      async onFilterButtonClicked(this: any) {
        if (this.tableOpen) {
          this.closeListAndRetainlastSelectedValue();
        } else {
          this.inputValue ? this.clearInputValue() : await this.openTable();
          this.setFocusOnNextTick(this.$refs.mstoreSelectTableButton);
        }
      },
      async openTable(this: any) {
        await this.loadListModel();
        this.tableOpen = true;
        this.initPopper();
        this.setSelectedRowOnNextTick();
      },
      clearInputValue(this: any) {
        this.inputValue = '';
        this.filter = '';
        this.lastSelectedValue = '';
        this.validate();
      },
      clearListModel() {
        this.listModel = {} as ListModel;
      },
      filterList(filterValue: any, event: any) {
        const preventKeys = [
          KeyboardKeyCode.Esc,
          KeyboardKeyCode.Up,
          KeyboardKeyCode.Down,
          KeyboardKeyCode.Enter,
          KeyboardKeyCode.Tab
        ];
        if (preventKeys.indexOf(event.keyCode) === -1) {
          this.getList(filterValue);
        }
      },
      onEnter(this: any) {
        if (this.totalRows() === 1) {
          this.onRowClicked(this.filteredItems?.[0] || this.listModel.list[0]);
        }
      },
      onfilterFocus(this: any) {
        if (!this.isReadonly && !this.isLoading && !this.tableOpen) {
          this.openTable();
        }
      },
      onRowClicked(this: any, item: any) {
        this.inputValue = item[this.primaryKey];
        this.$emit('row-selected', item);
        this.filter = item[this.primaryKey];
        this.lastSelectedValue = item[this.primaryKey];
        this.closeTable();
        this.setFocusOnNextTick(this.$refs.mstoreSelectTableButton);
        this.validate();
      },
      initialise(this: any) {
        if (this.filterDisabled || (this.hasInitialList && !this.isReadonly)) {
          this.getList('');
        }
      }
    },
    watch: {
      isLoadingbyId(value: boolean) {
        this.isLoading = value;
      }
    },
    mounted() {
      this.initialise();
    },
    components: {
      FieldActionButton,
      FieldTooltip,
      LoadingSpinner
    }
  });
</script>
