<template>
  <div id="app" v-if="hasAccess">
    <BaseLayout :isAuthenticated="oidcIsAuthenticated">
      <component :is="layout">
        <router-view :key="$route.fullPath" />
      </component>
    </BaseLayout>
    <vue-snotify></vue-snotify>
    <ExpiryModal
      :showModal="showAppIdleModal"
      @extend="extendSession"
      @expired="signOut"
      title="You are about to be logged out due to inactivity"
      caption="You will be logged out in"
      instruction="Click extend to stay logged in"
      extendButtonIcon="user"
      :expirySecondsLeft="expirySecondsLeft"
    ></ExpiryModal>
    <mstore-modal />
  </div>
</template>

<script lang="ts">
  import { Vue } from 'vue-property-decorator';
  import { UserService } from './services/UserService';
  import AxiosConfiguration from '@/classes/AxiosConfiguration';
  import SnotifyConfiguration from '@/classes/SnotifyConfiguration';
  import ExpiryModal from '@/components/shared/ExpiryModal.vue';
  import BaseLayout from '@/layouts/BaseLayout.vue';
  import { mapGetters, mapActions } from 'vuex';
  import { MStoreConstants } from '@/types';
  import axios from 'axios';
  import moment from 'moment';
  import { MStorePopup, Feedback } from '@/components/shared';
  import { ModalHelpers } from '@/mixins';
  import { LocalStorage, Fullscreen } from '@/utils';
  moment.locale('en-gb');

  const defaultlayout = 'Default';
  const localStorageKeys = MStoreConstants.LocalStorageKeys;
  export default Vue.extend({
    mixins: [ModalHelpers],
    data(this: any) {
      return {
        isAppIdleModalShown: false,
        waitForPostSignInIdleTime: true,
        nowIntervalId: 0,
        now: moment(),
        keepAliveInclude: '',
        appIdleTimeout: moment(),
        localStorageKeys: MStoreConstants.LocalStorageKeys
      };
    },
    computed: {
      ...mapGetters('oidcStore', ['oidcIsAuthenticated', 'oidcAccessToken']),
      ...mapGetters('userStore', ['postSignInIdleTime']),
      ...mapGetters('applicationDirtyStore', [
        'isApplicationDirty',
        'isApplicationDirtyOnAnotherTab',
        'showApplicationDirtyModal',
        'applicationDirtyRouteNavigatedTo'
      ]),
      ...mapGetters('workflowQueueStore', ['getLastSelectedWorkflowQueue']),
      hasAccess(this: any) {
        return this.oidcIsAuthenticated || this.$route.meta.isPublic;
      },
      layout(this: any) {
        return (this.$route.meta.layout || defaultlayout) + 'Layout';
      },
      showAppIdleModal(this: any) {
        return this.isAppIdleModalShown && !this.waitForPostSignInIdleTime;
      },
      expirySecondsLeft(this: any) {
        const expiryDate = moment(this.appIdleTimeout);
        const diff = expiryDate.diff(this.now);
        return Math.ceil(diff / 1000);
      },
      lastSelectedQueueId(this: any) {
        return this.getLastSelectedWorkflowQueue;
      },
      isActiveTab() {
        return !document.hidden;
      }
    },
    methods: {
      ...mapActions('oidcStore', ['signOutOidc', 'removeOidcUser']),
      ...mapActions('userStore', ['clearPostSignInIdleTime', 'currentUserAuthenticated']),
      ...mapActions('workflowQueueStore', ['setLastSelectedWorkflowQueue']),
      ...mapActions('applicationDirtyStore', [
        'setShowApplicationDirtyModal',
        'setApplicationDirty',
        'setApplicationDirtyOnAnotherTab'
      ]),
      setNowToNow() {
        this.now = moment();
      },
      signOut(this: any) {
        this.setApplicationDirty(false);
        UserService.disableWindowsAutoLogInForCurrentUserAsync().then(() => {
          this.signOutOidc();
        });
      },
      beforeUnloadApplication(this: any, event: any) {
        if (this.isApplicationDirty && !this.isAppIdle) {
          event.returnValue = '';
        } else {
          LocalStorage.remove(localStorageKeys.IsApplicationDirty);
        }
      },
      extendSession(this: any, event: any) {
        if (!document.hidden && this.isAppIdle && !Fullscreen.isFullscreen()) {
          this.isAppIdleModalShown = false;
          return;
        }
        this.$store.commit('idleStore/IDLE_CHANGED', false);
        this.isAppIdleModalShown = false;
        if (!document.hidden) {
          this.notifyOtherTabs(localStorageKeys.IsAppIdleExtended, event);
        }
      },
      showIdleTimeOut(this: any, event: any) {
        if (!document.hidden && (!this.isAppIdle || Fullscreen.isFullscreen())) {
          return this.extendSession();
        }
        if (!this.isAppIdleModalShown) {
          this.isAppIdleModalShown = true;
          this.appIdleTimeout = moment().add(60, 'seconds');
          this.notifyOtherTabs(MStoreConstants.LocalStorageKeys.IsAppIdleOnAnotherTab, event);
        }
      },
      notifyOtherTabs(key: string, event: any) {
        if (event !== true) {
          LocalStorage.emit(key, true);
        }
      },
      manageLastSelectedWorkflowQueue(this: any, lastSelectedWorkflowQueueId: number) {
        if (lastSelectedWorkflowQueueId !== this.lastSelectedQueueId) {
          this.setLastSelectedWorkflowQueue(lastSelectedWorkflowQueueId);
        }
      },
      async confirmDiscardChangesOnApplicationDirty(this: any, callback: () => any) {
        try {
          const discardUnsavedChanges = await this.showUnsavedChangesModalAsync(this.$bvModal);

          if (discardUnsavedChanges) {
            this.setApplicationDirty(false);
            callback();
          }
          this.setShowApplicationDirtyModal(false);
        } catch (error) {
          this.$log(error);
        }
      }
    },
    watch: {
      oidcAccessToken(this: any) {
        axios.defaults.headers.common.Authorization = `Bearer ${this.oidcAccessToken}`;
      },
      isAppIdle(this: any, event) {
        if (this.isAppIdle) {
          this.showIdleTimeOut();
        } else {
          this.clearPostSignInIdleTime();
        }
      },
      now(this: any) {
        if (this.postSignInIdleTime.isSameOrBefore(moment())) {
          this.waitForPostSignInIdleTime = false;
        }
      },
      oidcIsAuthenticated(this: any) {
        if (this.oidcIsAuthenticated) {
          this.currentUserAuthenticated();
        }
      },
      showApplicationDirtyModal(this: any) {
        if (this.showApplicationDirtyModal) {
          const callBackFunction = () => this.$router.push(this.applicationDirtyRouteNavigatedTo);
          this.confirmDiscardChangesOnApplicationDirty(callBackFunction);
        }
      }
    },
    created(this: any) {
      window.addEventListener('beforeunload', (event: any) => this.beforeUnloadApplication(event));
      window.addEventListener('unload', this.removeOidcUser);
      LocalStorage.on(localStorageKeys.LastSelectedWorkflowQueue, this.manageLastSelectedWorkflowQueue);
      LocalStorage.on(localStorageKeys.IsApplicationLoggedOutOnAnotherTab, this.setApplicationDirty);
      LocalStorage.on(localStorageKeys.IsApplicationDirtyOnAnotherTab, this.setApplicationDirtyOnAnotherTab);
      LocalStorage.on(localStorageKeys.IsAppIdleOnAnotherTab, this.showIdleTimeOut);
      LocalStorage.on(localStorageKeys.IsAppIdleExtended, this.extendSession);
    },
    mounted(this: any) {
      const vm = this;
      AxiosConfiguration.configure();
      SnotifyConfiguration.configure(vm);
      this.nowIntervalId = setInterval(this.setNowToNow, 1000);
      this.extendSession();
    },
    beforeRouteEnter() {
      this.keepAliveInclude = this.$route.meta.keepAliveInclude || '';
    },
    beforeDestroy(this: any) {
      clearInterval(this.nowIntervalId);

      window.removeEventListener('beforeunload', (event: any) => this.beforeUnloadApplication(event));
      window.removeEventListener('unload', this.removeOidcUser);
      LocalStorage.off(localStorageKeys.LastSelectedWorkflowQueue, this.manageLastSelectedWorkflowQueue);
      LocalStorage.off(localStorageKeys.IsApplicationLoggedOutOnAnotherTab, this.setApplicationDirty);
      LocalStorage.off(localStorageKeys.IsApplicationDirtyOnAnotherTab, this.setApplicationDirtyOnAnotherTab);
      LocalStorage.off(localStorageKeys.IsAppIdleOnAnotherTab, this.showIdleTimeOut);
      LocalStorage.off(localStorageKeys.IsAppIdleExtended, this.extendSession);
    },
    components: {
      BaseLayout,
      ExpiryModal,
      'mstore-modal': MStorePopup,
      Feedback
    }
  });
</script>

<style lang="sass">
  @import 'scss/site.scss'
</style>
