<template>
  <div>
    <m-unsupported-input
      :fieldLabel="inputProperties.fieldLabel"
      :htmlElementId="inputProperties.htmlElementId"
      :message="unsupportedMessage"
    />
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  import MStoreUnsupportedInput from '@/components/shared/MStoreUnsupportedInput.vue';
  export default Vue.extend({
    name: 'WorkflowUnsupportedInput',
    props: {
      inputProperties: {
        type: Object,
        required: true
      },
      data: {
        required: true
      },
      message: {
        type: String,
        default: null
      }
    },
    computed: {
      unsupportedMessage(this: any) {
        return this.message || this.inputProperties.additionalProperties.unsupportedMessage;
      }
    },
    components: {
      'm-unsupported-input': MStoreUnsupportedInput
    }
  });
</script>
