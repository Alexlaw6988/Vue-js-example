<template>
  <div>
    <ValidationObserver ref="ValidationObserver" v-slot="{ dirty, invalid, reset }" slim>
      <b-form
        :autocomplete="autocomplete"
        :id="id"
        @submit.prevent="(event) => onSubmit(event, reset)"
        :data-vv-scope="dataVvScope"
      >
        <slot :dirty="dirty" :invalid="invalid"></slot>
      </b-form>
    </ValidationObserver>
  </div>
</template>

<script lang="ts">
  import { FormFieldValidation } from '@/mixins/formValidation';
  import Vue from 'vue';

  export default Vue.extend({
    name: 'm-form',
    mixins: [FormFieldValidation],
    props: {
      autocomplete: {
        type: String,
        default: 'off'
      },
      id: {
        type: String
      },
      dataVvScope: {
        type: String
      },
      resetValidationOnSubmit: {
        default: false
      }
    },
    methods: {
      async onSubmit(this: any, event: any, reset: any) {
        const valid = await this.$refs.ValidationObserver.validate();
        if (valid) {
          this.$emit('submit', event);
          if (this.resetValidationOnSubmit) {
            reset();
          }
        }
      }
    },
    mounted(this: any) {
      this.$watch(
        () => {
          return (this.$refs.ValidationObserver as any).ctx.dirty;
        },
        (dirty: boolean) => {
          this.$emit('formDirty', dirty);
          this.setApplicationDirty(dirty);
        }
      );
    }
  });
</script>
