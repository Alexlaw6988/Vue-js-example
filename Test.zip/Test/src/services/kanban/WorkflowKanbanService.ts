import axios from 'axios';
import { WorkflowDataSourceModel } from '@/types';
import AxiosConfiguration from '@/classes/AxiosConfiguration';
import { KanbanCardOrderUpdateModel } from '@/types/models/kanban';

const WorkflowKanbanJobApiUrl = 'workflowKanbanJob';

export const WorkflowKanbanService = {
  async moveCardAsync(queueId: number, jobId: number, sourceLane: string, targetLane: string, readTime: Date) {
    const response = await axios.put(
      `${WorkflowKanbanJobApiUrl}/${[queueId, jobId, sourceLane, targetLane].join('/')}`,
      { ReadTime: readTime }
    );
    return response.data;
  },
  async processCardAsync(
    queueId: number, jobId: number, targetLane: string, readTime: Date, dataSources: WorkflowDataSourceModel[]) {
    const response = await AxiosConfiguration.axiosWithoutNotification.put(
      `${WorkflowKanbanJobApiUrl}/${[queueId, jobId, targetLane].join('/')}`,
      {
        ReadTime: readTime,
        WorkflowDataSources: dataSources
      }
    );
    return response.data;
  },
  async updateCardOrderAsync(
    queueId: number,
    jobId: number,
    updateModel: KanbanCardOrderUpdateModel,
  ) {
    const response = await axios.put(`${WorkflowKanbanJobApiUrl}/${queueId}/${jobId}/cardorder`, updateModel);
    return response.data;
  }
};
