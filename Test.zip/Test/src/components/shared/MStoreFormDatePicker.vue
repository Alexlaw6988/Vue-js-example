<template>
  <ValidationProvider :rules="veeValidateRule" :name="name" v-slot="{ flags, errors }" ref="ValidationProvider" slim>
    <m-form-group :label="label" :labelFor="id" :isRequired="validation.required">
      <date-picker
        v-model="inputValue"
        :lang="lang"
        :placeholder="placeholder"
        :input-attr="{ id }"
        :name="name"
        :append-to-body="true"
        :popup-style="readonly ? { visibility: 'hidden' } : null"
        :editable="!readonly"
        :clearable="!readonly"
        :disabled="disabled"
        :format="format"
        :input-class="getInputStateClass(flags, errors, 'form-control')"
        width="100%"
        @keypress.enter.native.prevent.self
      />
      <b-form-invalid-feedback :state="getInputState(flags, errors)">{{ errors[0] }}</b-form-invalid-feedback>
    </m-form-group>
  </ValidationProvider>
</template>

<script lang="ts">
  import Vue from 'vue';
  import DatePicker from 'vue2-datepicker';
  import moment from 'moment';
  import { FormFieldValidation } from '@/mixins/formValidation';
  import { ValidationModel } from '@/types/models/validation';

  export default Vue.extend({
    name: 'm-form-date-picker',
    mixins: [FormFieldValidation],
    props: {
      value: {
        required: true
      },
      placeholder: String,
      label: {
        type: String,
        default: ''
      },
      validation: {
        type: Object as () => ValidationModel,
        default: () => ({} as ValidationModel)
      },
      id: {
        type: String,
        required: true
      },
      name: String,
      readonly: Boolean,
      disabled: Boolean,
      format: {
        type: String,
        default: 'DD/MM/YYYY'
      },
      lang: {
        type: String,
        default: 'en'
      }
    },
    computed: {
      inputValue: {
        get(this: any) {
          return this.value;
        },
        set(this: any, newValue: string) {
          this.$emit(
            'input',
            newValue
              ? moment(newValue)
                  .locale('en-gb')
                  .format('YYYY-MM-DDTHH:mm:SS')
              : null
          );
        }
      }
    },
    components: {
      DatePicker
    }
  });
</script>
