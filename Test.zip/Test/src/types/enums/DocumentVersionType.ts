export enum DocumentVersionType {
  None = 0,
  ManualCheckedInOut = 1,
  ReIndexed = 2,
  HistoricVersion = 3,
  PagesChanged = 4,
  CapturePlusPdfPlugin = 5,
  Current = 6
}
