<template>
  <div id="m-pageRange" class="bg-light-gray border-bottom">
    <div class="form-inline ml-1">
      <b-input-group prepend="Pages" size="sm" class="mr-2 mt-1 mb-1">
        <b-form-input
          autocomplete="off"
          v-model="inputValue"
          type="text"
          size="sm"
          class="gotoPageInput"
          @keydown="onKeyDown"
        ></b-form-input>
      </b-input-group>

      <b-button
        id="previousPageButton"
        class="btn btn-primary m-1 btn-sm"
        title="Previous Page"
        variant="primary"
        :disabled="isLefttNavigationDisabled"
        @click="onPageNavigationClick(-1)"
      >
        <font-awesome-icon icon="arrow-left" />
      </b-button>
      <b-button
        id="nextPageButton"
        class="btn btn-primary m-1 btn-sm"
        title="Next Page"
        variant="primary"
        :disabled="isRightNavigationDisabled"
        @click="onPageNavigationClick(1)"
      >
        <font-awesome-icon icon="arrow-right" />
      </b-button>
      <div class="m-1">
        <b-checkbox class="pl-5 custom-switch" v-model="isAllPages" @change="onAllPagesChange"></b-checkbox>
        <label>All Pages</label>
      </div>
    </div>
    <b-form-invalid-feedback v-if="!isValidFormat && isDirty" class="display-block mt-0">
      Not a valid format.
    </b-form-invalid-feedback>
  </div>
</template>

<script lang="ts">
  import { KeyboardKeyCode } from '@/types';
  import { ObjectUtils } from '@/utils/objectUtils';
  import Vue from 'vue';

  export default Vue.extend({
    name: 'MStorePageRange',
    props: {
      totalPages: {
        type: Number,
        required: true
      },
      value: String,
      isValid: {
        type: Boolean,
        required: false
      },
      isContiguous: {
        type: Boolean,
        required: false
      }
    },
    data() {
      return {
        isAllPages: false,
        isDirty: false
      };
    },
    computed: {
      inputValue: {
        get(this: any) {
          return this.value;
        },
        set(this: any, value: string) {
          this.$emit('input', value);
        }
      },
      isValidFormat(this: any) {
        const value = this.validate(this.inputValue);
        this.$emit('update:isValid', value);
        return value;
      },
      isContiguousFormat(this: any) {
        const value =
          !this.isCustomRange &&
          this.isRangeFormat(this.inputValue) &&
          this.isValidContiguousFormat(this.startValue, this.endValue);
        this.$emit('update:isContiguous', value);
        return value;
      },
      startValue(this: any): number | null {
        return this.getValueFromPageRange(this.inputValue, 0);
      },
      endValue(this: any): number | null {
        return this.getValueFromPageRange(this.inputValue, 1);
      },
      isCustomRange(this: any) {
        return this.inputValue?.includes(',');
      },
      allPagesString(this: any) {
        return this.getRangeString(1, this.totalPages);
      },
      contiguousAllPagesString(this: any): string {
        return `1-${this.totalPages}`;
      },
      isRightNavigationDisabled(this: any): boolean {
        return this.endValue >= this.totalPages || this.startValue !== 1 || !this.isContiguousFormat;
      },
      isLefttNavigationDisabled(this: any): boolean {
        return this.endValue - 1 <= this.startValue || this.startValue !== 1 || !this.isContiguousFormat;
      }
    },
    methods: {
      onKeyDown(this: any, event: any): void {
        if (KeyboardKeyCode[event.keyCode]) {
          return;
        }
        if (!this.validateInput(event.key)) {
          event.preventDefault();
        }
      },
      validateInput(input: any): boolean {
        const validCharacters = /^[0-9-,]+$/;
        return validCharacters.test(input);
      },
      onAllPagesChange(this: any, event: any): void {
        if (event) {
          this.inputValue = this.contiguousAllPagesString;
        }
      },
      onPageNavigationClick(this: any, count: number): void {
        if (this.startValue && this.endValue) {
          this.inputValue = `${this.startValue}-${this.endValue + count}`;
          this.$nextTick(() => {
            this.isAllPages = this.totalPages === this.endValue;
          });
        }
      },
      getValueFromPageRange(this: any, inputValue: string, index: number): number | null {
        return this.parseNumber(inputValue?.split('-')[index]);
      },
      parseNumber(input: any): number | null {
        return Number.isNaN(input) ? null : Number(input);
      },
      getRangeString(rangeStart: number, rangeEnd: number): string {
        return `${this.getRangeArray(rangeStart, rangeEnd)}`;
      },
      getRangeArray(rangeStart: number, rangeEnd: number): number[] {
        return [...Array(rangeEnd - rangeStart + 1)].map((_, i) => rangeStart + i);
      },
      hasDuplicates(array: any): boolean {
        return new Set(array).size !== array.length;
      },
      isRangeFormat(this: any, value: string): boolean {
        return value?.includes('-') && this.isNumberArray(value?.split('-'));
      },
      isNumberArray(this: any, array: any[]): boolean {
        return array.every((x: string) => !ObjectUtils.isNaN(x));
      },
      isValidContiguousFormat(this: any, startValue: number, endValue: number): boolean {
        return startValue > 0 && endValue <= this.totalPages && endValue > startValue;
      },
      toArrayFromString(value: string, seperator: string): string[] {
        return value.split(seperator);
      },
      hasValidFormat(this: any, value: string): boolean {
        if (!this.isCustomRange && !this.isContiguousFormat && ObjectUtils.isNaN(value)) {
          return false;
        }
        if (this.isContiguousFormat) {
          return true;
        }
        const inputStringArray = this.toArrayFromString(value, ',');
        const inputRangeArray = inputStringArray.filter((x: string) => x?.includes('-'));
        const inputCustomArray = inputStringArray.filter((x: string) => !x?.includes('-'));
        const isValidRanges = inputRangeArray.every((x: string) => {
          const start = this.getValueFromPageRange(x, 0);
          const end = this.getValueFromPageRange(x, 1);
          return this.isRangeFormat(x) && this.isValidContiguousFormat(start, end);
        });
        const isValidPageNumbers =
          this.isNumberArray(inputCustomArray) && !inputCustomArray.some((x: string) => Number(x) > this.totalPages);
        return inputRangeArray?.length > 0 ? isValidRanges && isValidPageNumbers : isValidPageNumbers;
      },
      hasDuplicatePages(value: string): boolean | undefined {
        if (!this.isCustomRange) {
          return false;
        }
        const inputStringArray = this.toArrayFromString(value, ',');
        const inputRangeArray = inputStringArray.filter((x: string) => x?.includes('-'));
        const inputCustomArray = inputStringArray.filter((x: string) => !x?.includes('-'));
        const inputRangePagesArray = inputRangeArray.map((x) => {
          const rangeString = x.split('-');
          return this.getRangeArray(Number(rangeString[0]), Number(rangeString[1]));
        });
        return (
          (inputRangePagesArray.length > 0 &&
            inputRangePagesArray?.some((x: any, index: number) => {
              const restOfTheElements = [...inputRangePagesArray];
              restOfTheElements.splice(index, 1);
              return (
                restOfTheElements.some((y) => {
                  return y.some((z) => x.includes(z));
                }) || inputCustomArray.some((i) => x.includes(Number(i)))
              );
            })) ||
          this.hasDuplicates(inputCustomArray)
        );
      },
      validate(this: any, value: string): boolean {
        return !(
          !value ||
          this.totalPages <= 0 ||
          ObjectUtils.isNaN(this.totalPages) ||
          !this.validateInput(value) ||
          Number(value) > this.totalPages ||
          Number(value) <= 0 ||
          !this.hasValidFormat(value) ||
          this.hasDuplicatePages(value)
        );
      }
    },
    mounted(this: any) {
      this.$emit('update:isValid', this.validate(this.inputValue));
      this.$emit('update:isContiguous', this.isContiguous);
    },
    watch: {
      value(newValue, oldValue) {
        this.isDirty = true;
        this.isAllPages = this.inputValue === this.contiguousAllPagesString;
      }
    }
  });
</script>
