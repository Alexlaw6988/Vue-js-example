declare module 'vue-timeago';
