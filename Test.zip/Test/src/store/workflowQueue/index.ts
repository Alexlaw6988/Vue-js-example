import { actions } from './actions';
import { getters } from './getters';
import { mutations } from './mutations';
import { TableStateModel } from '@/types';
import { WorkflowQueueState } from '@/types/store/workflowQueue';

export function defaultWorkflowQueueState() {
  return {
    tableState: {
      stateKey: '',
      showFilters: false,
      currentPage: 1,
      itemsPerPage: 10,
      searchQuery: '',
      sortBy: '',
      sortDesc: false,
      selectedPk: '',
      filteredItems: []
    } as TableStateModel,
    queueId: 0,
    isLoading: false,
    error: false,
    errorMessage: '',
    allJobsList: [],
    nextJobsList: [],
    lastSelectedWorkflowQueue: 0
  };
}

export const state: WorkflowQueueState = defaultWorkflowQueueState();

const namespaced: boolean = true;

export const workflowQueue = {
  namespaced,
  state,
  actions,
  getters,
  mutations,
  defaultWorkflowQueueState
};
