import { MutationTree } from 'vuex';
import {
  DocumentViewState,
  BaseDocumentSearchModel,
  DocumentModel,
  DocumentVersionModel,
  RelatedDocumentViewModel,
  DocumentPageModel
} from '@/types';
import { DocumentViewUtils } from '@/utils/documentViewUtils';
import { ObjectUtils } from '@/utils/objectUtils';

export const mutations: MutationTree<DocumentViewState> = {
  DOCUMENT_SEARCH_MODEL(state, documentSearchModel: BaseDocumentSearchModel) {
    state.DocumentSearchModel = documentSearchModel;
    state.VersionBeingViewed = {} as DocumentVersionModel;
    state.RelatedDocumentBeingViewed = {} as RelatedDocumentViewModel;
  },
  PAGE_NUMBER(state, pageNumber: number) {
    state.PageNumber = pageNumber;
  },
  PAGE_LOADING(state) {
    state.isPageLoading = true;
  },
  DOCUMENT_VERSION_BEING_VIEWED(state, version: DocumentVersionModel) {
    state.VersionBeingViewed = version;
    state.RelatedDocumentBeingViewed = {} as RelatedDocumentViewModel;
    removePageFromCache(state, { documentId: version.documentId, pageNumber: 1 } as DocumentPageModel);
  },
  RELATED_DOCUMENT_BEING_VIEWED(state, relatedDocument: RelatedDocumentViewModel) {
    state.RelatedDocumentBeingViewed = relatedDocument;
    state.VersionBeingViewed = {} as DocumentVersionModel;
    const documentId =
      relatedDocument?.documentSearchModel?.documentId != null
        ? relatedDocument.documentSearchModel.documentId
        : state.DocumentSearchModel.documentId;
    removePageFromCache(state, { documentId, pageNumber: 1 } as DocumentPageModel);
  },
  DOCUMENT_LOADED(state, documentModel: DocumentModel) {
    state.hasDocumentError = false;
    state.isPageLoading = false;
    state.hasDocumentLoaded = true;
    state.DocumentModel = documentModel;
  },
  DOCUMENT_LOAD_FAILED(state, error: string) {
    state.isPageLoading = false;
    state.hasDocumentError = true;
    const document: DocumentModel = {
      notification: error,
      hasNotification: true
    } as DocumentModel;
    state.DocumentModel = document;
  },
  UNLOAD_DOCUMENT(state) {
    const initState = {
      PageNumber: 1,
      RelatedDocumentBeingViewed: {} as RelatedDocumentViewModel,
      VersionBeingViewed: {} as DocumentVersionModel,
      DocumentModel: { contentType: '', fileName: '', documentData: '', totalPages: 0 } as DocumentModel,
      DocumentSearchModel: {} as BaseDocumentSearchModel,
      hasDocumentError: false,
      isPageLoading: false,
      hasDocumentLoaded: false,
      documentPage: {} as DocumentPageModel,
      documentPageCache: [] as DocumentPageModel[],
      showLoadingSpinner: true
    } as DocumentViewState;
    Object.assign(state, initState);
  },
  PAGE_LOADED(state, documentPageModel: DocumentPageModel) {
    state.documentPage = documentPageModel;
    state.isPageLoading = false;
  },
  PAGE_DOWNLOADED(state, documentPage: DocumentPageModel) {
    const maximumPagesToCache = state.maximumNumberOfPagesToCache;
    if (maximumPagesToCache === 0) {
      return;
    }
    const cacheIndex = getPageCacheIndex(state, documentPage);
    if (cacheIndex !== -1) {
      Object.assign(state.documentPageCache[cacheIndex], documentPage);
      if (state.DocumentModel.id === documentPage.documentId && state.PageNumber === documentPage.pageNumber) {
        Object.assign(state.documentPage, documentPage);
      }
      return;
    }
    state.documentPageCache.push(documentPage);
  },
  LOAD_PAGE_FROM_CACHE(state, documentPage: DocumentPageModel) {
    const cachedPage = {} as DocumentPageModel;
    Object.assign(
      cachedPage,
      state.documentPageCache.find(
        (x: DocumentPageModel) => x.documentId === documentPage.documentId && x.pageNumber === documentPage.pageNumber
      )
    );

    if (!ObjectUtils.isNullOrEmpty(cachedPage)) {
      Object.assign(state.documentPage, cachedPage);
    }
  },
  PAGE_LOADED_FROM_CACHE(state) {
    state.isPageLoading = false;
  },
  SHOW_LOADING_SPINNER(state, showLoadingSpinner: boolean) {
    state.showLoadingSpinner = showLoadingSpinner;
  }
};

function removePageFromCache(state: DocumentViewState, documentPage: DocumentPageModel) {
  const cacheIndex = findCacheIndex(state, documentPage);
  if (cacheIndex !== -1) {
    state.documentPageCache.splice(cacheIndex, 1);
  }
}

function getPageCacheIndex(state: DocumentViewState, documentPage: DocumentPageModel): number {
  const maximumPagesToCache = state.maximumNumberOfPagesToCache;
  let cacheIndex = findCacheIndex(state, documentPage);
  if (cacheIndex !== -1) {
    return cacheIndex;
  } else {
    if (state.documentPageCache.length >= maximumPagesToCache) {
      const pageToRemoveFromCache = getPageToRemoveFromCache(state, documentPage);
      if (pageToRemoveFromCache) {
        cacheIndex = findCacheIndex(state, pageToRemoveFromCache);
      }
      return cacheIndex;
    } else {
      return cacheIndex;
    }
  }
}

function findCacheIndex(state: DocumentViewState, documentPage: DocumentPageModel): number {
  return state.documentPageCache.findIndex(
    (x: DocumentPageModel) => x.documentId === documentPage.documentId && x.pageNumber === documentPage.pageNumber
  );
}

function getPageToRemoveFromCache(
  state: DocumentViewState,
  documentPageModel: DocumentPageModel
): DocumentPageModel | undefined {
  const furtherstPageFromOtherDocument = DocumentViewUtils.getFurthestPageFromOtherDocument(
    state.documentPageCache,
    documentPageModel.documentId
  );
  if (furtherstPageFromOtherDocument) {
    return furtherstPageFromOtherDocument;
  }

  return DocumentViewUtils.getFurthestPage(state.documentPageCache, documentPageModel.pageNumber);
}
