import { DocuSignStandardProcessingAction } from '@/types';

export const DocuSignConstants = {
  SuccessMessage: {
    [DocuSignStandardProcessingAction.CreateEnvelope]: 'Envelope was created successfully',
    [DocuSignStandardProcessingAction.VoidEnvelope]: 'Envelope was voided successfully',
    [DocuSignStandardProcessingAction.ReturnToPrepare]:
      'The selected jobs are returned for Envelope preparation successfully',
    [DocuSignStandardProcessingAction.Cancel]: 'The selected jobs are cancelled successfully'
  },
  CustomSignersTabKey: 'Custom-DocuSignSignersTab',
  IntegrationPrivateKeyFormatRegex: `^-----BEGIN RSA PRIVATE KEY-----\n(?:.|\n)+\n-----END RSA PRIVATE KEY-----$`
};
