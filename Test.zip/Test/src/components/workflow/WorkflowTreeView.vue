<template>
  <div id="m-treeview" class="pb-5rem">
    <TreeViewHeader title="Workflow" @expand="expandAll('tree')" @collapse="collapseAll('tree')" />
    <tree
      ref="tree"
      v-if="!loading"
      :data="data"
      :options="options"
      @node:clicked="navigateToQueue"
      @tree:mounted="getNode"
    >
      <div class="tree-scope" slot-scope="{ node }">
        <template v-if="node.data.type === 'Process'">
          <h6 class="text">
            <font-awesome-icon icon="cogs" size="lg" class="mr-1 text-primary" />
            {{ node.text }}
          </h6>
        </template>
        <template v-else-if="node.data.type === 'Folder'">
          <span class="text">
            <font-awesome-icon icon="folder" size="lg" class="mr-1 text-secondary" />
            {{ node.text }}
          </span>
        </template>
        <template v-else-if="node.data.type === 'JobList'">
          <span class="text">
            <font-awesome-icon icon="list" size="lg" class="mr-1 text-info" />
            {{ node.text }}
          </span>
        </template>
        <template v-else-if="node.data.type === 'FilteredView'">
          <span class="text">
            <font-awesome-layers class="fa-lg mr-2">
              <font-awesome-icon icon="list" class="text-info" />
              <font-awesome-icon icon="filter" transform="shrink-3 down-4 right-7" />
            </font-awesome-layers>
            {{ node.text }}
          </span>
        </template>
      </div>
    </tree>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  import { mapGetters, mapActions } from 'vuex';
  import LiquorTree from 'liquor-tree';
  import { WorkflowTreeModel } from '@/types';
  import { WorkflowTreeService } from '@/services/WorkflowTreeService';
  import LoadingSpinner from '@/components/shared/LoadingSpinner.vue';
  import { TreeViewHeader } from '@/components/shared';
  import { TreeViewHelpers } from '@/mixins/treeView';
  import { MStoreConstants } from '@/types/constants';
  import { LocalStorage } from '@/utils';
  Vue.use(LiquorTree);

  export default Vue.extend({
    name: 'WorkflowTreeView',
    mixins: [TreeViewHelpers],
    props: {
      loading: {
        type: Boolean,
        required: false
      }
    },
    data() {
      return {
        data: {} as WorkflowTreeModel[],
        options: {
          checkbox: false,
          parentSelect: true
        }
      };
    },
    methods: {
      ...mapActions('workflowQueueStore', ['setLastSelectedWorkflowQueue']),
      ...mapActions('userPreferencesStore', ['setSelectedWorkFlowQueueId']),
      async getDataAsync() {
        const lastSelectedQueue =
          this.lastSelectedQueueId !== 0 ? this.lastSelectedQueueId : this.lastSelectedQueueIdOnOtherTab;
        if (lastSelectedQueue !== 0 && !this.$route.params.id) {
          this.$router.push({
            name: 'WorkflowQueue',
            params: {
              id: lastSelectedQueue
            }
          });
        } else {
          this._isLoading = true;
          this.data = await WorkflowTreeService.getWorkflowTreeAsync();
          this._isLoading = false;
          const isValidWorkflowQueue = this.isValidWorkflowQueue(this.data);
          if (isValidWorkflowQueue && this.$route.params.id !== lastSelectedQueue?.toString()) {
            this.setSelectedWorkFlowQueue(this.$route.params.id);
          }
        }
      },
      isValidWorkflowQueue(tree: any) {
        return tree?.some((parent: any) =>
          parent?.children?.length > 0
            ? this.isValidWorkflowQueue(parent.children)
            : parent.data.id === Number(this.$route.params.id)
        );
      },
      setSelectedWorkFlowQueue(id: any) {
        this.setLastSelectedWorkflowQueue(Number(id));
        this.setSelectedWorkFlowQueueId(id);
        LocalStorage.emit(MStoreConstants.LocalStorageKeys.LastSelectedWorkflowQueue, id);
      },
      navigateToQueue(node: any) {
        if (node.states.selectable && this.$router.currentRoute.params.id !== node.data.id) {
          this.setSelectedWorkFlowQueue(node.data.id);
          this.$router.push({
            name: 'WorkflowQueue',
            params: {
              id: node.data.id
            }
          });
        } else {
          node.states.expanded = !node.states.expanded;
        }
      },
      getNode(this: any, tree: any) {
        const id: number = Number(this.$route.params.id);
        if (!id) {
          return;
        }
        const node = this.$refs.tree.find({
          data: { id }
        });
        if (!node) {
          return;
        }
        this.selectNode(node);
      }
    },
    watch: {
      '$route.params.id'(this: any, id) {
        if (!id) {
          const selectedNode = this.$refs.tree.find({
            state: { selected: true }
          });
          this.unselectNode(selectedNode);
        }
      }
    },
    computed: {
      ...mapGetters('workflowQueueStore', ['getLastSelectedWorkflowQueue']),
      ...mapGetters('userPreferencesStore', ['getSelectedWorkflowQueue']),
      _isLoading: {
        get(this: any) {
          return this.loading;
        },
        set(this: any, value: boolean) {
          this.$emit('update:loading', value);
        }
      },
      lastSelectedQueueId(this: any) {
        return this.getLastSelectedWorkflowQueue;
      },
      lastSelectedQueueIdOnOtherTab(this: any) {
        return this.getSelectedWorkflowQueue();
      }
    },
    async mounted() {
      await this.getDataAsync();
    },
    components: {
      LoadingSpinner,
      TreeViewHeader
    }
  });
</script>
