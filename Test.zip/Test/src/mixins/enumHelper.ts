export const EnumHelper = {
  methods: {
    convertNumberBasedEnumToArray(this: any, e: any) {
      const keys: string[] = Object.keys(e).filter((k) => typeof e[k as any] === 'number');
      const values: string[] = keys.map((k) => e[k as any]);
      const data: object[] = [];
      for (let i = 0; i < values.length; i++) {
        data.push({ key: values[i], value: keys[i] });
      }
      return data;
    }
  }
};
