import { ApplicationDirtyStateModel, RootState, MStoreConstants } from '@/types';
import { GetterTree } from 'vuex';
import { LocalStorage } from '@/utils';

export const getters: GetterTree<ApplicationDirtyStateModel, RootState> = {
  isApplicationDirty(state) {
    return state.isDirty;
  },
  isApplicationDirtyOnAnotherTab(state) {
    const isDirtyOnAnotherTab = LocalStorage.get(MStoreConstants.LocalStorageKeys.IsApplicationDirty);
    return state.isDirtyOnAnotherTab || (!state.isDirty && isDirtyOnAnotherTab);
  },
  showApplicationDirtyModal(state) {
    return state.showModal;
  },
  applicationDirtyRouteNavigatedTo(state) {
    return state.routeNavigatedTo;
  }
};
