import {
  WorkflowJobState,
  RootState,
  WorkflowJobModel,
  WorkflowJobSearchModel,
  FieldUpdateModel,
  WorkflowJobTabModel,
  JobTabOrientation,
  JobTabStateModel,
  LockModel,
  ErrorModel,
  TabStateModel,
  DynamicFormValidationModel,
  WorkflowJobMutationTypes,
  CustomTabDynamicFormUpdateModel,
  WorkflowDocumentSearchModel
} from '@/types';
import { ActionTree } from 'vuex';
import { WorkflowJobService } from '@/services/WorkflowJobService';
import { LockService } from '@/services/LockService';
import store from '../index';

export const actions: ActionTree<WorkflowJobState, RootState> = {
  setIsLoading({ commit }, isLoading: boolean) {
    commit(WorkflowJobMutationTypes.SetIsLoading, isLoading);
  },
  setIsDirty({ commit }, isDirty: boolean) {
    store.dispatch('applicationDirtyStore/setApplicationDirty', isDirty);
    commit(WorkflowJobMutationTypes.SetIsDirty, isDirty);
  },
  setIsAwaitingProcessing({ commit }, isAwaitingProcessing: boolean) {
    commit(WorkflowJobMutationTypes.SetIsAwaitingProcessing, isAwaitingProcessing);
  },
  getWorkflowJob({ commit, getters }, searchModel: WorkflowJobSearchModel) {
    commit(WorkflowJobMutationTypes.SetIsLoading, true);

    store.dispatch('documentViewStore/loadPageWithJobId', {
      jobId: searchModel.jobId,
      page: 1
    } as WorkflowDocumentSearchModel);

    WorkflowJobService.getWorkflowJobAsync(searchModel.queueId, searchModel.jobId).then(
      (response: WorkflowJobModel) => {
        store.dispatch('documentViewStore/setDocumentSearchModel', response.documentSearchModel);

        const payload: WorkflowJobModel = response;

        commit(WorkflowJobMutationTypes.WorkflowJobLoaded, payload);

        const horizontalTabs = getters.allJobTabsByOrientation(JobTabOrientation.Horizontal) as
          | WorkflowJobTabModel[]
          | undefined;

        if (horizontalTabs && horizontalTabs.length > 0) {
          commit(WorkflowJobMutationTypes.PopulateHorizontalJobTabStates, horizontalTabs);
        }

        const verticalTabs = getters.allJobTabsByOrientation(JobTabOrientation.Vertical) as
          | WorkflowJobTabModel[]
          | undefined;

        if (verticalTabs && verticalTabs.length > 0) {
          commit(WorkflowJobMutationTypes.PopulateVerticalJobTabStates, verticalTabs);
        }

        const workflowTabs = getters.workflowJobTabs as WorkflowJobTabModel[] | undefined;

        if (workflowTabs && workflowTabs.length > 0) {
          workflowTabs.forEach((workflowTab: WorkflowJobTabModel) => {
            commit(WorkflowJobMutationTypes.SetDynamicFormValidationModel, {
              formId: workflowTab.dynamicFormModel.formId
            } as DynamicFormValidationModel);
          });
        }
      },
      (error) => {
        commit(WorkflowJobMutationTypes.WorkflowJobError, error);
      }
    );
  },
  setWorkflowDataSourceField(this: any, { commit, dispatch, getters }, fieldUpdateModel: FieldUpdateModel) {
    const field = getters.workflowDataSourceField(fieldUpdateModel.dataSourceKey, fieldUpdateModel.fieldName) as
      | object
      | undefined;

    if (field !== undefined) {
      commit(WorkflowJobMutationTypes.UpdateWorkflowDataSourceField, fieldUpdateModel);
      dispatch('setIsDirty', true);
    } else {
      let errorMessage = 'Unable to find workflow data source field. ';
      errorMessage += `Data source key: ${fieldUpdateModel.dataSourceKey} | `;
      errorMessage += `Field name: ${fieldUpdateModel.fieldName}`;
      commit(WorkflowJobMutationTypes.SetErrorMessage, errorMessage);
    }
  },
  setActiveHorizontalTab({ commit, getters, state }, tabKey: string) {
    const tab =
      state.activeHorizontalTab.key === tabKey
        ? ({} as WorkflowJobTabModel)
        : (getters.horizontalJobTabByKey(tabKey) as WorkflowJobTabModel | undefined);

    commit(WorkflowJobMutationTypes.SetActiveHorizontalTab, tab);
  },
  setActiveVerticalTab({ commit, getters, state }, tabKey: string) {
    const tab = getters.verticalJobTabByKey(tabKey) as WorkflowJobTabModel | undefined;
    if (tab) {
      commit(WorkflowJobMutationTypes.SetActiveVerticalTab, getActiveTab(state.activeVerticalTab, tab));
    } else {
      const tabs = getters.visibleVerticalJobTabs as WorkflowJobTabModel[];
      if (tabs) {
        commit(WorkflowJobMutationTypes.SetActiveVerticalTab, tabs[0]);
      }
    }
  },
  setJobTabStateCount({ commit, getters }, tabStateModel: TabStateModel) {
    const tab = getters.jobTabState(tabStateModel.key) as JobTabStateModel | undefined;
    if (tab) {
      commit(WorkflowJobMutationTypes.SetJobTabStateCount, tabStateModel);
    }
  },
  setJobTabStateDirty({ commit, getters }, tabStateModel: TabStateModel) {
    const tab = getters.jobTabState(tabStateModel.key) as JobTabStateModel | undefined;
    if (tab) {
      commit(WorkflowJobMutationTypes.SetJobTabStateDirty, tabStateModel);
    }
  },
  setJobTabStateHidden({ commit, getters }, tabStateModel: TabStateModel) {
    const tab = getters.jobTabState(tabStateModel.key) as JobTabStateModel | undefined;
    if (tab) {
      commit(WorkflowJobMutationTypes.SetJobTabStateHidden, tabStateModel);
    }
  },
  setExtendingWorkflowJobLock({ commit }, payload: boolean) {
    commit(WorkflowJobMutationTypes.SetExtendingWorkflowJobLock, payload);
  },
  extendWorkflowJobLock({ commit, getters }) {
    const currentLock = getters.workflowJobLock as LockModel | undefined;
    if (currentLock && currentLock.isLockedByCurrentSessionId) {
      commit(WorkflowJobMutationTypes.SetExtendingWorkflowJobLock, true);
      LockService.extendLockAsync(currentLock.id)
        .then((response: LockModel) => {
          const payload: LockModel = response;
          commit(WorkflowJobMutationTypes.ExtendWorkflowJobLock, payload);
          commit(WorkflowJobMutationTypes.SetExtendingWorkflowJobLock, false);
        })
        .catch((error: any) => {
          commit(WorkflowJobMutationTypes.ExpireWorkflowJobLock, error);
          commit(WorkflowJobMutationTypes.SetExtendingWorkflowJobLock, false);
        });
    }
  },
  releaseWorkflowJobLock({ commit, getters }) {
    const currentLock = getters.workflowJobLock as LockModel | undefined;
    if (currentLock && currentLock.isLockedByCurrentSessionId) {
      LockService.releaseLockAsync(currentLock.id).then(() => {
        commit(WorkflowJobMutationTypes.ExpireWorkflowJobLock);
      });
    }
  },
  setJobComponentName({ commit }, componentName: string) {
    commit(WorkflowJobMutationTypes.SetJobComponentName, componentName);
  },
  setJobErrorModel({ commit }, errorModel: ErrorModel) {
    commit(WorkflowJobMutationTypes.SetJobErrorModel, errorModel);
  },
  setDynamicFormValidationModel({ commit }, validationModel: DynamicFormValidationModel) {
    commit(WorkflowJobMutationTypes.SetDynamicFormValidationModel, validationModel);
  },
  addCustomFormsDynamicFormValidationModel({ commit }, formId: string) {
    commit(WorkflowJobMutationTypes.SetDynamicFormValidationModel, { formId } as DynamicFormValidationModel);
  },
  unloadWorkflowJob({ commit }) {
    commit(WorkflowJobMutationTypes.UnloadWorkflowJob);
  },
  addDynamicFormModelToCustomJobTab({ commit }, data: CustomTabDynamicFormUpdateModel) {
    commit(WorkflowJobMutationTypes.AddDynamicFormModelToCustomJobTab, data);
  },
  invalidateAllDynamicForms({ commit }) {
    commit(WorkflowJobMutationTypes.InvalidateAllDynamicForms);
  }
};

function getActiveTab(
  currentActiveTab: WorkflowJobTabModel,
  targetActiveTab: WorkflowJobTabModel
): WorkflowJobTabModel {
  if (currentActiveTab.key === targetActiveTab.key) {
    return currentActiveTab;
  } else {
    return targetActiveTab;
  }
}
