import { TableStateModel, RootState } from '@/types';
import { ActionTree } from 'vuex';

export const actions: ActionTree<TableStateModel[], RootState> = {
  resetMTableState({ commit }, stateKey: string) {
    const tableStateKey = stateKey ? stateKey : '';
    commit('RESET_MTABLE_STATE', tableStateKey);
  },
  setTableStateField({ commit }, payload: any) {
    const tableStateKey = payload.stateKey ? payload.stateKey : '';
    commit('SET_MTABLE_STATE_FIELD', { stateKey: tableStateKey, tableStateField: payload.tableStateField });
  }
};
