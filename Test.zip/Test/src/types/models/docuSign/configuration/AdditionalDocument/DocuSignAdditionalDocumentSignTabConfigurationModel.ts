import { DocuSignAdditionalDocumentSignTabModel, DocuSignAdditionalDocumentFileModel } from '@/types';

export interface DocuSignAdditionalDocumentSignTabConfigurationModel {
  signTabs: DocuSignAdditionalDocumentSignTabModel[];
  additionalDocumentFile: DocuSignAdditionalDocumentFileModel;
}
