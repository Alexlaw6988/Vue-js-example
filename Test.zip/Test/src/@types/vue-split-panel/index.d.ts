declare module 'vue-split-panel';
