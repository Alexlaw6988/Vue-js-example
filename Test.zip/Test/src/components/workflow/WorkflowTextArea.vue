<template>
  <ValidationProvider :rules="validationRule" :name="inputProperties.fieldLabel" slim>
    <m-form-group
      :class="{ 'mb-5': isLastElement }"
      :label="inputProperties.fieldLabel"
      :labelFor="inputProperties.htmlElementId"
      :isRequired="inputProperties.isRequired"
      slot-scope="{ flags, errors }"
    >
      <b-form-textarea
        :id="elementId"
        v-model="inputValue"
        :name="inputProperties.fieldLabel"
        :readonly="inputProperties.isReadonly || isDisabled"
        :state="validationState(flags, errors)"
        :rows="inputProperties.additionalProperties.rows"
        :max-rows="maxRows"
        :no-resize="inputProperties.additionalProperties.noResize"
      />
      <b-form-invalid-feedback :state="validationState(flags, errors)">{{ errors[0] }}</b-form-invalid-feedback>
    </m-form-group>
  </ValidationProvider>
</template>

<script lang="ts">
  import Vue from 'vue';
  import { FormFieldValidation } from '@/mixins/formValidation';

  export default Vue.extend({
    name: 'WorkflowTextArea',
    mixins: [FormFieldValidation],
    props: {
      inputProperties: {
        type: Object,
        required: true
      },
      data: {
        required: true
      },
      ignoreIsRequired: {
        type: Boolean,
        default: false
      },
      isDisabled: {
        type: Boolean,
        default: false
      },
      isLastElement: {
        type: Boolean,
        default: false
      }
    },
    computed: {
      validationRule(this: any): string {
        let rule = this.inputProperties.isRequired && !this.ignoreIsRequired ? 'required' : '';
        rule += this.getMaxLengthValidationRule(this.inputProperties.additionalProperties.maxLength);
        return rule;
      },
      inputValue: {
        get(this: any) {
          return this.data;
        },
        set(this: any, value: string) {
          if (value !== this.data?.toString() && (value || this.data)) {
            this.$emit('update:data', value);
          }
        }
      },
      elementId(this: any) {
        return this.inputProperties?.htmlElementId?.replace(/[. ]/g, '-');
      },
      maxRows(this: any) {
        return !this.isLastElement ? this.inputProperties.additionalProperties.maxRows : 4;
      }
    },
    methods: {
      validationState(this: any, flags: any, errors: string[]): boolean | null {
        const isInputValid = this.getInputState(flags, errors);
        return (!this.inputProperties.isRequired || this.ignoreIsRequired) &&
          (this.inputValue == null || this.inputValue === '') &&
          isInputValid
          ? null
          : isInputValid;
      }
    }
  });
</script>
