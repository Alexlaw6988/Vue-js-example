export enum EntityType {
  UserClient = 1,
  WorkflowJob = 204
}
