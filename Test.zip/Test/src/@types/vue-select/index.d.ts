declare module 'vue-select';
