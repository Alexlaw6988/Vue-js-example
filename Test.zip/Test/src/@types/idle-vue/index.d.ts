declare module 'idle-vue';
