import { RouteHelpers } from '@/mixins';
import { Configuration } from '@/types';
import ConfigurationTreeView from '@/components/configuration/TreeView.vue';

const DocusignAdditionalDocumentManagement = () =>
  import(
    /* webpackChunkName: "DocusignAdditionalDocumentManagement" */
    '@/views/configuration/docusign/DocusignAdditionalDocumentManagement.vue'
  );

const DocusignEditAdditionalDocument = () =>
  import(
    /* webpackChunkName: "DocusignEditAdditionalDocument" */
    '@/views/configuration/docusign/DocusignEditAdditionalDocument.vue'
  );

const DocusignAddAdditionalDocument = () =>
  import(
    /* webpackChunkName: "DocusignAddAdditionalDocument" */
    '@/views/configuration/docusign/DocusignAddAdditionalDocument.vue'
  );

const DocusignAdditionalDocumentSignTabManagement = () =>
  import(
    /* webpackChunkName: "SignTabManagement" */
    '@/views/configuration/docusign/DocusignAdditionalDocumentSignTabManagement.vue'
  );

const DocusignEditAdditionalDocumentSignTab = () =>
  import(
    /* webpackChunkName: "EditAdditionalDocumentSignTab" */
    '@/views/configuration/docusign/DocusignEditAdditionalDocumentSignTab.vue'
  );

const DocusignAddAdditionalDocumentSignTab = () =>
  import(
    /* webpackChunkName: "AddAdditionalDocumentSignTab" */
    '@/views/configuration/docusign/DocusignAddAdditionalDocumentSignTab.vue'
  );

const meta = {
  layout: 'TreeView',
  treePath: 'docusignadditionaldocuments'
};

const metaWithModel = {
  ...meta,
  model: 'additionalDocument'
};

export const AdditionalDocumentRoutes = [
  {
    ...Configuration.DocuSign.AdditionalDocument.Management,
    components: {
      default: DocusignAdditionalDocumentManagement,
      treeView: ConfigurationTreeView
    },
    meta
  },
  {
    ...Configuration.DocuSign.AdditionalDocument.Edit,
    components: {
      default: DocusignEditAdditionalDocument,
      treeView: ConfigurationTreeView
    },
    meta: metaWithModel,
    beforeEnter: (to: any, from: any, next: any) => {
      RouteHelpers.setErrorPageRedirect(Configuration.DocuSign.AdditionalDocument.Management.name);
      RouteHelpers.beforeEnterCheckRouteParamAsNumeric(to, from, next, ['id']);
    }
  },
  {
    ...Configuration.DocuSign.AdditionalDocument.Add,
    components: {
      default: DocusignAddAdditionalDocument,
      treeView: ConfigurationTreeView
    },
    meta: metaWithModel
  },
  {
    ...Configuration.DocuSign.AdditionalDocumentSignTab.Management,
    components: {
      default: DocusignAdditionalDocumentSignTabManagement,
      treeView: ConfigurationTreeView
    },
    meta,
    beforeEnter: (to: any, from: any, next: any) => {
      RouteHelpers.setErrorPageRedirect(Configuration.DocuSign.AdditionalDocument.Management.name);
      RouteHelpers.beforeEnterCheckRouteParamAsNumeric(to, from, next, ['id']);
    }
  },
  {
    ...Configuration.DocuSign.AdditionalDocumentSignTab.Edit,
    components: {
      default: DocusignEditAdditionalDocumentSignTab,
      treeView: ConfigurationTreeView
    },
    meta,
    beforeEnter: (to: any, from: any, next: any) => {
      RouteHelpers.setErrorPageRedirect(Configuration.DocuSign.AdditionalDocument.Management.name);
      RouteHelpers.beforeEnterCheckRouteParamAsNumeric(to, from, next, ['additionalDocumentId', 'id']);
    }
  },
  {
    ...Configuration.DocuSign.AdditionalDocumentSignTab.Add,
    components: {
      default: DocusignAddAdditionalDocumentSignTab,
      treeView: ConfigurationTreeView
    },
    meta,
    beforeEnter: (to: any, from: any, next: any) => {
      RouteHelpers.setErrorPageRedirect(Configuration.DocuSign.AdditionalDocument.Management.name);
      RouteHelpers.beforeEnterCheckRouteParamAsNumeric(to, from, next, ['id']);
    }
  }
];
