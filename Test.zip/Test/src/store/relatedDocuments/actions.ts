import { RelatedDocumentsState } from '@/types/store/RelatedDocumentsState';
import { ActionTree } from 'vuex';
import { RootState, RelatedDocumentModel, DocumentSearchModel, RelatedDocumentsModel } from '@/types';
import { RelatedDocumentsService } from '@/services/RelatedDocumentsService';
import moment from 'moment';

export const actions: ActionTree<RelatedDocumentsState, RootState> = {
  getRelatedDocuments({ commit }, documentSearchModel: DocumentSearchModel) {
    commit('LOADING');
    RelatedDocumentsService.getRelatedDocumentsAsync(documentSearchModel).then(
      (response: RelatedDocumentsModel) => {
        addDateFormatter(response);
        const payload: RelatedDocumentsModel = response;
        commit('RELATED_DOCUMENTS_LOADED', payload);
      },
      (error: any) => {
        commit('RELATED_DOCUMENTS_ERROR', error);
      }
    );
  },
  unloadRelatedDocuments({ commit }) {
    commit('UNLOAD_RELATED_DOCUMENTS');
  },
  setRelationshipBeingViewed({ commit }, linkId: number) {
    commit('RELATIONSHIP_BEING_VIEWED', linkId);
  }
};

function addDateFormatter(this: any, relatedDocuments: RelatedDocumentsModel) {
  relatedDocuments.columns.forEach((column) => {
    if (column.key === 'cb_docdate') {
      column.formatter = (value: any) => {
        const locale = window.navigator.language;
        return value ? moment(value).locale(locale).format('L LT').split(' ')[0] : null;
      };
    }
  });
}
