<template>
  <div>
    <LoadingSpinner :isLoading="isLoading"></LoadingSpinner>
    <div v-show="!isLoading">
      <b-table
        small
        head-variant="primary"
        bordered
        sticky-header="284px"
        :items="workflowJobHistoryData.historyData"
        :fields="workflowJobHistoryData.historyColumns"
      />
    </div>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  import { WorkflowJobService } from '@/services/WorkflowJobService';
  import { WorkflowJobHistoryDataModel } from '@/types';
  import LoadingSpinner from '@/components/shared/LoadingSpinner.vue';
  import { WorkflowJobModel } from '@/types';
  import { BTableHelpers } from '@/mixins/bTable';

  export default Vue.extend({
    name: 'WorkflowJobHistoryTab',
    mixins: [BTableHelpers],
    props: {
      workflowJobModel: {
        type: Object as () => WorkflowJobModel,
        required: true
      }
    },
    methods: {
      async getWorkflowJobHistoryAsync(this: any, jobId: number) {
        this.isLoading = true;
        this.workflowJobHistoryData = await WorkflowJobService.getWorkflowJobHistoryAsync(jobId).catch(
          (reason: any) => {
            this.isLoading = false;
          }
        );
        this.isLoading = false;
      }
    },
    data() {
      return {
        workflowJobHistoryData: {} as WorkflowJobHistoryDataModel,
        isLoading: false
      };
    },
    mounted() {
      this.getWorkflowJobHistoryAsync(this.workflowJobModel.jobId);
    },
    components: {
      LoadingSpinner
    }
  });
</script>
