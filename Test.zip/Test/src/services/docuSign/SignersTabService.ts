import axios from 'axios';
import { SignersTabModel, WorkflowDataSourceModel } from '@/types';

const SignerTabApiUrl = 'docusign/signerstab/';

export const SignersTabService = {
  async getSignersTabAsync(jobId: number): Promise<SignersTabModel> {
    const response = await axios.get(`${SignerTabApiUrl}${jobId}`);
    return response.data;
  },
  async updateSignersTabDataSourceAsync(jobId: number, signersTabDataSource: WorkflowDataSourceModel) {
    await axios.post(`${SignerTabApiUrl}${jobId}`, signersTabDataSource);
  }
};
