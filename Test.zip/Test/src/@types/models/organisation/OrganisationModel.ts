export interface OrganisationModel {
  clientId: number;
  Name: string;
}
