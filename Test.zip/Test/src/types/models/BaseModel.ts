export interface BaseModel {
  notification: string;
  hasNotification: boolean;
  showToast: boolean;
  errorCode: number;
}
