export interface DocuSignSignerRoleCreateUpdateModel {
    description: string;
    common: boolean;
    enter: boolean;
    useDataSourceForName: boolean;
    nameDataSourceKey: string;
    nameDataFieldKey: string;
    useDataSourceForEmailAddress: boolean;
    emailAddressDataSourceKey: string;
    emailAddressDataFieldKey: string;
    useListForNameAndEmailAddress: boolean;
    listId: number | null;
    mustBeSameRecipientWithinEnvelope: boolean;
}