import { debounce } from 'vue-debounce';
export const TreeViewHelpers = {
  updated(this: any) {
    this.$nextTick(
      debounce(() => {
        const selectedNode = document.querySelector('.tree-node.selected');
        selectedNode?.scrollIntoView(false);
      }, 250)
    );
  },
  methods: {
    selectNode(node: any) {
      node = node[0];
      if (node) {
        node.select();
        this.expandParentNode(node);
      }
    },
    unselectNode(node: any) {
      node = node[0];
      if (node) {
        node.unselect();
        this.collapseParentNode(node);
      }
    },
    expandParentNode(node: any) {
      const parentNode = node.parent;
      if (parentNode) {
        parentNode.expand();
        this.expandParentNode(parentNode);
      }
    },
    collapseParentNode(node: any) {
      const parentNode = node.parent;
      if (parentNode) {
        parentNode.collapse();
        this.collapseParentNode(parentNode);
      }
    },
    expandAll(this: any, treeName: string) {
      const treeElement = this.$refs[treeName];
      if (treeElement) {
        treeElement.expandAll();
      }
    },
    collapseAll(this: any, treeName: string) {
      const treeElement = this.$refs[treeName];
      if (treeElement) {
        treeElement.collapseAll();
      }
    }
  }
};
