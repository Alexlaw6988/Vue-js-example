import { BaseDocumentSearchModel } from './BaseDocumentSearchModel';

export interface DocumentSearchModel extends BaseDocumentSearchModel {
  page: number;
  viewConversionId: number;
}
