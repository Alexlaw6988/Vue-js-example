<template>
  <b-form-checkbox
    class="mt-1 mb-3"
    :id="inputProperties.htmlElementId"
    v-model="inputValue"
    :required="inputProperties.isRequired"
    :disabled="inputProperties.isReadonly || isDisabled"
  >
    <div class="mt-05">{{ inputProperties.fieldLabel }}</div>
  </b-form-checkbox>
</template>

<script lang="ts">
  import Vue from 'vue';

  export default Vue.extend({
    name: 'WorkflowFormCheckbox',
    props: {
      inputProperties: {
        type: Object,
        required: true
      },
      data: {
        required: true
      },
      isDisabled: {
        type: Boolean,
        default: false
      }
    },
    computed: {
      inputValue: {
        get(this: any) {
          return this.data;
        },
        set(this: any, value: string) {
          this.$emit('update:data', value);
        }
      }
    }
  });
</script>
