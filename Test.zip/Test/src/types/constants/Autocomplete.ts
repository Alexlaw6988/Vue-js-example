export const Autocomplete = {
  off: 'off',
  on: 'on',
  newPassword: 'new-password',
  nope: 'nope'
};
