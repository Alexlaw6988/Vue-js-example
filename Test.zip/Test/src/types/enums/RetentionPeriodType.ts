export enum RetentionPeriodType {
  None = 1,
  Days = 2,
  Weeks = 3,
  Months = 4,
  Years = 5
}
