declare module 'vue-slide-up-down';
