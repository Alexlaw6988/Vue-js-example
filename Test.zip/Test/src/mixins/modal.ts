import { ColourVariantType } from '@/types/enums/ColourVariantType';
import { OkCancelModalSettingsModel } from '@/types/models/modal';
import { VNode } from 'vue';

export const ModalHelpers = {
  methods: {
    async showUnsavedChangesModalAsync(modal: any, message: string): Promise<boolean> {
      let confirmed: boolean = false;
      await modal
        .msgBoxConfirm(message ? message : 'You have unsaved changes', {
          title: 'Are you sure?',
          okVariant: 'danger',
          okTitle: 'Discard Changes',
          cancelVariant: 'primary',
          cancelTitle: 'Cancel'
        })
        .then((result: boolean) => {
          confirmed = result;
        });
      return confirmed;
    },
    async showConfirmationModalAsync(modal: any, message: string): Promise<boolean> {
      let confirmed: boolean = false;
      await modal
        .msgBoxConfirm(message, {
          title: 'Are you sure?',
          okVariant: 'danger',
          okTitle: 'Yes',
          cancelVariant: 'primary',
          cancelTitle: 'No'
        })
        .then((result: boolean) => {
          confirmed = result;
        });
      return confirmed;
    },
    async showConfirmationHtmlModalAsync(this: any, modal: any, html: string): Promise<boolean> {
      const messageHtml = [this.$createElement('div', { domProps: { innerHTML: html } })];
      return await modal.msgBoxConfirm(messageHtml, {
        title: 'Are you sure?',
        okVariant: 'danger',
        okTitle: 'Yes',
        cancelVariant: 'primary',
        cancelTitle: 'No'
      });
    },

    async showOkHtmlModalAsync(this: any, modal: any, title: any, html: string): Promise<boolean> {
      const messageHtml = [this.$createElement('div', { domProps: { innerHTML: html } })];
      return await modal.msgBoxOk(messageHtml, {
        title,
        okVariant: 'danger',
        okTitle: 'Ok'
      });
    },
    async showDeleteModalAsync(modal: any, message: string): Promise<boolean> {
      let confirmed: boolean = false;
      await modal
        .msgBoxConfirm(message ? message : 'Are you sure you want to delete this?', {
          title: 'Are you sure?',
          okVariant: 'danger',
          okTitle: 'Delete',
          cancelVariant: 'primary',
          cancelTitle: 'Cancel'
        })
        .then((result: boolean) => {
          confirmed = result;
        });
      return confirmed;
    },
    async showDeleteModalVNodeAsync(modal: any, vNodemessage: any): Promise<boolean> {
      let confirmed: boolean = false;
      await modal
        .msgBoxConfirm([vNodemessage], {
          title: 'Are you sure?',
          okVariant: 'danger',
          okTitle: 'Delete',
          cancelVariant: 'primary',
          cancelTitle: 'Cancel'
        })
        .then((result: boolean) => {
          confirmed = result;
        });
      return confirmed;
    },
    async showOkCancelModalAsync(modal: any, okModal: OkCancelModalSettingsModel): Promise<boolean> {
      let okClicked: boolean = false;

      await modal
        .msgBoxConfirm(okModal.message, {
          title: okModal.title,
          okVariant: okModal.okVariant ? okModal.okVariant : ColourVariantType.Primary,
          okTitle: okModal.okTitle ? okModal.okTitle : 'OK',
          cancelVariant: okModal.cancelVariant ? okModal.cancelVariant : ColourVariantType.Danger,
          cancelTitle: okModal.cancelTitle ? okModal.cancelTitle : 'Cancel'
        })
        .then((result: boolean) => {
          okClicked = result;
        });

      return okClicked;
    }
  }
};
