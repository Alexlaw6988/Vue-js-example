import router from '@/router';
import store from '@/store';
import { mapGetters } from 'vuex';
import { ObjectHelper } from './objectHelper';

export const RouteHelpers = {
  beforeEnterCheckRouteParamAsNumeric(to: any, from: any, next: any, numericParams: string[]) {
    const incorrectParams = numericParams.filter((x: string) => ObjectHelper.methods.isNaN(to.params[x]));
    if (incorrectParams.length) {
      router.push({
        name: 'errorPage',
        params: {
          errorCode: '404',
          errorMessage: 'Sorry, the request parameters are invalid'
        }
      });
    }
    next();
  },
  beforeEnterCheckthePropsForErrorPage(to: any, from: any, next: any) {
    const key = 'previousError';
    if (!to.params.errorCode && !to.params.errorMessage) {
      const params = JSON.parse(localStorage.getItem(key)!);
      router.push({
        name: 'errorPage',
        params
      });
      return;
    }
    localStorage.setItem(key, JSON.stringify(to.params));
    next();
  },
  setErrorPageRedirect(routeName: string) {
    store.dispatch('userStore/errorPageRoute', {
      name: routeName,
      params: {}
    });
  },
  methods: {
    navigateToRoute(this: any, routeName: any, data: any = null, paramName: string = 'id') {
      const param = {} as { [index: string]: any };
      param[paramName] = data;
      this.$router.push({
        name: routeName,
        params: data ? param : undefined
      });
    },
    canKeepState(this: any, routeRegEx: string) {
      return this.previousRoute?.currentRoute?.name?.toLowerCase().match(routeRegEx);
    }
  },
  computed: {
    ...mapGetters('userStore', ['previousRoute'])
  }
};
