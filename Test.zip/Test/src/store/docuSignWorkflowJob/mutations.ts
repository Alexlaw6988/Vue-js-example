import { DocuSignWorkflowJobState, DocuSignWorkflowJobMutationTypes, SignersTabModel, FieldUpdateModel } from '@/types';
import { MutationTree } from 'vuex';

export const mutations: MutationTree<DocuSignWorkflowJobState> = {
  [DocuSignWorkflowJobMutationTypes.SetIsSignersTabLoading](state, isLoading: boolean) {
    state.isSignersTabLoading = isLoading;
  },
  [DocuSignWorkflowJobMutationTypes.SignersTabLoaded](state, payload: SignersTabModel) {
    state.errorMessage = '';
    state.error = false;
    state.signersTab = payload;
    state.isSignersTabLoading = false;
  },
  [DocuSignWorkflowJobMutationTypes.SignersTabError](state, payload: any) {
    state.errorMessage = JSON.stringify(payload);
    state.error = true;
    state.signersTab = {} as SignersTabModel;
    state.isSignersTabLoading = false;
  },
  [DocuSignWorkflowJobMutationTypes.UpdateSignersDataSourceFieldValue](state, payload: FieldUpdateModel) {
    if (state.signersTab && state.signersTab.signersDataSource) {
      (state.signersTab.signersDataSource.fields as any)[payload.fieldName] = payload.value;
    }
  },
  [DocuSignWorkflowJobMutationTypes.UnloadSignersWorkflowJob](state, payload) {
    const initState = {
      signersTab: {} as SignersTabModel,
      isSignersTabLoading: true,
      isLoading: false,
      error: false,
      errorMessage: ''
    } as DocuSignWorkflowJobState;
    Object.assign(state, initState);
  }
};
