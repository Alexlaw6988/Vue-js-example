export const DocumentTypes = {
  MyDocuments: 'myDocuments',
  EveryonesDocuments: 'everyonesDocuments'
};