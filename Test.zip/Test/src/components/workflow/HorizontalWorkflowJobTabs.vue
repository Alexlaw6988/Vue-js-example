<template>
  <div class="horizontal-tabs bg-light-gray border-top">
    <div class="horizontal-tab-header border-bottom">
      <span class="horizontalTabExpandButton float-left" @click="onHorizontalTabExpandButtonClick()">
        <font-awesome-icon :icon="horizontalTabExpandButtonIcon" />
      </span>
      <b-tabs ref="horizontalTabButtons " class="horizontal-tab-buttons">
        <template slot="tabs-end">
          <b-nav-item
            v-for="tab in horizontalJobTabs"
            :key="tab.key"
            :class="`border-right  border-bottom ${activeHorizontalTab.key == tab.key ? 'selected' : ''}`"
            @click="onHorizontalTabClick(tab.key)"
          >
            {{ tab.description }}
            <span v-if="jobTabState(tab.key).showCount" class="ml-1 align-items-center">
              <b-badge pill variant="danger">{{ jobTabState(tab.key).itemCount }}</b-badge>
            </span>
          </b-nav-item>
        </template>
      </b-tabs>
    </div>

    <div :class="`bg-white ${activeHorizontalTab.key ? 'border-bottom' : ''}`">
      <slide-up-down :active="activeHorizontalTab.key != ''">
        <div
          class="p-3 slide-up"
          v-for="workflowTab in horizontalWorkflowJobTabs"
          :key="workflowTab.key"
          v-show="activeHorizontalTab.key == workflowTab.key"
        >
          <workflow-dynamic-form
            storeNamespace="workflowJobStore"
            storeGetter="workflowDataSourceField"
            storeAction="setWorkflowDataSourceField"
            :documentSearchModel="workflowJob.documentSearchModel"
            v-bind:dynamic-form-model="workflowTab.dynamicFormModel"
            :ignoreRequiredFieldsValidation="isCancelProcess"
            :isLoading="isLoading"
          />
        </div>
        <div
          class="p-2 slide-up standard"
          v-for="preloadTab in preloadTabs"
          :key="preloadTab.key"
          v-show="activeHorizontalTab.key == preloadTab.key"
        >
          <component
            :is="preloadTab.componentName"
            :dataSources="workflowDataSources"
            :workflowJobModel="workflowJob"
            v-on:tabItemCountChanged="updateItemCount"
            v-on:tabIsDirtyChanged="updateIsDirty"
            :tab-key="preloadTab.key"
            :job-tab-orientation="preloadTab.jobTabOrientation"
          />
        </div>
        <div
          class="p-2 slide-up standard"
          v-if="activeTabIsStandardTabWithoutPreload && !activeTabIsStandardTabAndHasAlreadyBeenLoaded"
        >
          <component
            :is="activeTab.componentName"
            :dataSources="workflowDataSources"
            :workflowJobModel="workflowJob"
            v-on:tabItemCountChanged="updateItemCount"
            v-on:tabIsDirtyChanged="updateIsDirty"
            :tab-key="activeTab.key"
            :job-tab-orientation="activeTab.jobTabOrientation"
          />
        </div>
        <div
          class="p-2 slide-up standard"
          v-for="loadedTab in loadedTabs"
          :key="loadedTab.key"
          v-show="activeHorizontalTab.key == loadedTab.key"
        >
          <component
            :key="loadedTabKey(loadedTab)"
            :is="loadedTab.componentName"
            :dataSources="workflowDataSources"
            :workflowJobModel="workflowJob"
            v-on:tabItemCountChanged="updateItemCount"
            v-on:tabIsDirtyChanged="updateIsDirty"
            :tab-key="loadedTab.key"
            :job-tab-orientation="loadedTab.jobTabOrientation"
          />
        </div>
      </slide-up-down>
    </div>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  import {
    WorkflowJobTabModel,
    WorkflowJobTabType,
    TabStateModel,
    WorkflowStandardProcessingAction
  } from '@/types';
  import WorkflowDynamicForm from '@/components/workflow/WorkflowDynamicForm.vue';
  import WorkflowJobHistoryTab from '@/components/workflow/standardtabs/WorkflowJobHistoryTab.vue';
  import WorkflowJobAuditTab from '@/components/workflow/standardtabs/WorkflowJobAuditTab.vue';
  import WorkflowDocumentInformationTab from '@/components/workflow/standardtabs/WorkflowDocumentInformationTab.vue';
  import { WorkflowFormValidation, workflowTabsHelper } from '@/mixins';
  import WorkflowNarrativeTab from '@/components/workflow/standardtabs/WorkflowNarrativeTab.vue';
  import WorkflowVersionsTab from '@/components/workflow/standardtabs/WorkflowVersionsTab.vue';
  import WorkflowRelatedDocumentsTab from '@/components/workflow/standardtabs/WorkflowRelatedDocumentsTab.vue';
  import { mapGetters, mapActions } from 'vuex';
  import ResizeObserver from 'resize-observer-polyfill';

  export default Vue.extend({
    name: 'HorizontalWorkflowJobTabs',
    mixins: [WorkflowFormValidation, workflowTabsHelper],
    props: {
      processingAction: {
        type: Number,
        validator: (processingAction: number) => WorkflowStandardProcessingAction[processingAction] !== undefined,
        required: true
      },
      isLoading: {
        type: Boolean,
        default: false
      }
    },
    data() {
      return {
        loadedTabs: [] as WorkflowJobTabModel[],
        tabBottomPosition: 0,
        borderSize: 1,
        resizeObserver: {} as ResizeObserver,
        jobTabOrientation: 'horizontal'
      };
    },
    methods: {
      ...mapActions('workflowJobStore', ['setActiveHorizontalTab', 'setJobTabStateCount', 'setJobTabStateDirty']),
      updateItemCount(this: any, result: TabStateModel) {
        this.setJobTabStateCount(result);
      },
      updateIsDirty(this: any, result: TabStateModel) {
        this.setJobTabStateDirty(result);
      },
      loadedTabKey(this: any, loadedTab: WorkflowJobTabModel): string {
        return loadedTab.componentName === 'DocumentInformationTab'
          ? this.documentSearchModel.documentId
          : loadedTab.key;
      },
      onHorizontalTabClick(this: any, tabKey: string) {
        this.setActiveHorizontalTab(tabKey);
      },
      onHorizontalTabExpandButtonClick(this: any) {
        const tabKey = this.activeHorizontalTab?.key ? this.activeHorizontalTab.key : this.horizontalJobTabs[0]?.key;
        this.onHorizontalTabClick(tabKey);
      }
    },
    watch: {
      activeHorizontalTab(this: any, activeTab: WorkflowJobTabModel) {
        if (this.activeTabIsStandardTabWithoutPreload && !this.loadedTabs.includes(activeTab)) {
          this.loadedTabs.push(activeTab);
        }
      }
    },
    computed: {
      ...mapGetters('workflowJobStore', [
        'workflowJob',
        'horizontalJobTabs',
        'horizontalWorkflowJobTabs',
        'workflowDataSources',
        'activeHorizontalTab',
        'jobTabState'
      ]),
      ...mapGetters('documentViewStore', ['documentSearchModel']),
      preloadTabs(this: any): WorkflowJobTabModel[] {
        return this.horizontalJobTabs.filter(
          (x: WorkflowJobTabModel) => x.workflowJobTabType !== WorkflowJobTabType.Workflow && x.preLoad
        );
      },
      activeTabIsStandardTabWithoutPreload(this: any): boolean {
        return (
          this.activeHorizontalTab.workflowJobTabType === WorkflowJobTabType.Standard &&
          !this.activeHorizontalTab.preLoad
        );
      },
      activeTabIsStandardTabAndHasAlreadyBeenLoaded(this: any): boolean {
        return (
          this.loadedTabs.includes(this.activeHorizontalTab) &&
          this.activeHorizontalTab.workflowJobTabType === WorkflowJobTabType.Standard
        );
      },
      isCancelProcess(this: any): boolean {
        return this.processingAction === WorkflowStandardProcessingAction.CancelJob;
      },
      horizontalTabExpandButtonIcon(this: any): string {
        return this.activeHorizontalTab?.key ? 'angle-double-down' : 'angle-double-up';
      }
    },
    components: {
      WorkflowDynamicForm,
      WorkflowJobHistoryTab,
      WorkflowJobAuditTab,
      WorkflowDocumentInformationTab,
      WorkflowNarrativeTab,
      WorkflowVersionsTab,
      WorkflowRelatedDocumentsTab
    }
  });
</script>
