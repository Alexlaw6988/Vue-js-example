import { VNode } from 'vue/types';

export const onIntersect = {
  inserted(element: HTMLElement, binding: any, vnode: VNode) {
    let emitTimer: any = null;
    const emitTimeout: number = binding.value?.emitTimeout ? binding.value.emitTimeout : undefined;

    function cancelPendingTimeout() {
      clearTimeout(emitTimer);
      emitTimer = null;
    }

    function registerObserver() {
      function handleIntersection(entries: IntersectionObserverEntry[], observer: IntersectionObserver) {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            emitTimer = setTimeout(() => {
              vnode.componentInstance?.$emit('isIntersected');
              observer.unobserve(entry.target);
            }, emitTimeout);
          } else if (emitTimer !== null) {
            cancelPendingTimeout();
          }
        });
      }

      const options = {
        root: binding.value?.rootSelector ? document.querySelector(binding.value.rootSelector) : element.parentElement,
        rootMargin: binding.value?.margin ? binding.value.margin : '0px',
        threshold: binding.value?.threshold ? binding.value.threshold : 0.0
      };

      const observer = new IntersectionObserver(handleIntersection, options);
      observer.observe(element);
    }

    function emitImmediatelyOnNonSupportedBrowser() {
      vnode.componentInstance?.$emit('isIntersected');
    }

    if ('IntersectionObserver' in window) {
      registerObserver();
    } else {
      emitImmediatelyOnNonSupportedBrowser();
    }
  }
};
