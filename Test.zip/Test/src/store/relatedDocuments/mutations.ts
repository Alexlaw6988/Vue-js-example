import { RelatedDocumentsState } from '@/types/store/RelatedDocumentsState';
import { MutationTree } from 'vuex';
import { RelatedDocumentsModel, RelatedDocumentModel } from '@/types';

export const mutations: MutationTree<RelatedDocumentsState> = {
  LOADING(state) {
    state.isLoading = true;
  },
  RELATED_DOCUMENTS_LOADED(state, payload: RelatedDocumentsModel) {
    state.isLoading = false;
    state.error = false;
    state.relatedDocumentsModel = payload;
  },
  RELATED_DOCUMENTS_ERROR(state, payload: any) {
    state.isLoading = false;
    state.error = true;
    state.errorMessage = JSON.stringify(payload);
    state.relatedDocumentsModel = {} as RelatedDocumentsModel;
  },
  UNLOAD_RELATED_DOCUMENTS(state) {
    const initState = {
      relatedDocumentsModel: {
        relatedDocuments: [],
        count: 0,
        columns: [],
        documentTypes: []
      } as RelatedDocumentsModel,
      isLoading: false,
      error: false,
      errorMessage: ''
    } as RelatedDocumentsState;
    Object.assign(state, initState);
  },
  RELATIONSHIP_BEING_VIEWED(state, payload: number) {
    state.relatedDocumentsModel.relatedDocuments.forEach((item) => {
      item.visible = item.linkId === payload;
    });
  }
};
