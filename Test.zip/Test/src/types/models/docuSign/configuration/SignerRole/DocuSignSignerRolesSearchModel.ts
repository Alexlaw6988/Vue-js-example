export interface DocuSignSignerRolesSearchModel {
  documentTypeId: number | null;
}
