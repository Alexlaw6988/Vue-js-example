export const DocumentConstants = {
  ASeriesPaperAspectRatio: 0.7
};
