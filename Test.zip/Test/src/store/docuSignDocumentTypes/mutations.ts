import { MutationTree } from 'vuex';
import { DocuSignDocumentTypesState, DocuSignDocumentTypesMutationTypes } from '@/types';
import { docuSignDocumentTypes } from '../docuSignDocumentTypes';

export const mutations: MutationTree<DocuSignDocumentTypesState> = {
    [DocuSignDocumentTypesMutationTypes.ResetState](state) {
        Object.assign(state, docuSignDocumentTypes.defaultDocuSignDocumentTypesState());
    },
    [DocuSignDocumentTypesMutationTypes.SetDocumentType](state, documentTypeId: number) {
        state.documentTypeId = documentTypeId;
    }
};