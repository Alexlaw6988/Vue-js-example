import axios from 'axios';
import { ComponentVersionModel } from '@/types';

const ComponentVersionApiUrl = 'componentversion/';

export const ComponentVersionService = {
  async getComponentVersions(): Promise<ComponentVersionModel[]> {
    const response = await axios.get(ComponentVersionApiUrl);
    return response.data;
  }
};
