export enum FieldState {
  Valid,
  Dirty,
  Changed
}
