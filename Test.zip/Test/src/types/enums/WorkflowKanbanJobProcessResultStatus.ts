export enum WorkflowKanbanJobProcessResultStatus {
  UnableToAcquireLock,
  PopUpFieldsRequired,
  ProcessSuccessful,
  IllegalLaneMove
}