export enum RouteRegEx {
  User = '(view|edit|add|copy)user',
  Organisation = '(view|edit|add)organisation',
  Role = '(view|edit|add|copy)role',
  WorkflowQueue = 'workflowjob',
  DocuSignAdditionalDocuments = 'docusignaddadditionaldocument|docusigneditadditionaldocument',
  DocuSignAdditionalDocumentTabs = 'docusigneditadditionaldocumentsigntab|docusignaddadditionaldocumentsigntab',
  DocuSignSignerRoles = 'docusigneditsignerrole|docusignaddsignerrole',
  DocuSignTemplateAfterSignMappings = 'docusignedittemplateaftersignmappings',
  DocuSignTemplates = 'docusignedittemplate|docusignaddtemplate',
  DocuSignTemplateSignHeres = 'docusignedittemplatesignhere|docusignaddtemplatesignhere',
  DocuSignTemplateAdditionalDocuments = 'docusignedittemplateadditionaldocument|docusignaddtemplateadditionaldocument',
}