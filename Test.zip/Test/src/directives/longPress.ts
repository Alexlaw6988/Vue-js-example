import { DeviceConstants } from '@/types/constants/DeviceConstants';
import { LongPressEventType, MouseButton } from '@/types/enums';

const touchPointerEvents = DeviceConstants.TouchPointerEvents;
const startEvents = [touchPointerEvents.MouseDown, touchPointerEvents.TouchStart];
const cancelEvents = [
  touchPointerEvents.Click,
  touchPointerEvents.MouseOut,
  touchPointerEvents.TouchEnd,
  touchPointerEvents.TouchCancel
];

export const onLongPress = {
  bind(element: any, binding: any) {
    const longPressDetectionDelay = 700;
    let pressTimer: any = null;
    let pressed = false;
    const start = (e: any) => {
      if (
        (e.type === touchPointerEvents.Click || e.type === touchPointerEvents.MouseDown) &&
        e.button !== MouseButton.Main
      ) {
        return;
      }
      if (pressTimer === null) {
        pressTimer = setTimeout(() => press(), longPressDetectionDelay);
      }
    };

    function press() {
      pressed = true;
      binding.value(LongPressEventType.Press);
    }

    const cancel = (e: any) => {
      if (pressTimer !== null) {
        clearTimeout(pressTimer);
        pressTimer = null;
      }
      if (pressed) {
        pressed = false;
        binding.value(LongPressEventType.Release);
        return;
      }
      if (e.type === touchPointerEvents.Click) {
        binding.value(LongPressEventType.Click);
      }
    };

    startEvents.forEach((e) => element.addEventListener(e, start));
    cancelEvents.forEach((e) => element.addEventListener(e, cancel));
  },
  unbind(element: any, binding: any) {
    startEvents.forEach((e) => element.removeEventListener(binding.arg, null));
    cancelEvents.forEach((e) => element.removeEventListener(binding.arg, null));
  }
};
