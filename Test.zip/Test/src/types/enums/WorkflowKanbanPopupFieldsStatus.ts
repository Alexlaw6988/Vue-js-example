export enum WorkflowKanbanPopupFieldsStatus {
  None = 0,
  Displayed = 1,
  Processing = 2,
  ProcessSuccessful = 3,
  ProcessCancelled = 4,
  ProcessFailed = 5
}