import { OrganisationRoutes } from './organisation';
import { UserManagementRoutes } from './user';
import { RoleManagementRoutes } from './role';
import { LeaverRuleRoutes } from './leaverRule';
import { DocuSignRoutes } from './docuSign';
import { Configuration } from '@/types';
import ConfigurationTreeView from '@/components/configuration/TreeView.vue';

const ConfigurationDashboard = () =>
  import(
    /* webpackChunkName: "configuration" */
    '@/views/configuration/ConfigurationDashboard.vue'
  );

export const ConfigurationRoutes = [
  {
    path: Configuration.Base.path,
    name: Configuration.Base.name,
    components: {
      default: ConfigurationDashboard,
      treeView: ConfigurationTreeView
    },
    meta: {
      layout: 'TreeView'
    }
  },
  ...OrganisationRoutes,
  ...UserManagementRoutes,
  ...RoleManagementRoutes,
  ...LeaverRuleRoutes,
  ...DocuSignRoutes
];
