import Vue from 'vue';
import Vuex from 'vuex';
import { vuexOidcCreateStoreModule } from 'vuex-oidc';
import { user } from './user';
import { oidcSettings } from '@/settings/oidcSettings';
import { mstoreSettings } from '@/settings/mstoreSettings';
import { documentView } from './documentView';
import { relatedDocuments } from './relatedDocuments';
import { list } from './list';
import { workflowJob } from './workflowJob';
import { workflowQueue } from './workflowQueue';
import { userManagement } from './userManagement';
import { organisationManagement } from './organisationManagement';
import { userPreferences } from './userPreferences';
import createPersistedState from 'vuex-persistedstate';
import { automotiveWorklowJob } from './automotiveWorklowJob';
import { mTable } from './mtable';
import { docuSignWorklowJob } from './docuSignWorkflowJob';
import { applicationDirty } from './applicationDirty';
import { appSettings } from './appSettings';
import { docuSignSignerRoleManagement } from './docuSignSignerRoleManagement';
import { mGroupedTable } from './mGroupedTable';
import { docuSignTemplateManagement } from './docuSignTemplateManagement';
import { documentsToStore } from './documentsToStore';
import { workflowKanbanJob } from './workflowKanbanJob';
import { documentToStore } from './documentToStore';

Vue.use(Vuex);

const store = new Vuex.Store({
  modules: {
    oidcStore: vuexOidcCreateStoreModule(
      oidcSettings,
      {
        namespaced: true,
        dispatchEventsOnWindow: true
      },
      {
        userSignedOut: () => store.dispatch('oidcStore/authenticateOidc'),
        accessTokenExpired: () => store.dispatch('oidcStore/signOutOidc'),
        userLoaded: (user: any) => store.dispatch('userStore/updateCurrentUser', user)
      }
    ),
    userStore: user as any,
    documentViewStore: documentView as any,
    mstoreSettingsStore: mstoreSettings as any,
    relatedDocumentsStore: relatedDocuments as any,
    workflowJobStore: workflowJob as any,
    listStore: list as any,
    workflowQueueStore: workflowQueue as any,
    userManagementStore: userManagement as any,
    organisationManagementStore: organisationManagement as any,
    userPreferencesStore: userPreferences as any,
    automotiveWorkflowJobStore: automotiveWorklowJob as any,
    mTableStore: mTable as any,
    docuSignWorkflowJobStore: docuSignWorklowJob as any,
    applicationDirtyStore: applicationDirty as any,
    appSettingsStore: appSettings as any,
    docuSignSignerRoleManagementStore: docuSignSignerRoleManagement as any,
    mGroupedTableStore: mGroupedTable as any,
    docuSignTemplateManagementStore: docuSignTemplateManagement as any,
    documentsToStoreStore: documentsToStore as any,
    workflowKanbanJobStore: workflowKanbanJob as any,
    documentToStoreStore: documentToStore as any
  },
  plugins: [
    createPersistedState({
      paths: ['userPreferencesStore']
    })
  ]
});

export default store;
