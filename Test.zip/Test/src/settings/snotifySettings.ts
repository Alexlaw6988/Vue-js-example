import { SnotifyPosition } from 'vue-snotify';

export const snotifySettings = {
  toast: {
    position: SnotifyPosition.rightBottom,
    icon: false,
    maxOnScreen: 4,
    bodyMaxLength: 400
  }
};
