export interface DocumentToStoreUploadModel {
  formFile: File;
  isDocumentToStoreDocument: boolean;
  isMyDocument: boolean;
  documentTypeId: number;
}
