<template>
  <div>
    <b-form-group :label="fieldLabel" :label-for="htmlElementId">
      <b-input-group :id="htmlElementId">
        <b-form-input class="danger" :name="fieldLabel" disabled value="Unsupported" />
        <b-input-group-append>
          <b-button disabled>
            <font-awesome-icon icon="exclamation-triangle" />
          </b-button>
          <b-tooltip :target="htmlElementId" placement="right">
            {{ message }}
          </b-tooltip>
        </b-input-group-append>
      </b-input-group>
    </b-form-group>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';

  export default Vue.extend({
    name: 'MStoreUnsupportedInput',
    props: {
      fieldLabel: {
        type: String,
        required: true
      },
      htmlElementId: {
        type: String,
        required: true
      },
      message: {
        type: String,
        default: null
      }
    }
  });
</script>
