import { DocuSignWorkflowJobState, RootState, SignersTabModel } from '@/types';
import { GetterTree } from 'vuex';

export const getters: GetterTree<DocuSignWorkflowJobState, RootState> = {
  isSignersTabLoading(state): boolean {
    return state.isSignersTabLoading;
  },
  signersTab(state): SignersTabModel {
    return state.signersTab;
  },
  signersTabFieldValue: (state) => (dataSourceKey: string, fieldName: string): object | undefined => {
    if (state.signersTab?.signersDataSource?.fields) {
      return (state.signersTab.signersDataSource.fields as any)[fieldName];
    }
    return undefined;
  }
};
