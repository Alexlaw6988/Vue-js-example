import { WorkflowQueueService } from '@/services/WorkflowQueueService';
import { WorkflowJobService } from '@/services/WorkflowJobService';
import { BTableHelpers } from './bTable';

export const GetNextJobs = {
  computed: {
    processNextJob(this: any) {
      return this.getNextJob && this.workflowJob?.canGetNextJob;
    },
    previousJobs(this: any) {
      return this.getNextJobsLists.nextJobsList.slice(0, this.currentJobIndex);
    },
    currentJobIndex(this: any) {
      return this.getNextJobsLists.nextJobsList.indexOf(this.jobId);
    },
    allJobsList(this: any) {
      return this.getNextJobsLists.allJobsList;
    },
    searchQuery(this: any) {
      return this.getTableStateField(this.workflowJob.queueId, 'searchQuery');
    },
    sortBy(this: any) {
      return this.getTableStateField(this.workflowJob.queueId, 'sortBy');
    },
    sortByDes(this: any) {
      return this.getTableStateField(this.workflowJob.queueId, 'sortDesc');
    }
  },
  methods: {
    nextJobId(this: any) {
      return this.nextJobsList[0];
    },
    initializeCanGetNextJob(this: any) {
      const workflowJobPreferences = this.getWorkflowJobPreferences(this.workflowJob.queueId);
      this.getNextJob = workflowJobPreferences.canGetNextJob;
      this.jobId = this.workflowJob.jobId;
      this.nextJobsList = this.getNextJobsLists.nextJobsList.slice(this.currentJobIndex + 1);
      if (this.nextJobsList.length === 0) {
        this.nextJobsList = this.previousJobs;
      }
    },
    async processGetNextJob(this: any) {
      this.isLoading = true;
      if (this.processNextJob) {
        if (this.nextJobsList.length === 0) {
          const newJobs = await this.checkForNewJobsAsync();
          if (!newJobs) {
            this.goBackToWorkflowQueue();
            return;
          }
        }
        this.checkNextJob();
      } else {
        this.goBackToWorkflowQueue();
      }
    },
    async checkNextJob(this: any) {
      const result = await WorkflowJobService.getWorkflowJobAsync(this.$route.params.queueId, this.nextJobId());
      if (result.canProcess) {
        this.gotoNextJob();
        return;
      }
      this.nextJobsList.shift();
      if (this.nextJobsList.length === 0) {
        this.nextJobsList = this.previousJobs;
      }
      this.processGetNextJob();
    },
    async gotoNextJob(this: any) {
      const jobId = this.nextJobId().toString();
      const queueId = this.$route.params.queueId.toString();
      this.setNextJobs(this.currentJobIndex);
      this.$router.push({
        name: 'WorkflowJob',
        params: {
          queueId,
          jobId
        }
      });
    },
    async checkForNewJobsAsync(this: any): Promise<boolean> {
      const jobs = await WorkflowQueueService.getWorkflowQueueAsync(this.workflowJob.queueId);
      const newJobsList = this.applyFilterAndSort(jobs.queueData, jobs.queueColumns);
      if (this.allJobsList) {
        const newJobs = newJobsList.filter((job: any) => this.allJobsList.indexOf(job) < 0);
        if (newJobs.length !== 0) {
          this.setNextJobsList(newJobs);
          this.nextJobsList = newJobs;
          return true;
        } else {
          return false;
        }
      } else {
        return false;
      }
    },
    setCanGetNextJobforCurrentQueue(this: any) {
      this.setCanGetNextJob({ queueId: this.workflowJob.queueId, canGetNextJob: this.getNextJob });
    },
    setNextJobs(this: any, index: number) {
      const jobs = this.getNextJobsLists.nextJobsList;
      jobs.splice(index, 1);
      this.setNextJobsList(jobs);
    },
    applyFilterAndSort(this: any, jobsList: any, jobFields: any) {
      let newJobs = jobsList.filter((job: any) =>
        BTableHelpers.methods.customTableFilter(jobFields, job, this.searchQuery)
      );
      if (newJobs?.length > 0) {
        newJobs = BTableHelpers.methods.customTableSort(newJobs, this.sortBy, this.sortDes);
        return newJobs.map((job: any) => job.jobid);
      }
      return newJobs;
    }
  }
};
