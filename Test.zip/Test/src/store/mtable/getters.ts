import { TableStateModel, RootState } from '@/types';
import { mTable } from '../mtable';
import { GetterTree } from 'vuex';

export const getters: GetterTree<TableStateModel[], RootState> = {
  getTableStateField: (state) => (field: keyof TableStateModel, stateKey: string): any => {
    const tableStateKey = stateKey ? stateKey : '';
    const indexPosition = state.findIndex((x: any) => x.stateKey === tableStateKey);
    const tableState = indexPosition !== -1 ? state[indexPosition] : mTable.defaultMtableState();
    return tableState[field];
  }
};
