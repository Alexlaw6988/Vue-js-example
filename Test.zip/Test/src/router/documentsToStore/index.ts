import { RouteHelpers } from '@/mixins';
import { DocumentsToStore } from '@/types';

const DocumentToStore = () => import('@/views/DocumentToStore.vue');

const DocumentsToStoreDashboard = () =>
  import(/* webpackChunkName: "documents-to-store" */'@/views/documentsToStore/dashboard.vue');
const DocumentsToStoreTreeView = () =>
  import(/* webpackChunkName: "documents-to-store" */'@/components/documentsToStore/TreeView.vue');

const layout = 'DocumentsToStoreTreeView';

const dashboardComponents = {
  default: DocumentsToStoreDashboard,
  treeView: DocumentsToStoreTreeView
};

export const DocumentsToStoreRoutes = [
  {
    ...DocumentsToStore.DocumentsToStore,
    component: DocumentToStore,
    beforeEnter: (to: any, from: any, next: any) =>
      RouteHelpers.beforeEnterCheckRouteParamAsNumeric(to, from, next, ['documentId'])
  },
  {
    ...DocumentsToStore.Base,
    components: dashboardComponents,
    meta: {
      layout
    }
  }
];