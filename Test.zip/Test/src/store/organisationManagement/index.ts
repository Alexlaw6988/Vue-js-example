import { actions } from './actions';
import { getters } from './getters';
import { mutations } from './mutations';
import { OrganisationManagementState } from '@/types';

export function defaultOrganisationManagementState() {
  return {
    showDeactivated: false,
    isLoading: false,
    error: false,
    errorMessage: ''
  } as OrganisationManagementState;
}

export const state: OrganisationManagementState = defaultOrganisationManagementState();

const namespaced: boolean = true;

export const organisationManagement = {
  namespaced,
  state,
  actions,
  getters,
  mutations,
  defaultOrganisationManagementState
};
