<template>
  <div class="h-100 text-center bg-light-gray w-100">
    <div class="h-100 d-inline-flex flex-column">
      <div class="card p-5 text-center m-auto bg-light-gray border-dark">
        <div class="text-center">
          <font-awesome-icon :icon="errorModel.icon" size="5x" class="mb-3" :class="errorModel.iconTheme" />
        </div>
        <h2 v-if="errorModel.showHeader" class="mb-2">{{ errorModel.header }}</h2>
        <h6>{{ errorModel.message }}</h6>
        <div v-show="errorModel.showButton">
          <b-button variant="primary" size="sm" class="mt-3" @click="navigate()">{{ errorModel.buttonText }}</b-button>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  import { ErrorModel } from '@/types';

  export default Vue.extend({
    name: 'ErrorNotification',
    props: {
      errorModel: {
        type: Object as () => ErrorModel,
        required: true
      }
    },
    methods: {
      navigate() {
        this.$router.push({
          name: this.errorModel.buttonRouteName,
          params: this.errorModel.buttonRouteParams
        });
      }
    }
  });
</script>
