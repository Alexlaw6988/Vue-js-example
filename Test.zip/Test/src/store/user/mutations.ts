import { MutationTree } from 'vuex';
import { UserState, UserModel } from '@/types';
import moment from 'moment';

export const mutations: MutationTree<UserState> = {
  LOADING(state) {
    state.isLoading = true;
  },
  CURRENT_USER_AUTHENTICATED(state) {
    state.postSignInIdleTime = moment().add(20, 'seconds');
  },
  CURRENT_USER_LOADED(state, payload: UserModel) {
    state.isLoading = false;
    state.error = false;
    state.currentUser = payload;
  },
  CURRENT_USER_ERROR(state, payload: any) {
    state.isLoading = false;
    state.error = true;
    state.errorMessage = JSON.stringify(payload);
    state.currentUser = {} as UserModel;
  },
  APP_ACTIVITY_WHILE_SIGNED_IN(state) {
    state.postSignInIdleTime = moment();
  },
  PREVIOUS_ROUTE(state, payload: any) {
    Object.assign(state.previousRoute.lastRoute, state.previousRoute.currentRoute);
    Object.assign(state.previousRoute.currentRoute, payload);

    const excludedErrorPageRoutes = ['oidcCallback', 'errorPage'];
    if (!excludedErrorPageRoutes.some((excludedRoute) => excludedRoute.includes(payload.name!))) {
      Object.assign(state.errorPageRoute.lastRoute, state.errorPageRoute.currentRoute);
      Object.assign(state.errorPageRoute.currentRoute, payload);
    }
  },
  ERROR_PAGE_ROUTE(state, payload: any) {
    Object.assign(state.errorPageRoute.lastRoute, state.errorPageRoute.currentRoute);
    Object.assign(state.errorPageRoute.currentRoute, payload);
  }
};
