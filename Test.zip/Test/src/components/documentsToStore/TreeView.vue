<template>
  <div id="m-treeview" @dragover.prevent @drop.stop.prevent>
    <div class="h-100">
      <TreeViewHeader title="Documents to Store" icon="folder" />
      <tree
        ref="tree"
        v-if="!loading"
        :data="treeData"
        :options="options"
        @node:clicked="navigate"
        @tree:mounted="getNode"
        class="h-40 tree-border"
      >
        <div
          class="tree-scope w-100"
          slot-scope="{ node }"
          @drop.prevent="addFile(node.data.id, $event)"
          @dragover="onDragOver(node.data.id)"
          @dragleave="onDragLeave(node.data.id)"
        >
          <template>
            <h6 class="text">
              <font-awesome-icon :icon="node.data.icon" size="lg" class="mr-1 text-primary" />
              {{ node.text }}
            </h6>
          </template>
        </div>
      </tree>
      <div
        class="p-1 pt-2 pb-2 file-upload-place-holder btn w-100 btn-secondary"
        @drop.prevent="
          buttonDragover = false;
          addFile(selectedDocumentType, $event);
        "
        @dragover="buttonDragover = true"
        @dragleave="buttonDragover = false"
        :class="{ 'drag-highlight': buttonDragover }"
        @click="onPickFile"
      >
        Drag and drop to add documents or click the icon to browse your device.
        <font-awesome-icon icon="upload" size="lg" class="mr-1 text-white float-right pointer" />
        <input
          type="file"
          style="display: none"
          ref="fileUpload"
          @change="addFile(selectedDocumentType, $event)"
          :accept="fileTypeWhiteList"
          multiple
        />
      </div>
      <div
        class="h-50 pb-3"
        @drop.prevent="
          gridDragover = false;
          addFile(selectedDocumentType, $event);
        "
        @dragover="gridDragover = true"
        @dragleave="gridDragover = false"
        :class="gridDragover ? 'drag-highlight' : ''"
      >
        <m-table
          v-if="!_isLoading"
          ref="documentsTable"
          class="w-100 pb-2"
          header-text=""
          :items="documents"
          :fields="fields"
          :is-loading="loading || isDataLoading"
          :can-hover-on-table-row="false"
          :show-hide-filters="true"
          :emit-filters="true"
          pk-field="documentId"
          :show-header="false"
          :pagination="false"
          :sticky-header="true"
          :row-class="selectedRowClass"
          :empty-text="emptyText"
          :sort-by="sortBy"
          :sort-desc="sortDesc"
          @on-items-changed="loadFirstDocument()"
        >
          <template slot="cell(actions)" slot-scope="row">
            <b-button
              data-testid="view-user-button"
              class="mr-1 mt-1"
              variant="info"
              size="sm"
              @click="storeDocument(row)"
            >
              Store
            </b-button>
            <b-button
              data-testid="edit-user-button"
              size="sm"
              variant="primary"
              class="mt-1"
              @click="viewDocument(row)"
              :disabled="documentIsBeingViewed(row.item)"
            >
              View
            </b-button>
          </template>
        </m-table>
      </div>
    </div>
    <b-modal
      size="md"
      id="modal"
      :visible="showModal"
      :no-close-on-backdrop="true"
      :no-close-on-esc="true"
      :hide-header-close="true"
      :centered="true"
      :hide-header="true"
      :hide-footer="true"
      body-class="progress-modal"
    >
      <div>
        <div v-for="(file, $index) in files" :key="file.file.name + $index" class="pt-3 pb-3">
          <h6>{{ file.file.name }}</h6>
          <b-progress :value="progress($index)" :max="max" show-progress animated></b-progress>
        </div>
      </div>
    </b-modal>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  import LiquorTree from 'liquor-tree';
  import LoadingSpinner from '@/components/shared/LoadingSpinner.vue';
  import { TreeViewHeader } from '@/components/shared';
  import { TreeViewHelpers } from '@/mixins/treeView';
  import MStoreTableVue from '@/components/shared/Table/MStoreTable.vue';
  import { BaseDocumentSearchModel, Cabinet, DocumentsToStore, DocumentTypes } from '@/types';
  import { mapActions, mapGetters } from 'vuex';
  import { DocumentsToStoreService } from '@/services';
  import SnotifyConfiguration from '@/classes/SnotifyConfiguration';
  import { ModalHelpers } from '@/mixins';
  import { DocumentToStoreUploadModel } from '@/types/models/documentsToStore';

  Vue.use(LiquorTree);

  Vue.filter('kb', (val: any) => {
    return Math.floor(val / 1024);
  });

  interface FileUploadModel {
    file: any;
    type: any;
    progress: number;
  }

  export default Vue.extend({
    name: 'DocumentsToStoreTreeView',
    mixins: [TreeViewHelpers, ModalHelpers],
    props: {
      loading: {
        type: Boolean,
        required: false
      }
    },
    data() {
      return {
        permissionData: null,
        options: {
          checkbox: false,
          parentSelect: true
        },
        documents: [],
        isDataLoading: false,
        fields: [
          {
            key: 'indexTime',
            label: 'Date/Time',
            sortable: true,
            formatter: 'date'
          },
          {
            key: 'indexUser',
            label: 'User',
            sortable: true
          },
          {
            key: 'indexStatus',
            label: 'Status',
            sortable: true
          },
          {
            key: 'totalPages',
            label: 'Pages',
            sortable: true
          },
          {
            key: 'actions',
            label: '',
            sortable: false
          }
        ],
        dynamicTreeData: [],
        emptyText: 'There are no documents to show.',
        files: [] as FileUploadModel[],
        max: 100,
        showModal: false,
        buttonDragover: false,
        gridDragover: false,
        sortBy: 'indexTime',
        sortDesc: true
      };
    },
    methods: {
      ...mapActions('documentViewStore', [
        'loadPage',
        'setDocumentSearchModel',
        'unloadDocument',
        'showLoadingSpinner'
      ]),
      ...mapActions('documentsToStoreStore', ['setShowNoDocumentNotification']),
      async initialise(this: any): Promise<void> {
        try {
          this._isLoading = true;
          this.permissionData = await DocumentsToStoreService.getDocumentsToStoreAsync();
          if (this.permissionData) {
            if (!this.$route.params.id) {
              this.documents = this.permissionData.myDocuments || [];

              this.fileTypeWhiteList = this.permissionData?.fileUploadSettings?.fileExtensionWhiteList
                .map((type: string) => `.${type}`)
                .join(',');
              this.fileUploadSizeLimitMb = this.permissionData?.fileUploadSettings?.fileSizeLimitMb;
              this.maximumFileUploadCount = this.permissionData?.fileUploadSettings?.maximumFileUploadCount;
            }
            this.initialiseTreeData();
          }
        } catch (error) {
          this.$log(error);
        } finally {
          this._isLoading = false;
        }
      },
      navigate(this: any, node: any): void {
        this.selectedDocumentType = node.data.id;
        this.getDocuments(node.data.id);
      },
      getNode(this: any, tree: any, id: any): void | undefined {
        id = id || DocumentTypes.MyDocuments;
        const node = this.$refs.tree.find({
          data: { id }
        });
        if (!node) {
          return;
        }
        this.selectedDocumentType = id;
        this.selectNode(node);
        this.getDocuments(id);
      },
      initialiseTreeData(this: any): any {
        const documentTypes = this.permissionData.documentTypes;
        if (documentTypes?.length > 0) {
          this.dynamicTreeData = documentTypes.map((x: any) => {
            return {
              text: x.description,
              data: { icon: 'folder-open', id: x.id },
              state: {
                visible: true,
                selectable: true
              }
            };
          });
        }
      },
      async getDocuments(this: any, id: string): Promise<void> {
        try {
          this.isDataLoading = true;
          this.documents = [];
          this.showLoadingSpinner(true);
          switch (id) {
            case DocumentTypes.MyDocuments:
              this.documents = await DocumentsToStoreService.getMyDocumentsAsync();
              break;
            case DocumentTypes.EveryonesDocuments:
              this.documents = await DocumentsToStoreService.getEveryonesDocumentsAsync();
              break;
            default:
              const typeId = Number(id);
              if (!typeId) {
                return;
              }
              this.documents = await DocumentsToStoreService.getDocumentsByDocumentTypeAsync(typeId);
              break;
          }
        } catch (error) {
          this.$log(error);
          this.showLoadingSpinner(false);
        } finally {
          this.isDataLoading = false;
        }
      },
      loadFirstDocument(this: any): void {
        this.loadDocument(this.$refs?.documentsTable?.filteredItems[0]);
      },
      loadDocument(this: any, document: any): void {
        this.unloadDocument();
        if (document) {
          this.setDocumentSearchModel({
            cabinetId: Cabinet.IncomingDocuments,
            documentId: document.documentId
          } as BaseDocumentSearchModel);
          this.loadPage(1);
        } else {
          this.showLoadingSpinner(false);
        }
      },
      viewDocument(this: any, row: any): void {
        this.loadDocument(row.item);
      },
      selectedRowClass(item: any, type: any): string | undefined {
        if (!item || type !== 'row') {
          return;
        }

        if (this.documentIsBeingViewed(item)) {
          return 'table-success';
        }
      },
      documentIsBeingViewed(this: any, item: any): boolean {
        return (
          this.documentSearchModel?.documentId === item.documentId &&
          this.documentSearchModel?.cabinetId.toString() === Cabinet.IncomingDocuments
        );
      },
      validateFileType(this: any, file: any): boolean {
        const filenameSplitArray = file.name.split('.');
        const fileType = filenameSplitArray[filenameSplitArray.length - 1];
        return this.fileTypeWhiteList.includes(fileType.toLowerCase());
      },
      validateFileSize(this: any, file: any): boolean {
        const fileSizeMB = Math.ceil(file.size / (1024 * 1024));
        return fileSizeMB <= this.fileUploadSizeLimitMb;
      },
      getErrorMessage(this: any, files: any, isUnsupportedTypeError: boolean | undefined): string {
        if (files.length < 1) {
          return '';
        }
        const fileNames = this.getFileNamesFromFiles(files);
        const multipleFiles = files.length > 1;
        const postFixMessage = isUnsupportedTypeError ? 'not supported by mstore' : 'too large to upload';
        return `<p class="text-danger">The file${multipleFiles ? 's' : ''} ${fileNames} ${
          multipleFiles ? 'are' : 'is'
        } ${postFixMessage}.</p>`;
      },
      getFileNamesFromFiles(this: any, files: any): string {
        return [
          ...files.map((file: any) => {
            return file.file.name;
          })
        ].join(', ');
      },

      addErrorDetailsToConfirmationMessage(
        this: any,
        confirmationMessage: string,
        unsupportedError: string,
        largeFileErrorMessage: string
      ): string {
        const note = `
                 <div>
                     <b>Note:</b>
                     <p class="text-wrap text-break">File types supported by mstore are ${this.fileTypeWhiteList} and maximum size is ${this.fileUploadSizeLimitMb}MB.</p>
                   </div>`;
        return `${confirmationMessage} ${unsupportedError} ${largeFileErrorMessage} ${note}`;
      },
      async addFile(this: any, type: string, event: any) {
        try {
          this.onDragLeave(type);
          let unsupportedFiles = [] as any[];
          let droppedFiles = event?.dataTransfer?.files || event?.target?.files;
          if (!droppedFiles) return;
          if (droppedFiles.length > this.maximumFileUploadCount) {
            SnotifyConfiguration.showInformation(`Maximum ${this.maximumFileUploadCount} files can be uploaded.`);
            return;
          }
          [...droppedFiles].forEach((file) => {
            const isValidFileType = this.validateFileType(file);
            if (isValidFileType && this.validateFileSize(file)) {
              this.files.push({ file, type, progress: 0 } as FileUploadModel);
            } else {
              unsupportedFiles.push({ file, type, progress: 0, unsupportedFile: !isValidFileType });
            }
          });

          let confirmationMessage: string = '';
          let folderName: string = '';

          if (this.files.length > 0) {
            const fileNames = this.getFileNamesFromFiles(this.files);
            folderName = this.treeData.find((node: any) => node.data.id === type)?.text;
            confirmationMessage = `<p>You are about to upload the file${
              this.files.length > 1 ? 's' : ''
            } ${fileNames} to ${folderName}. <p>`;
          }

          if (unsupportedFiles.length > 0) {
            const unsupportedFileErrorMessage = this.getErrorMessage(
              unsupportedFiles.filter((file) => file.unsupportedFile),
              true
            );

            const largeFileErrorMessage = this.getErrorMessage(
              unsupportedFiles.filter((file) => !file.unsupportedFile)
            );

            confirmationMessage = this.addErrorDetailsToConfirmationMessage(
              confirmationMessage,
              unsupportedFileErrorMessage,
              largeFileErrorMessage
            );
          }

          if (this.files.length > 0 || unsupportedFiles.length > 0) {
            if (this.files.length > 0) {
              const userConfirmation = await this.showConfirmationHtmlModalAsync(this.$bvModal, confirmationMessage);
              if (userConfirmation) {
                this.showModal = true;
                const uploadCompleted = await new Promise((resolve, reject): void => {
                  this.files.forEach(async (file: any, index: number, array: any) => {
                    let uploadmodel = {
                      formFile: file.file,
                      isDocumentToStoreDocument: [DocumentTypes.MyDocuments, DocumentTypes.EveryonesDocuments].includes(
                        type
                      ),
                      isMyDocument: DocumentTypes.MyDocuments === type
                    } as DocumentToStoreUploadModel;
                    if (!isNaN(Number(type))) {
                      uploadmodel.documentTypeId = Number(type);
                    }
                    DocumentsToStoreService.uploadDocumentsToStoreAsync(uploadmodel, (event: any) => {
                      file.progress = Math.round((100 * event.loaded) / event.total);
                    })
                      .then((response: any) => {
                        file.uploaded = true;
                        if (this.files.every((file: any) => file.uploaded || file.error)) {
                          resolve(true);
                        }
                      })
                      .catch((error: any) => {
                        file.error = true;
                        this.handleErrorResponse(error, file.file.name, folderName);
                      });
                  });
                });

                if (uploadCompleted) {
                  const uploadedFiles = this.files.filter((file: any) => file.progress === 100 && !file.error);
                  if (uploadedFiles.length > 0) {
                    const fileNames = this.getFileNamesFromFiles(uploadedFiles);
                    const multipleFiles = uploadedFiles.length > 1;
                    const successMessage = `The file${
                      multipleFiles ? 's' : ''
                    } ${fileNames} has been uploaded to ${folderName}`;
                    SnotifyConfiguration.showSuccess(successMessage);
                  }
                  this.showModal = false;
                  this.getNode(null, type);
                }
              }
            } else if (unsupportedFiles.length > 0) {
              await this.showOkHtmlModalAsync(this.$bvModal, 'Unsupported file type:', confirmationMessage);
            }
          }
        } catch (error) {
          this.$log(error);
          this.showModal = false;
        } finally {
          this.clearFiles();
        }
      },
      uploadfile(this: any, delay: number, index: number): Promise<any> {
        return new Promise((resolve) => setTimeout(() => resolve(delay + 10), 500 * index));
      },
      handleErrorResponse(this: any, error: any, fileName: string, folderName: string) {
        const handledHttpResponseCodes = [404, 401, 500];
        let errorMessage = '';
        if (handledHttpResponseCodes.includes(error?.response?.status)) {
          errorMessage = error.response.data;
        } else {
          errorMessage = `Unable to upload the file ${fileName} to ${folderName}`;

          if (!error.response) {
            errorMessage = `${errorMessage}, there may be an issue with the file, please check it.`;
          } else if (error?.response.status === 400) {
            errorMessage = `${errorMessage}, ${error?.response?.data?.title}, trace Id : ${error?.response?.data?.traceId}.`;
          }
        }

        SnotifyConfiguration.showError(errorMessage);
      },
      removeFile(file: any) {
        this.files = this.files.filter((f) => {
          return f != file;
        });
      },
      onPickFile(this: any) {
        this.$refs.fileUpload.click();
      },
      onFilePicked(this: any, event: any) {
        let files = event.target.files;
        if (!files) return;
        [...files].forEach((f) => {
          this.files.push({ file: f, type: 'default' });
        });
      },
      onDragOver(this: any, id: any) {
        const node = this.$refs.tree.find({
          data: { id }
        });
        if (!node) {
          return;
        }
        node[0]?.vm?.$el?.classList?.add('drag-highlight');
      },
      onDragLeave(this: any, id: any) {
        const node = this.$refs.tree.find({
          data: { id }
        });
        if (!node) {
          return;
        }
        node[0]?.vm?.$el?.classList?.remove('drag-highlight');
      },
      clearFiles(this: any) {
        this.files = [];
        this.$refs.fileUpload.value = null;
      },
      storeDocument(this: any, row: any) {
        this.$router.push({
          name: DocumentsToStore.DocumentsToStore.name,
          params: {
            documentId: row.item.documentId,
            documentTypeId: this.selectedDocumentType
          }
        });
      }
    },
    computed: {
      ...mapGetters('documentViewStore', ['documentSearchModel']),
      defaultTreeData(this: any): object {
        return [
          {
            text: 'My Documents',
            data: { icon: 'folder-open', id: DocumentTypes.MyDocuments },
            state: {
              visible: this.permissionData?.canAccessMyDocuments,
              selectable: true
            }
          },
          {
            text: `Everyone's Documents`,
            data: { icon: 'folder-open', id: DocumentTypes.EveryonesDocuments },
            state: {
              visible: this.permissionData?.canAccessEveryonesDocuments,
              selectable: true
            }
          }
        ];
      },
      treeData(this: any): object {
        return [...this.defaultTreeData, ...this.dynamicTreeData];
      },
      _isLoading: {
        get(this: any) {
          return this.loading;
        },
        set(this: any, value: boolean) {
          this.$emit('update:loading', value);
        }
      },
      progress(this: any) {
        return (index: number) => {
          return this.files[index].progress;
        };
      }
    },
    watch: {
      documents(this: any) {
        this.setShowNoDocumentNotification(!(this.documents?.length >= 1));
      }
    },
    mounted() {
      this.initialise();
    },
    created(this: any) {
      this.selectedDocumentType = DocumentTypes.MyDocuments;
      this.fileUploadSizeLimitMb = 1;
      this.fileTypeWhiteList = '';
      this.maximumFileUploadCount = 1;
    },
    components: {
      'm-table': MStoreTableVue,
      LoadingSpinner,
      TreeViewHeader
    }
  });
</script>
