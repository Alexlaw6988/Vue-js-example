import moment from 'moment';
import { ObjectHelper } from '@/mixins/objectHelper';

export const BTableHelpers = {
  data(this: any) {
    return {
      tableFields: []
    };
  },
  methods: {
    date(value: Date) {
      const locale = window.navigator.language;
      return value ? moment(value).locale(locale).format('L LT') : null;
    },
    tableFilterFields(this: any, fields: any) {
      this.tableFields = fields;
      return this.tableFields;
    },
    tableFilter(this: any, row: any, searchText: any): boolean {
      const fields = this.fields ? this.fields : this.tableFields;
      return this.customTableFilter(fields, row, searchText);
    },
    getKey(field: any) {
      const keys = Object.keys(field);
      return keys.indexOf('key') > -1 ? field.key : keys[0];
    },
    customTableFilter(fields: any, row: any, searchText: any): boolean {
      let filteredRow = false;

      fields.some((field: any) => {
        const key = this.getKey(field);
        let value =
          key.contains('.') && !row[key] ? ObjectHelper.methods.getNestedPropertyValue(key.split('.'), row) : row[key];

        if (field.formatter) {
          const thisElement: { [index: string]: any } = this;

          let formatter = field.formatter;

          if (typeof formatter === 'string' && typeof thisElement[formatter] === 'function') {
            formatter = thisElement[formatter];
          }
          value = formatter(value, key, row);
        }

        if (value && value.toString().contains(searchText)) {
          filteredRow = true;
          return filteredRow;
        }
      });
      return filteredRow;
    },
    customTableSort(rows: any, sortBy: any, sortByDes: boolean = false) {
      if (!ObjectHelper.methods.isNullOrEmpty(sortBy)) {
        rows.sort((x: any, y: any) => (x[sortBy] > y[sortBy] ? 1 : -1));
        if (sortByDes) {
          rows.reverse();
        }
      }
      return rows;
    }
  }
};
