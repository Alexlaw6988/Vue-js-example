export interface DocuSignAdditionalDocumentFileUpdateModel {
  id: number;
  description: string;
}
