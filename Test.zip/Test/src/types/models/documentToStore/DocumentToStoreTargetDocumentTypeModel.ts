export interface DocumentToStoreTargetDocumentTypeModel {
  sourceDocumentType: string;
  targetDocumentType: number;
}
