import { DocuSignSignerRoleManagementState, TableStateModel, RootState } from '@/types';
import { GetterTree } from 'vuex';

export const getters: GetterTree<DocuSignSignerRoleManagementState, RootState> = {
  getTableStateField: (state) => (field: keyof TableStateModel): any => {
    return state.tableState[field];
  },
  getDocumentTypeId(state) {
    return state.documentTypeId;
  }
};
