export const FeedbackTypeConstants = {
  Feedback: {
    title: 'Feedback',
    key: 'feedback'
  },
  GetHelp: {
    title: 'Help',
    key: 'getHelp'
  },
  ReportIssue: {
    title: 'Report Issue',
    key: 'reportIssue'
  }
};
