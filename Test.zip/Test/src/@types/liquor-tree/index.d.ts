declare module 'liquor-tree';
