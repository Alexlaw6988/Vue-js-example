export interface SourceDocumentTypeSettingsModel {
  setFocusToDocumentTypeAfterStore: boolean;
}