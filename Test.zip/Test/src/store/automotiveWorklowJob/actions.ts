import {
  AutomotiveWorkflowJobState,
  AutomotiveWorkflowJobMutationTypes,
  CustomTabDynamicFormUpdateModel,
  FieldUpdateModel,
  ManufacturerTabModel,
  ManufacturerTabSearchModel,
  RootState
} from '@/types';
import { ActionTree } from 'vuex';
import { ManufacturerTabService } from '@/services/automotive/ManufacturerTabService';
import store from '../index';

export const actions: ActionTree<AutomotiveWorkflowJobState, RootState> = {
  getManufacturerTab(this: any, { commit, getters }: any, searchModel: ManufacturerTabSearchModel) {
    commit(AutomotiveWorkflowJobMutationTypes.SetIsManufacturerTabLoading, true);
    ManufacturerTabService.getManufacturerTabAsync(
      searchModel.queueId,
      searchModel.jobId,
      searchModel.saleType,
      searchModel.manufacturer
    )
      .then((response: ManufacturerTabModel) => {
        commit(AutomotiveWorkflowJobMutationTypes.ManufacturerTabLoaded, response);
        store.dispatch('workflowJobStore/addCustomFormsDynamicFormValidationModel', response.dynamicForm.formId);
        store.dispatch('workflowJobStore/addDynamicFormModelToCustomJobTab', {
          key: 'Custom-ManufacturerTab',
          dynamicForm: response.dynamicForm
        } as CustomTabDynamicFormUpdateModel);
      })
      .catch((error: any) => {
        commit(AutomotiveWorkflowJobMutationTypes.ManufacturerTabError, error);
      });
  },
  setManufacturerTabFieldValue(this: any, { commit }, fieldUpdateModel: FieldUpdateModel) {
    store.dispatch('workflowJobStore/setIsDirty', true);
    commit(AutomotiveWorkflowJobMutationTypes.UpdateManufacturerDataSourceFieldValue, fieldUpdateModel);
  },
  unloadAutomotiveWorkflowJob({ commit }) {
    commit(AutomotiveWorkflowJobMutationTypes.UnloadAutomotiveWorkflowJob);
  }
};
