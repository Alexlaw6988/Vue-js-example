declare module 'vue-dragscroll';
