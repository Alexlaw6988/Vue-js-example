import { WorkflowQueueState, RootState, WorkflowQueueNextJobsModel, UserPreferencesMutationTypes } from '@/types';
import { ActionTree } from 'vuex';

export const actions: ActionTree<WorkflowQueueState, RootState> = {
  resetWorkflowQueueState({ commit, state }, queueId: number) {
    commit('RESET_WORKFLOW_QUEUE_STATE', queueId);
  },
  setTableStateField({ commit, state }, tableStateField: any) {
    if (state.queueId === (tableStateField.queueId as number)) {
      commit('SET_TABLE_STATE_FIELD', tableStateField);
      return;
    }
    commit('RESET_WORKFLOW_QUEUE_STATE', tableStateField.queueId as number);
  },
  setNextJobsList({ commit }, payload: any) {
    commit('SET_NEXT_JOB_LIST', payload);
  },
  setAllJobsList({ commit }, payload: any) {
    commit('SET_ALL_JOB_LIST', payload);
  },
  setLastSelectedWorkflowQueue({ commit }, payload: any) {
    commit(UserPreferencesMutationTypes.SetLastSelectedWorkflowQueue, payload);
  }
};
