import { MutationTree } from 'vuex';
import { DocuSignSignerRoleManagementState, TableStateModel } from '@/types';
import { docuSignSignerRoleManagement } from '../docuSignSignerRoleManagement';

export const mutations: MutationTree<DocuSignSignerRoleManagementState> = {
  RESET_STATE(state) {
    Object.assign(state, docuSignSignerRoleManagement.defaultDocuSignSignerRoleManagementState());
  },
  SET_TABLE_STATE_FIELD(state, tableStateField: any) {
    Object.assign(state.tableState, {
      [tableStateField.field]: tableStateField.value
    });
  },
  SET_DOCUMENT_TYPE(state, documentTypeId: number) {
    state.documentTypeId = documentTypeId;
  }
};
