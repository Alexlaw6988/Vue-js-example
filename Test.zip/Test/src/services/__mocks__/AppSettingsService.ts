import { AppSettingsModel } from '@/types';

export const AppSettingsService = {
  getAppStartSettings(url: string) {
    return {} as AppSettingsModel;
  }
};
