export interface ManufacturerTabDataSourceUpdateModel {
  queueId: number;
  jobId: number;
}
