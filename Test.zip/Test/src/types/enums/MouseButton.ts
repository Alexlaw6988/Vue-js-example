export const MouseButton = {
  Main: 0,
  Auxiliary: 1,
  Secondary: 2
};
