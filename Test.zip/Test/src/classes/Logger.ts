import Vue from 'vue';
export const Logger = new Vue();
