import { mapGetters, mapActions } from 'vuex';

export const MTablehelper = {
    data() {
        return {
            hasError: false,
            errorMessage: ''
        };
    },
    methods: {
        ...mapActions('mTableStore', [
            'setTableStateField',
            'resetMTableState'
        ]),
        handleError(this: any, error: any) {
            this.hasError = true;
            this.errorMessage = error;
        },
        rowClass(item: any) {
            if (item?.isDeactivated) {
                return 'text-muted font-italic';
            }
        },
        onTableStateFieldUpdated(this: any, field: string, value: any, stateKey: string) {
            this.setTableStateField({ stateKey, tableStateField: { field, value } });
        }
    },
    computed: {
        ...mapGetters('mTableStore', [
            'getTableStateField'
        ]),
        tableStateField(this: any) {
            return (stateKey: string, field: string) => this.getTableStateField(stateKey, field);
        }
    },
    Constants: {
        TableStoreKeys: {
            DocuSignAdditionalDocuments: 'docuSignAdditionalDocuments',
            DocuSignAdditionalDocumentTabs: 'docuSignAdditionalDocumentTabs',
            DocuSignTemplateSignHeres: 'docuSignTemplateSignHeres',
            DocuSignTemplateAdditionalDocuments: 'docuSignTemplateAdditionalDocuments'
        }
    }
};