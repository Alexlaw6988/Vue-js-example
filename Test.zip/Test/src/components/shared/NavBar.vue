<template>
  <div id="m-navbar">
    <nav
      class="navbar navbar-expand-lg navbar-light bg-light shadow-sm bg-white rounded bg-gradient-light pl-2 border-bottom py-0"
    >
      <a class="navbar-brand pt-0" href="#">
        <img src="@/assets/logo_nav.png" alt="mStore logo" />
      </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbar">
        <ul class="navbar-nav ml-auto">
          <li v-if="appSettings.showV4NavItems && navBarAccess.search" class="nav-item h6 mb-0 py-1 px-1">
            <a class="nav-link" href="/#/search">Search</a>
          </li>
          <li
            v-if="appSettings.showV4NavItems && navBarAccess.index && featureEnabled === 'false'"
            class="nav-item h6 mb-0 py-1 px-1"
          >
            <a class="nav-link" href="/#/index">Index</a>
          </li>
          <router-link
            v-if="navBarAccess.index && featureEnabled === 'true'"
            :to="{ name: documentsToStoreRoutes.Base.name }"
            class="nav-item h6 mb-0 py-1 px-1"
            tag="li"
          >
            <a class="nav-link">Store Documents</a>
          </router-link>
          <li v-if="appSettings.showV4NavItems && navBarAccess.workspaces" class="nav-item h6 mb-0 py-1 px-1">
            <a class="nav-link" href="/#/workspaces">Workspaces</a>
          </li>
          <router-link
            v-if="
              (appSettings.showV4NavItems && navBarAccess.workflow) ||
                (!appSettings.showV4NavItems && navBarAccess.workflow && navBarAccess.configuration)
            "
            :to="{ name: 'Workflow' }"
            class="nav-item h6 mb-0 py-1 px-1"
            tag="li"
          >
            <a class="nav-link">Workflow</a>
          </router-link>
          <router-link v-if="navBarAccess.tools" :to="{ name: 'tools' }" class="nav-item h6 mb-0 py-1 px-1" tag="li">
            <a class="nav-link">Tools</a>
          </router-link>
          <router-link
            v-if="navBarAccess.configuration"
            :to="{ name: 'configuration' }"
            class="nav-item h6 mb-0 py-1 px-1"
            tag="li"
          >
            <a class="nav-link">Configuration</a>
          </router-link>
          <li class="nav-item dropdown h6 mb-0 py-1 px-1">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown">
              {{ navBarAccess.currentUsername }}
              <font-awesome-icon icon="user" class="text-primary" />
            </a>
            <div class="dropdown-menu dropdown-menu-right">
              <span v-if="appSettings.showV4NavItems">
                <a class="dropdown-item" href="/#/user/changepassword">Change Password</a>
                <div class="dropdown-divider"></div>
              </span>
              <span>
                <a class="dropdown-item" @click="onFeedbackClick(FeedbackType.Feedback.title)">Send Feedback</a>
                <div class="dropdown-divider"></div>
              </span>
              <span>
                <a class="dropdown-item" @click="onFeedbackClick(FeedbackType.ReportIssue.title)">Report Issue</a>
                <div class="dropdown-divider"></div>
              </span>
              <span>
                <a class="dropdown-item" @click="onFeedbackClick(FeedbackType.GetHelp.title)">Get Help</a>
                <div class="dropdown-divider"></div>
              </span>
              <router-link :to="{ name: 'about' }" class="dropdown-item">About</router-link>
              <div class="dropdown-divider" />
              <a class="dropdown-item" @click="logOut">
                <font-awesome-icon icon="power-off" class="text-primary mr-1" />
                Logout
              </a>
            </div>
          </li>
        </ul>
      </div>
    </nav>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  import { mapGetters, mapActions } from 'vuex';
  import { UserModel, AppSettingsModel, MStoreConstants, FeedbackTypeConstants } from '@/types';
  import { UserService } from '@/services/UserService';
  import SessionStorageService from '@/services/SessionStorageService';
  import { ConfigurationModel, DocumentsToStore } from '@/types';
  import { ConfigurationService } from '@/services/ConfigurationService';
  import { NavBarAccessService } from '@/services/NavBarAccessService';
  import { NavBarAccessModel } from '@/types';
  import { FeedbackHelper, ModalHelpers, UnsavedChangesHelper, AppSettingsHelper } from '@/mixins';
  import { LocalStorage } from '@/utils';
  import AxiosConfiguration from '@/classes/AxiosConfiguration';

  export default Vue.extend({
    props: {
      loading: {
        type: Boolean,
        required: false
      }
    },
    mixins: [FeedbackHelper, ModalHelpers, UnsavedChangesHelper, AppSettingsHelper],
    data() {
      return {
        navBarAccess: {} as NavBarAccessModel,
        featureEnabled: false,
        documentsToStoreRoutes: DocumentsToStore
      };
    },
    computed: {
      ...mapGetters('oidcStore', ['oidcUser']),
      ...mapGetters('applicationDirtyStore', ['isApplicationDirty', 'isApplicationDirtyOnAnotherTab']),
      ...mapGetters('workflowJobStore', ['isWorkFlowJobDirty']),
      _isLoading: {
        get(this: any) {
          return this.loading;
        },
        set(this: any, value: boolean) {
          this.$emit('update:loading', value);
        }
      },
      FeedbackType() {
        return FeedbackTypeConstants;
      }
    },
    methods: {
      ...mapActions('oidcStore', ['signOutOidc']),
      ...mapActions('applicationDirtyStore', ['setApplicationDirty']),
      async logOut(this: any) {
        try {
          const hasUnsavedChangesToKeep: boolean = await this.hasUnsavedChangesToKeepAsync(
            this.$bvModal,
            this.isApplicationDirty || this.isWorkFlowJobDirty
          );
          if (hasUnsavedChangesToKeep) {
            return;
          }
          if (this.isApplicationDirtyOnAnotherTab) {
            const hasUnsavedChangesToKeepOnOtherTabs = await this.showUnsavedChangesModalAsync(
              this.$bvModal,
              'You have unsaved changes on an another tab or a window'
            );
            if (!hasUnsavedChangesToKeepOnOtherTabs) {
              return;
            }
          }
          LocalStorage.emit(MStoreConstants.LocalStorageKeys.IsApplicationLoggedOutOnAnotherTab, false);
          this.setApplicationDirty(false);
          UserService.disableWindowsAutoLogInForCurrentUserAsync().then(() => {
            SessionStorageService.removeSessionId();
            this.signOutOidc();
          });
        } catch (error) {
          this.$log(error);
        }
      },
      navigate(routeName: string) {
        this.$router.push({ name: routeName });
      },
      async getDataAsync(this: any) {
        this._isLoading = true;
        this.navBarAccess = await NavBarAccessService.getNavBarAccessAsync();
        this._isLoading = false;
        const response = await AxiosConfiguration.axiosWithErrorPage.get(
          'parameter?entityTypeId=0&entityPk=0&group=DocumentsToStore&code=FeatureToggle'
        );
        this.featureEnabled = (response.data as string).toLowerCase();
      },
      onFeedbackClick(this: any, type: string) {
        this.ShowFeedbackInPopup(type);
      }
    },
    async mounted(this: any) {
      await this.getDataAsync();
    }
  });
</script>
