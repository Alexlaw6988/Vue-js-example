import {
  WorkflowJobState,
  RootState,
  WorkflowJobModel,
  WorkflowDataSourceModel,
  WorkflowJobTabModel,
  WorkflowQueueConfigurationModel,
  JobTabOrientation,
  JobTabStateModel,
  LockModel,
  DynamicFormValidationModel,
  TabStateModel
} from '@/types';
import { GetterTree } from 'vuex';
import { ObjectUtils } from '@/utils/objectUtils';

export const getters: GetterTree<WorkflowJobState, RootState> = {
  isLoading(state): boolean {
    return state.isLoading;
  },
  isDirty(state): boolean {
    return state.isDirty;
  },
  isWorkFlowJobDirty(state, getters): boolean {
    return state.isDirty || !ObjectUtils.isNullOrEmpty(getters.dirtyJobTabStates);
  },
  workflowJob(state): WorkflowJobModel {
    return state.workflowJob;
  },
  workflowDataSources(state): WorkflowDataSourceModel[] {
    return state.workflowJob.workflowDataSources;
  },
  workflowDataSource: (state) => (dataSourceKey: string): WorkflowDataSourceModel | undefined => {
    return state.workflowJob.workflowDataSources.find(
      (x: WorkflowDataSourceModel) => x.key.toLowerCase() === dataSourceKey.toLowerCase()
    );
  },
  workflowDataSourceField: (state, getters) => (dataSourceKey: string, fieldName: string): object | undefined => {
    const dataSource = getters.workflowDataSource(dataSourceKey) as any;

    if (dataSource) {
      const fieldKey = ObjectUtils.getFieldKeyIgnoreCase(dataSource.fields, fieldName);
      if (fieldKey) {
        return dataSource.fields[fieldKey];
      }
    }

    return undefined;
  },
  verticalJobTabs(state, getters): WorkflowJobTabModel[] {
    return getters.allJobTabsByOrientation(JobTabOrientation.Vertical);
  },
  visibleVerticalJobTabs(state, getters): WorkflowJobTabModel[] {
    const tabs = getters.allJobTabsByOrientation(JobTabOrientation.Vertical) as WorkflowJobTabModel[];
    return tabs.filter((x: WorkflowJobTabModel) => (getters.jobTabState(x.key) as TabStateModel).hidden === false);
  },
  hasVerticalJobTabs(state, getters): boolean {
    return getters.verticalJobTabs && getters.verticalJobTabs.length > 0;
  },
  verticalJobTabByKey: (state, getters) => (tabKey: string): WorkflowJobTabModel | undefined => {
    const tabs = getters.allJobTabsByOrientation(JobTabOrientation.Vertical);
    if (tabs) {
      return tabs.find((x: WorkflowJobTabModel) => x.key === tabKey);
    }
  },
  horizontalJobTabs(state, getters): WorkflowJobTabModel[] {
    return getters.allJobTabsByOrientation(JobTabOrientation.Horizontal);
  },
  hasHorizontalJobTabs(state, getters): boolean {
    return getters.horizontalJobTabs && getters.horizontalJobTabs.length > 0;
  },
  horizontalJobTabByKey: (state, getters) => (tabKey: string): WorkflowJobTabModel | undefined => {
    const tabs = getters.allJobTabsByOrientation(JobTabOrientation.Horizontal);
    if (tabs) {
      return tabs.find((x: WorkflowJobTabModel) => x.key === tabKey);
    }
  },
  allJobTabsByOrientation: (state, getters) => (
    tabOrientation: JobTabOrientation
  ): WorkflowJobTabModel[] | undefined => {
    const workflowTabs = getters.workflowJobTabsByOrientation(tabOrientation);
    const standardTabs = getters.standardJobTabsByOrientation(tabOrientation);
    const customTabs = getters.customJobTabsByOrientation(tabOrientation);

    return [...(workflowTabs || []), ...(standardTabs || []), ...(customTabs || [])];
  },
  workflowJobTabsByOrientation: (state) => (tabOrientation: JobTabOrientation): WorkflowJobTabModel[] => {
    return state.workflowJob?.workflowQueueConfiguration?.workflowJobTabs?.filter(
      (x: WorkflowJobTabModel) => x.jobTabOrientation === tabOrientation && !x.hidden
    );
  },
  workflowJobTabs(state): WorkflowJobTabModel[] | undefined {
    return state.workflowJob?.workflowQueueConfiguration?.workflowJobTabs;
  },
  visibleWorkflowJobTabs(state, getters): WorkflowJobTabModel[] {
    const tabs = getters.workflowJobTabs as WorkflowJobTabModel[];
    if (tabs) {
      return tabs.filter((x: WorkflowJobTabModel) => (getters.jobTabState(x.key) as TabStateModel)?.hidden === false);
    }
    return [] as WorkflowJobTabModel[];
  },
  hasWorkflowTabs(state, getters): boolean {
    return getters.workflowJobTabs && getters.workflowJobTabs.length > 0;
  },
  hasVisibleWorkflowTabs(state, getters): boolean {
    return getters.hasWorkflowTabs && getters.visibleWorkflowJobTabs.length > 0;
  },
  hasHorizontalWorkflowJobTabs(state, getters): boolean {
    return (
      getters.workflowJobTabsByOrientation(JobTabOrientation.Horizontal) &&
      getters.workflowJobTabsByOrientation(JobTabOrientation.Horizontal).length > 0
    );
  },
  horizontalWorkflowJobTabs(state, getters): WorkflowJobTabModel[] | undefined {
    return getters.workflowJobTabsByOrientation(JobTabOrientation.Horizontal);
  },
  hasVerticalWorkflowJobTabs(state, getters): boolean {
    return (
      getters.workflowJobTabsByOrientation(JobTabOrientation.Vertical) &&
      getters.workflowJobTabsByOrientation(JobTabOrientation.Vertical).length > 0
    );
  },
  verticalWorkflowJobTabs(state, getters): WorkflowJobTabModel[] {
    return getters.workflowJobTabsByOrientation(JobTabOrientation.Vertical);
  },
  visibleVerticalWorkflowJobTabs(state, getters): WorkflowJobTabModel[] | undefined {
    const tabs = getters.verticalWorkflowJobTabs as WorkflowJobTabModel[];
    return tabs.filter((x: WorkflowJobTabModel) => (getters.jobTabState(x.key) as TabStateModel)?.hidden === false);
  },
  standardJobTabsByOrientation: (state) => (tabOrientation: JobTabOrientation): WorkflowJobTabModel[] | undefined => {
    return state.workflowJob?.workflowQueueConfiguration?.standardJobTabs.filter(
      (x: WorkflowJobTabModel) => x.jobTabOrientation === tabOrientation && !x.hidden
    );
  },
  standardJobTabs(state): WorkflowJobTabModel[] | undefined {
    return state.workflowJob?.workflowQueueConfiguration?.standardJobTabs;
  },
  customJobTabsByOrientation: (state) => (tabOrientation: JobTabOrientation): WorkflowJobTabModel[] | undefined => {
    return state.workflowJob?.workflowQueueConfiguration?.customJobTabs.filter(
      (x: WorkflowJobTabModel) => x.jobTabOrientation === tabOrientation && !x.hidden
    );
  },
  customJobTabs(state): WorkflowJobTabModel[] | undefined {
    return state.workflowJob?.workflowQueueConfiguration?.customJobTabs;
  },
  visibleCustomJobTabsThatNeedValidating(state, getters): WorkflowJobTabModel[] {
    const dynamicFormIds = state.dynamicFormValidationModels.map((x: DynamicFormValidationModel) => x.formId);

    const tabs = getters.customJobTabs.filter((x: WorkflowJobTabModel) => {
      return x.dynamicFormModel != null && dynamicFormIds.includes(x.dynamicFormModel.formId);
    }) as WorkflowJobTabModel[];

    if (tabs) {
      return tabs.filter((x: WorkflowJobTabModel) => (getters.jobTabState(x.key) as TabStateModel)?.hidden === false);
    }
    return [] as WorkflowJobTabModel[];
  },
  workflowQueueConfiguration(state): WorkflowQueueConfigurationModel {
    return state.workflowJob.workflowQueueConfiguration;
  },
  activeHorizontalTab(state): WorkflowJobTabModel {
    return state.activeHorizontalTab;
  },
  activeVerticalTab(state): WorkflowJobTabModel {
    return state.activeVerticalTab;
  },
  jobTabState: (state) => (jobTabKey: string): JobTabStateModel | undefined => {
    if (state.jobTabStates && state.jobTabStates.length > 0) {
      return state.jobTabStates.find((x: JobTabStateModel) => x.key === jobTabKey);
    }
  },
  dirtyJobTabStates(state): JobTabStateModel[] | undefined {
    if (state.jobTabStates && state.jobTabStates.length > 0) {
      return state.jobTabStates.filter((x: JobTabStateModel) => x.isDirty);
    }
  },
  dirtyHorizontalJobTabStates(state, getters): JobTabStateModel[] | undefined {
    const dirtyJobTabStates = getters.dirtyJobTabStates;
    if (dirtyJobTabStates && dirtyJobTabStates.length > 0) {
      return getters.dirtyJobTabStates.filter(
        (x: JobTabStateModel) => x.jobTabOrientation === JobTabOrientation.Horizontal
      );
    }
  },
  dirtyVerticalJobTabStates(state, getters): JobTabStateModel[] | undefined {
    const dirtyJobTabStates = getters.dirtyJobTabStates;
    if (dirtyJobTabStates && dirtyJobTabStates.length > 0) {
      return dirtyJobTabStates.filter((x: JobTabStateModel) => x.jobTabOrientation === JobTabOrientation.Vertical);
    }
  },
  workflowJobLock(state): LockModel | undefined {
    return state.workflowJob.lockModel;
  },
  extendingWorkflowJobLock(state): boolean {
    return state.extendingWorkflowJobLock;
  },
  dynamicFormValidationModel: (state) => (formId: string): DynamicFormValidationModel | undefined => {
    return state.dynamicFormValidationModels.find((x: DynamicFormValidationModel) => x.formId === formId);
  },
  validWorkflowTabs(state, getters): WorkflowJobTabModel[] {
    const validDynamicFormIds = state.dynamicFormValidationModels
      .filter((x: DynamicFormValidationModel) => x.validated && x.valid)
      .map((x: DynamicFormValidationModel) => x.formId);

    const workflowJobTabModels = getters.visibleWorkflowJobTabs.filter((x: WorkflowJobTabModel) =>
      validDynamicFormIds.includes(x.dynamicFormModel.formId)
    ) as WorkflowJobTabModel[];

    return workflowJobTabModels.concat(
      getters.customJobTabs.filter((x: WorkflowJobTabModel) => {
        return x.dynamicFormModel != null && validDynamicFormIds.includes(x.dynamicFormModel.formId);
      }) as WorkflowJobTabModel[]
    );
  },
  invalidWorkflowTabs(state, getters): WorkflowJobTabModel[] {
    const invalidDynamicFormIds = state.dynamicFormValidationModels
      .filter((x: DynamicFormValidationModel) => x.validated && !x.valid)
      .map((x: DynamicFormValidationModel) => x.formId) as string[];

    const workflowJobTabModels = getters.visibleWorkflowJobTabs.filter((x: WorkflowJobTabModel) =>
      invalidDynamicFormIds.includes(x.dynamicFormModel.formId)
    );

    return workflowJobTabModels.concat(
      getters.customJobTabs.filter((x: WorkflowJobTabModel) => {
        return x.dynamicFormModel != null && invalidDynamicFormIds.includes(x.dynamicFormModel.formId);
      }) as WorkflowJobTabModel[]
    );
  },
  allTabsValid(state, getters): boolean {
    return (
      getters.validWorkflowTabs.length ===
      getters.visibleWorkflowJobTabs.length + getters.visibleCustomJobTabsThatNeedValidating.length
    );
  },
  isAwaitingProcessing(state): boolean {
    return state.isAwaitingProcessing;
  }
};
