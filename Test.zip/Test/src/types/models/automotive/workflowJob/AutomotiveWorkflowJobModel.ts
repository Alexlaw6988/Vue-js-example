import { WorkflowJobTabsToHideModel } from '.';

export interface AutomotiveWorkflowJobModel {
  jobId: number;
  queueId: number;
  jobTabsToHide: WorkflowJobTabsToHideModel[];
  tabKeysHiddenBySaleType: string[];
  jobInForwardOrderFreeReleaseQueue: boolean;
}
