export const ArrayHelper = {
  methods: {
    removeDuplicates(myArr: [], prop: string) {
      return myArr.filter((obj, pos, arr) => {
        return arr.map((mapObj) => mapObj[prop]).indexOf(obj[prop]) === pos;
      });
    },
    joinWithDifferentLastSeperator(myArr: string[], seperator: string, lastSeperator: string): string {
      if (myArr.length === 0) {
        return '';
      }

      if (myArr.length === 1) {
        return myArr[0];
      }

      return myArr.slice(0, -1).join(seperator) + lastSeperator + myArr.slice(-1);
    },
    createArray(object: any): any[] {
      return object ? Array.prototype.slice.call(object) : object;
    }
  }
};
