<template>
  <div id="m-baseLayout" class="wrapper overflow-hidden">
    <NavBar v-if="isAuthenticated" v-bind:loading.sync="isLoading" v-show="!isLoading" class="sticky-top" />
    <div id="m-content" class="h-100" v-show="!isLoading">
      <slot />
    </div>
    <loading-spinner v-if="isLoading" :isLoading="isLoading" />
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  import NavBar from '@/components/shared/NavBar.vue';
  import LoadingSpinner from '@/components/shared/LoadingSpinner.vue';

  export default Vue.extend({
    name: 'BaseLayout',
    props: {
      isAuthenticated: {
        type: Boolean,
        required: true
      }
    },
    data() {
      return {
        isLoading: false
      };
    },
    components: {
      NavBar,
      LoadingSpinner
    }
  });
</script>
