import axios from 'axios';
import { DocuSignGroupActionModel } from '@/types';

const GroupActionsApiUrl = 'docusignworkflowjob/groupAction';

export const DocuSignWorkflowJobService = {
  async GroupActionsAsync(queueId: number, dataSource: DocuSignGroupActionModel) {
    await axios.post(`${GroupActionsApiUrl}/${queueId}`, dataSource);
  }
};
