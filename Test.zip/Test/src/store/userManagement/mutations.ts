import { MutationTree } from 'vuex';
import { UserManagementState } from '@/types';
import { userManagement } from '../userManagement';

export const mutations: MutationTree<UserManagementState> = {
  RESET_USER_MANAGEMENT_STATE(state) {
    Object.assign(state, userManagement.defaultUserManagementState());
  },
  SET_USER_MANAGEMENT_STATE_FIELD(state, userManagementStateField: any) {
    Object.assign(state, {
      [userManagementStateField.field]: userManagementStateField.value
    });
  }
};
