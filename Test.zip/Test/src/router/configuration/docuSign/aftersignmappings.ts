import { RouteHelpers } from '@/mixins';
import { Configuration } from '@/types';
import ConfigurationTreeView from '@/components/configuration/TreeView.vue';

const DocusignAfterSignMappingsManagement = () =>
  import(
    /* webpackChunkName: "DocusignAfterSignMappingsManagement" */
    '@/views/configuration/docusign/DocusignAfterSignMappingsManagement.vue'
  );

const DocuSignEditTemplateAfterSignMappings = () =>
  import(
    /* webpackChunkName: "EditTemplateAfterSignMappings" */
    '@/views/configuration/docusign/DocuSignEditTemplateAfterSignMappings.vue'
  );

const meta = {
  layout: 'TreeView',
  treePath: 'docusignaftersignmappings'
};

export const AfterSignMappingRoutes = [
  {
    ...Configuration.DocuSign.AfterSignMapping.Management,
    components: {
      default: DocusignAfterSignMappingsManagement,
      treeView: ConfigurationTreeView
    },
    meta
  },
  {
    ...Configuration.DocuSign.AfterSignMapping.Edit,
    components: {
      default: DocuSignEditTemplateAfterSignMappings,
      treeView: ConfigurationTreeView
    },
    meta: {
      ...meta,
      model: 'docusignaftersign'
    },
    beforeEnter: (to: any, from: any, next: any) => {
      RouteHelpers.setErrorPageRedirect(Configuration.DocuSign.AfterSignMapping.Management.name);
      RouteHelpers.beforeEnterCheckRouteParamAsNumeric(to, from, next, ['id']);
    }
  }
];
