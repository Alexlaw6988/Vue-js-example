<template>
  <div>
    <m-form @submit.prevent="onSubmit">
      <component
        v-for="(schema, index) in value"
        :key="schema.id"
        :is="getComponentName(schema)"
        v-bind="getVueBindings(schema, index)"
        v-on="getVueEventHandlers(schema, index)"
        :name="`${schema.componentProperties.componentName}_${schema.id}`"
        :validation="schema.validation"
        :ref="schema.id"
      />
    </m-form>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  import {
    MStoreFormDatePickerPropertiesModel,
    MStoreFormInputPropertiesModel,
    MStoreFormLookupPropertiesModel,
    SchemaModel,
    MStoreUnsupportedInputPropertiesModel,
    MStoreFormSelectTablePropertiesModel
  } from '@/types';
  import MStoreFormInput from '@/components/shared/MStoreFormInput.vue';
  import MStoreUnsupportedInput from '@/components/shared/MStoreUnsupportedInput.vue';
  import MStoreFormSelectTable from '@/components/shared/MStoreFormSelectTable.vue';
  import MStoreFormLookup from '@/components/shared/MStoreFormLookup.vue';
  import MStoreFormDatePicker from '@/components/shared/MStoreFormDatePicker.vue';

  export default Vue.extend({
    props: {
      value: {
        type: Array as () => SchemaModel[],
        default: Array as () => SchemaModel[]
      },
      isLoading: {
        type: Boolean,
        default: false
      },
      isReadonly: {
        type: Boolean,
        default: false
      }
    },
    methods: {
      getComponentName(this: any, schema: SchemaModel) {
        const registeredComponents = [
          'MStoreFormInput',
          'MStoreFormSelectTable',
          'MStoreFormLookup',
          'MStoreFormDatePicker',
          'MStoreUnsupportedInput'
        ];
        return (
          registeredComponents.find((x) => x === schema.componentProperties?.componentName) || 'MStoreUnsupportedInput'
        );
      },
      getVueBindings(this: any, schema: SchemaModel, index: number) {
        const readonly = schema.readonly || this.isReadonly;
        switch (schema.componentProperties?.componentName) {
          case 'MStoreFormInput': {
            const componentProperties = schema.componentProperties as MStoreFormInputPropertiesModel;
            return {
              id: schema.id,
              value: schema.value,
              readonly,
              label: schema.label,
              disabled: schema.disabled,
              autocomplete: componentProperties.autocomplete,
              lazyFormatter: componentProperties.lazyFormatter,
              placeholder: componentProperties.placeholder,
              type: componentProperties.type,
              forceUpperCase: componentProperties.forceUpperCase
            };
          }
          case 'MStoreFormSelectTable': {
            const componentProperties = schema.componentProperties as MStoreFormSelectTablePropertiesModel;
            return {
              data: schema.value,
              list: componentProperties.list,
              isLoading: this.isLoading,
              fieldLabel: schema.label,
              fieldId: schema.id,
              filterDisabled: componentProperties.filterDisabled,
              isReadonly: readonly,
              displayField: componentProperties.displayField,
              valueField: componentProperties.valueField,
              ignoreIsRequired: componentProperties.ignoreIsRequired,
              actionButtonComponentName: componentProperties.actionButtonComponentName || '',
              actionButtonState: componentProperties.actionButtonState,
              formId: componentProperties.formId,
              isActionButtonDisabled: componentProperties.isActionButtonDisabled,
              lineUpOnType: componentProperties.lineUpOnType,
              allowTypedValue: componentProperties.allowTypedValue
            };
          }
          case 'MStoreFormLookup': {
            const componentProperties = schema.componentProperties as MStoreFormLookupPropertiesModel;
            return {
              data: schema.value,
              listId: componentProperties.listId,
              isLoading: this.isLoading,
              fieldLabel: schema.label,
              fieldId: schema.id,
              isReadonly: readonly,
              hasInitialList: componentProperties.hasInitialList,
              actionButtonComponentName: componentProperties.actionButtonComponentName || '',
              actionButtonState: componentProperties.actionButtonState,
              ignoreIsRequired: componentProperties.ignoreIsRequired,
              formId: componentProperties.formId,
              filterDisabled: componentProperties.filterDisabled
            };
          }
          case 'MStoreFormDatePicker': {
            const componentProperties = schema.componentProperties as MStoreFormDatePickerPropertiesModel;
            return {
              id: schema.id,
              value: schema.value,
              label: schema.label,
              lang: componentProperties.language || 'en',
              format: componentProperties.format || 'DD/MM/YYYY',
              placeholder: componentProperties.placeholder,
              readonly,
              disabled: schema.disabled
            };
          }
          default: {
            const componentProperties = schema.componentProperties as MStoreUnsupportedInputPropertiesModel;
            return {
              htmlElementId: `unsupported_${schema.id}`,
              fieldLabel: schema.label,
              message: componentProperties.unsupportedMessage || 'The requested input method is unsupported'
            };
          }
        }
      },
      getVueEventHandlers(this: any, schema: SchemaModel, index: number) {
        switch (schema.componentProperties?.componentName) {
          case 'MStoreFormInput': {
            return {
              [(schema.componentProperties as MStoreFormInputPropertiesModel).updateValueOnBlur ? 'blur' : 'input']: (
                $event: any
              ) => this.updateValue($event, schema, index)
            };
          }
          case 'MStoreFormSelectTable':
          case 'MStoreFormLookup': {
            return {
              'update:data': ($event: any) => this.updateValue($event, schema, index)
            };
          }
          case 'MStoreFormDatePicker': {
            return {
              input: ($event: any) => this.updateValue($event, schema, index)
            };
          }
          default: {
            return {};
          }
        }
      },
      updateValue(this: any, newValue: any, schema: SchemaModel, indexOfSchema: number) {
        if (schema.readonly || schema.disabled) {
          return;
        }
        const updatedSchemaArray = [...this.value] as SchemaModel[];
        const updatedSchema = { ...schema, value: newValue };
        Vue.set(updatedSchemaArray, indexOfSchema, updatedSchema);
        this.$emit(`update:${schema.id}`, newValue);
        this.$emit('input', updatedSchemaArray);
      }
    },
    components: {
      /* When adding a new component the name of the component must also be added to 
      the registeredComponents array in the getComponentName method */
      MStoreFormInput,
      MStoreUnsupportedInput,
      MStoreFormSelectTable,
      MStoreFormLookup,
      MStoreFormDatePicker
    }
  });
</script>
