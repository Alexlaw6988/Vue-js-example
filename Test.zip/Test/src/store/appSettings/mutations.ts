import { AppSettingsModel } from '@/types';
import { MutationTree } from 'vuex';

export const mutations: MutationTree<any> = {
  APP_SETINGS_LOADED(state, payload: AppSettingsModel) {
    state.appSettings = payload;
  }
};
