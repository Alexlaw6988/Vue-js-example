<template>
  <m-form-input
    :disabled="disabled"
    :data-testid="dataTestid"
    :id="id"
    :name="name"
    :placeholder="placeholder"
    type="text"
    v-model="inputValue"
    :label="label"
  >
    <template #append>
      <b-button :disabled="!inputValue" variant="primary" @click="inputValue = ''">
        <font-awesome-icon icon="window-close" />
      </b-button>
    </template>
  </m-form-input>
</template>

<script lang="ts">
  import Vue from 'vue';

  export default Vue.extend({
    name: 'm-filter',
    $_veeValidate: {
      value() {
        return this.value;
      }
    },
    props: {
      disabled: {
        type: Boolean,
        default: false
      },
      id: {
        type: String
      },
      name: {
        type: String
      },
      placeholder: {
        type: String
      },
      value: String,
      dataTestid: {
        type: String,
        default: 'searchbox-input'
      },
      label: {
        type: String
      }
    },
    computed: {
      inputValue: {
        get(this: any) {
          return this.value;
        },
        set(this: any, value: string) {
          this.$emit('input', value);
        }
      }
    }
  });
</script>
