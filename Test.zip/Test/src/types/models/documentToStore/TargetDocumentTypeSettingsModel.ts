export interface TargetDocumentTypeSettingsModel {
  clearGridAfterUpdate: boolean;
  retainCommonReferenceValues: boolean;
  retainDocumentReferenceValues: boolean;
}