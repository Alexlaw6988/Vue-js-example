import { CabinetReferenceType, ReferenceValidationType } from '@/types';

export interface CabinetReferenceModel {
  id: number;
  type: CabinetReferenceType;
  fieldNumber: number;
  referenceDescription: string;
  referenceNumber: number;
  fieldName: string;
  documentTypeId: number;
  fieldKey: string;
  cabinetReferenceModel: CabinetReferenceModel;
  referenceValidationType: ReferenceValidationType;
}
