import { CabinetModel } from '@/types';

export const ProcessLeaver = {
  methods: {
    getLeaverDescription(currentCabinet: CabinetModel, destinationCabinet: CabinetModel) {
      return `${currentCabinet.description} - ${destinationCabinet.description}`;
    }
  }
};
