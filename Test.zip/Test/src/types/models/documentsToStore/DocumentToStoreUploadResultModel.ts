export interface DocumentToStoreUploadResultModel {
  documentId: number;
}
