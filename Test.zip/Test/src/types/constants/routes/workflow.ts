export const Workflow = {
  Base: {
    path: '/workflow',
    name: 'Workflow'
  },
  Queue: {
    path: '/workflow/queue/:id',
    name: 'WorkflowQueue'
  },
  Job: {
    path: '/workflow/job/:queueId/:jobId',
    name: 'WorkflowJob'
  }
};
