export interface DocumentPageDataModel {
  pageNumber: number;
  documentId: number;
  cabinetId: string;
}
