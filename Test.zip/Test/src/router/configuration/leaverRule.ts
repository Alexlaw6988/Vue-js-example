import { Configuration } from '@/types';
import ConfigurationTreeView from '@/components/configuration/TreeView.vue';
import { RouteHelpers } from '@/mixins';

const LeaversToolConfiguration = () =>
  import(
    /* webpackChunkName: "leaversTool" */
    '@/views/configuration/leaversTool/LeaversToolConfiguration.vue'
  );
const LeaverRules = () =>
  import(
    /* webpackChunkName: "LeaverRules" */
    '@/views/configuration/leaversTool/LeaverRules.vue'
  );
const AddLeaverRule = () =>
  import(
    /* webpackChunkName: "AddLeaverRule" */
    '@/views/configuration/leaversTool/AddLeaverRule.vue'
  );
const EditLeaverRule = () =>
  import(
    /* webpackChunkName: "EditLeaverRule" */
    '@/views/configuration/leaversTool/EditLeaverRule.vue'
  );

const meta = {
  layout: 'TreeView',
  treePath: 'leaverRules'
};

const props = {
  default: true
};

export const LeaverRuleRoutes = [
  {
    ...Configuration.LeaversTool.Base,
    components: {
      default: LeaversToolConfiguration,
      treeView: ConfigurationTreeView
    },
    meta: {
      layout: 'TreeView',
      treePath: 'leaversToolConfiguration'
    }
  },
  {
    ...Configuration.LeaverRule.Add,
    components: {
      default: AddLeaverRule,
      treeView: ConfigurationTreeView
    },
    props,
    meta,
    beforeEnter: (to: any, from: any, next: any) => {
      RouteHelpers.setErrorPageRedirect(Configuration.LeaversTool.Base.name);
      RouteHelpers.beforeEnterCheckRouteParamAsNumeric(to, from, next, ['configurationId']);
    }
  },
  {
    ...Configuration.LeaverRule.Edit,
    components: {
      default: EditLeaverRule,
      treeView: ConfigurationTreeView
    },
    props,
    meta,
    beforeEnter: (to: any, from: any, next: any) => {
      RouteHelpers.setErrorPageRedirect(Configuration.LeaversTool.Base.name);
      RouteHelpers.beforeEnterCheckRouteParamAsNumeric(to, from, next, ['configurationId', 'ruleId']);
    }
  },
  {
    ...Configuration.LeaverRule.Management,
    components: {
      default: LeaverRules,
      treeView: ConfigurationTreeView
    },
    meta
  }
];
