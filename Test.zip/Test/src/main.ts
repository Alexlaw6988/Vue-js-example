import 'babel-polyfill';
import Vue from 'vue';
import App from './App.vue';
import router from '@/router';
import store from './store';
import './registerServiceWorker';
import { library } from '@fortawesome/fontawesome-svg-core';
import { fas } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon, FontAwesomeLayers } from '@fortawesome/vue-fontawesome';
import 'bootstrap';
import BootstrapVue from 'bootstrap-vue';
import axios from 'axios';
import VueAxios from 'vue-axios';
import DefaultLayout from './layouts/DefaultLayout.vue';
import LoadingLayout from './layouts/LoadingLayout.vue';
import TreeViewLayout from './layouts/TreeViewLayout.vue';
import DocumentsToStoreTreeViewLayout from './layouts/DocumentsToStoreTreeViewLayout.vue';
import SlideUpDown from 'vue-slide-up-down';
import Snotify from 'vue-snotify';
import { snotifySettings } from '@/settings/snotifySettings';
import { mstoreSettings } from '@/settings/mstoreSettings';
import vSelect from 'vue-select';
import 'vue-select/dist/vue-select.css';
import VeeValidate from 'vee-validate';
import { ValidationProvider, ValidationObserver } from 'vee-validate';
import VueTimeago from 'vue-timeago';
import VueSignaturePad from 'vue-signature-pad';
import IdleVue from 'idle-vue';
import NProgress from 'nprogress';
import 'nprogress/nprogress.css';
import vueDebounce from 'vue-debounce';
import MStoreFormGroup from '@/components/shared/MStoreFormGroup.vue';
import '@/extensionMethods';
import { onEvent, onLongPress, onIntersect } from '@/directives';
import { MStoreForm, MStoreFormInput } from '@/components/shared';

Vue.config.productionTip = false;
library.add(fas);
Vue.component('font-awesome-icon', FontAwesomeIcon);
Vue.component('font-awesome-layers', FontAwesomeLayers);
Vue.use(BootstrapVue);
Vue.use(VueAxios, axios);
Vue.component('slide-up-down', SlideUpDown);
Vue.use(Snotify, snotifySettings);
Vue.use(VeeValidate, {
  inject: true,
  fieldsBagName: 'veeFields'
});
Vue.component('ValidationProvider', ValidationProvider);
Vue.component('ValidationObserver', ValidationObserver);
Vue.component('v-select', vSelect);
Vue.use(VueTimeago, {
  locale: 'en'
});
Vue.use(VueSignaturePad);
Vue.use(vueDebounce);
const idleVueEventsEmitter = new Vue();
Vue.use(IdleVue, {
  eventEmitter: idleVueEventsEmitter,
  idleTime: mstoreSettings.idleTimeout,
  startAtIdle: false,
  store,
  moduleName: 'idleStore'
});
Vue.component('DefaultLayout', DefaultLayout);
Vue.component('LoadingLayout', LoadingLayout);
Vue.component('TreeViewLayout', TreeViewLayout);
Vue.component('DocumentsToStoreTreeViewLayout', DocumentsToStoreTreeViewLayout);
NProgress.configure({ parent: '#m-content', showSpinner: false });
Vue.component('m-form-group', MStoreFormGroup);
Vue.component('m-form', MStoreForm);
Vue.component('m-form-input', MStoreFormInput);

Vue.directive('on-event', onEvent);
Vue.directive('on-longPress', onLongPress);
Vue.directive('on-intersect', onIntersect);

Vue.prototype.$log = (message: any) => { console.log(message); };

new Vue({
  router,
  store,
  render: (h) => h(App)
}).$mount('#app');
