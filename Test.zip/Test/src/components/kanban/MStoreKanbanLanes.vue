<template>
  <div id="kanbanLaneContainer" class="vue-drag-n-drop overflow-x-auto-y-hidden h-100" align="center">
    <div class="dd-result-group d-inline-flex h-100  pb-2">
      <div v-for="(lane, $index) in dataSource" :key="$index" class="dd-drop-container h-100">
        <h5 class="pb-2">{{ lane.laneName }}</h5>
        <div class="emptyContainer overflow-auto" :data-id="$index">
          <Container
            group-name="col"
            @drop="(event) => onCardDrop(lane.laneName, event)"
            :get-child-payload="getCardPayload(lane.laneName)"
            drag-class="dd-card-drag"
            drop-class="dd-card-drop"
            @drag-start="onDragStart($event, lane)"
            @drag-end="onDragEnd($event, lane.laneName)"
            @drag-enter="dragEnter = lane.laneName"
            :style="containerStyle(lane.cards.length, lane.laneName)"
            drag-handle-selector=".drag-enabled"
          >
            <Draggable
              :ref="`draggableElement${lane.laneName}`"
              v-for="(card, cid) in lane.cards"
              :key="cid"
              :style="cardStyle(lane.cards.length, lane.laneName, cid)"
              :data-id="card.cardId"
              :class="cardClass"
            >
              <slot name="dd-card" :cardData="card"></slot>
            </Draggable>
          </Container>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
  import { Container, Draggable } from 'vue-smooth-dnd';
  import { CardDragEventModel, KanbanLaneModel } from '@/types/models/kanban';
  import ResizeObserver from 'resize-observer-polyfill';
  import { Cursor } from '@/types';
  export default {
    name: 'MStoreKanbanLanes',
    components: { Container, Draggable },
    props: {
      dataSource: {
        type: Array as () => KanbanLaneModel[],
        required: true
      },
      isReadonly: {
        type: Boolean,
        default: false
      }
    },
    data() {
      return {
        containerHeight: 0,
        dragStart: false,
        dragEnter: null
      };
    },
    computed: {
      cardStyle(this: any) {
        return (cardsCount: number, laneName: string, index: number) => {
          const height = this.getCardHeight(laneName);
          return this.containerHeight > cardsCount * height || `top:${this.getTopPosition(height, index)}px;`;
        };
      },
      containerStyle(this: any) {
        return (cardsCount: number, laneName: string) => {
          if (!this.dragStart || this.dragEnter !== laneName) {
            return;
          }
          const cardHeight = this.getCardHeight(laneName);
          const totalHeight = cardsCount * cardHeight * (1 - this.stackingHeight) + cardHeight;
          const totalHeightOnDrop = totalHeight + cardHeight;
          return (
            this.containerHeight > totalHeightOnDrop ||
            `height: calc(100% + ${totalHeightOnDrop - this.containerHeight}px);`
          );
        };
      },
      cardClass(this: any) {
        return [this.isReadonly ? 'drag-disabled' : 'drag-enabled'];
      }
    },
    methods: {
      onCardDrop(this: any, laneName: any, dropResult: any): void {
        if (dropResult.removedIndex !== null || dropResult.addedIndex !== null) {
          this.$emit('dropInDestinationBucket', laneName, dropResult);
        }
        if (dropResult.addedIndex != null) {
          const cardDragEvent = { ...this.cardDragEvent } as CardDragEventModel;
          cardDragEvent.toLaneName = laneName;
          cardDragEvent.toLaneCardIndex = dropResult.addedIndex;
          this.$emit('cardDragEvent', cardDragEvent);
        }
      },
      getCardPayload(this: any, id: any) {
        return (index: number) => {
          const found = this.dataSource.find((lane: KanbanLaneModel) => lane.laneName === id) as KanbanLaneModel;
          return found?.cards[index];
        };
      },
      onDragStart(this: any, event: any, lane: KanbanLaneModel) {
        if (this.dragStart || !event.isSource) {
          return;
        }

        const fromIndex = lane.cards.findIndex((x) => x === event.payload);

        this.cardDragEvent = {
          fromLaneName: lane.laneName,
          fromLaneCardIndex: fromIndex,
          card: event.payload
        } as CardDragEventModel;

        this.dragStart = true;
        document.documentElement.style.cursor = Cursor.webkitGrabbing;
        const elements = this.$refs[`draggableElement${lane.laneName}`];
        const isStackable = this.containerHeight > elements.length * elements[0].$el.clientHeight;
        if (elements && !isStackable) {
          elements.forEach((element: any, index: number) => {
            if (index > fromIndex) {
              element.$el.style.top = `${this.getTopPosition(element.$el.clientHeight, index - 1)}px`;
            }
          });
        }
      },
      onDragEnd(this: any, event: any, laneName: string) {
        if (event.payload.laneName !== laneName) {
          return;
        }
        document.documentElement.style.cursor = Cursor.default;
        this.dragStart = false;
        this.dragEnter = null;
        const elements = this.$refs[`draggableElement${laneName}`];
        if (elements) {
          elements.forEach((element: any, index: number) => {
            element.$el.style = this.cardStyle(elements.length, laneName, index);
          });
        }
      },
      getTopPosition(this: any, height: number, index: number) {
        return index * -(height * this.stackingHeight);
      },
      setContainerHeight(this: any) {
        this.containerHeight = document.querySelector('.emptyContainer')!?.clientHeight;
      },
      getCardHeight(this: any, laneName: string) {
        const elements = this.$refs[`draggableElement${laneName}`];
        if (!elements) {
          return this.draggableHeight;
        }
        return elements[0]?.$el.clientHeight || this.draggableHeight;
      }
    },
    created(this: any) {
      this.stackingHeight = 0.36;
      this.draggableHeight = 150;
    },
    mounted(this: any) {
      this.setContainerHeight();
      const laneContainer = document.getElementById('kanbanLaneContainer') as HTMLElement;
      this.laneContainerResizeObserver = new ResizeObserver(() => this.setContainerHeight());
      this.laneContainerResizeObserver.observe(laneContainer);
    },
    beforeDestroy(this: any) {
      this.laneContainerResizeObserver.disconnect();
    }
  };
</script>
