<template>
  <div class="tree-header">
    <h5 class="text">
      <font-awesome-icon v-if="icon" :icon="icon" size="lg" class="mr-1 text-primary" />
      <span v-else>
        <a>
          <font-awesome-icon
            icon="plus-square"
            size="lg"
            class="mr-1 text-primary p-1 cursor-pointer"
            title="Expand All"
            @click="onExpandOrCollapseClicked('expand')"
          />
        </a>
        <a>
          <font-awesome-icon
            icon="minus-square"
            size="lg"
            class="mr-1 text-primary p-1 cursor-pointer"
            title="Collapse All"
            @click="onExpandOrCollapseClicked('collapse')"
          />
        </a>
      </span>
      {{ title }}
    </h5>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';

  export default Vue.extend({
    name: 'TreeViewHeader',
    props: {
      title: {
        type: String,
        required: true
      },
      icon: {
        type: String,
        required: false
      }
    },
    methods: {
      onExpandOrCollapseClicked(this: any, event: string) {
        this.$emit(event);
      }
    }
  });
</script>
