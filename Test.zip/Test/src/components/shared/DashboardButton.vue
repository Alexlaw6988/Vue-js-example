<template>
  <div class="card mb-3">
    <div class="row no-gutters" @click="navigate">
      <div class="col-md-4 bg-primary text-center rounded-left">
        <div :class="iconCss" @mouseover="hover = true" @mouseleave="hover = false">
          <font-awesome-icon :icon="icon" size="4x" class="text-light" />
        </div>
      </div>
      <div class="col-md-8">
        <div :class="buttonCss">
          <div class="d-flex h-100 align-items-center" @mouseover="hover = true" @mouseleave="hover = false">
            <h5>{{ text }}</h5>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  export default Vue.extend({
    name: 'DashboardButton',
    props: {
      icon: {
        type: String,
        required: true
      },
      text: {
        type: String,
        required: true
      },
      routeName: {
        type: String,
        required: true
      }
    },
    data() {
      return {
        hover: false
      };
    },
    methods: {
      navigate() {
        this.$router.push({ name: this.routeName });
      }
    },
    computed: {
      buttonCss(): string {
        return `card-body h-100 ${this.hover ? 'pointer bg-light-gray' : ''}`;
      },
      iconCss(): string {
        return `d-flex h-100 justify-content-center align-items-center p-3 ${this.hover ? 'pointer' : ''}`;
      }
    }
  });
</script>
