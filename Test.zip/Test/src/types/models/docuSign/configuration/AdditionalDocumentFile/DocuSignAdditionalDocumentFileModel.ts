import { DocuSignAdditionalDocumentSignTabModel } from '@/types';

export interface DocuSignAdditionalDocumentFileModel {
    id: number;
    fileName: string;
    description: string;
    signTabs: DocuSignAdditionalDocumentSignTabModel[];
}