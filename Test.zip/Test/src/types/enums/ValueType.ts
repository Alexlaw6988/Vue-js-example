export enum ValueType {
  Any = 0,
  AlphaNumeric = 1,
  Integer = 2,
  Decimal = 3,
  Email = 4
}