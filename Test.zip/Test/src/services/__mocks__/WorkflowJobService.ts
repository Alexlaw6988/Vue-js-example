import { DocumentModel } from '@/types';

export const WorkflowJobService = {
  getWorkflowDocumentAsync(jobId: number, pageNumber: number): Promise<DocumentModel> {
    return Promise.resolve({
      cabinetId: 'Test',
      id: 123
    } as DocumentModel);
  }
};
