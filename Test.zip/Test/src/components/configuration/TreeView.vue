<template>
	<div id="m-treeview">
		<TreeViewHeader title="Configurations" @expand="expandAll('tree')" @collapse="collapseAll('tree')" />
		<tree ref="tree" v-if="!loading" :data="treeData" :options="options" @node:clicked="navigate" @tree:mounted="getNode">
			<div class="tree-scope" slot-scope="{ node }">
				<template>
					<h6 class="text" data-testid="treeview-header">
						<font-awesome-icon :icon="node.data.icon" size="lg" class="text-primary" />
						{{ node.text }}
					</h6>
				</template>
			</div>
		</tree>
	</div>
</template>

<script lang="ts">
import Vue from 'vue';
import LiquorTree from 'liquor-tree';
import { ConfigurationModel } from '@/types';
import { ConfigurationService } from '@/services/ConfigurationService';
import LoadingSpinner from '@/components/shared/LoadingSpinner.vue';
import { TreeViewHeader } from '@/components/shared';
import { TreeViewHelpers } from '@/mixins/treeView.ts';
Vue.use(LiquorTree);

export default Vue.extend({
  name: 'ConfigurationTreeView',
  mixins: [TreeViewHelpers],
  props: {
    loading: {
      type: Boolean,
      required: false
    }
  },
  data() {
    return {
      permissionData: {} as ConfigurationModel,
      options: {
        checkbox: false,
        parentSelect: true
      }
    };
  },
  methods: {
    async getPermissions() {
      this._isLoading = true;
      this.permissionData = await ConfigurationService.getConfigurationAsync();
      this._isLoading = false;
    },
    navigate(node: any) {
      if (node.data.componentName && node.data.componentName.localeCompare(this.$router.currentRoute.name)) {
        this.$router.push({ name: node.data.componentName });
      } else {
        node.states.expanded = !node.states.expanded;
      }
    },
    getNode(this: any, tree: any) {
      const node = tree.find({
        data: { path: this.$route.meta.treePath }
      });
      if (!node) {
        return;
      }
      this.selectNode(node);
    }
  },
  watch: {
    '$route.meta.treePath'(this: any, treePath) {
      if (!treePath) {
        const selectedNode = this.$refs.tree.find({
          state: { selected: true }
        });
        this.unselectNode(selectedNode);
      }
    }
  },
  computed: {
    treeData(): object {
      return [
        {
          text: 'Security',
          data: { icon: 'lock' },
          state: {
            visible: this.permissionData.canConfigureSecurity,
            selectable: false
          },
          children: [
            {
              text: 'User Management',
              data: {
                icon: 'user',
                componentName: 'userManagement',
                path: 'users'
              },
              state: { visible: this.permissionData.canMaintainAllUsers }
            },
            {
              text: 'Role Management',
              data: {
                icon: 'users',
                componentName: 'roleManagement',
                path: 'roles'
              },
              state: {
                visible: this.permissionData.canMaintainAllRoles || this.permissionData.canMaintainMyRoles
              }
            },
            {
              text: 'Organisation Management',
              data: {
                icon: 'building',
                componentName: 'organisationManagement',
                path: 'organisations'
              },
              state: {
                visible: this.permissionData.canMaintainUserClientMaintenance
              }
            }
          ]
        },
        {
          text: 'HR',
          data: { icon: 'users' },
          state: {
            visible: this.permissionData.canConfigureHr,
            selectable: false
          },
          children: [
            {
              text: 'Leavers Tool',
              data: {
                icon: 'cog',
                componentName: 'leaversToolConfiguration',
                path: 'leaversToolConfiguration'
              },
              state: {
                visible: this.permissionData.canConfigureLeaversTool
              }
            },
            {
              text: 'Leaver Rules',
              data: {
                icon: 'tasks',
                componentName: 'leaverRules',
                path: 'leaverRules'
              },
              state: {
                visible: this.permissionData.canConfigureLeaversTool
              }
            }
          ]
        },
        {
          text: 'DocuSign',
          data: { icon: 'file-signature' },
          state: {
            visible: this.permissionData.canConfigureDocuSign,
            selectable: false
          },
          children: [
            {
              text: 'Document Types',
              data: {
                icon: 'sitemap',
                componentName: 'docusignEditDocumentTypes',
                path: 'docusigndocumenttypes'
              },
              state: {
                visible: this.permissionData.canConfigureDocuSign
              }
            },
            {
              text: 'Settings',
              data: {
                icon: 'cog',
                componentName: 'docusignSettings',
                path: 'docusignsettings'
              },
              state: {
                visible: this.permissionData.canConfigureDocuSign
              }
            },
            {
              text: 'Additional Documents',
              data: {
                icon: 'copy',
                componentName: 'docusignAdditionalDocumentManagement',
                path: 'docusignadditionaldocuments'
              },
              state: {
                visible: this.permissionData.canConfigureDocuSign
              }
            },
            {
              text: 'Signers',
              data: {
                icon: 'user-edit',
                componentName: 'docusignSignerRoleManagement',
                path: 'docusignsignerroles'
              },
              state: {
                visible: this.permissionData.canConfigureDocuSign
              }
            },
            {
              text: 'Templates',
              data: {
                icon: 'file-contract',
                componentName: 'docusignTemplateManagement',
                path: 'docusigntemplates'
              },
              state: {
                visible: this.permissionData.canConfigureDocuSign
              }
            },
            {
              text: 'After Sign Mappings',
              data: {
                icon: 'file-import',
                componentName: 'docusignAfterSignMappingsManagement',
                path: 'docusignaftersignmappings'
              },
              state: {
                visible: this.permissionData.canConfigureDocuSign
              }
            },
            {
              text: 'Account Configuration',
              data: {
                icon: 'cog',
                componentName: 'docusignAccountConfiguration',
                path: 'docusignaccountconfiguration'
              },
              state: {
                visible: this.permissionData.canConfigureDocuSign
              }
            }
          ]
        }
      ];
    },
    _isLoading: {
      get(this: any) {
        return this.loading;
      },
      set(this: any, value: boolean) {
        this.$emit('update:loading', value);
      }
    }
  },
  async mounted() {
    await this.getPermissions();
  },
  components: {
    LoadingSpinner,
    TreeViewHeader
  }
});
</script>
