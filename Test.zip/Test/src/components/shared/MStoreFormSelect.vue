<template>
  <b-form-group :label="fieldLabel" :description="fieldDescription">
    <b-input-group>
      <b-input-group-prepend v-if="this.isLoading || this.hasError">
        <b-button disabled :variant="buttonVariant" readonly v-b-tooltip.hover :title="errorMessage">
          <b-spinner class="align-middle" small v-if="isLoading"></b-spinner>
          <font-awesome-icon class="align-middle" icon="exclamation-triangle" v-if="hasError" />
        </b-button>
      </b-input-group-prepend>
      <b-form-select
        :id="id"
        data-testid="select-control"
        v-model="selectedValue"
        :options="_selectOptions"
        :value-field="valueFieldName"
        :text-field="displayFieldName"
        :disabled="disable || isLoading || hasError"
      ></b-form-select>
    </b-input-group>
  </b-form-group>
</template>

<script lang="ts">
  import Vue from 'vue';
  import AxiosConfiguration from '@/classes/AxiosConfiguration';
  import { FormFieldValidation } from '@/mixins/formValidation';

  export default Vue.extend({
    name: 'm-form-select',
    mixins: [FormFieldValidation],
    props: {
      selectOptionsApiPath: {
        type: String,
        required: false
      },
      selectOptionsData: {
        required: false
      },
      value: {
        required: true
      },
      displayFieldName: {
        type: String,
        required: true
      },
      valueFieldName: {
        type: String,
        required: true
      },
      fieldLabel: {
        type: String,
        required: true
      },
      fieldDescription: {
        type: String,
        required: false
      },
      disable: {
        type: Boolean,
        required: false
      },
      id: {
        type: String
      }
    },
    data(this: any) {
      return {
        selectOptions: [],
        isLoading: false,
        hasError: false,
        errorMessage: '',
        selectedValue: !this.value || this.hasError ? 0 : this.value,
        defaultItem: {
          [this.displayFieldName]: '- Please select -',
          [this.valueFieldName]: 0,
          disabled: true
        }
      };
    },
    watch: {
      hasError(this: any) {
        this.$emit('hasError', this.hasError, this.errorMessage);
      },
      selectedValue(this: any, value: any) {
        if (!this.isLoading) {
          this.$emit('input', value);
        }
      },
      isLoading(this: any, value: boolean) {
        if (value) {
          this._defaultItem = 'Loading...';
        } else if (this.hasError) {
          this._defaultItem = this.errorMessage;
        } else {
          this._defaultItem = '- Please select -';
        }
        this.selectedValue = !this.value || this.hasError ? 0 : this.value;
      },
      selectOptionsData(this: any, value: any) {
        this._selectOptions = value;
      },
      value(this: any, value: any) {
        this.selectedValue = value ? value : 0;
      }
    },
    methods: {
      addDefaultItem(this: any) {
        this.selectOptions.push(this._defaultItem);
      },
      async getItemsViaApiAsync() {
        this.isLoading = true;
        await AxiosConfiguration.axiosWithoutNotification
          .get(this.selectOptionsApiPath)
          .then((response) => {
            this._selectOptions = response.data;
            this.isLoading = false;
            this.hasError = false;
            this.errorMessage = '';
          })
          .catch((error: any) => {
            this._selectOptions = [];
            this.isLoading = false;
            this.hasError = true;
            this.errorMessage = error.response.data;
            this._defaultItem = error.response.data;
          });
      }
    },
    async mounted(this: any) {
      this.addDefaultItem();
      if (this.selectOptionsApiPath) {
        await this.getItemsViaApiAsync();
      } else {
        this._selectOptions = this.selectOptionsData as any;
      }
    },
    computed: {
      _selectOptions: {
        get(this: any) {
          return this.selectOptions;
        },
        set(this: any, value: any) {
          if (value) {
            this.selectOptions = [this.defaultItem];
            for (const i of value) {
              this.selectOptions.push(i);
            }
          }
        }
      },
      _defaultItem: {
        get(this: any) {
          return this.defaultItem;
        },
        set(this: any, value: any) {
          this.defaultItem[this.displayFieldName] = value;
        }
      },
      buttonVariant(): string {
        return this.hasError ? 'danger' : 'primary';
      }
    }
  });
</script>
