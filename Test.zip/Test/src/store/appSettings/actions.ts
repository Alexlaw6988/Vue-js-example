import { DocuSignWorkflowJobState, RootState, AppSettingsModel } from '@/types';
import { ActionTree } from 'vuex';
import { AppSettingsService } from '@/services/AppSettingsService';
import { Logger } from '@/classes/Logger';

export const actions: ActionTree<DocuSignWorkflowJobState, RootState> = {
  getAppSettings(this: any, { commit }: any) {
    AppSettingsService.getAppSettingsAsync()
      .then((response: AppSettingsModel) => {
        commit('APP_SETINGS_LOADED', response);
      })
      .catch((error: any) => {
        Logger.$log(error);
      });
  }
};
