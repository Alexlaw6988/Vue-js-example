import { OrganisationManagementState, RootState } from '@/types';
import { GetterTree } from 'vuex';

export const getters: GetterTree<OrganisationManagementState, RootState> = {
  getOrganisationManagementStateField: (state) => (field: keyof OrganisationManagementState): any => {
    return state[field];
  }
};
