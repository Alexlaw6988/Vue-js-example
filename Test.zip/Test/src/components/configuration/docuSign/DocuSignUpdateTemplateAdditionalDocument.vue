<template>
  <div v-if="!isLoading">
    <m-form @submit.prevent="onSubmit" v-slot="{ dirty }">
      <div class="row">
        <div class="col">
          <m-form-select
            id="additionalDocumentFile"
            name="additionalDocumentFile"
            v-if="!isLoading"
            :select-options-data="templateAdditionalDocumentConfiguration.additionalDocumentFiles"
            v-model="additionalDocumentFileId"
            display-field-name="description"
            value-field-name="id"
            field-label="Additional Document File"
            v-validate.disabled
          ></m-form-select>
          <b-tooltip target="additionalDocumentFile" placement="left"></b-tooltip>
        </div>
      </div>

      <div class="row mb-3">
        <div class="col">
          <div class="card min-h-100">
            <div class="card-header">
              Additional Document Signing
            </div>
            <div class="card-body">
              <b-alert v-if="selectedAdditionalDocumentHasSignTabs" variant="info" show dismissible>
                The sign locations are pre-defined for each additional document file. Here, we just need to select the
                signer we want to sign each location.
              </b-alert>
              <div v-else>
                <b-alert variant="info" show dismissible>
                  There are no sign locations configured for this additional document.
                </b-alert>
              </div>
              <div v-show="selectedAdditionalDocumentHasSignTabs" class="row mb-3">
                <div class="col-3">
                  <h6>Sign Location</h6>
                </div>
                <div class="col">
                  <h6>Signer</h6>
                </div>
              </div>

              <div
                class="row"
                v-for="additionalDocumentSignTab in additionalDocumentSignTabs"
                :key="additionalDocumentSignTab.id"
              >
                <div class="col-3 align-self-center">
                  <b-form-group>
                    <span>
                      {{ additionalDocumentSignTab.tabName }}
                    </span>
                  </b-form-group>
                </div>

                <div class="col">
                  <m-form-select
                    :select-options-data="templateAdditionalDocumentConfiguration.signerRoles"
                    v-model="tabSigners[`${additionalDocumentSignTab.id}`]"
                    display-field-name="description"
                    value-field-name="id"
                    v-validate.disabled
                    :field-label="''"
                    :name="`TabSigner-${additionalDocumentSignTab.id}`"
                  ></m-form-select>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <b-form-invalid-feedback id="formValidation-feedback" :force-show="true">
        {{ errors.first('validationErrors') }}
      </b-form-invalid-feedback>
      <b-form-group class="float-right">
        <b-button
          variant="danger"
          data-testid="update-template-additional-document-cancel-button"
          class="mr-1"
          :disabled="submitIsLoading"
          @click="onCancel()"
        >
          Cancel
        </b-button>
        <b-button
          type="submit"
          data-testid="update-template-additional-document-save-button"
          variant="primary"
          :disabled="submitIsLoading || (!isFormDirty() && !dirty)"
        >
          <b-spinner small class="mb-1 mr-1" v-if="submitIsLoading"></b-spinner>
          Save
        </b-button>
      </b-form-group>
    </m-form>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  import { FormFieldValidation, RouteHelpers, ObjectHelper } from '@/mixins';
  import {
    DocuSignTemplateAdditionalDocumentConfigurationModel,
    DocuSignTemplateAdditionalDocumentCreateUpdateModel,
    DocuSignTemplateAdditionalDocumentSignHereModel,
    DocuSignAdditionalDocumentFileModel,
    DocuSignAdditionalDocumentSignTabModel,
    DocuSignTemplateAdditionalDocumentSignHereCreateUpdateModel,
    Dictionary,
    Configuration
  } from '@/types';
  import MStoreFormSelect from '@/components/shared/MStoreFormSelect.vue';
  export default Vue.extend({
    name: 'ds-update-template-additional-document',
    mixins: [FormFieldValidation, RouteHelpers, ObjectHelper],
    props: {
      isLoading: {
        type: Boolean,
        required: true
      },
      submitIsLoading: {
        type: Boolean,
        required: true
      },
      templateAdditionalDocumentConfiguration: {
        type: Object as () => DocuSignTemplateAdditionalDocumentConfigurationModel,
        required: true,
        default: {} as DocuSignTemplateAdditionalDocumentConfigurationModel
      },
      templateAdditionalDocument: {
        type: Object as () => DocuSignTemplateAdditionalDocumentCreateUpdateModel,
        required: true,
        default: {} as DocuSignTemplateAdditionalDocumentCreateUpdateModel
      },
      serverValidationMessage: {
        type: String,
        required: true
      }
    },
    data() {
      return {
        hasError: false,
        errorMessage: '',
        pageNumber: '',
        tabSigners: [],
        additionalDocumentFileId: null,
        additionalDocumentSignTabs: {} as DocuSignAdditionalDocumentSignTabModel[],
        loaded: false
      };
    },
    methods: {
      initialise(this: any) {
        this.templateAdditionalDocumentModel = this.templateAdditionalDocumentConfiguration.templateAdditionalDocument;
        this.additionalDocumentFileId = this.templateAdditionalDocumentConfiguration.additionalDocumentFileId;
        this.$nextTick(() => {
          this.resetField('additionalDocumentFile');
        });
      },
      async onSubmit(this: any) {
        this.resetFormValidation();
        try {
          const isValid = await this.$validator.validate();
          if (!isValid || !this.validateSigners()) {
            return;
          }

          this.$emit('submit', {
            documentTypeId: this.documentTypeId,
            templateId: this.templateId,
            additionalDocumentFileId: this.additionalDocumentFileId,
            templateAdditionalDocumentSignHeres: this.getTemplateAdditionalDocumentSignHeres()
          });
        } catch (error) {
          this.$log('Error updating Template Additional Document', error);
        } finally {
          this.submitIsLoading = false;
        }
      },
      validateSigners(this: any): boolean {
        if (this.tabSigners.some((x: number) => x === 0)) {
          this.addFormValidationError('Please select a signer for each location');
          return false;
        }
        return true;
      },
      async onCancel(this: any) {
        this.navigateToTemplateAdditionalDocumentManagement();
      },
      navigateToTemplateAdditionalDocumentManagement(this: any) {
        const param = {} as Dictionary<any>;
        param.documentTypeId = this.documentTypeId;
        param.templateId = this.templateId;
        this.$router.push({
          name: Configuration.DocuSign.TemplateAdditionalDocument.Management.name,
          params: param
        });
      },
      getTemplateAdditionalDocumentSignHeres(this: any): DocuSignTemplateAdditionalDocumentSignHereCreateUpdateModel[] {
        const templateSignHeres: DocuSignTemplateAdditionalDocumentSignHereCreateUpdateModel[] = [];
        this.tabSigners.forEach((value: number, index: number) => {
          templateSignHeres.push({
            additionalDocumentSignTabId: index,
            signerRoleId: value
          } as DocuSignTemplateAdditionalDocumentSignHereCreateUpdateModel);
        });
        return templateSignHeres;
      }
    },
    computed: {
      documentTypeId(): number {
        return Number(this.$route.params.documentTypeId);
      },
      templateId(): number {
        return Number(this.$route.params.templateId);
      },
      templateAdditionalDocumentId(): number {
        return Number(this.$route.params.id);
      },
      selectedAdditionalDocumentHasSignTabs(this: any) {
        return this.additionalDocumentSignTabs.length > 0;
      }
    },
    watch: {
      serverValidationMessage(this: any, value: string) {
        if (!this.isNullOrEmpty(value)) {
          this.addFormValidationError(value);
        }
      },
      additionalDocumentFileId(this: any, value: number | null) {
        if (value === null) {
          return;
        }
        this.tabSigners = [];
        const additionalDocumentFile = this.templateAdditionalDocumentConfiguration.additionalDocumentFiles.find(
          (x: DocuSignAdditionalDocumentFileModel) => x.id === value
        );
        if (!additionalDocumentFile) {
          return;
        }
        this.additionalDocumentSignTabs = additionalDocumentFile.signTabs;
        if (!this.loaded && this.templateAdditionalDocument?.additionalDocumentFile?.id === value) {
          this.templateAdditionalDocument.signHeres.forEach((x: DocuSignTemplateAdditionalDocumentSignHereModel) => {
            this.tabSigners[x.additionalDocumentSignTab.id] = x.signerRole.id;
          });
          this.loaded = true;
          return;
        }
        additionalDocumentFile.signTabs.forEach((x: DocuSignAdditionalDocumentSignTabModel) => {
          this.tabSigners[x.id] = 0;
        });
      }
    },
    mounted(this: any) {
      this.initialise();
    },
    components: {
      'm-form-select': MStoreFormSelect
    }
  });
</script>
