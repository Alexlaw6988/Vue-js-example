<template>
  <div class="card">
    <Header
      v-if="showHeader"
      :show-hide-filters="showHideFilters && items.length > 0"
      :is-loading="isLoading"
      :has-error="hasError"
      :show-filters="showFilters"
      :emit-filters="emitFilters"
      :items-per-page="itemsPerPage"
      :search-query="searchQuery"
      :header-text="`${headerText} - ${totalRows} Items`"
      :allow-wallboard-mode="allowWallboardMode"
      :wallboard-refresh-interval-in-seconds="wallboardRefreshIntervalInSeconds"
      @refresh-triggered="onRefresh()"
      @update:show-filters="$emit('update:show-filters', 'showFilters', $event)"
      @update:items-per-page="$emit('update:items-per-page', 'itemsPerPage', $event)"
      @update:search-query="$emit('update:search-query', 'searchQuery', $event)"
    >
      <template v-for="(value, slot) in $slots">
        <template :slot="slot">
          <slot :name="slot"></slot>
        </template>
      </template>
    </Header>
    <div class="card-body overflow-auto p-0">
      <h6 v-if="hasError" class="text-center pt-4">{{ errorMessage }}</h6>
      <div v-else>
        <div class="card-body p-0">
          <b-table
            ref="mtable"
            :id="tableId"
            :data-testid="`table-${tableId}`"
            bordered
            show-empty
            :busy="isLoading"
            :empty-text="emptyText"
            :empty-html="emptyHtml"
            :items="items"
            :fields="fields"
            :current-page="localCurrentPage"
            :per-page="localItemsPerPage"
            :filter="searchQuery"
            @filtered="onFiltered"
            @row-clicked="rowClicked"
            @update:sortBy="sortByChanged"
            @update:sortDesc="sortDescChanged"
            :hover="canHoverOnTableRow"
            :tbody-tr-class="rowClass"
            :thead-tr-class="theadClass"
            :sort-by="sortBy"
            :sort-desc="sortDesc"
            :filter-function="tableFilter"
            @sort-changed="onSorted"
            :primary-key="primaryKey"
            :sticky-header="stickyHeader"
          >
            <template v-for="(value, slot) in $scopedSlots" :slot="slot" slot-scope="slotData">
              <slot :name="slot" v-bind="slotData" />
            </template>
          </b-table>
        </div>
      </div>
    </div>
    <div v-if="!hasError && pagination" class="card-footer">
      <b-pagination
        size="md"
        align="right"
        class="mb-0"
        :total-rows="totalRows"
        v-model="localCurrentPage"
        :per-page="localItemsPerPage"
      />
    </div>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  import Header from './Header.vue';
  import { BTableHelpers } from '@/mixins/bTable';
  import { ObjectUtils } from '@/utils/objectUtils';

  export default Vue.extend({
    name: 'm-table',
    mixins: [BTableHelpers],
    props: {
      headerText: {
        type: String,
        required: true
      },
      errorMessage: {
        type: String,
        required: false
      },
      hasError: {
        type: Boolean,
        required: false
      },
      showHideFilters: {
        type: Boolean,
        required: false,
        default: false
      },
      items: {
        type: Array,
        required: true
      },
      fields: {
        type: Array,
        required: true
      },
      isLoading: {
        type: Boolean,
        required: true
      },
      emptyText: {
        type: String,
        required: false
      },
      canHoverOnTableRow: {
        type: Boolean,
        required: false,
        default: true
      },
      rowClass: {
        type: Function,
        required: false
      },
      theadClass: {
        type: String,
        required: false,
        default: 'text-no-wrap'
      },
      tableId: {
        type: String,
        required: false
      },
      emitFilters: {
        type: Boolean,
        required: false,
        default: false
      },
      showFilters: {
        type: Boolean,
        required: false,
        default: false
      },
      currentPage: {
        type: Number,
        required: false,
        default: 1
      },
      itemsPerPage: {
        type: Number,
        required: false
      },
      searchQuery: {
        type: String,
        required: false,
        default: ''
      },
      sortBy: {
        type: String,
        required: false,
        default: ''
      },
      sortDesc: {
        type: Boolean,
        required: false,
        default: false
      },
      emptyHtml: {
        type: String,
        required: false,
        default: ''
      },
      pkField: {
        type: String,
        required: false
      },
      selectedPk: {
        required: false
      },
      pagination: {
        type: Boolean,
        required: false,
        default: true
      },
      showHeader: {
        type: Boolean,
        required: false,
        default: true
      },
      stickyHeader: {
        type: Boolean,
        required: false,
        default: false
      },
      allowWallboardMode: {
        type: Boolean,
        default: false
      },
      wallboardRefreshIntervalInSeconds: {
        type: Number,
        default: 0
      }
    },
    data(this: any) {
      return {
        internalCurrentPage: 1,
        internalItemsPerPage: 20,
        totalRows: this.items.length as number,
        filteredItems: []
      };
    },
    methods: {
      onSorted(this: any, item: any) {
        this.$emit('on-filtered-or-sorted', this.$refs.mtable?.sortedItems);
      },
      onFiltered(this: any, filteredItems: any) {
        this.totalRows = filteredItems.length;
        this.filteredItems = filteredItems;
        this.$emit('update:filtered-items', 'filteredItems', filteredItems);
        this.$emit('on-filtered-or-sorted', this.$refs.mtable?.sortedItems);
      },
      onRefresh() {
        this.$emit('refresh-clicked');
      },
      rowClicked(item: any) {
        this.$emit('row-clicked', item);
        this.$emit('update:selected-pk', 'selectedPk', item[this.primaryKey]);
      },
      sortByChanged(item: any) {
        this.$emit('update:sort-by', 'sortBy', item);
      },
      sortDescChanged(item: any) {
        this.$emit('update:sort-desc', 'sortDesc', item);
      },
      setCurrentPage(this: any) {
        this.localCurrentPage = this.getCurrentPage();
      },
      selectRowByIndex(this: any, index: number) {
        this.$refs.mtable.selectRow(index);
      },
      initialise(this: any) {
        this.filteredItems = this.getFilteredItems();
        this.totalRows = this.filteredItems.length;
        this.setCurrentPage();
        this.$emit('on-filtered-or-sorted', this.filteredItems);
        this.$emit('on-items-changed', this.items);
      },
      getCurrentPage(this: any) {
        const itemsPerPage = this.itemsPerPage ? this.itemsPerPage : this.internalItemsPerPage;
        const index = this.filteredItems.findIndex((row: any) => row[this.primaryKey] === this.selectedPk);
        if (index > -1) {
          return Math.ceil((index + 1) / itemsPerPage);
        } else {
          return Math.min(this.currentPage, Math.ceil(this.totalRows / itemsPerPage));
        }
      },
      getFilteredItems(this: any) {
        if (this.sortBy) {
          return this.$refs.mtable?.sortedItems;
        }
        return this.$refs.mtable?.filteredItems || this.items;
      },
      checkItemsHasThePrimaryKey(this: any) {
        if (ObjectUtils.isNullOrEmpty(this.items[0])) {
          return false;
        }

        return Object.keys(this.items[0])?.some((field: any) => field === this.pkField);
      }
    },
    watch: {
      isLoading(this: any) {
        if (!this.isLoading) {
          this.$nextTick(() => {
            this.initialise();
          });
        }
      }
    },
    computed: {
      localCurrentPage: {
        get(this: any): number {
          return this.emitFilters ? this.currentPage : this.internalCurrentPage;
        },
        set(this: any, value: any) {
          if (this.emitFilters) {
            this.$emit('update:current-page', 'currentPage', Math.max(1, value));
          } else {
            this.internalCurrentPage = Math.max(1, value);
          }
        }
      },
      localItemsPerPage: {
        get(this: any): number {
          return this.emitFilters ? this.itemsPerPage : this.internalItemsPerPage;
        },
        set(this: any, value: any) {
          if (this.emitFilters) {
            this.$emit('update:items-per-page', 'itemsPerPage', value);
          } else {
            this.internalItemsPerPage = value;
          }
        }
      },
      primaryKey(this: any) {
        return this.pkField &&
          (this.fields.some((field: any) => field.key === this.pkField) || this.checkItemsHasThePrimaryKey())
          ? this.pkField
          : this.getKey(this.fields[0]);
      }
    },
    mounted() {
      this.initialise();
    },
    components: {
      Header
    }
  });
</script>
