export const AutomotiveConstants = {
  WorkflowTabKeys: {
    WorkflowTabKey: 'WorkflowTab'
  }
};
