interface String {
  contains(searchString: string): boolean;
  empty(): string;
}

String.prototype.contains = function contains(searchString: string) {
  return this.toLowerCase().indexOf(searchString.toLowerCase()) > -1;
};

String.prototype.empty = () => '';
