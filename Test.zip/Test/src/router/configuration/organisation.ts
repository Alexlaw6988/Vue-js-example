import { RouteHelpers } from '@/mixins';
import { Configuration } from '@/types';
import ConfigurationTreeView from '@/components/configuration/TreeView.vue';

const OrganisationManagement = () =>
  import(
    /* webpackChunkName: "configuration" */
    '@/views/configuration/organisation/OrganisationManagement.vue'
  );
const AddOrganisation = () =>
  import(
    /* webpackChunkName: "configuration" */
    '@/views/configuration/organisation/AddOrganisation.vue'
  );
const ViewOrganisation = () =>
  import(
    /* webpackChunkName: "configuration" */
    '@/views/configuration/organisation/ViewOrganisation.vue'
  );
const EditOrganisation = () =>
  import(
    /* webpackChunkName: "configuration" */
    '@/views/configuration/organisation/EditOrganisation.vue'
  );

const meta = {
  layout: 'TreeView',
  treePath: 'organisations'
};

const metaWithModel = {
  ...meta,
  model: 'organisation'
};

export const OrganisationRoutes = [
  {
    ...Configuration.Organisation.Management,
    components: {
      default: OrganisationManagement,
      treeView: ConfigurationTreeView
    },
    meta
  },
  {
    ...Configuration.Organisation.Add,
    components: {
      default: AddOrganisation,
      treeView: ConfigurationTreeView
    },
    meta
  },
  {
    ...Configuration.Organisation.View,
    components: {
      default: ViewOrganisation,
      treeView: ConfigurationTreeView
    },
    meta: metaWithModel,
    beforeEnter: (to: any, from: any, next: any) => {
      RouteHelpers.setErrorPageRedirect(Configuration.Organisation.Management.name);
      RouteHelpers.beforeEnterCheckRouteParamAsNumeric(to, from, next, ['id']);
    }
  },
  {
    ...Configuration.Organisation.Edit,
    components: {
      default: EditOrganisation,
      treeView: ConfigurationTreeView
    },
    meta: metaWithModel,
    beforeEnter: (to: any, from: any, next: any) => {
      RouteHelpers.setErrorPageRedirect(Configuration.Organisation.Management.name);
      RouteHelpers.beforeEnterCheckRouteParamAsNumeric(to, from, next, ['id']);
    }
  }
];
