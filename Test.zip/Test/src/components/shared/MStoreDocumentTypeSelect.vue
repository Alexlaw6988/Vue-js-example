<template>
  <div class="row col-md-12">
    <MStoreFormSelectTable
      :field-id="htmlElementIdCabinet"
      :field-label="cabinetLabel"
      :is-readonly="isDisabled"
      :is-required="isRequired"
      :action-button-component-name="properties.cabinet.actionButtonComponent"
      :is-loading="isLoading"
      :filter-disabled="!properties.cabinet.filterEnabled"
      :data="selectedCabinet"
      :list="cabinetList"
      :display-field="properties.cabinet.displayField"
      :value-field="properties.cabinet.valueField"
      :lineUpOnType="true"
      v-on:update:data="onCabinetChange"
      class="col-md-6"
    ></MStoreFormSelectTable>
    <MStoreFormSelectTable
      :field-id="htmlElementIdDocumentType"
      :field-label="documentTypeLabel"
      :is-readonly="isDisabled"
      :is-required="isRequired"
      :action-button-component-name="properties.documentType.actionButtonComponent"
      :is-loading="isLoading"
      :filter-disabled="!properties.documentType.filterEnabled"
      :data.sync="inputValue"
      :list="documentTypeList"
      :display-field="properties.documentType.displayField"
      :value-field="properties.documentType.valueField"
      :lineUpOnType="true"
      class="col-md-6"
    ></MStoreFormSelectTable>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  import { ListModel, ListHeaderModel, CabinetModel } from '@/types';
  import MStoreFormSelectTable from '@/components/shared/MStoreFormSelectTable.vue';

  export default Vue.extend({
    name: 'm-document-type-select',
    props: {
      value: {
        required: true
      },
      isRequired: {
        default: false,
        type: Boolean
      },
      isReadonly: {
        default: false,
        type: Boolean
      },
      formId: {
        required: false,
        type: String
      },
      id: {
        default: 'documentTypeSelect',
        type: String
      },
      excludeCabinetWithNoDocumentType: {
        default: false,
        type: Boolean
      },
      cabinetLabel: {
        default: 'Cabinet',
        type: String
      },
      documentTypeLabel: {
        default: 'Document Type',
        type: String
      },
      items: {
        required: true,
        type: Array
      },
      isLoading: {
        default: false,
        type: Boolean
      }
    },
    data() {
      return {
        selectedCabinet: null
      };
    },
    computed: {
      htmlElementId(this: any) {
        return this.formId ? `${this.formId}.${this.id}` : this.id;
      },
      htmlElementIdCabinet(this: any) {
        return `${this.htmlElementId}_cabinet`;
      },
      htmlElementIdDocumentType(this: any) {
        return `${this.htmlElementId}_documentType`;
      },
      cabinetList(this: any): ListModel {
        return this.cabinetWithDocumentTypes?.length > 0
          ? {
              id: 0,
              text: this.cabinetLabel,
              key: this.properties.cabinet.displayField,
              headers: this.fields.cabinet as ListHeaderModel[],
              list: this.sort(this.cabinetWithDocumentTypes, this.properties.cabinet.displayField),
              totalRow: this.cabinetWithDocumentTypes.length,
              resultType: 1,
              listDataResultTypeMessage: ''
            }
          : ({} as ListModel);
      },
      documentTypeList(this: any): ListModel {
        const cabinet = this.cabinetWithDocumentTypes?.find((cabinet: any) => cabinet.id === this.selectedCabinet);
        return cabinet?.documentTypes?.length > 0
          ? {
              id: 0,
              text: this.documentTypeLabel,
              key: this.properties.documentType.displayField,
              headers: this.fields.documentType as ListHeaderModel[],
              list: this.sort(cabinet.documentTypes, this.properties.documentType.displayField),
              totalRow: cabinet?.documentTypes?.length,
              resultType: 1,
              listDataResultTypeMessage: ''
            }
          : ({} as ListModel);
      },
      inputValue: {
        get(this: any) {
          return this.value;
        },
        set(this: any, value: string) {
          this.$emit('input', value);
        }
      },
      cabinetWithDocumentTypes(this: any) {
        return this.excludeCabinetWithNoDocumentType
          ? this.items.filter((cabinet: CabinetModel) => cabinet?.documentTypes?.length > 0)
          : this.items;
      },
      isDisabled(this: any): boolean {
        return this.isReadonly || this.isLoading;
      }
    },
    methods: {
      onCabinetChange(this: any, value: any) {
        this.selectedCabinet = value;
        this.inputValue = null;
      },
      prepareDefaultValue(this: any) {
        const cabinet = this.cabinetWithDocumentTypes.find((cabinet: any) =>
          cabinet.documentTypes.some((documentType: any) => documentType.id === this.value)
        );
        if (!cabinet) {
          this.inputValue = null;
        }
        this.selectedCabinet = cabinet?.id;
      },
      sort(this: any, list: any[], key: string): any[] {
        return list.sort((item1: any, item2: any) => (item1[key] > item2[key] ? 1 : -1));
      }
    },
    watch: {
      items(this: any) {
        this.prepareDefaultValue();
      }
    },
    created(this: any) {
      this.properties = {
        cabinet: {
          actionButtonComponent: '',
          maxLength: 0,
          filterEnabled: true,
          displayField: 'description',
          valueField: 'id'
        },
        documentType: {
          actionButtonComponent: '',
          maxLength: 0,
          filterEnabled: true,
          displayField: 'description',
          valueField: 'id'
        }
      };
      this.fields = {
        cabinet: [
          {
            id: '',
            data: 'description',
            title: 'Cabinet',
            key: 'id',
            label: 'description'
          }
        ],
        documentType: [
          {
            id: '',
            data: 'description',
            title: 'Document Type',
            key: 'id',
            label: 'description'
          }
        ]
      };
    },
    components: {
      MStoreFormSelectTable
    }
  });
</script>
