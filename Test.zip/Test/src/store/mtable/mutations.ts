import { MutationTree } from 'vuex';
import { TableStateModel } from '@/types';
import { mTable } from '../mtable';

export const mutations: MutationTree<TableStateModel[]> = {
  RESET_MTABLE_STATE(state, stateKey: string) {
    const indexPosition = state.findIndex((x: any) => x.stateKey === stateKey);
    if (indexPosition !== -1) {
      const defaultTableState = mTable.defaultMtableState();
      defaultTableState.stateKey = stateKey;
      Object.assign(state[indexPosition], defaultTableState);
    }
  },
  SET_MTABLE_STATE_FIELD(state, payload: any) {
    const tableStateKey = payload.stateKey;
    const tableStateField = payload.tableStateField;
    const indexPosition = state.findIndex((x: any) => x.stateKey === tableStateKey);

    if (indexPosition === -1) {
      const newTableState = mTable.defaultMtableState();
      newTableState.stateKey = tableStateKey;
      Object.assign(newTableState, {
        [tableStateField.field]: tableStateField.value
      });
      state.push(newTableState);
      return;
    }

    const existingTableState = state[indexPosition];
    Object.assign(existingTableState, {
      [tableStateField.field]: tableStateField.value
    });
  }
};
