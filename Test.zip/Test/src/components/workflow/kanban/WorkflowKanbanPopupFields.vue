<template>
  <div class="row">
    <div class="col col-xl-12">
      <div class="card">
        <div class="card-header text-white bg-primary">
          <h6 data-testid="workflow-kanban-popup-fields-header">{{ title }}</h6>
        </div>
        <div class="card-body pb-0">
          <m-form @submit.prevent="onProcess" v-slot="{ dirty }">
            <DynamicForm v-model="popupFieldSchemas" :isReadonly="isSubmitting" />
            <b-form-group class="float-right">
              <b-button @click="onCancel(dirty)" variant="danger" class="ml-2" :disabled="isSubmitting">
                Cancel
              </b-button>
              <b-button type="submit" variant="primary" class="ml-2" :disabled="isSubmitting || !getCanProcess">
                Process
              </b-button>
            </b-form-group>
            <b-form-invalid-feedback id="formValidation-feedback" :force-show="true">
              {{ formInvalidFeedback }}
            </b-form-invalid-feedback>
          </m-form>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  import { mapGetters, mapActions } from 'vuex';
  import DynamicForm from '@/components/shared/DynamicForm.vue';
  import { WorkflowKanbanPopupFieldsHelper, ModalHelpers } from '@/mixins';
  import { WorkflowKanbanJobProcessResultStatus, WorkflowKanbanPopupFieldsStatus } from '@/types';
  import { WorkflowKanbanService } from '@/services';

  export default Vue.extend({
    name: 'WorkflowKanbanPopupFields',
    data() {
      return {
        formInvalidFeedback: '',
        isSubmitting: false
      };
    },
    mixins: [WorkflowKanbanPopupFieldsHelper, ModalHelpers],
    methods: {
      ...mapActions('workflowKanbanJobStore', ['setPopupFieldsSchema', 'setPopupFieldsStatus']),
      ...mapActions('applicationDirtyStore', ['setApplicationDirty']),
      resetFormInvalidFeedback() {
        this.formInvalidFeedback = '';
      },
      setFormInvalidFeedback(feedback: string) {
        this.formInvalidFeedback = feedback;
      },
      async onCancel(this: any, dirty: boolean) {
        const confirmed = await this.haveConfirmationToLoseUnsavedChangesAsync(dirty);
        if (!confirmed) {
          return;
        }
        this.closeModal();
        this.setApplicationDirty(false);
        this.setPopupFieldsStatus(WorkflowKanbanPopupFieldsStatus.ProcessCancelled);
      },
      async haveConfirmationToLoseUnsavedChangesAsync(this: any, dirty: boolean): Promise<boolean> {
        if (!dirty) {
          return true;
        }
        try {
          return await this.showUnsavedChangesModalAsync(this.$bvModal);
        } catch (error) {
          this.$log('failed to confirm unsaved changes');
          return false;
        }
      },
      async onProcess(this: any) {
        this.isSubmitting = true;
        this.resetFormInvalidFeedback();
        this.setPopupFieldsStatus(WorkflowKanbanPopupFieldsStatus.Processing);
        try {
          const response = await WorkflowKanbanService.processCardAsync(
            this.getQueueId,
            this.getJobId,
            this.getTargetLane,
            this.getReadTime,
            this.getPopupFieldDataSources
          );

          switch (parseInt(response.workflowKanbanJobProcessResultStatus, 10)) {
            case WorkflowKanbanJobProcessResultStatus.UnableToAcquireLock: {
              const message = response.workflowJobProcessResult.message;
              this.setFormInvalidFeedback(message);
              break;
            }
            case WorkflowKanbanJobProcessResultStatus.ProcessSuccessful: {
              this.closeModal();
              this.setApplicationDirty(false);
              this.setPopupFieldsStatus(WorkflowKanbanPopupFieldsStatus.ProcessSuccessful);
            }
          }
        } catch (error) {
          this.setFormInvalidFeedback(error.response.data);
        } finally {
          this.isSubmitting = false;
        }
      }
    },
    computed: {
      ...mapGetters('workflowKanbanJobStore', [
        'getPopupFieldSchema',
        'getPopupFieldDataSources',
        'getQueueId',
        'getJobId',
        'getSourceLane',
        'getTargetLane',
        'getReadTime',
        'getCanProcess'
      ]),
      popupFieldSchemas: {
        get(this: any) {
          return this.getPopupFieldSchema;
        },
        set(this: any, value: any) {
          this.setPopupFieldsSchema(value);
        }
      },
      title(this: any) {
        return `${this.getSourceLane} to ${this.getTargetLane}`;
      }
    },
    mounted() {
      this.setPopupFieldsStatus(WorkflowKanbanPopupFieldsStatus.Displayed);
    },
    components: {
      DynamicForm
    }
  });
</script>
