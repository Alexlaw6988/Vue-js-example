import { RouteHelpers } from '@/mixins';
import { Workflow } from '@/types';

const WorkflowDashboard = () => import(/* webpackChunkName: "WorkflowDashboard" */ '@/views/Dashboard.vue');
const WorkflowQueue = () => import(/* webpackChunkName: "WorkflowQueue" */ '@/views/WorkflowQueue.vue');
const WorkflowJob = () => import(/* webpackChunkName: "WorkflowJob" */ '@/views/WorkflowJob.vue');
const TreeView = () => import(/* webpackChunkName: "WorkflowTreeView" */ '@/components/workflow/WorkflowTreeView.vue');

const meta = {
  layout: 'TreeView'
};

export const WorkflowRoutes = [
  {
    ...Workflow.Base,
    components: {
      default: WorkflowDashboard,
      treeView: TreeView
    },
    meta
  },
  {
    ...Workflow.Queue,
    components: {
      default: WorkflowQueue,
      treeView: TreeView
    },
    meta,
    beforeEnter: (to: any, from: any, next: any) => {
      RouteHelpers.setErrorPageRedirect(Workflow.Base.name);
      RouteHelpers.beforeEnterCheckRouteParamAsNumeric(to, from, next, ['id']);
    }
  },
  {
    ...Workflow.Job,
    component: WorkflowJob,
    beforeEnter: (to: any, from: any, next: any) => {
      RouteHelpers.setErrorPageRedirect(Workflow.Base.name);
      RouteHelpers.beforeEnterCheckRouteParamAsNumeric(to, from, next, ['queueId', 'jobId']);
    }
  }
];
