export interface Dictionary<T> {
  [Key: string]: T;
}
