import { KeyboardKeyCode } from '@/types';

export const onEvent = {
  bind(element: any, binding: any) {
    element.addEventListener(
      binding.arg,
      (event: any) => {
        const hasModifiers = Object.keys(binding.modifiers).length > 0;
        const isKeyBoardEvent = hasModifiers ? binding.modifiers[KeyboardKeyCode[event.keyCode]] : true;
        if (binding.arg === event.type && isKeyBoardEvent) {
          if (hasModifiers) {
            event.preventDefault();
          }
          if (typeof binding.value === 'function') {
            binding.value(event);
          }
        }
      },
      true
    );
  },
  unbind(element: any, binding: any) {
    element.removeEventListener(binding.arg, null);
  }
};
