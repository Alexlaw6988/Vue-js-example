import {
  WorkflowKanbanJobState,
  RootState,
  SchemaModel,
  WorkflowDataSourceModel,
  Dictionary,
  WorkflowKanbanPopupFieldsStatus,
  LockModel,
  KanbanCardMoveModel
} from '@/types';
import { GetterTree } from 'vuex';

export const getters: GetterTree<WorkflowKanbanJobState, RootState> = {
  getPopupFieldSchema(state): SchemaModel[] {
    return state.popupFieldsSchema;
  },
  getQueueId(state): number {
    return state.queueId;
  },
  getJobId(state): number {
    return state.jobId;
  },
  getSourceLane(state): string {
    return state.sourceLane;
  },
  getTargetLane(state): string {
    return state.targetLane;
  },
  getReadTime(state): Date {
    return state.readTime;
  },
  getCanProcess(state): boolean {
    return state.canProcess;
  },
  getPopupFieldDataSources(state): WorkflowDataSourceModel[] {
    const popupFieldsDataSources: WorkflowDataSourceModel[] = new Array();
    state.popupFieldsSchema.forEach((x: any) =>
      addDataSourceField(popupFieldsDataSources, x.metadata.DataSourceKey, x.metadata.DataFieldKey, x.value));
    return popupFieldsDataSources;
  },
  getPopupFieldsStatus(state): WorkflowKanbanPopupFieldsStatus {
    return state.popupFieldsStatus;
  },
  getLock(state): LockModel {
    return state.lock;
  },
  getLastCardMove(state): KanbanCardMoveModel {
    return state.lastCardMove;
  }
};

function addDataSourceField(
  popupFieldsDataSources: WorkflowDataSourceModel[],
  dataSourceKey: string,
  dataSourceFieldKey: any,
  fieldValue: object
) {
  const dataSource = popupFieldsDataSources.find((x) => x.key === dataSourceKey);
  if (dataSource) {
    if (!dataSource.fields[dataSourceFieldKey]) {
      dataSource.fields[dataSourceFieldKey] = fieldValue;
    }
  } else {
    const fields: Dictionary<any> = { [dataSourceFieldKey]: fieldValue };
    popupFieldsDataSources.push({ key: dataSourceKey, fields } as WorkflowDataSourceModel);
  }
}
