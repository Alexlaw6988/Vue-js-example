<template>
  <MStoreFormSelectTable
    :field-id="htmlElementId"
    :field-label="name"
    :is-readonly="isReadonly"
    :action-button-component-name="properties.actionButtonComponent"
    :is-loading="isLoading"
    :filter-disabled="!properties.filterEnabled"
    :data="value"
    :list="organisationsList"
    :display-field="properties.displayField"
    :value-field="properties.valueField"
    v-on:update:data="onOrganisationChange"
    :validation="{ required: isRequired, maxLength: properties.maxLength }"
  ></MStoreFormSelectTable>
</template>

<script lang="ts">
  import Vue from 'vue';
  import { ListModel, ListHeaderModel } from '@/types';
  import MStoreFormSelectTable from '@/components/shared/MStoreFormSelectTable.vue';
  import AxiosConfiguration from '@/classes/AxiosConfiguration';

  export default Vue.extend({
    name: 'organisation-select-list',
    props: {
      value: {
        required: true
      },
      isRequired: {
        required: false,
        default: false,
        type: Boolean
      },
      name: {
        required: false,
        default: 'Organisation',
        type: String
      },
      isReadonly: {
        required: false,
        default: false,
        type: Boolean
      },
      formId: {
        required: false,
        type: String
      },
      id: {
        required: false,
        default: 'organisation',
        type: String
      }
    },
    data() {
      return {
        isLoading: true,
        organisations: [] as any,
        filter: '',
        properties: {
          filterEnabled: true,
          displayField: 'name',
          valueField: 'id',
          maxLength: 0,
          actionButtonComponent: ''
        },
        fields: [
          {
            id: '',
            data: 'name',
            title: this.name,
            key: 'name',
            label: this.name
          }
        ]
      };
    },
    computed: {
      htmlElementId() {
        return this.formId ? `${this.formId}.${this.id}` : this.id;
      },
      organisationsList(this: any): ListModel {
        return this.organisations.length > 0
          ? {
              id: 0,
              key: this.properties.displayField,
              text: this.name,
              headers: this.fields as ListHeaderModel[],
              list: this.organisations,
              totalRow: this.organisations.length,
              resultType: 1,
              listDataResultTypeMessage: ''
            }
          : ({} as ListModel);
      }
    },
    methods: {
      async getItemsViaApiAsync(this: any) {
        this.isLoading = true;
        await AxiosConfiguration.axiosWithoutNotification
          .get('organisations?isDeactivated=false')
          .then((response: any) => {
            this.organisations = response.data;
            this.isLoading = false;
          })
          .catch((error: any) => {
            this.organisations = [];
            this.isLoading = false;
          });
      },
      onOrganisationChange(this: any, value: any) {
        if (value || this.organisations.length !== 1 || this.required) {
          this.$emit('input', value);
        }
        this.prepareDefaultValue(value);
      },
      prepareDefaultValue(this: any, value: any) {
        this.filter = !value
          ? value
          : this.organisations
              .filter((x: any) => x[this.properties.valueField] === value)
              .map((y: any) => y[this.properties.displayField])
              .reduce((z: any) => z);
      }
    },
    mounted(this: any) {
      this.getItemsViaApiAsync();
    },
    components: {
      MStoreFormSelectTable
    }
  });
</script>
