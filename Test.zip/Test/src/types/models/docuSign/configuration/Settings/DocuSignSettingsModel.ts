export interface DocuSignSettingsModel {
  expiryEnabled: boolean;
  expireAfterDays: string;
  beforeExpiryWarningDays: string;
  remindersEnabled: string;
  reminderDelayDays: string;
  reminderFrequencyDays: string;
  emailSubject: string;
}
