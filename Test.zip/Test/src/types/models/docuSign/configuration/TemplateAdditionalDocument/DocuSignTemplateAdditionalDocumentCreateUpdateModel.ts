import { DocuSignTemplateAdditionalDocumentSignHereCreateUpdateModel } from '@/types';

export interface DocuSignTemplateAdditionalDocumentCreateUpdateModel {
    documentTypeId: number;
    templateId: number;
    additionalDocumentFileId: number;
    templateAdditionalDocumentSignHeres: DocuSignTemplateAdditionalDocumentSignHereCreateUpdateModel[];
}