<template>
  <b-tabs card nav-class="flex-nowrap">
    <template slot="tabs-end">
      <b-nav-item
        class="border-bottom"
        v-for="tab in visibleVerticalJobTabs"
        :key="tab.key"
        :class="`border-right ${activeVerticalTab.key == tab.key ? 'selected' : ''}`"
        @click="localSetActiveVerticalTab(tab)"
      >
        {{ tab.description }}
      </b-nav-item>
    </template>
    <div class="p-3">
      <div v-for="workflowTab in visibleVerticalWorkflowJobTabs" :key="workflowTab.key">
        <workflow-dynamic-form
          storeNamespace="workflowJobStore"
          storeGetter="workflowDataSourceField"
          storeAction="setWorkflowDataSourceField"
          :documentSearchModel="workflowJob.documentSearchModel"
          v-bind:dynamic-form-model="workflowTab.dynamicFormModel"
          :class="dynamicFormHidden(workflowTab.key) ? 'd-none' : ''"
          :ignoreRequiredFieldsValidation="isCancelProcess"
          :isLoading="isLoading"
        />
      </div>
      <div v-for="preloadTab in preloadTabs" :key="preloadTab.key" v-show="activeVerticalTab.key == preloadTab.key">
        <component
          :is="preloadTab.componentName"
          :dataSources="workflowDataSources"
          :workflowJobModel="workflowJob"
          :isLoading="isLoading"
          :tab-key="preloadTab.key"
          :job-tab-orientation="preloadTab.jobTabOrientation"
        />
      </div>
      <div
        v-if="
          tabIsStandardOrCustom(activeVerticalTab) &&
            !tabHasLoaded(activeVerticalTab) &&
            !tabIsPreLoaded(activeVerticalTab)
        "
      >
        <component
          :is="activeVerticalTab.componentName"
          :dataSources="workflowDataSources"
          v-bind:dynamic-form-model="activeVerticalTab.dynamicFormModel"
          :isLoading="isLoading"
          :tab-key="activeVerticalTab.key"
          :job-tab-orientation="activeVerticalTab.jobTabOrientation"
        />
      </div>
      <div v-for="loadedTab in loadedTabs" :key="loadedTab.key" v-show="activeVerticalTab.key == loadedTab.key">
        <component
          :is="loadedTab.componentName"
          :dataSources="workflowDataSources"
          v-bind:dynamic-form-model="loadedTab.dynamicFormModel"
          :isLoading="isLoading"
          :tab-key="loadedTab.key"
          :job-tab-orientation="loadedTab.jobTabOrientation"
        />
      </div>
    </div>
  </b-tabs>
</template>

<script lang="ts">
  import Vue from 'vue';
  import { WorkflowJobTabModel, WorkflowJobTabType, WorkflowStandardProcessingAction, EVENT_BUS } from '@/types';
  import WorkflowDynamicForm from '@/components/workflow/WorkflowDynamicForm.vue';
  import ManufacturerTab from '@/components/workflow/automotive/tabs/ManufacturerTab.vue';
  import DocuSignSignersTab from '@/components/workflow/docuSign/tabs/DocuSignSignersTab.vue';
  import { WorkflowFormValidation, workflowTabsHelper } from '@/mixins';
  import { mapGetters, mapActions } from 'vuex';
  import { EventBus } from '@/classes/EventBus';

  export default Vue.extend({
    name: 'VerticalWorkflowJobTabs',
    mixins: [WorkflowFormValidation, workflowTabsHelper],
    props: {
      processingAction: {
        type: Number,
        validator: (processingAction: number) => WorkflowStandardProcessingAction[processingAction] !== undefined,
        required: true
      },
      isLoading: {
        type: Boolean,
        default: false
      }
    },
    data() {
      return {
        activeTab: {} as WorkflowJobTabModel,
        loadedTabs: [] as WorkflowJobTabModel[],
        jobTabOrientation: 'vertical'
      };
    },
    methods: {
      ...mapActions('workflowJobStore', ['setActiveVerticalTab']),
      dynamicFormHidden(this: any, key: string): boolean {
        return this.activeVerticalTab.key !== key;
      },
      tabIsStandardOrCustom(this: any, tab: WorkflowJobTabModel) {
        return (
          tab.workflowJobTabType === WorkflowJobTabType.Standard || tab.workflowJobTabType === WorkflowJobTabType.Custom
        );
      },
      tabHasLoaded(this: any, tab: WorkflowJobTabModel) {
        return this.loadedTabs.includes(tab);
      },
      tabIsPreLoaded(this: any, tab: WorkflowJobTabModel) {
        return tab.preLoad;
      },
      localSetActiveVerticalTab(this: any, tab: WorkflowJobTabModel) {
        if (this.tabIsStandardOrCustom(tab) && !this.loadedTabs.includes(tab) && !this.tabIsPreLoaded(tab)) {
          this.loadedTabs.push(tab);
        }
        this.setActiveVerticalTab(tab.key);
      }
    },
    computed: {
      ...mapGetters('workflowJobStore', [
        'workflowJob',
        'visibleVerticalJobTabs',
        'visibleVerticalWorkflowJobTabs',
        'workflowDataSources',
        'activeVerticalTab'
      ]),
      isCancelProcess(this: any): boolean {
        return this.processingAction === WorkflowStandardProcessingAction.CancelJob;
      },
      preloadTabs(this: any): WorkflowJobTabModel[] {
        return this.visibleVerticalJobTabs.filter(
          (x: WorkflowJobTabModel) => x.workflowJobTabType !== WorkflowJobTabType.Workflow && x.preLoad
        );
      }
    },
    mounted(this: any) {
      this.setActiveVerticalTab();
      if (this.preloadTabs.length < 1) {
        EventBus.$emit(EVENT_BUS.TABS_LOADED, 'vertical');
      } else {
        this.tabs = [...this.preloadTabs.map((tab: WorkflowJobTabModel) => tab.key)];
      }
    },
    components: {
      WorkflowDynamicForm,
      ManufacturerTab,
      DocuSignSignersTab
    }
  });
</script>
