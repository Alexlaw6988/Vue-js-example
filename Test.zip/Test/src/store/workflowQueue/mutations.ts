import { MutationTree } from 'vuex';
import { WorkflowQueueState, TableStateModel, WorkflowQueueNextJobsModel, UserPreferencesMutationTypes } from '@/types';
import { workflowQueue } from '../workflowQueue';

export const mutations: MutationTree<WorkflowQueueState> = {
  SET_TABLE_STATE(state, tableStateModel: TableStateModel) {
    state.tableState = tableStateModel;
  },
  RESET_WORKFLOW_QUEUE_STATE(state, queueId: number) {
    Object.assign(state, workflowQueue.defaultWorkflowQueueState());
    state.queueId = queueId;
  },
  SET_TABLE_STATE_FIELD(state, tableStateField: any) {
    Object.assign(state.tableState, {
      [tableStateField.field]: tableStateField.value
    });
  },
  SET_ALL_JOB_LIST(state, payload: any) {
    state.allJobsList = payload;
  },
  SET_NEXT_JOB_LIST(state, payload: any) {
    state.nextJobsList = payload;
  },
  [UserPreferencesMutationTypes.SetLastSelectedWorkflowQueue](state, payload: any) {
    state.lastSelectedWorkflowQueue = payload;
  }
};
