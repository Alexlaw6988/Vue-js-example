<template>
  <div class="row">
    <div class="col col-xl-12">
      <div class="card">
        <div class="card-header text-white bg-primary">
          <h6 data-testid="add-user-page-header">{{ title }}</h6>
        </div>
        <div class="card-body pb-0">
          <loading-spinner :isLoading="isLoading" :isSpinner="false" v-if="isLoading"></loading-spinner>
          <div v-else-if="showSuccessMessage" class="d-block text-center m-5">
            <h4>{{ successMessage }}</h4>
            <b-button type="close" @click="onClose" variant="success" class="btn ext-white flex-fill m-2 text-white">
              Close
            </b-button>
          </div>
          <div v-else class="d-flex align-items-center">
            <m-form
              data-vv-scope="feedbackForm"
              @submit.prevent="onSubmit"
              class="p-1 flex-fill align-self-center"
              v-slot="{ invalid }"
            >
              <m-form-group label="Subject" label-for="subject" :isRequired="true">
                <b-form-group>
                  <b-form-select
                    id="form-select-subject"
                    v-model="selectedSubject"
                    :options="subjectList"
                    v-validate="{ required: isRequired }"
                    name="Subject"
                    :state="validateInputState('Subject', 'feedbackForm')"
                    :disabled="isDisabled"
                  >
                    <template v-slot:first>
                      <b-form-select-option :disabled="true" :value="null">
                        Please select an option or type your own
                      </b-form-select-option>
                    </template>
                    <b-form-select-option value="custom">Type your own</b-form-select-option>
                  </b-form-select>
                  <m-form-input
                    v-if="selectedSubject === 'custom'"
                    id="subject"
                    name="subject"
                    :value="feedbackModel.subject"
                    @input="($event) => updateFeedbackModel('subject', $event)"
                    class="mt-2"
                    :validation="{ required: true, maxLength: 100 }"
                  ></m-form-input>
                  <b-form-invalid-feedback id="Subject-feedback">
                    {{ errors.first('Subject', 'feedbackForm') || errors.first('subject', 'feedbackForm') }}
                  </b-form-invalid-feedback>
                </b-form-group>
              </m-form-group>
              <m-form-group label="Message" label-for="message" :isRequired="true">
                <b-form-group>
                  <b-form-textarea
                    id="message"
                    name="message"
                    v-model="feedbackModel.message"
                    v-validate="'required|max:4000'"
                    :state="validateInputState('message', 'feedbackForm')"
                  ></b-form-textarea>
                  <b-form-invalid-feedback id="message-feedback">
                    {{ errors.first('message', 'feedbackForm') }}
                  </b-form-invalid-feedback>
                </b-form-group>
              </m-form-group>
              <b-form-group v-if="!isDisabled">
                <span class="mb-2 d-inline-block">Include my email address</span>
                <b-form-checkbox
                  v-model="feedbackModel.includeUserInformation"
                  name="check-button"
                  switch
                  size="lg"
                  :disabled="isDisabled"
                ></b-form-checkbox>
              </b-form-group>
              <div class="col-md-12 row" v-if="feedbackModel.includeUserInformation && user">
                <div class="col-md-6">
                  <div class="border-bottom mb-2">
                    <label class="h6 mb-2 font-weight-bold">Name</label>
                  </div>
                  <p>{{ user.name }}</p>
                </div>
                <div class="col-md-6">
                  <div class="border-bottom mb-2">
                    <label class="h6 mb-2 font-weight-bold">Email Address</label>
                  </div>
                  <p>{{ user.emailAddress }}</p>
                </div>
              </div>
              <b-form-invalid-feedback id="apiError-feedback" class="mb-2" :force-show="true">
                <h6>{{ errors.first('apiError') }}</h6>
              </b-form-invalid-feedback>
              <div class="d-flex">
                <b-button
                  type="submit"
                  variant="primary"
                  class="btn btn-sm text-white flex-fill mr-2"
                  :disabled="isSending || !isFormValid() || invalid"
                >
                  Submit
                  <font-awesome-icon icon="spinner" size="sm" class="ml-2" :hidden="!isSending" spin />
                </b-button>
                <b-button
                  type="button"
                  @click="onReset"
                  variant="secondary"
                  class="btn btn-sm text-white flex-fill ml-2"
                  :disabled="isSending"
                >
                  Clear
                </b-button>
                <b-button
                  v-if="showModal"
                  type="cancel"
                  @click="onClose"
                  variant="danger"
                  class="btn btn-sm text-white flex-fill ml-2"
                  :disabled="isSending"
                >
                  Cancel
                </b-button>
              </div>
            </m-form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
  import { Vue } from 'vue-property-decorator';
  import { FeedbackModel, FeedbackTypeConstants } from '@/types';
  import { FeedbackService } from '@/services';
  import { FormFieldValidation, ObjectHelper, FeedbackHelper } from '@/mixins';
  import { UserService } from '@/services/UserService';
  import LoadingSpinner from '@/components/shared/LoadingSpinner.vue';

  export default Vue.extend({
    name: 'Feedback',
    mixins: [FormFieldValidation, ObjectHelper, FeedbackHelper],
    props: {
      showModal: {
        type: Boolean,
        default: false
      },
      title: {
        type: String,
        default: 'Feedback'
      }
    },
    data() {
      return {
        successMessage: 'Thanks for your feedback.',
        isSending: false,
        isLoading: false,
        feedbackModel: {},
        user: {},
        subjectList: [],
        selectedSubject: null,
        showSuccessMessage: false
      };
    },
    methods: {
      async onSubmit(this: any) {
        const formIsvalid = await this.validateFeedbackFormAsync();
        if (formIsvalid) {
          this.isSending = true;
          try {
            const result = await FeedbackService.sendFeedbackEmailAsync(this.feedbackModel);
            if (result) {
              this.showSuccessMessage = true;
            }
          } catch (error) {
            this.handleError(error);
          } finally {
            this.isSending = false;
          }
        }
      },
      async validateFeedbackFormAsync() {
        try {
          return this.$validator.validateAll('feedbackForm');
        } catch (error) {
          this.$log('validator error ' + error);
          return false;
        }
      },
      resetFeedbackForm(this: any) {
        this.feedbackModel = {
          includeUserInformation: true
        } as FeedbackModel;
        this.setSelectedSubject();
        this.showSuccessMessage = false;
        this.$validator.reset();
        this.$validator.errors.remove('apiError');
      },
      onReset(this: any) {
        this.resetFeedbackForm();
      },
      onClose(this: any) {
        this.resetFeedbackForm();
        this.closeModal();
      },
      handleError(error: any) {
        this.$validator.errors.remove('apiError');
        this.$validator.errors.add({
          field: 'apiError',
          msg: error.response.data
        });
      },
      async getUserInformation(this: any) {
        try {
          this.user = await UserService.getCurrentUserAsync();
        } catch {
          this.user = {};
        }
      },
      async getSubjectList(this: any) {
        try {
          const getFeedbackSubjectsResponse = await FeedbackService.getFeedbackSubjectsAsync();
          this.initializeFeedbackSubjects(getFeedbackSubjectsResponse);
        } catch {
          this.subjectList = [];
        }
      },
      initialize(this: any) {
        this.isLoading = true;
        this.resetFeedbackForm();
        this.getUserInformation();
        this.getSubjectList();
        this.isLoading = false;
      },
      initializeFeedbackSubjects(this: any, feedbackSubjects: any) {
        if (this.title === FeedbackTypeConstants.GetHelp.title) {
          this.subjectList = feedbackSubjects[FeedbackTypeConstants.GetHelp.key];
        } else if (this.title === FeedbackTypeConstants.ReportIssue.title) {
          this.subjectList = feedbackSubjects[FeedbackTypeConstants.ReportIssue.key];
        } else {
          this.subjectList = feedbackSubjects[FeedbackTypeConstants.Feedback.key];
        }
        this.setSelectedSubject();
      },
      setSelectedSubject(this: any) {
        if (this.subjectList?.length > 0) {
          this.selectedSubject = this.title === FeedbackTypeConstants.Feedback.title ? null : this.subjectList[0];
          this.feedbackModel.subject = this.selectedSubject;
        }
      },
      updateFeedbackModel(this: any, propertyKey: string, newValue: string) {
        this.feedbackModel = { ...this.feedbackModel, [propertyKey]: newValue };
      }
    },
    watch: {
      selectedSubject(this: any) {
        this.feedbackModel.subject = this.selectedSubject === 'custom' ? null : this.selectedSubject;
        if (this.selectedSubject === 'custom') {
          this.$nextTick(() => {
            this.$nextTick(() => {
              this.resetField('subject', 'feedbackForm');
            });
          });
        }
      }
    },
    computed: {
      isRequired(this: any) {
        return this.selectedSubject === null || this.selectedSubject !== 'custom';
      },
      isDisabled(this: any) {
        return this.title !== FeedbackTypeConstants.Feedback.title;
      }
    },
    mounted(this: any) {
      this.initialize();
    },
    components: { LoadingSpinner }
  });
</script>
