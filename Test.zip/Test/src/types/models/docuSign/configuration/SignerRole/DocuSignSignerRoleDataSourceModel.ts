import { DocuSignSignerRoleDataFieldModel } from '@/types';

export interface DocuSignSignerRoleDataSourceModel {
  key: string;
  description: string;
  fields: DocuSignSignerRoleDataFieldModel[];
}
