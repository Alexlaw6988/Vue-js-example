import {
  DocumentToStoreState,
  DocumentToStoreModel,
  DocumentToStoreViewModel,
  CabinetModel,
  SchemaModel,
  TargetDocumentTypeSettingsModel
} from '@/types';
import { getters } from './getters';
import { actions } from './actions';
import { mutations } from './mutations';

export const state: DocumentToStoreState = {
  documentToStore: {} as DocumentToStoreModel,
  documentToStoreView: {
    cabinets: [] as CabinetModel[],
    dynamicFormSchema: [] as SchemaModel[],
    targetDocumentTypeSettings: {} as TargetDocumentTypeSettingsModel
  } as DocumentToStoreViewModel,
  selectedTargetCabinetId: '',
  selectedTargetDocumentTypeId: 0,
  selectedPages: ''
};

const namespaced: boolean = true;

export const documentToStore = {
  namespaced,
  state,
  getters,
  actions,
  mutations
};
