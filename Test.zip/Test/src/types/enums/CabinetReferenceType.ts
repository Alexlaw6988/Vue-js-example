export enum CabinetReferenceType {
  Common = 1,
  Document = 2,
  Display = 3
}
