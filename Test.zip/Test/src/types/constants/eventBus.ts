export const EVENT_BUS = {
  RESET_TAB_DIRTY: 'ResetTabDirty',
  TABS_LOADED: 'tabs-loaded',
  VERTICAL_TABS_LOADED: 'vertical-tabs-loaded',
  HORIZONTAL_TABS_LOADED: 'horizontal-tabs-loaded'
};
