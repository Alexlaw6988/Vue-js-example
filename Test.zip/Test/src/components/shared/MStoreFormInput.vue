<template>
  <ValidationProvider :rules="veeValidateRule" :name="label" ref="ValidationProvider" slim v-slot="{ flags, errors }">
    <m-form-group :label="label" :labelFor="id" :isRequired="validation && validation.required">
      <b-input-group>
        <b-form-input
          :autocomplete="isAutoComplete"
          :disabled="disabled"
          :id="id"
          :lazy-formatter="lazyFormatter"
          :name="name"
          :placeholder="placeholder"
          :readonly="readonly"
          :state="getInputState(flags, errors)"
          :type="type"
          v-model="inputValue"
          @blur="$emit('blur', forceUpperCase ? $event.target.value.toUpperCase() : $event.target.value)"
          @click="$emit('click', $event)"
          @focus="$emit('focus', $event)"
          @keydown="$emit('keydown', $event)"
          @keypress="$emit('keypress', $event)"
          @keyup="$emit('keyup', $event)"
        />
        <b-input-group-append v-if="$slots['append']">
          <slot name="append" />
        </b-input-group-append>
      </b-input-group>
      <b-form-invalid-feedback :id="`${name}-feedback`" :state="getInputState(flags, errors)">
        {{ errors[0] }}
      </b-form-invalid-feedback>
    </m-form-group>
  </ValidationProvider>
</template>

<script lang="ts">
  import Vue from 'vue';
  import { MStoreInputType, Autocomplete } from '@/types';
  import { FormFieldValidation } from '@/mixins/formValidation';
  import { ValidationModel } from '@/types/models/validation';

  export default Vue.extend({
    name: 'MStoreFormInput',
    mixins: [FormFieldValidation],
    props: {
      autocomplete: {
        type: String,
        default: Autocomplete.off
      },
      disabled: {
        type: Boolean,
        default: false
      },
      id: {
        type: String
      },
      lazyFormatter: {
        type: Boolean,
        default: false
      },
      name: {
        type: String
      },
      placeholder: {
        type: String
      },
      readonly: {
        type: Boolean,
        default: false
      },
      type: {
        type: String,
        default: MStoreInputType.Text,
        validator: (val) => {
          return (
            [
              MStoreInputType.Email,
              MStoreInputType.Password,
              MStoreInputType.Search,
              MStoreInputType.Text,
              MStoreInputType.Url
            ].indexOf(val) !== -1
          );
        }
      },
      value: {
        required: true
      },
      label: {
        type: String,
        default: ''
      },
      validation: {
        type: Object as () => ValidationModel
      },
      forceUpperCase: {
        type: Boolean,
        default: false
      }
    },
    computed: {
      inputValue: {
        get(this: any) {
          return this.value;
        },
        set(this: any, value: string) {
          this.$emit('input', this.forceUpperCase ? value.toUpperCase() : value);
        }
      },
      isAutoComplete(this: any) {
        if (this.autocomplete === Autocomplete.on) {
          return this.autocomplete;
        } else if (this.type === MStoreInputType.Email) {
          return Autocomplete.nope;
        } else if (this.type === MStoreInputType.Password) {
          return Autocomplete.newPassword;
        } else {
          return Autocomplete.off;
        }
      }
    }
  });
</script>
