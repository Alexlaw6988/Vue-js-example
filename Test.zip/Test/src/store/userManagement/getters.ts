import { UserManagementState, RootState } from '@/types';
import { GetterTree } from 'vuex';

export const getters: GetterTree<UserManagementState, RootState> = {
  getUserManagementStateField: (state) => (field: keyof UserManagementState): any => {
    return state[field];
  }
};
