import { actions } from './actions';
import { getters } from './getters';
import { mutations } from './mutations';
import { DocuSignDocumentTypesState } from '@/types';

export function defaultDocuSignDocumentTypesState() {
    return {
        documentTypeId: null
    } as DocuSignDocumentTypesState;
}

export const state: DocuSignDocumentTypesState = defaultDocuSignDocumentTypesState();

const namespaced: boolean = true;

export const docuSignDocumentTypes = {
    namespaced,
    state,
    actions,
    getters,
    mutations,
    defaultDocuSignDocumentTypesState
};