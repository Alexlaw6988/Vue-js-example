export interface WorkflowJobTabsToHideModel {
  saleType: string;
  tabKeyToShow: string;
  tabKeysToHide: string[];
}
