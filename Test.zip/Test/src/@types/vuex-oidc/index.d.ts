declare module 'vuex-oidc';
