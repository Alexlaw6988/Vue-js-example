export interface DocuSignDocumentTypeUpdateModel {
    documentTypeId: number;
    keyBusinessReferenceField: string;
}