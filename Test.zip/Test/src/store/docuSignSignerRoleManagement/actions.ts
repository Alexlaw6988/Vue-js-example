import { DocuSignSignerRoleManagementState, RootState } from '@/types';
import { ActionTree } from 'vuex';

export const actions: ActionTree<DocuSignSignerRoleManagementState, RootState> = {
  resetSignerRoleManagementState({ commit }) {
    commit('RESET_STATE');
  },
  setTableStateField({ commit, state }, tableStateField: any) {
    commit('SET_TABLE_STATE_FIELD', tableStateField);
  },
  setDocumentTypeId({ commit, state }, documentTypeId: number) {
    commit('SET_DOCUMENT_TYPE', documentTypeId);
  }
};
