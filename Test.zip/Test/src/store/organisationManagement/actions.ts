import { OrganisationManagementState, RootState } from '@/types';
import { ActionTree } from 'vuex';

export const actions: ActionTree<OrganisationManagementState, RootState> = {
  resetOrganisationManagementState({ commit }) {
    commit('RESET_ORGANISATION_MANAGEMENT_STATE');
  },
  setOrganisationManagementStateField({ commit }, organisationManagementStateField: any) {
    commit('SET_ORGANISATION_MANAGEMENT_STATE_FIELD', organisationManagementStateField);
  }
};
