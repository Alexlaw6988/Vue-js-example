<template>
  <ValidationProvider :rules="veeValidateRule" :name="fieldLabel" ref="ValidationProvider" slim>
    <m-form-group
      v-on-event:blur="closeList"
      v-on-event:keydown.Esc="onEscape"
      v-on-event:keydown.Up.Down="onUpDownArrowKey"
      :label="fieldLabel"
      :labelFor="elementId"
      :isRequired="validation.required"
      slot-scope="{ flags, errors }"
      :data-testid="`selectTableGroup-${fieldId}`"
    >
      <b-input-group :id="fieldId">
        <b-form-input
          ref="mstoreSelectTableInput"
          :id="elementId"
          :data-testid="`selectTableInput-${fieldId}`"
          :name="fieldLabel"
          :readonly="isFilterDisabledOrReadOnly || isLineUpOnType"
          :state="veeValidateRule ? getInputState(flags, errors) : null"
          :class="isFilterDisabledAndNotReadOnly || isLineUpOnType ? 'mstore-select-table-filter-disabled' : ''"
          v-model="filter"
          lazy-formatter
          @focus="onfilterFocus"
          @keydown.enter.prevent.self="onEnter()"
          @keydown="onKeyDown"
          @click="onfilterFocus"
        />
        <b-input-group-append v-if="!allowTypedValue">
          <b-button
            ref="mstoreSelectTableButton"
            variant="primary"
            class="mstore-form-select-button"
            :disabled="isReadonly || isLoading"
            :id="`mstoreSelectTableButton-${elementId}`"
            :data-testid="`selectTableDropButton-${fieldId}`"
            @click="onFilterButtonClicked"
            @mousedown="onMStoreSelectTableButtonClick($event)"
          >
            <font-awesome-icon :icon="mstoreSelectTableButtonIcon" :spin="isLoading" />
          </b-button>
          <component
            :id="`actionButtonComponent-${elementId}`"
            :is="actionButtonComponentName"
            v-if="!isNullOrEmpty(actionButtonState)"
            :buttonId="fieldId"
            :actionButtonState="actionButtonState"
            @actionButtonClicked="onActionButtonClicked"
            :isDisabled="isActionButtonDisabled"
          ></component>
        </b-input-group-append>
      </b-input-group>
      <div
        tabindex="-1"
        v-show="tableOpen && showTable"
        ref="mstoreSelectTableDiv"
        :id="`mstoreSelectTableDiv-${elementId}`"
        class="table-dropdown-container table-box-shadow w-400"
      >
        <b-table
          ref="mstoreSelectTable"
          class="table table-sm table-bordered mb-0"
          small
          bordered
          show-empty
          empty-filtered-text="No matching list items can be found."
          :empty-text="emptyText"
          :sticky-header="stickyHeaderHeight"
          :items="listData"
          :fields="listHeaders"
          :filter="filterDisabled || isLineUpOnType ? '' : filter"
          @row-clicked="onRowClicked"
          @head-clicked="onHeadClicked"
          hover
          :busy="isLoading"
          :filter-function="filterDisabled || isLineUpOnType ? null : customFilter"
          :id="`mstoreSelectTable-${elementId}`"
          :data-testid="`selectTable-${fieldId}`"
          primary-key="index"
          @filtered="onFiltered"
          v-on-event:keydown="onKeyDown"
          :tabindex="-1"
          :thead-class="theadClass"
        >
          <template v-for="header in listModel.headers" v-slot:[getSlotName(header)]>{{ header.title }}</template>
        </b-table>
      </div>
      <b-form-invalid-feedback :state="getInputState(flags, errors)">
        {{ errors[0] }}
      </b-form-invalid-feedback>
    </m-form-group>
  </ValidationProvider>
</template>

<script lang="ts">
  import Vue from 'vue';
  import { KeyboardKeyCode, ListModel } from '@/types';
  import FieldActionButton from '@/components/shared/FieldActionButton.vue';
  import FieldTooltip from '@/components/shared/FieldTooltip.vue';
  import { FormFieldValidation } from '@/mixins/formValidation';
  import { ObjectHelper } from '@/mixins/objectHelper';
  import { BTableHelpers } from '@/mixins/bTable';
  import { FormSelectHelper } from '@/mixins/formSelectHelper';
  import { ValidationModel } from '@/types/models/validation';

  export default Vue.extend({
    name: 'm-form-select-table',
    mixins: [FormFieldValidation, ObjectHelper, BTableHelpers, FormSelectHelper],
    props: {
      data: {
        required: true
      },
      list: {
        type: Object as () => ListModel,
        required: true,
        default: {}
      },
      isLoading: {
        required: true,
        default: true
      },
      actionButtonState: {
        type: Object,
        required: false
      },
      fieldId: {
        type: String,
        required: true
      },
      fieldLabel: {
        type: String,
        required: true
      },
      isReadonly: {
        type: Boolean,
        required: true
      },
      formId: {
        type: String,
        required: false
      },
      actionButtonComponentName: {
        type: String,
        required: true
      },
      filterDisabled: {
        type: Boolean,
        default: false
      },
      displayField: {
        type: String,
        required: false
      },
      valueField: {
        type: String,
        required: false
      },
      isActionButtonDisabled: {
        type: Boolean,
        default: false
      },
      validation: {
        type: Object as () => ValidationModel,
        default: () => ({} as ValidationModel)
      },
      lineUpOnType: {
        type: Boolean,
        default: false
      },
      allowTypedValue: {
        type: Boolean,
        default: false
      }
    },
    data(this: any) {
      return {
        filter: '' as any,
        lastSelectedValue: '' as any,
        filteredItems: []
      };
    },
    computed: {
      listModel(this: any) {
        return this.list;
      },
      inputValue: {
        get(this: any) {
          return this.data;
        },
        set(this: any, value: string) {
          this.$emit('update:data', value);
        }
      },
      emptyText: {
        get(this: any) {
          return this.listModel.listDataResultTypeMessage;
        }
      },
      _valueField(this: any) {
        return this.valueField || Object.keys(this.listModel.list[0])[0];
      },
      _displayField(this: any) {
        return this.displayField || Object.keys(this.listModel.list[0])[0];
      },
      displayData(this: any) {
        return (this.list as ListModel)?.list?.find((x) => x[this._valueField] === this.data)?.[this._displayField];
      },
      isLineUpOnType(this: any) {
        return this.lineUpOnType && (!this.listHeaders || this.listHeaders?.length === 1);
      },
      showTable(this: any) {
        return !this.allowTypedValue || this.filteredItems?.length;
      },
      theadClass(this: any) {
        return this.allowTypedValue ? 'd-none' : '';
      }
    },
    watch: {
      inputValue(this: any) {
        this.setFilter();
      },
      list() {
        this.setFilter();
      },
      showTable(this: any, newvalue: any) {
        if (newvalue && this.allowTypedValue) {
          this.initPopper();
        }
      }
    },
    methods: {
      setFilter(this: any) {
        debugger;
        const value = this.displayData || (this.allowTypedValue ? this.data : this.filter);
        this.filter = value;
        this.lastSelectedValue = value;
      },
      onEnter(this: any) {
        if (this.totalRows() === 1 && this.showTable) {
          this.onRowClicked(this.filteredItems?.[0] || this.listModel.list[0]);
        }
      },
      onfilterFocus(this: any) {
        if (!this.isReadonly && !this.isLoading && !this.tableOpen && !this.allowTypedValue) {
          this.openTable();
        }
      },
      onRowClicked(this: any, item: any) {
        this.inputValue = item[this._valueField];
        this.$emit('row-selected', item);
        this.filter = this.displayData;
        this.closeTable();
        this.setFocusOnNextTick(this.$refs.mstoreSelectTableButton);
        const focusElement = this.allowTypedValue
          ? this.$refs.mstoreSelectTableInput
          : this.$refs.mstoreSelectTableButton;
        this.setFocusOnNextTick(focusElement);
        this.validate();
      },
      onFilterButtonClicked(this: any) {
        if (this.tableOpen) {
          this.closeListAndRetainlastSelectedValue();
        } else {
          this.inputValue ? this.clearInputValue() : this.openTable();
        }
      },
      clearInputValue(this: any) {
        this.inputValue = '';
        this.filter = '';
        this.lastSelectedValue = '';
        this.validate();
      },
      openTable(this: any) {
        this.tableOpen = true;
        this.initPopper();
        this.setSelectedRowOnNextTick();
      },
      customFilter(this: any, row: any, txt: any): any {
        this.clearAllSelectedRows();
        return this.customTableFilter(this.listHeaders, row, txt);
      },
      async onFiltered(this: any, filteredItems: any) {
        await this.clearAllSelectedRows();
        this.filteredItems = filteredItems;
        this.setSelectedRow();
      },
      onKeyDown(this: any, event: any) {
        if (
          (!this.isLineUpOnType && !this.allowTypedValue) ||
          [KeyboardKeyCode.Tab, KeyboardKeyCode.Up, KeyboardKeyCode.Down].includes(event.keyCode)
        ) {
          return;
        }
        if (event.keyCode === KeyboardKeyCode.Enter && !this.allowTypedValue) {
          this.closeTable();
        } else if (this.allowTypedValue && ![KeyboardKeyCode.Esc, KeyboardKeyCode.Enter].includes(event.keyCode)) {
          this.openTable();
        } else {
          event.preventDefault();
          const key = event.key as string;
          const filterList = this.listData?.filter((x: any) => {
            const value = x[this.listModel.key] as string;
            return value?.toLowerCase().startsWith(key.toLowerCase());
          });
          if (!filterList) {
            return;
          }
          const lastSelectedValueIndex = filterList?.findIndex((data: any) => data[this.listModel.key] === this.filter);

          const newIndex =
            lastSelectedValueIndex === -1
              ? 0
              : lastSelectedValueIndex >= filterList.length - 1
              ? 0
              : lastSelectedValueIndex + 1;

          const filter = filterList[newIndex];

          if (filter && this.tableOpen) {
            this.inputValue = filter[this._valueField];
            this.$nextTick(() => {
              this.clearAllSelectedRows();
              const element = this.setSelectedRow();
              this.setFocusOnElement(element);
            });
          }
        }
      },
      onUpDownArrowKey(this: any, event: any) {
        event.stopPropagation();

        if (this.tableOpen) {
          this.onArrowKey(event);
        }
        if (this.isLineUpOnType) {
          const index = Number(
            this.listData?.findIndex((x: any) => {
              const value = x[this.listModel.key] as string;
              return value === this.filter;
            })
          );
          const currentindex =
            event.keyCode === KeyboardKeyCode.Up
              ? index - 1
              : index === -1
              ? 0
              : this.calculateCurrentIndexOnArrowDown(index, this.listData?.length);
          const item = this.listData[currentindex];
          if (this.isLineUpOnType && item) {
            this.$nextTick(() => (this.inputValue = item[this._valueField]));
          }
        }
      }
    },
    mounted(this: any) {
      this.setFilter();
    },
    components: {
      FieldActionButton,
      FieldTooltip
    }
  });
</script>
<style>
  tbody :focus {
    outline: none !important;
    border: none !important;
    background-color: rgba(0, 0, 0, 0.075);
  }
</style>
