<template>
  <LoadingSpinner :isLoading="isManufacturerTabLoading">
    <workflow-dynamic-form
      v-if="!isManufacturerTabLoading"
      storeNamespace="automotiveWorkflowJobStore"
      storeGetter="manufacturerTabFieldValue"
      storeAction="setManufacturerTabFieldValue"
      v-bind:dynamic-form-model="manufacturerTab.dynamicForm"
      :documentSearchModel="{}"
      class="w-100"
      :isLoading="isLoading"
    />
  </LoadingSpinner>
</template>

<script lang="ts">
  import Vue from 'vue';
  import { mapActions, mapGetters } from 'vuex';
  import { ManufacturerTabSearchModel } from '@/types';
  import WorkflowDynamicForm from '@/components/workflow/WorkflowDynamicForm.vue';
  import LoadingSpinner from '@/components/shared/LoadingSpinner.vue';
  import { AutomotiveHelper, ObjectHelper } from '@/mixins';

  export default Vue.extend({
    name: 'ManufacturerTab',
    mixins: [AutomotiveHelper, ObjectHelper],
    props: {
      isLoading: {
        type: Boolean,
        default: false
      }
    },
    methods: {
      ...mapActions('automotiveWorkflowJobStore', ['getManufacturerTab']),
      getManufacturerTabData(this: any) {
        if (!this.isNullOrEmpty(this.saleType) && this.manufacturer) {
          this.getManufacturerTab({
            queueId: this.workflowJob.queueId,
            jobId: this.workflowJob.jobId,
            saleType: this.saleType,
            manufacturer: this.manufacturer
          } as ManufacturerTabSearchModel);
        }
      }
    },
    computed: {
      ...mapGetters('workflowJobStore', ['workflowDataSourceField', 'workflowJob']),
      ...mapGetters('automotiveWorkflowJobStore', ['manufacturerTab', 'isManufacturerTabLoading'])
    },
    mounted() {
      this.getManufacturerTabData();
    },
    watch: {
      saleType(this: any) {
        this.getManufacturerTabData();
      }
    },
    components: {
      WorkflowDynamicForm,
      LoadingSpinner
    }
  });
</script>
