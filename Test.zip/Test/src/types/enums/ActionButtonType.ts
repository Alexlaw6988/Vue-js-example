export enum ActionButtonType {
  None = 0,
  ViewRelatedDocument = 1,
  Tooltip = 2,
  CurrentDocument = 3
}
