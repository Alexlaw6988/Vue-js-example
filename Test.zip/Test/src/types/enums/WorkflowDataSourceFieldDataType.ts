export enum WorkflowDataSourceFieldDataType {
  String = 1,
  Integer = 2,
  Boolean = 3,
  DateTime = 4,
  Decimal = 5,
  Double = 6,
  Object = 7,
  Unknown = 8
}
