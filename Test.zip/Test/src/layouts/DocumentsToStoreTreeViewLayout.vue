<template>
  <div :class="`h-100 ${backgroundColor}`">
    <splitpanes watch-slots class="default-theme" v-show="!isLoading" @resized="onResized">
      <div
        :splitpanes-size="leftPaneSize"
        :splitpanes-min="minPaneSize"
        :splitpanes-max="maxPaneSize"
        class="sidebarWrapper"
      >
        <router-view name="treeView" v-bind:loading.sync="isLoading" :key="$route.fullPath" />
      </div>
      <div :splitpanes-size="rightPaneSize" class="contentWrapper">
        <slot />
      </div>
    </splitpanes>
    <loading-spinner v-if="isLoading" :isLoading="isLoading" />
  </div>
</template>

<script lang="ts">
  import { Vue } from 'vue-property-decorator';
  import Splitpanes from 'splitpanes';
  import 'splitpanes/dist/splitpanes.css';
  import LoadingSpinner from '@/components/shared/LoadingSpinner.vue';

  export default Vue.extend({
    name: 'DocumentsToStoreTreeViewLayout',
    data() {
      return {
        isLoading: false,
        leftPaneSize: 40,
        rightPaneSize: 0,
        minPaneSize: 15,
        maxPaneSize: 50
      };
    },
    methods: {
      initializePaneSize(this: any): void {
        this.rightPaneSize = 100 - this.leftPaneSize;
      },
      onResized(this: any, panes: any): void {
        this.leftPaneSize = panes[0].width;
        this.initializePaneSize();
      }
    },
    computed: {
      backgroundColor(this: any): string {
        return this.isLoading ? 'bg-light-gray' : '';
      }
    },
    created() {
      this.initializePaneSize();
    },
    components: {
      Splitpanes,
      LoadingSpinner
    }
  });
</script>
