import { actions } from './actions';
import { getters } from './getters';
import { mutations } from './mutations';
import { DocuSignWorkflowJobState, SignersTabModel } from '@/types';

export const state: DocuSignWorkflowJobState = {
  signersTab: {} as SignersTabModel,
  isSignersTabLoading: true,
  isLoading: false,
  error: false,
  errorMessage: ''
};

const namespaced: boolean = true;

export const docuSignWorklowJob = {
  namespaced,
  state,
  actions,
  getters,
  mutations
};
