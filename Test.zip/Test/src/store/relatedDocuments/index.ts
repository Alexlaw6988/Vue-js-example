import { actions } from './actions';
import { getters } from './getters';
import { mutations } from './mutations';
import { RelatedDocumentsModel } from '@/types';
import { RelatedDocumentsState } from '@/types/store/RelatedDocumentsState';

export const state: RelatedDocumentsState = {
  relatedDocumentsModel: {} as RelatedDocumentsModel,
  isLoading: false,
  error: false,
  errorMessage: ''
};

const namespaced: boolean = true;

export const relatedDocuments = {
  namespaced,
  state,
  actions,
  getters,
  mutations
};
