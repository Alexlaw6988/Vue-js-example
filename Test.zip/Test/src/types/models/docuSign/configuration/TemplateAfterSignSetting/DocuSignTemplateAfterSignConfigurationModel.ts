import { CabinetModel } from '@/types';
import { DocuSignTemplateAfterSignSettingModel } from '@/types';

export interface DocuSignTemplateAfterSignConfigurationModel {
  templateAfterSignSetting: DocuSignTemplateAfterSignSettingModel;
  targetCabinets: CabinetModel[];
}
