<template>
  <div>
    <div class="card-header text-white bg-primary">
      <div v-if="hasError" data-testid="error-notification" class="row justify-content-between px-2">
        <h6>Error</h6>
        <font-awesome-icon size="lg" icon="exclamation-triangle" class="float-right" />
      </div>
      <div v-else class="row justify-content-between px-2">
        <h6 data-testid="header-text" class="d-flex align-items-center">{{ headerText }}</h6>
        <div class="float-right d-flex align-items-center">
          <button
            v-if="showHideFilters"
            class="btn btn-sm btn-outline-light mr-3"
            data-testid="show-hide-filters-button"
            @click="localShowFilters = !localShowFilters"
          >
            Show / Hide Filters
          </button>
          <font-awesome-icon
            v-if="supportsWallboardMode"
            size="2x"
            :icon="isFullscreen ? 'compress-alt' : 'expand-alt'"
            class="pointer mr-3"
            data-testid="wallboard-mode-button"
            @click="onToggleWallboardMode"
          />
          <font-awesome-icon
            size="2x"
            icon="sync-alt"
            class="pointer"
            data-testid="refresh-button"
            @click="$emit('refresh-triggered')"
            :spin="isLoading"
          />
        </div>
      </div>
    </div>
    <slide-up-down v-if="showHideFilters && !hasError" :active="localShowFilters" :duration="slideDuration">
      <HeaderFilters
        :itemsPerPage.sync="localItemsPerPage"
        :searchQuery.sync="localSearchQuery"
        :show-items-per-page="showItemsPerPage"
      >
        <template v-for="(value, slot) in $slots">
          <template :slot="slot">
            <slot :name="slot"></slot>
          </template>
        </template>
      </HeaderFilters>
    </slide-up-down>
    <HeaderFilters
      v-else-if="!hasError"
      :itemsPerPage.sync="localItemsPerPage"
      :searchQuery.sync="localSearchQuery"
      :show-items-per-page="showItemsPerPage"
    >
      <template v-for="(value, slot) in $slots">
        <template :slot="slot">
          <slot :name="slot"></slot>
        </template>
      </template>
    </HeaderFilters>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  import HeaderFilters from './HeaderFilters.vue';
  import { Fullscreen } from '@/utils';

  export default Vue.extend({
    name: 'Header',
    components: {
      HeaderFilters
    },
    props: {
      headerText: {
        type: String,
        required: true
      },
      hasError: {
        type: Boolean,
        default: false
      },
      isLoading: {
        type: Boolean,
        default: false
      },
      showHideFilters: {
        type: Boolean,
        default: false
      },
      allowWallboardMode: {
        type: Boolean,
        default: false
      },
      wallboardRefreshIntervalInSeconds: {
        type: Number,
        default: 0
      },
      emitFilters: {
        type: Boolean,
        default: false
      },
      showFilters: {
        type: Boolean,
        default: false
      },
      itemsPerPage: {
        type: Number,
        required: false
      },
      searchQuery: {
        type: String,
        default: ''
      },
      slideDuration: {
        type: Number,
        default: 1000
      },
      wallboardElement: {
        type: Element,
        required: false
      },
      showItemsPerPage: {
        type: Boolean,
        default: true
      },
      isWallboardMode: {
        type: Boolean,
        default: false
      }
    },
    data() {
      return {
        internalShowFilters: false,
        internalItemsPerPage: 20,
        internalSearchQuery: '',
        supportsFullscreen: false,
        isFullscreen: false,
        wallboardRefreshInterval: null
      };
    },
    methods: {
      onToggleWallboardMode(this: any) {
        const elementToFullscreen = this.wallboardElement ? this.wallboardElement : this.$el.parentElement;
        Fullscreen.toggleFullscreen(elementToFullscreen);
      },
      handleWallboardRefresh(this: any) {
        if (this.wallboardRefreshInterval) {
          clearInterval(this.wallboardRefreshInterval);
          this.wallboardRefreshInterval = null;
        }

        if (this.wallboardRefreshIntervalInSeconds > 0 && this.isFullscreen) {
          const timeout = this.wallboardRefreshIntervalInSeconds * 1000;

          this.wallboardRefreshInterval = setInterval(() => {
            this.$emit('refresh-triggered');
          }, timeout);
        }
      },
      handleOnFullscreenChange(this: any) {
        this.isFullscreen = Fullscreen.isFullscreen();
        this.handleWallboardRefresh();
        this.$emit('update:is-wallboard-mode', this.isFullscreen);
      }
    },
    computed: {
      localShowFilters: {
        get(this: any): boolean {
          return this.emitFilters ? this.showFilters : this.internalShowFilters;
        },
        set(this: any, value: any) {
          if (this.emitFilters) {
            this.$emit('update:show-filters', value);
          } else {
            this.internalShowFilters = value;
          }
        }
      },
      localItemsPerPage: {
        get(this: any): number {
          return this.emitFilters ? this.itemsPerPage : this.internalItemsPerPage;
        },
        set(this: any, value: any) {
          if (this.emitFilters) {
            this.$emit('update:items-per-page', value);
          } else {
            this.internalItemsPerPage = value;
          }
        }
      },
      localSearchQuery: {
        get(this: any): string {
          return this.emitFilters ? this.searchQuery : this.internalSearchQuery;
        },
        set(this: any, value: any) {
          if (this.emitFilters) {
            this.$emit('update:search-query', value);
          } else {
            this.internalSearchQuery = value;
          }
        }
      },
      supportsWallboardMode: {
        get(this: any): boolean {
          return this.allowWallboardMode && this.supportsFullscreen;
        }
      }
    },
    created() {
      this.supportsFullscreen = Fullscreen.supportsFullscreen();

      Fullscreen.registerFullscreenChange(this.handleOnFullscreenChange);
    },
    beforeDestroy() {
      Fullscreen.removeFullscreenChange(this.handleOnFullscreenChange);
    },
    watch: {
      wallboardRefreshIntervalInSeconds(this: any) {
        this.handleWallboardRefresh();
      }
    }
  });
</script>
