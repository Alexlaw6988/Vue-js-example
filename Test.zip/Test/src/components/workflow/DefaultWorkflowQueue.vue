<template>
  <m-table
    class="mb-3 mh-100 min-h-100 w-100"
    :header-text="workflowQueueDataModel.queueName"
    :items="workflowQueueDataModel.queueData"
    :fields="workflowQueueDataModel.queueColumns"
    :is-loading="isLoading"
    :can-hover-on-table-row="workflowQueueDataModel.canOpenJobs"
    :empty-text="emptyText"
    :empty-html="emptyHtml"
    :show-hide-filters="true"
    :emit-filters="true"
    :show-filters="tableStateField('showFilters')"
    :current-page="tableStateField('currentPage')"
    :items-per-page="userPreferedTableStateField('itemsPerPage')"
    :search-query="tableStateField('searchQuery')"
    :sort-by="userPreferedTableStateField('sortBy')"
    :sort-desc="userPreferedTableStateField('sortDesc')"
    :selected-pk="tableStateField('selectedPk')"
    :allow-wallboard-mode="workflowQueueDataModel.allowWallboardMode"
    :wallboard-refresh-interval-in-seconds="workflowQueueDataModel.wallboardRefreshIntervalInSeconds"
    pk-field="jobid"
    @update:show-filters="onTableStateFieldUpdated"
    @update:current-page="onTableStateFieldUpdated"
    @update:items-per-page="onUserPreferedTableStateFieldUpdated"
    @update:search-query="onTableStateFieldUpdated"
    @update:sort-by="onUserPreferedTableStateFieldUpdated"
    @update:sort-desc="onUserPreferedTableStateFieldUpdated"
    @update:filtered-items="onTableStateFieldUpdated"
    @update:selected-pk="onTableStateFieldUpdated"
    @refresh-clicked="getWorkflowQueue()"
    @row-clicked="getWorkflowJob"
    @on-filtered-or-sorted="setNextJobs"
    @on-items-changed="setAllJobs"
  ></m-table>
</template>

<script lang="ts">
  import Vue from 'vue';
  import router from '@/router';
  import { mapGetters, mapActions } from 'vuex';
  import { ErrorCode, RouteRegEx } from '@/types';
  import MStoreTable from '@/components/shared/Table/MStoreTable.vue';
  import { ComponentHelper, RouteHelpers } from '@/mixins';

  export default Vue.extend({
    name: 'DefaultWorkflowQueue',
    mixins: [ComponentHelper, RouteHelpers],
    props: {
      workflowQueueDataModel: {
        type: Object,
        required: true
      },
      isLoading: {
        type: Boolean,
        required: true
      }
    },
    methods: {
      ...mapActions('workflowQueueStore', [
        'resetWorkflowQueueState',
        'setTableStateField',
        'setNextJobsList',
        'setAllJobsList'
      ]),
      ...mapActions('userPreferencesStore', ['setUserPreferedWorkflowQueueTableOptions']),
      getWorkflowQueue() {
        this.$emit('get-workflow-queue', this.workflowQueueDataModel.queueId);
      },
      getWorkflowJob(item: any) {
        this.$emit('get-workflow-job', item.jobid);
      },
      onTableStateFieldUpdated(this: any, field: string, value: any) {
        this.setTableStateField({
          queueId: this.workflowQueueDataModel.queueId,
          field,
          value
        });
      },
      onUserPreferedTableStateFieldUpdated(this: any, field: string, value: any) {
        this.setUserPreferedWorkflowQueueTableOptions({
          queueId: this.workflowQueueDataModel.queueId,
          field,
          value
        });
      },
      initialise(this: any) {
        const canKeepState = this.canKeepState(RouteRegEx.WorkflowQueue);
        if (!canKeepState) {
          this.resetWorkflowQueueState(this.workflowQueueDataModel.queueId);
          this.setNextJobs(this.workflowQueueDataModel.queueData);
          this.setAllJobs(this.workflowQueueDataModel.queueData);
        }
      },
      setAllJobs(this: any, items: any) {
        this.setAllJobsList(items.map((job: any) => job.jobid));
      },
      setNextJobs(this: any, items: any) {
        this.setNextJobsList(items.map((job: any) => job.jobid));
      }
    },
    computed: {
      ...mapGetters('workflowQueueStore', ['getTableStateField']),
      ...mapGetters('userPreferencesStore', ['getUserPreferedTableStateField']),
      emptyText(this: any): string {
        return this.workflowQueueDataModel.hasNotification
          ? this.workflowQueueDataModel.notification
          : 'There are no records to show';
      },
      tableStateField(this: any) {
        return (field: string) => this.getTableStateField(this.workflowQueueDataModel.queueId, field);
      },
      userPreferedTableStateField(this: any) {
        return (field: string) => this.getUserPreferedTableStateField(this.workflowQueueDataModel.queueId, field);
      },
      emptyHtml(this: any) {
        if (this.workflowQueueDataModel.errorCode === ErrorCode.SqlTimeOutException) {
          return `<div class="alert alert-danger rounded-0 font-weight-bold">
                ${this.workflowQueueDataModel.notification}</div>`;
        }
      }
    },
    mounted() {
      this.initialise();
    },
    beforeDestroy() {
      const toRouteName = this.$route.name?.toLowerCase();
      if (!toRouteName?.match(RouteRegEx.WorkflowQueue)) {
        this.resetWorkflowQueueState(this.workflowQueueDataModel.queueId);
      }
    },
    components: {
      'm-table': MStoreTable
    }
  });
</script>
