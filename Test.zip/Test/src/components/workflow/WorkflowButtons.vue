<template>
  <div>
    <div class="p-2 clearfix bg-transparent">
      <slot name="afterButtons"></slot>
      <div v-for="button in buttons" :key="button.caption">
        <span class="float-right">
          <b-tooltip :disabled="button.isEnabled || isLoading" :target="button.id">
            This job is read-only as you don't have permission to process jobs in this queue.
          </b-tooltip>
          <b-button
            :id="button.id"
            variant="primary"
            size="sm"
            class="float-right ml-2 mb-1"
            :disabled="isButtonDisabled(button)"
            @click="buttonClicked($event, button)"
          >
            <font-awesome-icon size="sm" icon="spinner" class="mr-1" spin v-if="showLoading(button)" />
            <slot :name="getButtonTextSlotName(button)">{{ button.caption }}</slot>
          </b-button>
        </span>
      </div>
      <slot name="beforeButtons"></slot>
    </div>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  import { WorkflowJobButtonModel } from '@/types';

  export default Vue.extend({
    name: 'WorkflowButtons',
    props: {
      buttons: {
        type: Array,
        required: true
      },
      isLoading: {
        type: Boolean,
        required: true
      }
    },
    data() {
      return {
        currentButtonId: ''
      };
    },
    methods: {
      getButtonTextSlotName(button: WorkflowJobButtonModel): string {
        return button.caption.trim().replace(' ', '-').toLowerCase() + 'ButtonText';
      },
      buttonClicked(this: any, event: any, button: WorkflowJobButtonModel) {
        this.currentButtonId = button.id;
        event.target.blur();
        this.$emit(`${button.caption.trim().replace(' ', '-').toLowerCase()}-button-clicked`, button);
      },
      showLoading(this: any, button: WorkflowJobButtonModel): boolean {
        return this.isLoading && this.currentButtonId === button.id;
      },
      isButtonDisabled(this: any, button: WorkflowJobButtonModel) {
        return (!button.isEnabled || this.isLoading) && button.processingAction !== null;
      }
    }
  });
</script>
