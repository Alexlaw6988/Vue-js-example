export const Tools = {
  Base: {
    path: '/tools',
    name: 'tools'
  },
  ProcessLeaver: {
    path: '/tools/processleaver',
    name: 'processLeaver'
  },
  ProcessLeaverHistory: {
    path: '/tools/processLeaverHistory',
    name: 'processLeaverHistory'
  },
  LeaverHistoryLog: {
    path: '/tools/leaverhistorylog/:leaverId',
    name: 'leaverHistoryLog'
  }
};
