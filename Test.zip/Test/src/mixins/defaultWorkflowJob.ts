import {
  WorkflowJobProcessModel,
  WorkflowJobButtonModel,
  WorkflowJobTabModel,
  JobTabStateModel,
  WorkflowStandardProcessingAction,
  EVENT_BUS
} from '@/types';
import { WorkflowJobService } from '@/services/WorkflowJobService';
import Toast from '@/classes/SnotifyConfiguration';
import { EventBus } from '@/classes/EventBus';
import { WorkflowJobPreference } from '@/types/store/userPreferences';
import { mapActions } from 'vuex';
import { UnsavedChangesHelper } from './unsavedChanges';

export const DefaultWorkflowJob = {
  data() {
    return {
      tabs: []
    };
  },
  mixins: [UnsavedChangesHelper],
  methods: {
    ...mapActions('workflowJobStore', [
      'invalidateAllDynamicForms',
      'setIsDirty',
      'releaseWorkflowJobLock',
      'unloadWorkflowJob'
    ]),
    ...mapActions('documentViewStore', ['unloadDocument']),
    async confirmDiscardChangesOnDirtyTabsAsync(this: any): Promise<boolean> {
      if (!this.dirtyJobTabStates || this.dirtyJobTabStates.length === 0) {
        return true;
      }
      const dirtyTabKeys: string[] = this.dirtyJobTabStates.map((state: JobTabStateModel) => state.key);
      const joinedDirtyTabKeys: string = this.joinWithDifferentLastSeperator(dirtyTabKeys, ', ', ' and ');
      const message: string = `You have unsaved changes on the 
            ${joinedDirtyTabKeys} tab${dirtyTabKeys.length > 1 ? 's' : ''}`;
      const result: boolean = await this.showUnsavedChangesModalAsync(this.$bvModal, message);
      if (!result) {
        if (
          this.hasHorizontalJobTabs &&
          this.dirtyHorizontalJobTabStates.length > 0 &&
          this.activeHorizontalTab.key !== this.dirtyHorizontalJobTabStates[0].key
        ) {
          this.setActiveHorizontalTab(this.dirtyHorizontalJobTabStates[0].key);
        }
        if (
          this.hasVerticalJobTabs &&
          this.dirtyVerticalJobTabStates.length > 0 &&
          this.activeVerticalTab.key !== this.dirtyVerticalJobTabStates[0].key
        ) {
          this.setActiveVerticalTab(this.dirtyVerticalJobTabStates[0].key);
        }
      } else {
        EventBus.$emit(EVENT_BUS.RESET_TAB_DIRTY);
      }

      return result;
    },
    async confirmProcessActionAsync(this: any, processingAction: WorkflowStandardProcessingAction): Promise<boolean> {
      const confirmationMessage = this.getConfirmationMessage(processingAction);
      if (!confirmationMessage) {
        return true;
      }
      const result: boolean = await this.showConfirmationModalAsync(this.$bvModal, confirmationMessage);
      return result;
    },
    getConfirmationMessage(this: any, processingAction: WorkflowStandardProcessingAction) {
      return processingAction === WorkflowStandardProcessingAction.CancelJob &&
        this.workflowQueueConfiguration.showCancelJobConfirmation
        ? this.workflowQueueConfiguration.cancelJobConfirmationMessage
        : undefined;
    },
    async closeWorkflowJobAsync(this: any) {
      const discardChangesOnDirtyTabs: boolean = await this.confirmDiscardChangesOnDirtyTabsAsync();
      if (!discardChangesOnDirtyTabs) {
        return;
      }
      const hasUnsavedChangesToKeep: boolean = await this.hasUnsavedChangesToKeepAsync(
        this.$bvModal,
        this.isWorkFlowJobDirty
      );
      if (hasUnsavedChangesToKeep) {
        return;
      }
      this.releaseWorkflowJobLockAndGoBackToWorkflowQueue();
    },
    releaseWorkflowJobLockAndGoBackToWorkflowQueue(this: any) {
      this.releaseWorkflowJobLock();
      this.unloadWorkflowJob();
      this.unloadDocument();
      this.goBackToWorkflowQueue();
    },
    goBackToWorkflowQueue(this: any) {
      this.$router.push({
        name: 'WorkflowQueue',
        params: {
          id: this.$route.params.queueId
        }
      });
    },
    async onProcessButtonClickedAsync(this: any, processButton: WorkflowJobButtonModel) {
      this.isLoading = true;
      this.invalidateAllDynamicForms();
      await this.validateWorkflowJobAsync(processButton);
    },
    async validateWorkflowJobAsync(this: any, processButton: WorkflowJobButtonModel) {
      await this.defaultValidateWorkflowJobAsync(processButton);
    },
    async defaultValidateWorkflowJobAsync(this: any, processButton: WorkflowJobButtonModel) {
      const result = await this.confirmDiscardChangesOnDirtyTabsAsync();
      if (!result) {
        this.isLoading = false;
        return;
      }
      this.processingAction = processButton.processingAction;
      const processActionConfirmed = await this.confirmProcessActionAsync(this.processingAction);
      if (!processActionConfirmed) {
        this.isLoading = false;
        return;
      }
      if (this.hasVisibleWorkflowTabs) {
        this.$nextTick(() => {
          this.setIsAwaitingProcessing(true);
          this.visibleWorkflowJobTabs.forEach((jobTab: WorkflowJobTabModel) => {
            EventBus.$emit(`dynamic-form-submit-${jobTab.dynamicFormModel.formId}`);
          });
        });
      } else {
        this.processWorkflowJob();
      }
    },
    async processWorkflowJob(this: any) {
      await this.defaultProcessWorkflowJob();
    },
    async defaultProcessWorkflowJob(this: any) {
      try {
        this.isLoading = true;

        const workflowJobProcessModel = {
          workflowDataSources: this.workflowJob.workflowDataSources,
          processingAction: this.processingAction
        } as WorkflowJobProcessModel;
        const result = await WorkflowJobService.processWorkflowJobAsync(
          this.workflowJob.queueId,
          this.workflowJob.jobId,
          workflowJobProcessModel
        );
        if (result) {
          if (!result.success) {
            Toast.showInformation(result.message);
            this.isLoading = false;
            return;
          }
          if (result.hasMessage) {
            if (result.messageAcknowledgementRequired) {
              Toast.showInformation(result.message);
            } else {
              Toast.showSuccess(result.message);
            }
          }
          this.setIsDirty(false);
          this.processGetNextJob();
        }
      } catch (error) {
        this.$log(error);
        this.isLoading = false;
      }
    },
    expiryModalButtonClicked(this: any, buttonId: string) {
      if (buttonId === 'returnToQueue') {
        this.releaseWorkflowJobLockAndGoBackToWorkflowQueue();
      }
    },
    onResize(this: any, panes: any) {
      this.leftPaneSize = panes[0].width;
      this.rightPaneSize = panes[1].width;
    },
    onResized(this: any, panes: any) {
      this.setJobVerticalSlider({
        queueId: this.workflowJob.queueId,
        verticalSider: {
          verticalTabWidth: panes[0].width,
          screenWidth: window.innerWidth
        },
        canGetNextJob: this.getNextJob
      } as WorkflowJobPreference);
    },
    initializePaneSize(this: any) {
      this.leftPaneSize = this.hasVerticalJobTabs ? 15 : 0;
      const workflowJobPreferences = this.getWorkflowJobPreferences(this.workflowJob.queueId);

      if (workflowJobPreferences) {
        if (window.innerWidth >= workflowJobPreferences.verticalSider.screenWidth) {
          this.leftPaneSize = this.hasVerticalJobTabs ? workflowJobPreferences.verticalSider.verticalTabWidth : 0;
        }
      }
      this.rightPaneSize = 100 - this.leftPaneSize;
    },
    setFocusOnInvalidField(this: any) {
      const element = this.$el.querySelector('.is-invalid') as HTMLInputElement;
      this.$nextTick(() => {
        if (element) {
          element.focus();
          element.select();
        }
      });
    },
    initializeTheTabs(this: any) {
      this.isLoading = true;
      this.tabs = [
        ...this.insertIf(this.hasHorizontalJobTabs, 'horizontal'),
        ...this.insertIf(this.hasVerticalJobTabs, 'vertical')
      ];
    },
    handleLoadedTabs(this: any, key: string) {
      const index = this.tabs.indexOf(key);
      if (index > -1) {
        this.tabs.splice(index, 1);
      }
      if (this.tabs.length === 0) {
        this.$nextTick(() => {
          this.isLoading = false;
        });
      }
    },
    insertIf(condition: boolean, ...elements: any) {
      return condition ? elements : [];
    }
  },
  created(this: any) {
    EventBus.$on(EVENT_BUS.TABS_LOADED, (key: string) => this.handleLoadedTabs(key));
  },
  beforeDestroy() {
    EventBus.$off(EVENT_BUS.TABS_LOADED);
  }
};
