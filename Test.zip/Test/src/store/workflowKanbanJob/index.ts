import { actions } from './actions';
import { getters } from './getters';
import { mutations } from './mutations';
import {
  KanbanCardMoveModel,
  LockModel,
  SchemaModel,
  WorkflowKanbanJobState,
  WorkflowKanbanPopupFieldsStatus
} from '@/types';

export const state: WorkflowKanbanJobState = {
  popupFieldsSchema: [] as SchemaModel[],
  queueId: 0,
  jobId: 0,
  sourceLane: '',
  targetLane: '',
  readTime: new Date(),
  popupFieldsStatus: WorkflowKanbanPopupFieldsStatus.None,
  lock: {} as LockModel,
  canProcess: false,
  lastCardMove: {} as KanbanCardMoveModel,
  isLoading: true,
  error: false,
  errorMessage: ''
};

const namespaced: boolean = true;

export const workflowKanbanJob = {
  namespaced,
  state,
  actions,
  getters,
  mutations
};
