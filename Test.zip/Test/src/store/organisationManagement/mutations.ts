import { MutationTree } from 'vuex';
import { OrganisationManagementState } from '@/types';
import { organisationManagement } from '../organisationManagement';

export const mutations: MutationTree<OrganisationManagementState> = {
  RESET_ORGANISATION_MANAGEMENT_STATE(state) {
    Object.assign(state, organisationManagement.defaultOrganisationManagementState());
  },
  SET_ORGANISATION_MANAGEMENT_STATE_FIELD(state, organisationManagementStateField: any) {
    Object.assign(state, {
      [organisationManagementStateField.field]: organisationManagementStateField.value
    });
  }
};
