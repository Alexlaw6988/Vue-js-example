export interface DocuSignSignerRoleSearchModel {
  documentTypeId: number;
  signerRoleId: number | null;
}
