<template>
  <div id="m-treeview">
    <TreeViewHeader title="Tools" @expand="expandAll('tree')" @collapse="collapseAll('tree')" />
    <tree
      ref="tree"
      v-if="!loading"
      :data="treeData"
      :options="options"
      @node:clicked="navigate"
      @tree:mounted="getNode"
    >
      <div class="tree-scope" slot-scope="{ node }">
        <template>
          <h6 class="text">
            <font-awesome-icon :icon="node.data.icon" size="lg" class="mr-1 text-primary" />
            {{ node.text }}
          </h6>
        </template>
      </div>
    </tree>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  import LiquorTree from 'liquor-tree';
  import { ToolsModel } from '@/types';
  import { ToolsService } from '@/services/ToolsService';
  import LoadingSpinner from '@/components/shared/LoadingSpinner.vue';
  import { TreeViewHeader } from '@/components/shared';
  import { TreeViewHelpers } from '@/mixins/treeView.ts';
  Vue.use(LiquorTree);

  export default Vue.extend({
    name: 'ToolsTreeView',
    mixins: [TreeViewHelpers],
    props: {
      loading: {
        type: Boolean,
        required: false
      }
    },
    data() {
      return {
        permissionData: {} as ToolsModel,
        options: {
          checkbox: false,
          parentSelect: true
        }
      };
    },
    methods: {
      async getPermissions() {
        this._isLoading = true;
        this.permissionData = await ToolsService.getToolsAsync();
        this._isLoading = false;
      },
      navigate(node: any) {
        if (node.data.componentName && node.data.componentName.localeCompare(this.$router.currentRoute.name)) {
          this.$router.push({ name: node.data.componentName });
        } else {
          node.states.expanded = !node.states.expanded;
        }
      },
      getNode(this: any, tree: any) {
        const node = tree.find({
          data: { path: this.$route.meta.treePath }
        });
        if (!node) {
          return;
        }
        this.selectNode(node);
      }
    },
    watch: {
      '$route.meta.treePath'(this: any, treePath) {
        if (!treePath) {
          const selectedNode = this.$refs.tree.find({
            state: { selected: true }
          });
          this.unselectNode(selectedNode);
        }
      }
    },
    computed: {
      treeData(): object {
        return [
          {
            text: 'HR',
            data: { icon: 'users' },
            state: {
              visible: this.permissionData.canAccessHr,
              selectable: false
            },
            children: [
              {
                text: 'Process Leaver',
                data: {
                  icon: 'user-cog',
                  componentName: 'processLeaver',
                  path: 'processLeaver'
                },
                state: {
                  visible: this.permissionData.canAccessLeaversTool
                }
              },
              {
                text: 'Process Leaver History',
                data: {
                  icon: 'history',
                  componentName: 'processLeaverHistory',
                  path: 'processLeaverHistory'
                },
                state: {
                  visible: this.permissionData.canAccessLeaversTool
                }
              }
            ]
          }
        ];
      },
      _isLoading: {
        get(this: any) {
          return this.loading;
        },
        set(this: any, value: boolean) {
          this.$emit('update:loading', value);
        }
      }
    },
    mounted() {
      this.getPermissions();
    },
    components: {
      LoadingSpinner,
      TreeViewHeader
    }
  });
</script>
