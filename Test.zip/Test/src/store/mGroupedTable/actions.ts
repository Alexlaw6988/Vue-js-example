import { GroupedTableStateModel, RootState, GroupedTableMutationTypes } from '@/types';
import { ActionTree } from 'vuex';

export const actions: ActionTree<GroupedTableStateModel, RootState> = {
  addExpandedGroup({ state, commit }, payload: any) {
    const lastExpandedGroups = state.lastExpandedGroups;
    if (lastExpandedGroups[payload.stateKey]) {
      lastExpandedGroups[payload.stateKey].push(payload.value);
    } else {
      lastExpandedGroups[payload.stateKey] = [payload.value];
    }
    commit(GroupedTableMutationTypes.updateLastExpandedGroups, lastExpandedGroups);
  },
  removeExpandedGroup({ state, commit }, payload: any) {
    const lastExpandedGroups = state.lastExpandedGroups;
    const indexPosition = lastExpandedGroups[payload.stateKey].findIndex((x: any) => x === payload.value);
    if (indexPosition > -1) {
      lastExpandedGroups[payload.stateKey].splice(indexPosition, 1);
    }
    commit(GroupedTableMutationTypes.updateLastExpandedGroups, lastExpandedGroups);
  }
};
