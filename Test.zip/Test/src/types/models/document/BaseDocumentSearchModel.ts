export interface BaseDocumentSearchModel {
  cabinetId: string;
  documentId: number;
  documentTypeId: number;
}
