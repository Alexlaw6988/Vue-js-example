import { AdditionalDocumentRoutes } from './additionalDocument';
import { SignerRoleRoutes } from './signerRole';
import { AfterSignMappingRoutes } from './aftersignmappings';
import { DocumentTypeRoutes } from './documentTypes';
import { TemplateRoutes } from './templates';
import { Configuration } from '@/types';
import ConfigurationTreeView from '@/components/configuration/TreeView.vue';

const DocusignSettings = () => import(/* webpackChunkName: "DocusignSettings" */
    '@/views/configuration/docusign/DocusignSettings.vue');

const DocuSignAccountConfiguration = () => import(/* webpackChunkName: "DocusignTemplateManagement" */
    '@/views/configuration/docusign/DocuSignAccountConfiguration.vue');

const layout = 'TreeView';

export const DocuSignRoutes = [
    {
        ...Configuration.DocuSign.Settings.Base,
        components: {
            default: DocusignSettings,
            treeView: ConfigurationTreeView
        },
        meta: {
            layout,
            treePath: 'docusignsettings'
        }
    },
    {
        ...Configuration.DocuSign.AccountMangement.Base,
        components: {
            default: DocuSignAccountConfiguration,
            treeView: ConfigurationTreeView
        },
        meta: {
            layout,
            treePath: 'docusignaccountconfiguration'
        }
    },
    ...AdditionalDocumentRoutes,
    ...SignerRoleRoutes,
    ...AfterSignMappingRoutes,
    ...DocumentTypeRoutes,
    ...TemplateRoutes
];