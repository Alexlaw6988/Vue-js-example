import axios from 'axios';
import {
  DocumentModel,
  DocumentInformationModel,
  BaseDocumentSearchModel,
  ThumbnailViewModel,
  ThumbnailSearchModel
} from '@/types';
import AxiosConfiguration from '@/classes/AxiosConfiguration';

const DocumentApiUrl = 'document/';
const DocumentInformationApiUrl = 'document/information/';
const DocumentExportApiUrl = 'documentExport/';
const DocumentActionsApiUrl = 'document/Actions/';
const DocumentThumbnailApiUrl = 'document/thumbnail/';

export const DocumentService = {
  async getDocumentAsync(
    cabinetId: string,
    documentId: number,
    page: number,
    viewConversionId: number | null = null
  ): Promise<DocumentModel> {
    const response = await AxiosConfiguration.axiosWithoutNotification.get(DocumentApiUrl, {
      params: {
        CabinetId: cabinetId,
        DocumentId: documentId,
        Page: page,
        ViewConversionId: viewConversionId
      }
    });
    return response.data;
  },
  async exportDocumentAsync(cabinetId: string, documentId: number) {
    const response = await AxiosConfiguration.axiosWithoutNotification.get(
      DocumentExportApiUrl.concat(cabinetId, '/', documentId.toString()),
      { responseType: 'blob' }
    );
    return response;
  },
  async getDocumentActionsAsync(documentSearchModel: BaseDocumentSearchModel): Promise<any> {
    const response = await axios.get(DocumentActionsApiUrl, {
      params: {
        CabinetId: documentSearchModel.cabinetId,
        DocumentId: documentSearchModel.documentId,
        DocumentTypeId: documentSearchModel.documentTypeId
      }
    });
    return response.data;
  },
  async getDocumentInformationAsync(cabinetId: string, documentId: number): Promise<DocumentInformationModel> {
    const response = await axios.get(DocumentInformationApiUrl, {
      params: {
        CabinetId: cabinetId,
        DocumentId: documentId
      }
    });
    return response.data;
  },
  async getThumbnailAsync(thumbnailSearchModel: ThumbnailSearchModel): Promise<ThumbnailViewModel> {
    const response = await AxiosConfiguration.axiosWithoutNotification.get(DocumentThumbnailApiUrl, {
      params: {
        CabinetId: thumbnailSearchModel.cabinetId,
        DocumentId: thumbnailSearchModel.documentId,
        DocumentTypeId: thumbnailSearchModel.documentTypeId,
        Page: thumbnailSearchModel.page,
        MaximumWidthInPixels: thumbnailSearchModel.maximumWidthInPixels,
        MaximumHeightInPixels: thumbnailSearchModel.maximumHeightInPixels
      }
    });
    return response.data;
  }
};
