export enum ListDataResultType {
  NoRecords = 0,
  SomeRecords = 1,
  ManyRecords = 2
}
