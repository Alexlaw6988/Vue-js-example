export interface DocumentToStoreSearchModel {
  sourceCabinetId: string;
  sourceDocumentId: number;
  targetDocumentTypeId: number | null;
}