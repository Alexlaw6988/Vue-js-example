import { ObjectHelper } from './objectHelper';
import { KeyboardKeyCode } from '@/types';
import { ComponentHelper } from './componentHelper';
import { createPopper } from '@popperjs/core';
import { DeviceHelper } from './deviceHelper';
import { ArrayHelper } from './arrayHelper';

export const FormSelectHelper = {
  mixins: [ObjectHelper, ArrayHelper, ComponentHelper, DeviceHelper],
  data() {
    return {
      tableOpen: false,
      rowSelectCss: 'table-row-select',
      popper: null
    };
  },
  computed: {
    elementId(this: any) {
      return this.fieldId.replace(/[. ]/g, '-');
    },
    mstoreSelectTableButtonIcon(this: any) {
      if (this.isLoading) {
        return 'spinner';
      } else if (this.tableOpen) {
        return 'chevron-up';
      } else if (this.inputValue) {
        return 'window-close';
      } else {
        return 'chevron-down';
      }
    },
    stickyHeaderHeight(this: any) {
      return '120px';
    },
    isIosOrIpad(this: any) {
      return this.isIpad() || this.isIOS();
    },
    listData(this: any) {
      if (this.listModel && this.listModel.list) {
        const tableData = this.listModel.list;
        tableData.forEach((x: any) => {
          x.index = String(tableData.indexOf(x));
        });
        return tableData;
      }
    },
    listHeaders(this: any): any[] | undefined {
      if (this.listModel && this.listModel.headers) {
        const tableHeaders = new Array();
        this.listModel.headers.forEach((x: any) => {
          tableHeaders.push({
            key: x.data,
            label: x.title
          });
        });
        return tableHeaders;
      }
    },
    isFilterDisabledOrReadOnly(this: any) {
      return this.isReadonly || this.filterDisabled;
    },
    isFilterDisabledAndNotReadOnly(this: any) {
      return !this.isReadonly && this.filterDisabled;
    }
  },
  methods: {
    closeList(this: any, event: any) {
      const relatedTarget = event.relatedTarget
        ? event.relatedTarget
        : document.activeElement?.tagName.toLowerCase() === 'td'
          ? document.activeElement?.parentElement
          : document.activeElement?.tagName.toLowerCase() === 'div'
            ? document.activeElement?.firstElementChild
            : document.activeElement;
      const targetElement = this.getElementById(relatedTarget!.id);
      const isHeaderClicked =
        relatedTarget?.tagName.toLowerCase() === 'th' ? this.getElementByCss(relatedTarget!.className) : null;
      if (!targetElement && !isHeaderClicked) {
        this.closeListAndRetainlastSelectedValue();
      }
    },
    onEscape(this: any, event: any) {
      this.closeListAndRetainlastSelectedValue();
      this.$refs.mstoreSelectTableButton?.focus();
    },
    closeListAndRetainlastSelectedValue(this: any) {
      if (!this.allowTypedValue) {
        this.filter = this.lastSelectedValue;
      } else {

        this.inputValue = this.filter;
      }
      this.closeTable();
    },
    onArrowKey(this: any, event: any) {
      const rows = this.getTableRows();
      if (!this.isNullOrEmpty(rows)) {
        const index = this.getIndex(rows, this.getElementByCss(this.rowSelectCss) || document.activeElement);
        const currentindex =
          event.keyCode === KeyboardKeyCode.Up
            ? this.calculateCurrentIndexOnArrowUp(index)
            : this.calculateCurrentIndexOnArrowDown(index, rows.length);
        this.setActiveRow(rows[currentindex], rows[index]);
        this.setFocusOnElement(rows[currentindex]);
      }
    },
    onHeadClicked(this: any, key: any, item: any, event: any) {
      event.preventDefault();
    },
    calculateCurrentIndexOnArrowDown(this: any, index: number, count: any) {
      index = index === -1 ? 0 : index;
      return index === count - 1 ? index : index + 1;
    },
    calculateCurrentIndexOnArrowUp(this: any, index: number) {
      return index === 1 ? 1 : index - 1;
    },
    getTableRows(this: any) {
      return this.createArray(this.$refs?.mstoreSelectTable?.$el?.firstChild?.rows) || null;
    },
    getSlotName(header: any) {
      return `head(${header.data})`;
    },
    clearAllSelectedRows(this: any) {
      const rows = this.createArray(this.getAllElementsByCss(this.rowSelectCss));
      if (!this.isNullOrEmpty(rows)) {
        rows.forEach((row: any) => {
          this.removeCss(row, this.rowSelectCss);
        });
      }
    },
    initPopper(this: any) {
      const tab = document.querySelector('.horizontal-tabs') as HTMLElement;
      const reference = this.getElementById(this.elementId);
      const source = this.getElementById(`mstoreSelectTableDiv-${this.elementId}`) as HTMLElement;
      const offSet = [0, 2];
      const preventOverflowOptions = {
        altBoundary: true,
        mainAxis: false,
        altAxis: tab ? tab?.offsetHeight > 300 : true
      };
      this.popper = createPopper(reference as HTMLElement, source, {
        modifiers: [
          {
            name: 'offset',
            options: {
              offset: offSet
            }
          },
          {
            name: 'flip',
            options: {
              behavior: ['bottom-start', 'top-start']
            }
          },
          {
            name: 'computeStyles',
            options: {
              gpuAcceleration: false
            }
          },
          {
            name: 'preventOverflow',
            options: preventOverflowOptions
          }
        ],
        placement: 'bottom-start'
      });
    },
    closeTable(this: any) {
      this.clearAllSelectedRows();
      this.tableOpen = false;
      this.popper?.destroy();
    },
    onMStoreSelectTableButtonClick(this: any, event: any) {
      if (this.isIosOrIpad) {
        event.preventDefault();
        this.$refs.mstoreSelectTableButton?.focus();
      }
    },
    setSelectedRow(this: any): any | undefined {
      if (this.totalRows() === 1) {
        const element = this.$refs?.mstoreSelectTable?.$el?.firstChild?.rows[1];
        this.setActiveRow(element);
        return element;
      } else if (this.filter && this.filter === this.lastSelectedValue) {
        const id = `mstoreSelectTable-${this.elementId}__row_${this.listData
          ?.find((x: any) => x[this.listModel.key] === this.filter)
          ?.index?.replace(' ', '_')}`;
        const element = this.getElementById(id);
        this.setActiveRow(element);
        return element;
      } else {
        if (!this.isIosOrIpad) {
          this.$refs?.mstoreSelectTable?.$el?.firstChild?.rows?.[1]?.scrollIntoView(false);
        }
      }
    },
    setActiveRow(this: any, targetElement: any, sourceElement: any = true) {
      this.removeCss(sourceElement, this.rowSelectCss);
      this.addCss(targetElement, this.rowSelectCss);
      if (sourceElement && !this.isIosOrIpad) {
        this.setScrollIntoView(targetElement);
      }
    },
    setSelectedRowOnNextTick(this: any) {
      this.$nextTick(() => {
        this.setSelectedRow();
      });
    },
    onActionButtonClicked(this: any) {
      this.$emit('actionButtonClicked');
    },
    totalRows(this: any) {
      return this.$refs?.mstoreSelectTable?.$el?.firstChild?.rows?.length - 1;
    },
    validate(this: any) {
      if (this.validation.required) {
        this.$nextTick(() => {
          this.$refs.ValidationProvider.validate();
        });
      }
    }
  },
  beforeDestroy(this: any) {
    this.popper?.destroy();
  }
};
