<template>
  <div>
    <info-tooltip :tooltipText="actionButtonState.tooltip" :id="actionButtonId" />
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  import InfoTooltip from '@/components/shared/InfoTooltip.vue';
  import { FieldTooltipStateModel } from '@/types/models';

  export default Vue.extend({
    name: 'FieldTooltip',
    props: {
      actionButtonState: {
        type: Object as () => FieldTooltipStateModel,
        required: true
      },
      buttonId: {
        type: String,
        required: true
      }
    },
    computed: {
      actionButtonId(this: any) {
        return `${'fieldTooltip-'}${this.buttonId}`;
      }
    },
    components: {
      InfoTooltip
    }
  });
</script>
