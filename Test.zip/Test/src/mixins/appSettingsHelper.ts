import { mapGetters, mapActions } from 'vuex';

export const AppSettingsHelper = {
  computed: {
    ...mapGetters('appSettingsStore', ['appSettings']),
    paginationOptions(this: any) {
      return this.appSettings.paginationOptions;
    }
  },
  methods: {
    ...mapActions('appSettingsStore', ['getAppSettings'])
  },
  created(this: any) {
    if (!this.appsettings) {
      this.getAppSettings();
    }
  }
};
