import { Configuration } from '@/types';
import ConfigurationTreeView from '@/components/configuration/TreeView.vue';
import { RouteHelpers } from '@/mixins';

const DocusignEditSignerRole = () =>
  import(
    /* webpackChunkName: "DocusignEditSignerRole" */
    '@/views/configuration/docusign/DocusignEditSignerRole.vue'
  );

const DocusignAddSignerRole = () =>
  import(
    /* webpackChunkName: "DocusignAddSignerRole" */
    '@/views/configuration/docusign/DocusignAddSignerRole.vue'
  );

const DocusignSignerRoleManagement = () =>
  import(
    /* webpackChunkName: "DocusignSignerRoleManagement" */
    '@/views/configuration/docusign/DocusignSignerRoleManagement.vue'
  );

const meta = {
  layout: 'TreeView',
  treePath: 'docusignsignerroles'
};

export const SignerRoleRoutes = [
  {
    ...Configuration.DocuSign.SignerRole.Management,
    components: {
      default: DocusignSignerRoleManagement,
      treeView: ConfigurationTreeView
    },
    meta
  },
  {
    ...Configuration.DocuSign.SignerRole.Edit,
    components: {
      default: DocusignEditSignerRole,
      treeView: ConfigurationTreeView
    },
    meta,
    beforeEnter: (to: any, from: any, next: any) => {
      RouteHelpers.setErrorPageRedirect(Configuration.DocuSign.SignerRole.Management.name);
      RouteHelpers.beforeEnterCheckRouteParamAsNumeric(to, from, next, ['documentTypeId', 'id']);
    }
  },
  {
    ...Configuration.DocuSign.SignerRole.Add,
    components: {
      default: DocusignAddSignerRole,
      treeView: ConfigurationTreeView
    },
    meta,
    beforeEnter: (to: any, from: any, next: any) => {
      RouteHelpers.setErrorPageRedirect(Configuration.DocuSign.SignerRole.Management.name);
      RouteHelpers.beforeEnterCheckRouteParamAsNumeric(to, from, next, ['documentTypeId']);
    }
  }
];
