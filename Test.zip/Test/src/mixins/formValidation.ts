import { WorkflowDataSourceFieldDataType, FieldState, ValueType } from '@/types/enums';
import { ValidationModel } from '@/types/models/validation';
import { mapActions } from 'vuex';

export const WorkflowFormValidation = {
  methods: {
    getDataTypeValidationRule(
      dataType: WorkflowDataSourceFieldDataType
    ): string {
      switch (dataType) {
        case WorkflowDataSourceFieldDataType.Integer:
          return '|integer';
        case WorkflowDataSourceFieldDataType.Decimal:
        case WorkflowDataSourceFieldDataType.Double:
          return '|decimal';
        case WorkflowDataSourceFieldDataType.String:
        case WorkflowDataSourceFieldDataType.Boolean:
        case WorkflowDataSourceFieldDataType.DateTime:
        case WorkflowDataSourceFieldDataType.Object:
        case WorkflowDataSourceFieldDataType.Unknown:
          return '';
      }
    },
  }
};

export const FormFieldValidation = {
  data() {
    return {
      _formDirty: false
    };
  },
  computed: {
    formDirty(this: any) {
      return this.isFormDirty() || this._formDirty;
    },
    veeValidateRule(this: any) {
      const validationModel = this.validation as ValidationModel;
      if (!validationModel) { return null; }
      const veeValidateRule = {} as any;

      if (validationModel.valueType != null) {
        switch (validationModel.valueType) {
          case ValueType.AlphaNumeric:
            veeValidateRule.alpha_num = true;
            break;
          case ValueType.Integer:
            veeValidateRule.integer = true;
            break;
          case ValueType.Decimal:
            veeValidateRule.decimal = true;
            break;
          case ValueType.Email:
            veeValidateRule.email = true;
            break;
        }
      }

      if (validationModel.required != null) { veeValidateRule.required = validationModel.required; }
      if (validationModel.minLength != null) { veeValidateRule.min = validationModel.minLength; }
      if (validationModel.maxLength) { veeValidateRule.max = validationModel.maxLength; }
      if (validationModel.fixedLength != null) { veeValidateRule.length = validationModel.fixedLength; }
      if (validationModel.minValue != null && validationModel.maxValue != null) {
        veeValidateRule.between = { min: validationModel.minValue, max: validationModel.maxValue };
      } else if (validationModel.minValue != null) {
        veeValidateRule.min_value = validationModel.minValue;
      } else if (validationModel.maxValue != null) {
        veeValidateRule.max_value = validationModel.maxValue;
      }
      return veeValidateRule;
    }
  },
  watch: {
    formDirty(this: any) {
      this.setApplicationDirty(this.formDirty);
    }
  },
  methods: {
    ...mapActions('applicationDirtyStore', ['setApplicationDirty']),
    getInputState(this: any, flags: any, errors: string[]) {
      if (flags && (flags.dirty || flags.validated)) {
        return !errors || errors.length === 0 ? null : false;
      }
      return null;
    },
    validateInputState(this: any, field: string, scope?: string) {
      const formField = this.getField(field, scope);
      if (formField && this.checkFieldDirtyOrValidated(formField)) {
        return !this.errors.has(field, scope) ? null : false;
      }
      return null;
    },
    getValidationInputClass(this: any, field: string, scope: string, baseClass?: string): string {
      const inputCssClass = baseClass === undefined ? '' : `${baseClass} `;
      const inputState = this.validateInputState(field, scope);

      if (inputState === null) {
        return inputCssClass;
      }

      return inputState ? `${inputCssClass}is-valid` : `${inputCssClass}is-invalid`;
    },
    getInputStateClass(this: any, flags: any, errors: string[], baseClass?: string): string {
      const inputCssClass = baseClass === undefined ? '' : `${baseClass} `;
      const inputState = this.getInputState(flags, errors);

      if (inputState === null) {
        return inputCssClass;
      }

      return inputState ? `${inputCssClass}is-valid` : `${inputCssClass}is-invalid`;
    },
    getRangeValidationRule(minimumValue: number, maximumValue: number): string {
      if (minimumValue && maximumValue) {
        return `|between:${minimumValue},${maximumValue}`;
      } else if (minimumValue && !maximumValue) {
        return `|min_value:${minimumValue}`;
      } else if (!minimumValue && maximumValue) {
        return `|max_value:${maximumValue}`;
      } else {
        return '';
      }
    },
    getMaxLengthValidationRule(this: any, maxLength: number): string {
      this.$validator.extend('max', {
        getMessage:
          (field: any, length: any) => `The ${field} field cannot be longer than ${length} characters`,
        validate: (value: any, length: any) => value.toString().length <= length
      });
      if (maxLength && maxLength !== 0) {
        return `|max:${maxLength}`;
      } else {
        return '';
      }
    },
    isFormValid(this: any, scope?: string): boolean {
      return this.checkForm(FieldState.Valid, scope);
    },
    isFormDirty(this: any, scope?: string): boolean {
      return this.checkForm(FieldState.Dirty, scope);
    },
    hasFormChanged(this: any, scope?: string): boolean {
      return this.checkForm(FieldState.Changed, scope);
    },
    checkForm(this: any, action: FieldState, scope?: string) {
      const fields = scope ? this.$validator?.fields[scope] : this.$validator?.fields;
      if (!fields) {
        return false;
      }

      if (action === FieldState.Valid) {
        return Object.keys(fields.items).some((key) => this.checkFieldValid(fields.items[key]));

      } else if (action === FieldState.Dirty) {
        return Object.keys(fields.items).some((key) => this.checkFieldDirty(fields.items[key]));

      } else {
        return Object.keys(fields.items).some((key) => this.checkFieldChanged(fields.items[key]));
      }
    },
    checkFieldDirtyOrValidated(field: any) {
      return this.checkFieldDirty(field) || this.checkFieldValidated(field);
    },
    checkFieldValid(field: any) {
      return field.flags.validated && field.flags.valid;
    },
    checkFieldValidated(field: any) {
      return field.flags.validated;
    },
    checkFieldDirty(field: any) {
      return field.flags.dirty;
    },
    checkFieldChanged(field: any) {
      return field.flags.changed;
    },
    resetField(this: any, field: any, scope?: any) {
      const formField = this.getField(field, scope);
      if (formField) {
        formField.reset();
        this.$validator.errors.remove(formField.name, formField.scope);
      }
    },
    getField(this: any, formField: any, formScope?: any) {
      return this.$validator.fields.find({ name: formField, scope: formScope });
    },
    async validateFormAsync(this: any, formScope?: any) {
      try {
        return formScope ? this.$validator.validateAll(formScope) : this.$validator.validate();
      } catch (error) {
        this.$log('validator error ' + error);
        return false;
      }
    },
    addFormValidationError(this: any, errorMessage: string) {
      this.$validator.errors.add({
        field: FormFieldValidation.Constants.FormsValidationErrorsField,
        msg: errorMessage
      });
    },
    resetFormValidation(this: any) {
      this.$validator.errors.remove(FormFieldValidation.Constants.FormsValidationErrorsField);
    }
  },
  Constants: {
    FormsValidationErrorsField: 'validationErrors'
  }
};

