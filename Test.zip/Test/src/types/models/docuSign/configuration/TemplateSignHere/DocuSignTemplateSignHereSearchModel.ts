export interface DocuSignTemplateSignHereSearchModel {
    documentTypeId: number;
    templateSignHereId: number | null;
}