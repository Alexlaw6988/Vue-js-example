import AxiosConfiguration from '@/classes/AxiosConfiguration';
import { DocumentToStoreModel, DocumentToStoreViewModel, DocumentToStoreSearchModel } from '@/types';

const DocumentToStoreApiUrl = 'DocumentToStore';

export const DocumentToStoreService = {
  async getDocumentToStoreAsync(sourceCabinetId: string, sourceDocumentId: number): Promise<DocumentToStoreModel> {
    const response = await AxiosConfiguration.axiosWithErrorPage.get(
      `${DocumentToStoreApiUrl}/${sourceCabinetId}/${sourceDocumentId}`
    );
    return response.data;
  },
  async getDocumentToStoreViewAsync(
    documentToStoreSearchModel: DocumentToStoreSearchModel
  ): Promise<DocumentToStoreViewModel> {
    const response = await AxiosConfiguration.axiosWithoutNotification.get(DocumentToStoreApiUrl, {
      params: {
        SourceCabinetId: documentToStoreSearchModel.sourceCabinetId,
        SourceDocumentId: documentToStoreSearchModel.sourceDocumentId,
        TargetDocumentTypeId: documentToStoreSearchModel.targetDocumentTypeId
      }
    });
    return response.data;
  }
};
