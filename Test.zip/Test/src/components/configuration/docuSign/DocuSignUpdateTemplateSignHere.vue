<template>
  <div v-if="!isLoading">
    <m-form @submit.prevent="onSubmit" v-slot="{ dirty }">
      <div class="row">
        <div class="col">
          <m-form-input
            id="tabname"
            type="text"
            v-model.trim="templateSignHere.tabName"
            :readonly="false"
            name="Sign Location"
            :state="validateInputState('Sign Location')"
            :validation="{ required: true, maxLength: 50 }"
            label="Sign Location Name"
          />
        </div>
      </div>

      <div class="row">
        <div class="col">
          <m-form-input
            id="pagenumber"
            type="text"
            v-model="pageNumber"
            :readonly="false"
            name="Page Number"
            :state="validateInputState('Page Number')"
            label="Page Number"
            :validation="pageNumberValidation"
          />
          <b-tooltip target="pagenumber" placement="left">
            The page in the document for this sign location
          </b-tooltip>
        </div>

        <div class="col">
          <m-form-input
            id="xcoord"
            type="text"
            v-model="xCoord"
            :readonly="false"
            name="XCoord"
            label="X Coord"
            :state="validateInputState('XCoord')"
            :validation="coordValidation"
          ></m-form-input>
          <b-tooltip target="xcoord" placement="left">
            The number of points from the left, to the top left corner of this sign location
          </b-tooltip>
        </div>

        <div class="col">
          <m-form-input
            id="ycoord"
            type="text"
            v-model="yCoord"
            :readonly="false"
            name="YCoord"
            label="Y Coord"
            :state="validateInputState('YCoord')"
            :validation="coordValidation"
          ></m-form-input>
          <b-tooltip target="ycoord" placement="left">
            The number of points from the top, to the top left corner of this sign location
          </b-tooltip>
        </div>
      </div>

      <div class="row">
        <div class="col">
          <m-form-select
            id="signerRoleId"
            v-if="!isLoading"
            :select-options-data="templateSignHereConfiguration.signerRoles"
            v-model="templateSignHere.signerRoleId"
            display-field-name="description"
            value-field-name="id"
            field-label="Signer"
            v-validate.disabled
            name="Signer"
          ></m-form-select>
          <b-tooltip target="signerRoleId" placement="left">The signer required to sign in this location</b-tooltip>
        </div>
      </div>

      <b-form-invalid-feedback id="formValidation-feedback" :force-show="true">
        {{ errors.first('validationErrors') }}
      </b-form-invalid-feedback>
      <b-form-group class="float-right">
        <b-button
          variant="danger"
          data-testid="update-template-sign-here-cancel-button"
          class="mr-1"
          :disabled="submitIsLoading"
          @click="onCancel()"
        >
          Cancel
        </b-button>
        <b-button
          type="submit"
          data-testid="update-template-sign-here-save-button"
          variant="primary"
          :disabled="submitIsLoading || (!isFormDirty() && !dirty)"
        >
          <b-spinner small class="mb-1 mr-1" v-if="submitIsLoading"></b-spinner>
          Save
        </b-button>
      </b-form-group>
    </m-form>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  import { FormFieldValidation, RouteHelpers, ObjectHelper } from '@/mixins';
  import {
    DocuSignTemplateSignHereConfigurationModel,
    DocuSignTemplateSignHereCreateUpdateModel,
    DocuSignSignerRoleModel,
    Dictionary,
    Configuration,
    ValueType
  } from '@/types';
  import MStoreFormSelect from '@/components/shared/MStoreFormSelect.vue';
  import { ValidationModel } from '@/types/models/validation';
  export default Vue.extend({
    name: 'ds-update-template-sign-here',
    mixins: [FormFieldValidation, RouteHelpers, ObjectHelper],
    props: {
      isLoading: {
        type: Boolean,
        required: true
      },
      submitIsLoading: {
        type: Boolean,
        required: true
      },
      templateSignHereConfiguration: {
        type: Object as () => DocuSignTemplateSignHereConfigurationModel,
        required: true,
        default: {} as DocuSignTemplateSignHereConfigurationModel
      },
      templateSignHere: {
        type: Object as () => DocuSignTemplateSignHereCreateUpdateModel,
        required: true,
        default: {} as DocuSignTemplateSignHereCreateUpdateModel
      },
      serverValidationMessage: {
        type: String,
        required: true
      }
    },
    data() {
      return {
        hasError: false,
        errorMessage: '',
        pageNumber: '',
        xCoord: '',
        yCoord: '',
        signerRoles: [] as DocuSignSignerRoleModel[]
      };
    },
    methods: {
      initialise() {
        this.pageNumber = String(this.templateSignHere.pageNumber);
        this.xCoord = String(this.templateSignHere.xCoord);
        this.yCoord = String(this.templateSignHere.yCoord);
      },
      async onSubmit(this: any) {
        this.resetFormValidation();
        try {
          const isValid = await this.$validator.validate();
          if (!isValid || !this.validateSignerRole()) {
            return;
          }
          this.templateSignHere.templateId = this.templateId;
          this.templateSignHere.pageNumber = Number(this.pageNumber);
          this.templateSignHere.xCoord = Number(this.xCoord);
          this.templateSignHere.yCoord = Number(this.yCoord);
          this.$emit('submit', this.templateSignHere);
        } catch (error) {
          this.$log('Error updating template sign here', error);
        } finally {
          this.submitIsLoading = false;
        }
      },
      onCancel() {
        this.navigateToTemplateSignHereManagement();
      },
      navigateToTemplateSignHereManagement(this: any) {
        const param = {} as Dictionary<any>;
        param.documentTypeId = this.documentTypeId;
        param.templateId = this.templateId;
        this.$router.push({
          name: Configuration.DocuSign.TemplateSignHere.Management.name,
          params: param
        });
      },
      validateSignerRole(this: any): boolean {
        this.resetFormValidation();
        if (this.templateSignHere.signerRoleId == null || this.templateSignHere.signerRoleId < 1) {
          this.addFormValidationError('Please select a Signer');
          return false;
        }
        return true;
      }
    },
    computed: {
      documentTypeId(): number {
        return Number(this.$route.params.documentTypeId);
      },
      templateId(): number {
        return Number(this.$route.params.templateId);
      }
    },
    watch: {
      serverValidationMessage(this: any, value: string) {
        if (!this.isNullOrEmpty(value)) {
          this.addFormValidationError(value);
        }
      }
    },
    mounted(this: any) {
      this.initialise();
    },
    created(this: any) {
      this.pageNumberValidation = {
        required: true,
        valueType: ValueType.Integer,
        minValue: 1,
        maxValue: 100
      } as ValidationModel;
      this.coordValidation = {
        required: true,
        valueType: ValueType.Integer,
        minValue: 0,
        maxValue: 10000
      } as ValidationModel;
    },
    components: {
      'm-form-select': MStoreFormSelect
    }
  });
</script>
