<template>
  <div v-if="showModal">
    <b-modal
      :visible="showModal"
      modal-class="text-center"
      :no-close-on-backdrop="true"
      :no-close-on-esc="true"
      :hide-header-close="true"
      :centered="true"
      id="idle-timeout"
    >
      <div slot="modal-header" class="w-100">
        <h5>
          <font-awesome-icon icon="hourglass-half" size="sm" class="mr-2" />
          {{ title }}
        </h5>
      </div>
      <div>
        <p class="mb-2">{{ caption }}</p>
        <h2 :class="this.expiresInLessThanTenSeconds ? 'mb-1 text-danger' : 'mb-1'">{{ this.expirySecondsLeft }}</h2>
        <p>seconds</p>
        <p class="mb-1 font-weight-bold">{{ instruction }}</p>
      </div>
      <div slot="modal-footer" class="w-100">
        <b-button variant="success" size="sm" class="mr-1" @click="extend()">
          <font-awesome-icon :icon="this.extendButtonIcon" size="sm" class="mr-2" />
          {{ this.extendButtonCaption }}
        </b-button>
        <template v-for="button in buttons">
          <b-button
            :variant="button.variant"
            size="sm"
            @click="buttonClicked(button)"
            :class="button.class"
            :key="button.id"
          >
            <font-awesome-icon :icon="button.icon" size="sm" class="mr-2" />
            {{ button.caption }}
          </b-button>
        </template>
      </div>
    </b-modal>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  import moment from 'moment';
  moment.locale('en-gb');
  import { ButtonModel } from '@/types';

  export default Vue.extend({
    props: {
      showModal: {
        type: Boolean,
        default: false
      },
      title: {
        type: String
      },
      caption: {
        type: String
      },
      instruction: {
        type: String
      },
      extendButtonIcon: {
        type: String,
        default: 'lock'
      },
      extendButtonCaption: {
        type: String,
        default: 'Extend'
      },
      expirySecondsLeft: {
        type: Number
      },
      buttons: {
        type: Array
      }
    },
    data() {
      return {
        expiryTime: moment(),
        nowIntervalId: 0,
        now: moment()
      };
    },
    methods: {
      setNowToNow(this: any) {
        this.now = moment();
      },
      extend(this: any) {
        clearInterval(this.nowIntervalId);
        this.$emit('extend');
      },
      buttonClicked(this: any, button: ButtonModel) {
        this.$emit('buttonClicked', button);
      }
    },
    computed: {
      expiresInLessThanTenSeconds(this: any): boolean {
        return this.expirySecondsLeft <= 10;
      },
      expired(this: any): boolean {
        return this.expirySecondsLeft <= 0;
      }
    },
    watch: {
      now(this: any) {
        if (this.showModal && this.expired) {
          clearInterval(this.nowIntervalId);
          this.$emit('expired');
        }
      },
      showModal(this: any) {
        if (this.showModal) {
          this.now = moment();
          this.nowIntervalId = setInterval(this.setNowToNow, 1000);
        }
      }
    },
    beforeDestroy(this: any) {
      clearInterval(this.nowIntervalId);
    }
  });
</script>
