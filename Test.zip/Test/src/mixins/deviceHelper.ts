export const DeviceHelper = {
  methods: {
    isIpad() {
      return navigator.userAgent.match(/iPad/i) !== null;
    },
    isIOS() {
      return navigator.platform.match(/MacIntel/i) !== null;
    },
    isAndroid() {
      return navigator.userAgent.match(/Android/i) !== null;
    }
  }
};
