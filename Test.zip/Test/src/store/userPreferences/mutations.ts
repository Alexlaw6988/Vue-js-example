import { MutationTree } from 'vuex';
import {
  UserPreferencesState,
  WorkflowJobPreference,
  WorkflowTreeView,
  TabStateModel,
  UserPreferencesMutationTypes,
  DocumentToStoreTargetDocumentTypeModel,
  Dictionary
} from '@/types';
import { userPreferences } from './index';
import { defaultMtableState } from '../mtable';

export const mutations: MutationTree<UserPreferencesState[]> = {
  [UserPreferencesMutationTypes.SetJobVerticalSlider](state, payload: any) {
    const loggedInUserId = Number(payload.userId);
    const userIndexPosition = state.findIndex((x: any) => x.userId === loggedInUserId);
    if (userIndexPosition === -1) {
      const userPreference = userPreferences.defaultUserPreferencesState()[0];
      userPreference.userId = loggedInUserId;
      userPreference.workflowJob.workflowJobPreferences[0] = payload.workflowJobPreference;
      state.push(userPreference);
    } else {
      const currentQueueIndexPosition = state[userIndexPosition].workflowJob.workflowJobPreferences.findIndex(
        (y: any) => y.queueId === payload.workflowJobPreference.queueId
      );

      if (currentQueueIndexPosition === -1) {
        state[userIndexPosition].workflowJob.workflowJobPreferences.push(payload.workflowJobPreference);
      } else {
        state[userIndexPosition].workflowJob.workflowJobPreferences[currentQueueIndexPosition] =
          payload.workflowJobPreference;
      }
    }
  },

  [UserPreferencesMutationTypes.SetWorkflowTreeView](state, payload: any) {
    const loggedInUserId = Number(payload.userId);
    const userIndexPosition = state.findIndex((x: any) => x.userId === loggedInUserId);

    if (userIndexPosition === -1) {
      const workflowTreeView = userPreferences.defaultUserPreferencesState()[0];
      workflowTreeView.userId = loggedInUserId;
      workflowTreeView.workflowTreeView = payload.workflowTreeView;
      state.push(workflowTreeView);
    } else {
      state[userIndexPosition].workflowTreeView = payload.workflowTreeView;
    }
  },

  [UserPreferencesMutationTypes.SetCanGetNextJob](state, payload: any) {
    const loggedInUserId = Number(payload.userId);
    const userIndexPosition = state.findIndex((x: any) => x.userId === loggedInUserId);
    const workflowJobPreferences = userPreferences.defaultWorkflowJobPreference(
      payload.workflowJobPreference.queueId,
      null,
      payload.workflowJobPreference.canGetNextJob
    );
    if (userIndexPosition === -1) {
      const userPreference = userPreferences.defaultUserPreferencesState()[0];
      userPreference.userId = loggedInUserId;
      userPreference.workflowJob.workflowJobPreferences[0] = workflowJobPreferences;
      state.push(userPreference);
    } else {
      const currentQueueIndexPosition = state[userIndexPosition].workflowJob.workflowJobPreferences.findIndex(
        (y: any) => y.queueId === payload.workflowJobPreference.queueId
      );

      if (currentQueueIndexPosition === -1) {
        state[userIndexPosition].workflowJob.workflowJobPreferences.push(workflowJobPreferences);
      } else {
        state[userIndexPosition].workflowJob.workflowJobPreferences[currentQueueIndexPosition].canGetNextJob =
          payload.workflowJobPreference.canGetNextJob;
      }
    }
  },

  [UserPreferencesMutationTypes.SetLastSelectedWorkflowQueue](state, payload: any) {
    const loggedInUserId = Number(payload.userId);
    const userIndexPosition = state.findIndex((x: any) => x.userId === loggedInUserId);

    if (userIndexPosition === -1) {
      const userPreference = userPreferences.defaultUserPreferencesState()[0];
      userPreference.userId = loggedInUserId;
      userPreference.workflowJob.SelectedWorkflowQueueID = payload.selectedQueueId;
      state.push(userPreference);
    } else {
      state[userIndexPosition].workflowJob.SelectedWorkflowQueueID = payload.selectedQueueId;
    }
  },

  [UserPreferencesMutationTypes.SetWorkflowQueueTableStateField](state, payload: any) {
    const loggedInUserId = Number(payload.userId);
    const userIndexPosition = state.findIndex((x: any) => x.userId === loggedInUserId);
    const tableOptions = Object.assign(defaultMtableState(), {
      [payload.workflowQueueTableStatePreference.field]: payload.workflowQueueTableStatePreference.value
    });
    const workflowJobPreferences = userPreferences.defaultWorkflowJobPreference(
      payload.workflowQueueTableStatePreference.queueId,
      null,
      null,
      tableOptions
    );
    if (userIndexPosition === -1) {
      const userPreference = userPreferences.defaultUserPreferencesState()[0];
      userPreference.userId = loggedInUserId;
      userPreference.workflowJob.workflowJobPreferences[0] = workflowJobPreferences;
      state.push(userPreference);
    } else {
      const currentQueueIndexPosition = state[userIndexPosition].workflowJob.workflowJobPreferences.findIndex(
        (y: any) => y.queueId === payload.workflowQueueTableStatePreference.queueId
      );

      if (currentQueueIndexPosition === -1) {
        state[userIndexPosition].workflowJob.workflowJobPreferences.push(workflowJobPreferences);
      } else {
        if (state[userIndexPosition].workflowJob.workflowJobPreferences[currentQueueIndexPosition].tableOptions) {
          Object.assign(
            state[userIndexPosition].workflowJob.workflowJobPreferences[currentQueueIndexPosition].tableOptions,
            {
              [payload.workflowQueueTableStatePreference.field]: payload.workflowQueueTableStatePreference.value
            }
          );
        } else {
          state[userIndexPosition].workflowJob.workflowJobPreferences[
            currentQueueIndexPosition
          ].tableOptions = tableOptions;
        }
      }
    }
  },

  [UserPreferencesMutationTypes.SetDocumentToStoreTargetDocumentType](state, payload: any) {
    const loggedInUserId = Number(payload.userId);
    const userIndexPosition = state.findIndex((x: any) => x.userId === loggedInUserId);
    const documentToStoreTargetDocumentType: DocumentToStoreTargetDocumentTypeModel =
      payload.documentToStoreTargetDocumentType;

    if (userIndexPosition === -1) {
      const userPreference = userPreferences.defaultUserPreferencesState()[0];
      userPreference.userId = loggedInUserId;
      userPreference.documentToStoreTargetDocumentTypes[documentToStoreTargetDocumentType.sourceDocumentType] =
        documentToStoreTargetDocumentType.targetDocumentType;
      state.push(userPreference);
    } else {
      if (!state[userIndexPosition].documentToStoreTargetDocumentTypes) {
        state[userIndexPosition].documentToStoreTargetDocumentTypes = {} as Dictionary<number>;
      }
      state[userIndexPosition].documentToStoreTargetDocumentTypes[
        documentToStoreTargetDocumentType.sourceDocumentType
      ] = documentToStoreTargetDocumentType.targetDocumentType;
    }
  }
};
