import { DocuSignTemplateSignHereModel, DocuSignSignerRoleModel } from '@/types';

export interface DocuSignTemplateSignHereConfigurationModel {
    templateSignHere: DocuSignTemplateSignHereModel;
    signerRoles: DocuSignSignerRoleModel[];
}