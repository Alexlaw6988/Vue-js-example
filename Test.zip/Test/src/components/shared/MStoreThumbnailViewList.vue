<template>
  <div data-testid="thumbnailsContainer" class="container bg-dark h-100 p-0" :style="containerStyle">
    <MStoreThumbnailView
      v-for="thumbnail in thumbnails"
      :key="getThumbnailKey(thumbnail)"
      :thumbnail="thumbnail"
      :maximumImageHeight="maximumImageHeight"
      class="m-0 p-1"
      :class="{ 'bg-info': selectedPage === thumbnail.page }"
      v-on-intersect="{ margin: getIntersectMargin, emitTimeout: 250 }"
      @isIntersected="onThumbnailIntersectedAsync(thumbnail.page)"
      @click="onPageClick(thumbnail.page)"
    />
  </div>
</template>

<script lang="ts">
import Vue from 'vue';
import { DocumentModel, ThumbnailSearchModel, ThumbnailViewModel } from '@/types';
import MStoreThumbnailView from '@/components/shared/MStoreThumbnailView.vue';
import { DocumentService } from '@/services/DocumentService';
import { DocumentConstants } from '@/types/constants';

export default Vue.extend({
  name: 'MStoreThumbnailViewList',
  components: {
    MStoreThumbnailView
  },
  props: {
    document: {
      type: Object as () => DocumentModel,
      required: true
    },
    maximumImageHeight: {
      type: Number,
      default: 150
    },
    selectedPage: {
      type: Number,
      required: false
    },
    maximumImagesToPreload: {
      type: Number,
      default: 2
    }
  },
  data() {
    return {
      thumbnails: {} as ThumbnailViewModel[]
    };
  },
  computed: {
    aSeriesPaperAspectRatio() {
      return DocumentConstants.ASeriesPaperAspectRatio;
    },
    containerStyle(): string {
      return `width: calc(${this.maximumImageHeight * this.aSeriesPaperAspectRatio}px + 1.8em);`;
    },
    getIntersectMargin() {
      return `0px 0px ${this.maximumImageHeight * this.maximumImagesToPreload}px 0px`;
    }
  },
  methods: {
    async onThumbnailIntersectedAsync(page: number) {
      const thumbnailWithData = await this.getThumbnailForPageAsync(page);
      if (!thumbnailWithData) {
        return;
      }

      const index = this.thumbnails.findIndex((x) => x.page === page);

      this.thumbnails.splice(index, 1, thumbnailWithData);
    },
    initThumbnails() {
      const pageNums = Array.from({ length: this.document.totalPages });

      this.thumbnails = pageNums.map((pageNum, index) => {
        const thumbnail = {
          page: index + 1
        } as ThumbnailViewModel;

        return thumbnail;
      });
    },
    async getThumbnailForPageAsync(this: any, pageNumber: number) {
      const searchModel = {
        documentId: this.document.id,
        cabinetId: this.document.cabinetId,
        page: pageNumber,
        maximumHeightInPixels: Math.floor(this.maximumImageHeight),
        maximumWidthInPixels: Math.floor(this.maximumImageHeight * this.aSeriesPaperAspectRatio)
      } as ThumbnailSearchModel;

      try {
        const thumbnailData = await DocumentService.getThumbnailAsync(searchModel);

        return thumbnailData;
      } catch (error) {
        this.$log(`Unable to load thumbnail for page ${pageNumber}`, error);
      }
    },
    onPageClick(pageNumber: number) {
      this.$emit('pageClick', pageNumber);
    },
    getThumbnailKey(thumbnail: ThumbnailViewModel): string {
      return `${this.document.id}_${thumbnail.page}`;
    }
  },
  mounted() {
    this.initThumbnails();
  },
  watch: {
    'document.id': {
      handler() {
        this.initThumbnails();
      }
    },
    'maximumImageHeight': {
      handler() {
        this.initThumbnails();
      }
    },
    'selectedPage': {
      handler() {
        this.$nextTick(() => {
          const element = document.querySelector('.bg-info');
          element?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        });
      }
    }
  }
});
</script>

<style scoped>
.container {
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
  align-content: flex-start;
  overflow-y: auto;
  overflow-x: hidden;
  display: flex;
}

.container div:hover {
  cursor: pointer;
}
</style>
