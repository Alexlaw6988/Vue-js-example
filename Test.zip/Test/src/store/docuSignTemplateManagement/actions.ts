import { DocuSignTemplateManagementState, RootState, DocuSignTemplateManagementMutationTypes } from '@/types';
import { ActionTree } from 'vuex';

export const actions: ActionTree<DocuSignTemplateManagementState, RootState> = {
    resetTemplateManagementState({ commit }) {
        commit(DocuSignTemplateManagementMutationTypes.ResetState);
    },
    setTableStateField({ commit, state }, tableStateField: any) {
        commit(DocuSignTemplateManagementMutationTypes.SetTableStateField, tableStateField);
    },
    setDocumentTypeId({ commit, state }, documentTypeId: number) {
        commit(DocuSignTemplateManagementMutationTypes.SetDocumentType, documentTypeId);
    }
};