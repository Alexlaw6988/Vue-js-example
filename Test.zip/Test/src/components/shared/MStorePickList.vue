<template>
  <div class="card">
    <div class="card-header text-white bg-primary">
      <div v-if="hasError" class="row justify-content-between px-2">
        <h6 class="d-flex align-items-center">Error</h6>
        <font-awesome-icon size="lg" icon="exclamation-triangle" class="float-right" />
      </div>
      <div v-else class="row justify-content-between px-2">
        <loading-spinner v-if="isPageLoading" :isLoading="isPageLoading" :isSpinner="false"></loading-spinner>
        <h6 v-else-if="!isPageLoading" class="d-flex align-items-center">
          {{ showPicklist ? 'Edit' : '' }} {{ headerName }}
        </h6>
        <font-awesome-icon v-if="showPicklist" size="lg" icon="edit" class="float-right" />
        <font-awesome-icon
          v-else
          size="lg"
          icon="sync-alt"
          class="float-right"
          :disabled="disableControl"
          @click="getData()"
          :spin="isPageLoading"
        />
      </div>
    </div>
    <div class="card-header">
      <div name="header" class="row">
        <div class="col col-xl-5">
          <m-store-filter
            data-testid="searchbox-input"
            placeholder="Start typing to search.."
            v-model="headerFilters.searchQuery"
            :disabled="disableControl"
          />
        </div>
        <div class="col col-xl-3">
          <b-form-checkbox
            class="py-2"
            v-show="showPicklist"
            v-model="showExcluded"
            name="Checkbutton"
            switch
            size="md"
            :disabled="disableControl"
          >
            Show Excluded
          </b-form-checkbox>
        </div>
        <div class="col col-xl-4">
          <b-button
            data-testid="edit-button"
            v-show="!showPicklist"
            variant="primary"
            class="float-right"
            :disabled="disableControl"
            @click="showPicklist = true"
          >
            <font-awesome-icon icon="edit" class="mr-1" />
            Edit
          </b-button>
        </div>
      </div>
    </div>
    <div class="card-body overflow-auto p-0" ref="cardBody">
      <h6 v-if="hasError" class="text-center mt-4">{{ errorMessage }}</h6>
      <LoadingSpinner v-else-if="isPageLoading" :isLoading="isPageLoading" />
      <div v-else>
        <b-table
          v-if="!showPicklist"
          name="default-table"
          show-empty
          bordered
          hover
          :busy="isPageLoading"
          :items="includedItems"
          :fields="tableFilterFields(viewItemsFields)"
          :filter="headerFilters.searchQuery"
          @filtered="onFiltered"
          :filter-function="tableFilter"
        ></b-table>
        <b-table
          v-if="showPicklist"
          :name="showExcluded ? 'excluded-table' : 'included-table'"
          show-empty
          bordered
          hover
          :busy="isPageLoading"
          :items="$data[showExcluded ? 'excludedItems' : 'includedItems']"
          :fields="tableFilterFields(picklistFields)"
          :filter="headerFilters.searchQuery"
          @filtered="onFiltered"
          :filter-function="tableFilter"
        >
          <template v-if="!showExcluded" v-slot:cell(actions)="row">
            <div class="text-center">
              <b-button
                data-testid="remove-button"
                size="sm"
                variant="danger"
                v-show="canRemove(row)"
                @click="removeItem(row)"
              >
                <font-awesome-icon icon="minus" />
              </b-button>
            </div>
          </template>
          <template v-else v-slot:cell(actions)="row">
            <div class="text-center">
              <b-button data-testid="add-button" size="sm" variant="success" @click="addItem(row)">
                <font-awesome-icon icon="plus" />
              </b-button>
            </div>
          </template>
        </b-table>
      </div>
    </div>
    <div class="card-footer" v-if="showPicklist && !hasError">
      <div class="float-right">
        <b-button
          data-testid="save-button"
          variant="primary"
          class="mr-2"
          :disabled="disableControl || !isPicklistDirty"
          @click="save()"
        >
          <b-spinner small class="mb-1 mr-1 align-middle" v-if="isLoading"></b-spinner>
          Save
        </b-button>
        <b-button
          data-testid="cancel-button"
          variant="danger"
          :disabled="disableControl"
          class="mr-1"
          @click="cancel()"
        >
          Cancel
        </b-button>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  import axios from 'axios';
  import LoadingSpinner from '@/components/shared/LoadingSpinner.vue';
  import MStoreFilter from '@/components/shared/MStoreFilter.vue';
  import { BTableHelpers, FormFieldValidation } from '@/mixins';

  export default Vue.extend({
    name: 'MStorePickList',
    mixins: [BTableHelpers, FormFieldValidation],
    props: {
      headerName: {
        type: String,
        required: true
      },
      includedItemsApiPath: {
        type: String,
        required: true
      },
      allItemsApiPath: {
        type: String,
        required: true
      },
      picklistFields: {
        type: Array,
        required: true
      },
      fixedItems: {
        type: Array,
        required: false
      }
    },
    data() {
      return {
        includedItems: [] as object[],
        excludedItems: [] as object[],
        viewItemsFields: [] as object[],
        distinctFixedItems: [] as object[],
        headerFilters: {
          totalRows: 0 as number,
          searchQuery: '' as string
        } as object,
        showExcluded: false,
        showPicklist: false,
        isLoading: false,
        isPageLoading: true,
        hasError: false,
        isPicklistDirty: false,
        errorMessage: ''
      };
    },
    methods: {
      async getData(this: any) {
        this.isPageLoading = true;
        this.distinctFixedItems = Array.from(new Set(this.fixedItems));
        this.includedItems = await this.getItemsAsync(this.includedItemsApiPath);
        this.excludedItems = await this.getItemsAsync(this.allItemsApiPath);
        this.getExcludedItems();
        this.isPageLoading = false;
      },
      async getItemsAsync(this: any, apiPath: string) {
        return await axios
          .get(apiPath)
          .then((response) => {
            this.hasError = false;
            return response.data;
          })
          .catch((error: any) => {
            this.hasError = true;
            this.errorMessage = error.response.data;
            return [];
          });
      },
      getExcludedItems(this: any) {
        this.excludedItems = this.excludedItems.filter(
          (excludedItem: any) =>
            this.includedItems.filter(
              (includedItem: any) =>
                excludedItem[Object.keys(excludedItem)[0]] === includedItem[Object.keys(includedItem)[0]]
            ).length === 0
        );
        this.viewItemsFields = this.picklistFields.map((x: any) => x);
        this.viewItemsFields.pop();
      },
      onFiltered(this: any, filteredItems: any) {
        this.headerFilters.totalRows = filteredItems.length;
      },
      removeItem(row: any) {
        const index = this.includedItems.findIndex((x: any) => x === row.item);
        this.includedItems.splice(index, 1);
        this.excludedItems.push(row.item);
        this.isPicklistDirty = true;
      },
      addItem(row: any) {
        const index = this.excludedItems.findIndex((x: any) => x === row.item);
        this.excludedItems.splice(index, 1);
        this.includedItems.push(row.item);
        this.isPicklistDirty = true;
      },
      canRemove(row: any): boolean {
        return !this.distinctFixedItems.find((x: any) => x === row.item.id);
      },
      save(this: any) {
        this.isLoading = true;
        this.$emit('saveClicked', this.includedItems);
        this.showPicklist = false;
        this.isLoading = false;
        this.isPicklistDirty = false;
      },
      cancel(this: any) {
        if (this.isPicklistDirty) {
          this.$bvModal
            .msgBoxConfirm('Are you sure you want to cancel, any changes will be lost?', {
              title: 'Are you sure?',
              cancelVariant: 'danger'
            })
            .then((result: boolean) => {
              if (result) {
                this.reset();
              }
            });
        } else {
          this.reset();
        }
      },
      reset() {
        this.showPicklist = false;
        if (this.isPicklistDirty) {
          this.isPicklistDirty = false;
          this.getData();
        }
      }
    },
    mounted(this: any) {
      this.getData();
    },
    computed: {
      disableControl(this: any) {
        return this.isPageLoading || this.isLoading || this.hasError;
      }
    },
    watch: {
      isPicklistDirty(this: any) {
        this.setApplicationDirty(this.isPicklistDirty);
      }
    },
    components: {
      LoadingSpinner,
      MStoreFilter
    }
  });
</script>
