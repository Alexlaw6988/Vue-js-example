export enum WorkflowStandardProcessingAction {
  ProcessJob = 0,
  ReturnJob = 1,
  ExceptionJob = 2,
  CancelJob = 3,
  SaveJob = 4
}
