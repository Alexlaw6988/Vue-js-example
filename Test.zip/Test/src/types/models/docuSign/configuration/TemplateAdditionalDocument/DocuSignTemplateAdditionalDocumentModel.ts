import { DocuSignAdditionalDocumentFileModel, DocuSignTemplateAdditionalDocumentSignHereModel } from '@/types';

export interface DocuSignTemplateAdditionalDocumentModel {
    id: number;
    templateId: number;
    additionalDocumentFile: DocuSignAdditionalDocumentFileModel;
    signHeres: DocuSignTemplateAdditionalDocumentSignHereModel[];
    canDelete: boolean;
}
