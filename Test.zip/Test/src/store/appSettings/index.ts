import { actions } from './actions';
import { getters } from './getters';
import { mutations } from './mutations';
import { AppSettingsModel } from '@/types';

export const state = {
  appSettings: {} as AppSettingsModel
};

const namespaced: boolean = true;

export const appSettings = {
  namespaced,
  state,
  actions,
  getters,
  mutations
};
