import { CabinetModel } from '@/types';
import { DocumentTypeModel } from '@/types';
import { DocuSignTemplateAfterSignReferenceMappingModel } from '@/types';

export interface DocuSignTemplateAfterSignSettingModel {
  id: number;
  templateType: string;
  templateName: string;
  targetCabinet: CabinetModel;
  targetDocumentType: DocumentTypeModel;
  sourceDocumentType: DocumentTypeModel;
  additionalDocumentFileDescription: string;
  referenceMappings: DocuSignTemplateAfterSignReferenceMappingModel[];
  indexAction: number;
}
