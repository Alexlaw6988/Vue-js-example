import { DocumentsToStoreState } from '@/types';
import { getters } from './getters';
import { actions } from './actions';
import { mutations } from './mutations';

export const state: DocumentsToStoreState = {
  cabinetId: 'I',
  documentId: 1,
  pagesToIndex: '0-10',
  thumbnails: [{ thumbnailData: 'data' }],
  error: false,
  errorMessage: '',
  isLoading: false,
  showNoDocumentNotification: false
};

const namespaced: boolean = true;

export const documentsToStore = {
  namespaced,
  state,
  getters,
  actions,
  mutations
};