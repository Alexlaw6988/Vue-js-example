import { BaseModel } from '../BaseModel';

export interface DocumentModel extends BaseModel {
  contentType: string;
  fileName: string;
  documentData: string;
  totalPages: number;
  viewConversionId: number;
  isBeingConverted: boolean;
  conversionRequestedDate: Date;
  id: number;
  cabinetId: string;
}
