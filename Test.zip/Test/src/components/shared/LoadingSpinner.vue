<template>
  <div class="d-flex justify-content-center w-100">
    <div v-if="isLoading && isSpinner" class="loadingSpinner" :style="`position: ${cssPositioning}`">
      <div :class="`text-center mb-2 pr-1 text-${textColourVariant}`">
        <font-awesome-icon size="2x" icon="spinner" spin />
      </div>
      <div :class="`text-center text-${textColourVariant}`">
        <p class="mb-0">
          {{ loadingMessage }}
          <span class="loader-dot">.</span>
          <span class="loader-dot">.</span>
          <span class="loader-dotd">.</span>
        </p>
      </div>
    </div>
    <div v-else-if="isLoading && !isSpinner">
      <h6 class="loader">
        {{ loadingMessage }}
        <span class="loader-dot">.</span>
        <span class="loader-dot">.</span>
        <span class="loader-dot">.</span>
      </h6>
    </div>
    <slot></slot>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  export default Vue.extend({
    name: 'LoadingSpinner',
    props: {
      isLoading: {
        type: Boolean,
        required: true
      },
      textColourVariant: {
        type: String,
        required: false,
        default: 'gray'
      },
      cssPositioning: {
        type: String,
        required: false,
        default: 'absolute'
      },
      loadingMessage: {
        type: String,
        required: false,
        default: 'Loading'
      },
      isSpinner: {
        type: Boolean,
        required: false,
        default: true
      }
    },
    created() {
      this.$on('update:loadingSpinnerIsLoading', function(this: any, value: boolean) {
        this.loading = value;
      });
    },
    computed: {
      loading: {
        get(this: any) {
          return this.isLoading;
        },
        set(this: any, value: boolean) {
          this.$emit('update:isLoading', value);
        }
      }
    }
  });
</script>
