import axios from 'axios';
import { DocumentVersionModel, BaseDocumentSearchModel } from '@/types';

const DocumentVersionsApiUrl = 'documentVersion/';

export const DocumentVersionService = {
  async getDocumentVersionsAsync(cabinetId: string, documentId: number): Promise<DocumentVersionModel[]> {
    const response = await axios.get(DocumentVersionsApiUrl.concat(cabinetId, '/', documentId.toString()));
    return response.data;
  },

  async makeCurrentVersionAsync(
    currentversionDocumentId: number,
    documentVersionId: number
  ): Promise<BaseDocumentSearchModel> {
    const response = await axios.post(
      DocumentVersionsApiUrl.concat(
        'MakeCurrentVersion',
        '/',
        currentversionDocumentId.toString(),
        '/',
        documentVersionId.toString()
      )
    );
    return response.data;
  }
};
