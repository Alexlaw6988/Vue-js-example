import { actions } from './actions';
import { getters } from './getters';
import { mutations } from './mutations';
import { UserState, UserModel, PreviousRoute } from '@/types';
import { mstoreSettings } from '@/settings/mstoreSettings';
import moment from 'moment';

export const state: UserState = {
  currentUser: {} as UserModel,
  isLoading: false,
  error: false,
  errorMessage: '',
  postSignInIdleTime: moment().add(mstoreSettings.idleTimeout, 'seconds'),
  previousRoute: { currentRoute: {}, lastRoute: {} } as PreviousRoute,
  errorPageRoute: { currentRoute: {}, lastRoute: {} } as PreviousRoute
};

const namespaced: boolean = true;

export const user = {
  namespaced,
  state,
  actions,
  getters,
  mutations
};
