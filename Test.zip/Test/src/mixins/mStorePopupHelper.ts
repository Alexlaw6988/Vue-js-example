import { EventBus } from '@/classes/EventBus';
import { MStorePopupEvent } from '@/types/enums';

export const MStorePopupHelper = {
  data() {
    return {
      showModal: false,
      showFooter: false,
      componentName: '',
      title: ''
    };
  },
  methods: {
    openModal() {
      EventBus.$emit(MStorePopupEvent.ShowModal, true);
    },
    closeModal() {
      EventBus.$emit(MStorePopupEvent.ShowModal, false);
    },
    setComponent(componentName: any) {
      EventBus.$emit(MStorePopupEvent.SetComponent, componentName);
    },
    setTitle(title: any) {
      EventBus.$emit(MStorePopupEvent.SetTitle, title);
    }
  },
  created(this: any) {
    EventBus.$on(MStorePopupEvent.ShowModal, (data: boolean) => {
      this.showModal = data;
    });
    EventBus.$on(MStorePopupEvent.SetComponent, (data: string) => {
      this.componentName = data;
    });
    EventBus.$on(MStorePopupEvent.SetTitle, (data: string) => {
      this.title = data;
    });
  },
  beforeDestroy() {
    EventBus.$off(MStorePopupEvent.ShowModal);
    EventBus.$off(MStorePopupEvent.SetComponent);
    EventBus.$off(MStorePopupEvent.SetTitle);
  }
};
