export interface DocumentPageModel {
  documentData: string;
  pageNumber: number;
  documentId: number;
}
