export enum LeaverDocumentStatus {
  Unprocessed = 1,
  Pending = 2,
  Success = 3,
  Failed = 4
}
