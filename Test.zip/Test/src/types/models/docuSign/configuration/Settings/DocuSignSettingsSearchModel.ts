export interface DocuSignSettingsSearchModel {
  documentTypeId: number | null;
}
