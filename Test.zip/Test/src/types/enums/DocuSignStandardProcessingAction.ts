export enum DocuSignStandardProcessingAction {
  ReturnToPrepare = 0,
  Cancel = 1,
  CreateEnvelope = 2,
  VoidEnvelope = 3
}
