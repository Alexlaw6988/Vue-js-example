import {
    DocuSignSignerRoleModel, DocuSignAdditionalDocumentFileModel,
    DocuSignTemplateAdditionalDocumentModel
} from '@/types';

export interface DocuSignTemplateAdditionalDocumentConfigurationModel {
    documentTypeId: number;
    templateId: number;
    additionalDocumentFileId: number | null;
    templateAdditionalDocumentId: number | null;
    signerRoles: DocuSignSignerRoleModel[];
    additionalDocumentFiles: DocuSignAdditionalDocumentFileModel[];
    templateAdditionalDocument: DocuSignTemplateAdditionalDocumentModel;
}