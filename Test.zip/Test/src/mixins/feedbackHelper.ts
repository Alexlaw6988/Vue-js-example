import { MStorePopupHelper } from './mStorePopupHelper';

export const FeedbackHelper = {
  methods: {
    ShowFeedbackInPopup(title: any) {
      MStorePopupHelper.methods.openModal();
      MStorePopupHelper.methods.setComponent('Feedback');
      MStorePopupHelper.methods.setTitle(title);
    },
    closeModal() {
      MStorePopupHelper.methods.closeModal();
    }
  }
};
