export interface AppStartSettingsModel {
  baseUrl: string;
  authServerAuthority: string;
  sessionId: string;
  idleTimeout: number;
  maximumNumberOfPagesToCache: number;
}
