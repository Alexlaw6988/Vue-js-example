import { Dictionary } from '@/types';

export interface DocumentToStoreUpdateModel {
  cabinetId: string;
  documentTypeId: number;
  references: Dictionary<any>;
  pages: string;
}