import { actions } from './actions';
import { getters } from './getters';
import { mutations } from './mutations';
import { ApplicationDirtyStateModel } from '@/types';

export function defaultApplicationDirtyState() {
  return {
    isDirty: false,
    showModal: false,
    routeNavigatedTo: '',
    isDirtyOnAnotherTab: false
  };
}

export const state: ApplicationDirtyStateModel = defaultApplicationDirtyState();

const namespaced: boolean = true;

export const applicationDirty = {
  namespaced,
  state,
  actions,
  getters,
  mutations,
  defaultApplicationDirtyState
};
