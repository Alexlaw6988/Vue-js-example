<template>
  <div id="m-loadingLayout" class="bg-light-gray h-100">
    <slot />
  </div>
</template>

<script>
  import { Vue } from 'vue-property-decorator';
  export default Vue.extend({
    name: 'LoadingLayout'
  });
</script>
