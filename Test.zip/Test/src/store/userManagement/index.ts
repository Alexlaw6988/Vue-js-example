import { actions } from './actions';
import { getters } from './getters';
import { mutations } from './mutations';
import { UserManagementState, StandardOrganisation } from '@/types';

export function defaultUserManagementState() {
  return {
    organisationId: StandardOrganisation.InternalUsers,
    showDeactivated: false,
    isLoading: false,
    error: false,
    errorMessage: ''
  } as UserManagementState;
}

export const state: UserManagementState = defaultUserManagementState();

const namespaced: boolean = true;

export const userManagement = {
  namespaced,
  state,
  actions,
  getters,
  mutations,
  defaultUserManagementState
};
