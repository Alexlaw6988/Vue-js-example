import axios from 'axios';
import { DocumentSearchModel, RelatedDocumentsModel } from '@/types';

const RelatedDocumentsApiUrl = 'relatedDocuments';

export const RelatedDocumentsService = {
  async getRelatedDocumentsAsync(documentSearchModel: DocumentSearchModel): Promise<RelatedDocumentsModel> {
    const response = await axios.get(
      `${RelatedDocumentsApiUrl}/${documentSearchModel.cabinetId}/${documentSearchModel.documentId}`
    );
    return response.data;
  }
};
