export interface DocuSignSignerRoleDataFieldModel {
  dataSourceKey: string;
  name: string;
  description: string;
}
