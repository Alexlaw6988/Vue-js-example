import { UserPreferencesState, RootState, WorkflowJobPreference, WorkflowTreeView, TableStateModel } from '@/types';
import { GetterTree } from 'vuex';
import { userPreferences } from './index';
import { defaultMtableState } from '../mtable';
import { state } from '../user';

export const getters: GetterTree<UserPreferencesState[], RootState> = {
  getWorkflowJobPreferences: (state, getters, rootState: any) => (queueId: number): WorkflowJobPreference => {
    const userPreference = getters.getUserPreferenceState();

    if (!userPreference) {
      return userPreferences.defaultUserPreferencesState()[0].workflowJob.workflowJobPreferences[0];
    } else {
      const workflowJobPreference = userPreference.workflowJob.workflowJobPreferences.find(
        (x: any) => x.queueId === queueId
      );
      return workflowJobPreference
        ? workflowJobPreference
        : userPreferences.defaultUserPreferencesState()[0].workflowJob.workflowJobPreferences[0];
    }
  },

  getWorkflowTreeViewPreferences: (state, getters, rootState: any) => (): WorkflowTreeView => {
    const userPreference = getters.getUserPreferenceState();

    return userPreference && userPreference.workflowTreeView != null
      ? userPreference.workflowTreeView
      : userPreferences.defaultUserPreferencesState()[0].workflowTreeView;
  },

  getSelectedWorkflowQueue: (state, getters, rootState: any) => (): number => {
    const userPreference = getters.getUserPreferenceState();

    return userPreference && userPreference.workflowJob != null
      ? userPreference.workflowJob.SelectedWorkflowQueueID
      : 0;
  },

  getUserPreferedTableStateField: (state, getters) => (queueId: number, field: keyof TableStateModel): any => {
    const workflowQueuePreference = getters.getWorkflowJobPreferences(queueId);

    return workflowQueuePreference.tableOptions
      ? workflowQueuePreference.tableOptions[field]
      : defaultMtableState()[field];
  },

  getUserPreferenceState: (state, getters, rootState: any) => (): any => {
    return state.find((x: any) => x.userId === Number(rootState.oidcStore.user.id));
  },

  getDocumentToStoreTargetDocumentType: (state, getters, rootState: any) => (
    documentToStoreSourceDocumentType: string
  ): number | null => {
    const userPreference = getters.getUserPreferenceState();
    if (!userPreference?.documentToStoreTargetDocumentTypes) {
      return null;
    }
    return userPreference.documentToStoreTargetDocumentTypes[documentToStoreSourceDocumentType] || null;
  }
};
