import { DocuSignSignerRoleModel } from '@/types';

export interface DocuSignTemplateSignHereModel {
    id: number;
    templateId: number;
    signerRoleId: number;
    tabName: string;
    pageNumber: number;
    xCoord: number;
    yCoord: number;
    signerRole: DocuSignSignerRoleModel;
}