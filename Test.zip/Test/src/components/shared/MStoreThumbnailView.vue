<template>
  <div class="d-inline-block" @click="$emit('click')">
    <div v-show="isLoading || hasError" class="justify-content-center bg-dark">
      <div data-testid="loadingPlaceholder" class="bg-light" :style="placeholderStyle">
        <div class="row h-100">
          <div class="col text-center align-self-center">
            <div data-testid="loadingContainer" v-show="isLoading" class="text-muted">
              <font-awesome-icon size="2x" icon="spinner" spin />
              <div v-show="pageLabel" class="mt-1">{{ thumbnail.page }}</div>
            </div>
            <div
              data-testid="errorContainer"
              v-show="hasError"
              class="text-warning"
              v-b-tooltip="'Click to display error information'"
              @mouseenter="onErrorMouseEnter"
              @mouseleave="onErrorMouseLeave"
              :style="errorStyle"
              @click="onErrorClick"
            >
              <span class="text-warning">
                <font-awesome-icon size="2x" icon="exclamation-circle" />
              </span>
              <div v-show="pageLabel" class="mt-1">{{ thumbnail.page }}</div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div data-testid="imageContainer" v-show="!isLoading && !hasError" class="justify-content-center bg-dark">
      <div>
        <img @load="onImageLoaded" :src="thumbnail.documentData" :alt="thumbnail.page" ref="image" :style="imageStyle" />
        <div class="text-center bg-light"><slot></slot></div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import Vue from 'vue';
import { ThumbnailViewModel } from '@/types';
import Toast from '@/classes/SnotifyConfiguration';
import { DocumentConstants } from '@/types/constants';

export default Vue.extend({
  name: 'MStoreThumbnailView',
  props: {
    thumbnail: {
      type: Object as () => ThumbnailViewModel,
      required: true
    },
    maximumImageHeight: {
      type: Number,
      required: false,
      default: 150
    }
  },
  data() {
    return {
      imageWidth: null,
      hoveringOverError: false
    };
  },
  methods: {
    onImageLoaded(this: any) {
      const image = this.$refs.image as HTMLImageElement;
      this.imageWidth = image?.naturalWidth;
    },
    onErrorClick(this: any) {
      Toast.showError(this.thumbnail.notification);
    },
    onErrorMouseEnter(this: any) {
      this.hoveringOverError = true;
    },
    onErrorMouseLeave(this: any) {
      this.hoveringOverError = false;
    }
  },
  computed: {
    isLoading(this: any): boolean {
      return !this.thumbnail?.documentData && !this.thumbnail?.hasNotification;
    },
    hasError(this: any): boolean {
      return this.thumbnail?.hasNotification;
    },
    pageLabel() {
      return this.thumbnail?.page;
    },
    thumbnailImageWidth(this: any) {
      return this.imageWidth;
    },
    imageStyle(): string {
      return `width: ${this.thumbnailImageWidth}px;`;
    },
    placeholderWidth(this: any): number {
      return Math.trunc(this.maximumImageHeight * this.aSeriesPaperAspectRatio);
    },
    placeholderStyle(): string {
      return `height: ${this.maximumImageHeight}px; width: ${this.placeholderWidth}px;`;
    },
    errorStyle(this: any): string {
      return this.hoveringOverError ? 'cursor: pointer' : '';
    },
    aSeriesPaperAspectRatio() {
      return DocumentConstants.ASeriesPaperAspectRatio;
    }
  }
});
</script>