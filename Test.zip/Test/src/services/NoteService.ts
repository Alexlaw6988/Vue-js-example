import axios from 'axios';
import { NoteModel, NoteCreateModel } from '@/types';

const NoteApiUrl = 'notes';

export const NoteService = {
  async getNotesAsync(entityTypeId: number, entityPk: string): Promise<NoteModel[]> {
    const response = await axios.get(NoteApiUrl.concat('/', entityTypeId.toString(), '/', entityPk));
    return response.data;
  },
  async createNoteAsync(entityTypeId: number, entityPk: string, noteCreateModel: NoteCreateModel): Promise<number> {
    const response = await axios.post(NoteApiUrl.concat('/', entityTypeId.toString(), '/', entityPk), noteCreateModel);
    return response.data;
  },

  async updateNoteAsync(entityTypeId: number, entityPk: string, noteUpdateModel: NoteModel) {
    const response = await axios.put(NoteApiUrl.concat('/', entityTypeId.toString(), '/', entityPk), noteUpdateModel);
    return response.data;
  },

  async deleteNoteAsync(entityTypeId: number, entityPk: string, noteId: number) {
    const response = await axios.delete(`${NoteApiUrl}/${entityTypeId}/${entityPk}/${noteId}`);
    return response.data;
  }
};
