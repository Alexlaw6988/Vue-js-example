declare module '@fortawesome/vue-fontawesome';
