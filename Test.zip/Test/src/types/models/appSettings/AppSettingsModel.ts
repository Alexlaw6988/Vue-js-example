import { PaginationOptionsModel } from '../pagination';
import { AppStartSettingsModel } from './AppStartSettingsModel';

export interface AppSettingsModel extends AppStartSettingsModel {
  showV4NavItems: boolean;
  externalSignaturePadEnabled: boolean;
  presentExportOptionWhenConvertingDocumentAfterSeconds: number;
  paginationOptions: PaginationOptionsModel;
}
