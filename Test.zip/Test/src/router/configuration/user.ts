import { RouteHelpers } from '@/mixins';
import { Configuration } from '@/types';
import ConfigurationTreeView from '@/components/configuration/TreeView.vue';

const UserManagement = () =>
  import(
    /* webpackChunkName: "UserManagement" */
    '@/views/configuration/user/UserManagement.vue'
  );

const ViewUser = () => import(/* webpackChunkName: "ViewUser" */ '@/views/configuration/user/ViewUser.vue');
const AddUser = () => import(/* webpackChunkName: "AddUser" */ '@/views/configuration/user/AddUser.vue');
const EditUser = () => import(/* webpackChunkName: "EditUser" */ '@/views/configuration/user/EditUser.vue');

const meta = {
  layout: 'TreeView',
  treePath: 'users'
};

const metaWithModel = {
  ...meta,
  model: 'user'
};

export const UserManagementRoutes = [
  {
    ...Configuration.User.Management,
    components: {
      default: UserManagement,
      treeView: ConfigurationTreeView
    },
    meta
  },
  {
    ...Configuration.User.Add,
    components: {
      default: AddUser,
      treeView: ConfigurationTreeView
    },
    meta
  },
  {
    ...Configuration.User.View,
    components: {
      default: ViewUser,
      treeView: ConfigurationTreeView
    },
    meta: metaWithModel,
    beforeEnter: (to: any, from: any, next: any) => {
      RouteHelpers.setErrorPageRedirect(Configuration.User.Management.name);
      RouteHelpers.beforeEnterCheckRouteParamAsNumeric(to, from, next, ['id']);
    }
  },
  {
    ...Configuration.User.Edit,
    components: {
      default: EditUser,
      treeView: ConfigurationTreeView
    },
    meta: metaWithModel,
    beforeEnter: (to: any, from: any, next: any) => {
      RouteHelpers.setErrorPageRedirect(Configuration.User.Management.name);
      RouteHelpers.beforeEnterCheckRouteParamAsNumeric(to, from, next, ['id']);
    }
  },
  {
    ...Configuration.User.Copy,
    props: {
      default: true
    },
    components: {
      default: AddUser,
      treeView: ConfigurationTreeView
    },
    meta
  }
];
