import { CabinetModel, TargetDocumentTypeSettingsModel } from '@/types';
import { SchemaModel } from '../dynamicForm';

export interface DocumentToStoreViewModel {
  cabinets: CabinetModel[];
  dynamicFormSchema: SchemaModel[];
  targetDocumentTypeSettings: TargetDocumentTypeSettingsModel;
}
