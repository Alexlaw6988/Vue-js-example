import { DocumentToStoreState, DocumentToStoreMutationTypes, DocumentToStoreViewModel } from '@/types';
import { MutationTree } from 'vuex';

export const mutations: MutationTree<DocumentToStoreState> = {
  [DocumentToStoreMutationTypes.SetDocumentToStoreView](state, payload: DocumentToStoreViewModel) {
    state.documentToStoreView = payload;
  }
};
