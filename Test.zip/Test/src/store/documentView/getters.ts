import {
  DocumentViewState,
  DocumentModel,
  RootState,
  BaseDocumentSearchModel,
  DocumentVersionModel,
  RelatedDocumentViewModel,
  DocumentPageModel,
  DocumentPageDataModel
} from '@/types';
import { GetterTree } from 'vuex';

export const getters: GetterTree<DocumentViewState, RootState> = {
  currentPage(state): number {
    return state.PageNumber;
  },
  document(state): DocumentModel {
    return state.DocumentModel;
  },
  versionBeingViewed(state): DocumentVersionModel {
    return state.VersionBeingViewed;
  },
  relatedDocumentBeingViewed(state): RelatedDocumentViewModel {
    return state.RelatedDocumentBeingViewed;
  },
  isPageLoading(state): boolean {
    return state.isPageLoading || !state.documentPage.documentData;
  },
  hasDocumentError(state): boolean {
    return state.hasDocumentError;
  },
  hasDocumentLoaded(state): boolean {
    return state.hasDocumentLoaded;
  },
  documentSearchModel(state): BaseDocumentSearchModel {
    return state.DocumentSearchModel;
  },
  documentPage(state): DocumentPageModel {
    return state.documentPage;
  },
  isDocumentPageLoaded: (state) => (documentPage: DocumentPageDataModel): boolean => {
    return (
      documentPage &&
      state.documentPage &&
      documentPage.documentId === state.documentPage.documentId &&
      documentPage.pageNumber === state.documentPage.pageNumber
    );
  },
  isDocumentPageCached: (state) => (documentPageData: DocumentPageDataModel) => {
    const index = state.documentPageCache.findIndex(
      (x: DocumentPageModel) =>
        x.documentId === documentPageData.documentId && x.pageNumber === documentPageData.pageNumber
    );
    return !(index === -1);
  },
  maximumPagesToCache(state): number {
    return state.maximumNumberOfPagesToCache;
  },
  showLoadingSpinner(state): boolean {
    return state.showLoadingSpinner;
  }
};
