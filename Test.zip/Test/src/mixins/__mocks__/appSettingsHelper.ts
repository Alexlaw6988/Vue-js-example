import { AppSettingsModel, PaginationOptionsModel } from '@/types';

export const AppSettingsHelper = {
  computed: {
    paginationOptions() {
      const paginationOptions = {
        minValue: 5,
        maxValue: 25,
        defaultValue: 25,
        incrementBy: 5
      } as PaginationOptionsModel;
      return paginationOptions;
    },
    appSettings() {
      const appSettings: AppSettingsModel = {
        baseUrl: '',
        authServerAuthority: '',
        sessionId: '',
        showV4NavItems: true,
        idleTimeout: 60,
        externalSignaturePadEnabled: false,
        maximumNumberOfPagesToCache: 15,
        presentExportOptionWhenConvertingDocumentAfterSeconds: 30,
        paginationOptions: {
          minValue: 5,
          maxValue: 25,
          defaultValue: 25,
          incrementBy: 5
        } as PaginationOptionsModel
      };
      return appSettings;
    }
  }
};
