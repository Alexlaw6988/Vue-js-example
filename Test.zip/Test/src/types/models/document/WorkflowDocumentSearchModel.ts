export interface WorkflowDocumentSearchModel {
  jobId: number;
  page: number;
}
