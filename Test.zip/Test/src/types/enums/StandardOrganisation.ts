export enum StandardOrganisation {
  InternalUsers = -1
}
