import axios from 'axios';
import { WorkflowQueueDataModel } from '@/types';

const WorkflowQueueApiUrl = 'workflowqueue/';

export const WorkflowQueueService = {
  async getWorkflowQueueAsync(id: number): Promise<WorkflowQueueDataModel> {
    const response = await axios.get(WorkflowQueueApiUrl.concat(id.toString()));
    return response.data;
  }
};
