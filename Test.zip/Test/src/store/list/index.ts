import { actions } from './actions';
import { getters } from './getters';
import { mutations } from './mutations';
import { ListState, ListModel } from '@/types';

export const state: ListState = {
  lists: [] as ListModel[],
  requestedListIds: [] as number[],
  isLoading: false,
  error: false,
  errorMessage: ''
};

const namespaced: boolean = true;

export const list = {
  namespaced,
  state,
  actions,
  getters,
  mutations
};
