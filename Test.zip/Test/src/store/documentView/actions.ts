import {
  DocumentViewState,
  DocumentModel,
  BaseDocumentSearchModel,
  RootState,
  DocumentVersionModel,
  DocumentSearchModel,
  RelatedDocumentViewModel,
  WorkflowDocumentSearchModel,
  DocumentPageModel,
  DocumentPageDataModel
} from '@/types';
import { ActionTree, Dispatch } from 'vuex';
import { DocumentService } from '@/services/DocumentService';
import { WorkflowJobService } from '@/services/WorkflowJobService';
import { DocumentViewUtils } from '@/utils/documentViewUtils';
import { mstoreSettings } from '@/settings/mstoreSettings';
import { Logger } from '@/classes/Logger';

export const actions: ActionTree<DocumentViewState, RootState> = {
  setDocumentSearchModel({ state, commit }, documentSearchModel: BaseDocumentSearchModel) {
    state.ViewConversionId = null;
    commit('DOCUMENT_SEARCH_MODEL', documentSearchModel);
  },
  setDocumentVersionBeingViewed({ state, commit }, version: DocumentVersionModel) {
    state.ViewConversionId = null;
    commit('DOCUMENT_VERSION_BEING_VIEWED', version);
  },
  setRelatedDocumentBeingViewed({ state, commit }, relatedDocument: RelatedDocumentViewModel) {
    state.ViewConversionId = null;
    commit('RELATED_DOCUMENT_BEING_VIEWED', relatedDocument);
    this.dispatch('documentViewStore/loadPage', 1);
  },
  loadPage({ state, commit, dispatch, rootGetters }, pageNumber: number) {
    connectToSignalRHub(state, rootGetters, dispatch).then(() => {
      commit('PAGE_NUMBER', pageNumber);
      commit('PAGE_LOADING');
      const documentSearchModel = getDocumentSearchModel(state);
      const documentPageData = {
        documentId: documentSearchModel.documentId,
        pageNumber,
        cabinetId: documentSearchModel.cabinetId
      } as DocumentPageDataModel;
      commit('LOAD_PAGE_FROM_CACHE', documentPageData);
      if (rootGetters['documentViewStore/isDocumentPageLoaded'](documentPageData)) {
        commit('PAGE_LOADED_FROM_CACHE');
        this.dispatch('documentViewStore/downloadPageNeighbours', documentPageData);
        return;
      }
      DocumentService.getDocumentAsync(
        documentSearchModel.cabinetId,
        documentSearchModel.documentId,
        pageNumber,
        state.ViewConversionId
      ).then(
        async (response: DocumentModel) => await handleGetDocumentResponse(response, commit, dispatch, pageNumber),
        (reason: any) => handleGetDocumentError(reason, commit)
      );
    });
  },
  loadPageWithJobId(
    { state, commit, dispatch, rootGetters },
    workflowDocumentSearchModel: WorkflowDocumentSearchModel
  ) {
    connectToSignalRHub(state, rootGetters, dispatch).then(() => {
      commit('PAGE_NUMBER', workflowDocumentSearchModel.page);
      commit('PAGE_LOADING');
      WorkflowJobService.getWorkflowDocumentAsync(
        workflowDocumentSearchModel.jobId,
        workflowDocumentSearchModel.page
      ).then(
        async (response: DocumentModel) =>
          await handleGetDocumentResponse(response, commit, dispatch, workflowDocumentSearchModel.page),
        (reason: any) => handleGetDocumentError(reason, commit)
      );
    });
  },
  setCurrentDocumentBeingViewed({ commit, dispatch }) {
    commit('DOCUMENT_VERSION_BEING_VIEWED', {} as DocumentVersionModel);
    commit('RELATED_DOCUMENT_BEING_VIEWED', {} as RelatedDocumentViewModel);
    dispatch('loadPage', 1);
  },
  unloadDocument({ commit }) {
    commit('UNLOAD_DOCUMENT');
    closeConnection = true;
    closeConnectionSR();
  },
  downloadPageNeighbours({ state, commit, rootGetters }, documentPageData: DocumentPageDataModel) {
    const maximumPagesToCache = rootGetters['documentViewStore/maximumPagesToCache'];
    if (maximumPagesToCache === 0) {
      return;
    }
    const pageNumbers = DocumentViewUtils.getNeighboringPageNumbers(
      state.DocumentModel.totalPages,
      documentPageData.pageNumber,
      2
    );
    for (const pageNumber of pageNumbers) {
      const isPageCached = rootGetters['documentViewStore/isDocumentPageCached']({
        pageNumber,
        documentId: documentPageData.documentId
      } as DocumentPageDataModel);
      if (!isPageCached) {
        commit('PAGE_DOWNLOADED', {
          pageNumber,
          documentData: '',
          documentId: documentPageData.documentId
        } as DocumentPageModel);
        DocumentService.getDocumentAsync(
          documentPageData.cabinetId,
          documentPageData.documentId,
          pageNumber,
          state.ViewConversionId
        ).then(async (response) => {
          const payload: DocumentModel = response;
          commit('PAGE_DOWNLOADED', {
            pageNumber,
            documentData: payload.documentData,
            documentId: documentPageData.documentId
          } as DocumentPageModel);
        });
      }
    }
  },
  showLoadingSpinner({ state, commit, rootGetters }, showLoadingSpinner: boolean) {
    commit('SHOW_LOADING_SPINNER', showLoadingSpinner);
  }
};

async function handleGetDocumentResponse(response: DocumentModel, commit: any, dispatch: Dispatch, pageNumber: number) {
  const payload: DocumentModel = response;
  const documentPageData = {
    documentId: payload.id,
    pageNumber,
    cabinetId: response.cabinetId
  } as DocumentPageDataModel;
  commit('DOCUMENT_LOADED', payload);
  if (payload.isBeingConverted) {
    await invokeConvertDocument(payload.viewConversionId);
  } else {
    commit('PAGE_LOADED', {
      pageNumber: documentPageData.pageNumber,
      documentData: payload.documentData
    } as DocumentPageModel);
    commit('PAGE_DOWNLOADED', {
      pageNumber: documentPageData.pageNumber,
      documentData: payload.documentData,
      documentId: documentPageData.documentId
    } as DocumentPageModel);
    dispatch('downloadPageNeighbours', documentPageData);
  }
}

function handleGetDocumentError(reason: any, commit: any) {
  commit('DOCUMENT_LOAD_FAILED', JSON.stringify(reason.response.data));
}

function getDocumentSearchModel(state: DocumentViewState) {
  if (state.VersionBeingViewed.documentId !== undefined) {
    return {
      documentId: state.VersionBeingViewed.documentId,
      cabinetId: state.VersionBeingViewed.cabinet.id
    } as DocumentSearchModel;
  }
  if (state.RelatedDocumentBeingViewed.documentSearchModel !== undefined) {
    return state.RelatedDocumentBeingViewed.documentSearchModel;
  }

  return state.DocumentSearchModel;
}

// tslint:disable-next-line: no-var-requires
const signalR = require('@aspnet/signalr');
let connection = null as any;
let closeConnection = false;

const ViewConversionHubMessageName = 'ViewConversion';
const ViewConversionSucceeededHubMessageName = 'ViewConversionSucceeded';
const ViewConversionFailedHubMessageName = 'ViewConversionFailed';
const ViewConversionTimedOutHubMessageName = 'ViewConversionTimedOut';

async function connectToSignalRHub(state: DocumentViewState, rootGetters: any, dispatch: Dispatch) {
  if (!connection) {
    closeConnection = false;
    buildSignalRConnection(rootGetters);
    await startSignalRConnection();
    await subscribeToViewConversionSucceeded(state, dispatch);
    await subscribeToViewConversionFailed(state);
    await subscribeToViewConversionTimedOut(state);
  }
}

function buildSignalRConnection(this: any, rootGetters: any) {
  connection = new signalR.HubConnectionBuilder()
    .withUrl(`${mstoreSettings.baseUrl}/signalrhubs/viewconversion`, {
      accessTokenFactory: () => rootGetters['oidcStore/oidcAccessToken']
    })
    .configureLogging(signalR.LogLevel.Information)
    .build();
}

async function startSignalRConnection() {
  try {
    await connection.start();
  } catch (error) {
    Logger.$log(error);
    setTimeout(() => startSignalRConnection(), 5000);
  }
}

async function reconnectOnClose() {
  await connection.onclose(async () => {
    if (!closeConnection) {
      await startSignalRConnection();
    }
  });
}

async function subscribeToViewConversionSucceeded(this: any, state: DocumentViewState, dispatch: Dispatch) {
  await connection.on(ViewConversionSucceeededHubMessageName, (data: any) => {
    state.ViewConversionId = data;
    dispatch('loadPage', 1);
  });
}

async function subscribeToViewConversionFailed(state: DocumentViewState) {
  await subscribeToFailureHubMessage(state, ViewConversionFailedHubMessageName, 'The document failed to be converted');
}

async function subscribeToViewConversionTimedOut(state: DocumentViewState) {
  await subscribeToFailureHubMessage(
    state,
    ViewConversionTimedOutHubMessageName,
    'The document failed to be converted because the time out period elapsed'
  );
}

async function subscribeToFailureHubMessage(
  state: DocumentViewState,
  hubMessageName: string,
  notificationMessage: string
) {
  await connection.on(hubMessageName, (data: any) => {
    state.ViewConversionId = null;
    state.DocumentModel.notification = notificationMessage;
    state.DocumentModel.hasNotification = true;
    state.DocumentModel.isBeingConverted = false;
    state.hasDocumentError = true;
  });
}

async function invokeConvertDocument(viewConversionId: number) {
  while (connection.state !== signalR.HubConnectionState.Connected) {
    if (closeConnection) {
      return;
    }
  }
  await connection.invoke(ViewConversionHubMessageName, viewConversionId);
}

function closeConnectionSR() {
  if (!connection) {
    return;
  }
  if (connection.state === signalR.HubConnectionState.Connected) {
    connection.off(ViewConversionSucceeededHubMessageName);
    connection.off(ViewConversionTimedOutHubMessageName);
    connection.off(ViewConversionFailedHubMessageName);
    connection.stop();
  }
  connection = null;
}
