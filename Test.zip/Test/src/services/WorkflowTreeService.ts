import axios from 'axios';
import { WorkflowTreeModel } from '@/types';

const WorkflowTreeViewApiUrl = 'workflowtree/';

export const WorkflowTreeService = {
  async getWorkflowTreeAsync(): Promise<WorkflowTreeModel[]> {
    const response = await axios.get(WorkflowTreeViewApiUrl);
    return response.data;
  }
};
