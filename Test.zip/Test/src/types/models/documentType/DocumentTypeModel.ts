import { CabinetReferenceModel } from '../documentReference';

export interface DocumentTypeModel {
  id: number;
  description: string;
  references: CabinetReferenceModel[];
}
