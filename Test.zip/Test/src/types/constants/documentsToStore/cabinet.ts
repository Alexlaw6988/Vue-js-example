export const Cabinet = {
  IncomingDocuments: 'I'
};