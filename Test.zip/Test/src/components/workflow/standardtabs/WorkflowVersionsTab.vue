<template>
  <div class="workflow-tab">
    <LoadingSpinner :isLoading="isLoading"></LoadingSpinner>
    <div v-show="!isLoading">
      <b-table
        head-variant="primary"
        bordered
        sticky-header="284px"
        small
        :items="documentVersions"
        :fields="fields"
        :tbody-tr-class="rowColor"
      >
        <template slot="cell(actions)" slot-scope="row">
          <div class="btn-group w-100">
            <button
              class="btn btn-primary btn-sm w-100"
              type="button"
              :disabled="isViewButtonDisabled(row.item)"
              @click="setDocumentVersion(row.item)"
            >
              <font-awesome-icon icon="file" class="mr-2" />
              View
            </button>
            <button
              type="button"
              class="btn btn-sm btn-outline-primary dropdown-toggle dropdown-toggle-split"
              data-toggle="dropdown"
              :disabled="!row.item.currentUserCanEdit"
            />
            <div class="dropdown-menu dropdown-menu-right py-1">
              <a v-if="row.item.currentUserCanEdit" class="dropdown-item" @click="makeCurrentVersion(row.item)">
                <font-awesome-icon icon="copy" class="mr-2 text-primary" />
                Make Current Version
              </a>
            </div>
          </div>
        </template>
      </b-table>
    </div>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  import { mapActions, mapGetters } from 'vuex';
  import LoadingSpinner from '@/components/shared/LoadingSpinner.vue';
  import { WorkflowJobModel, DocumentVersionModel, DocumentVersionType } from '@/types';
  import { DocumentVersionService } from '@/services/DocumentVersionService';
  import { BTableHelpers, ModalHelpers } from '@/mixins';
  import { OkCancelModalSettingsModel } from '@/types/models/modal';

  export default Vue.extend({
    name: 'WorkflowVersionsTab',
    mixins: [BTableHelpers, ModalHelpers],
    props: {
      workflowJobModel: {
        type: Object as () => WorkflowJobModel,
        required: true
      }
    },
    data() {
      return {
        isLoading: false,
        documentVersions: [] as DocumentVersionModel[],
        fields: [
          {
            number: {
              label: 'Version Number',
              sortable: true
            }
          },
          {
            type: {
              label: 'Version Type',
              sortable: true,
              formatter: (value: any) => {
                return DocumentVersionType[value];
              }
            }
          },
          {
            'documentType.description': {
              label: 'Document Type',
              sortable: true
            }
          },
          {
            'user.name': {
              label: 'User',
              sortable: true
            }
          },
          {
            date: {
              label: 'Created Date/Time',
              sortable: true,
              formatter: 'date'
            }
          },
          {
            details: {
              label: 'Details',
              sortable: true
            }
          },
          {
            key: 'actions',
            label: '',
            sortable: false
          }
        ]
      };
    },
    methods: {
      ...mapActions('documentViewStore', ['setDocumentVersionBeingViewed', 'loadPage', 'setDocumentSearchModel']),
      setDocumentVersion(this: any, version: DocumentVersionModel) {
        this.setDocumentVersionBeingViewed(version);
        this.loadPage(1);
      },
      async getDocumentVersions(this: any) {
        this.isLoading = true;
        this.documentVersions = await DocumentVersionService.getDocumentVersionsAsync(
          this.documentSearchModel.cabinetId,
          this.documentSearchModel.documentId
        ).catch((reason: any) => {
          this.isLoading = false;
        });
        this.isLoading = false;
      },
      async makeCurrentVersion(this: any, version: DocumentVersionModel) {
        const okModalSettings: OkCancelModalSettingsModel = {
          title: 'Are you sure?',
          message:
            'You are about to change the current version. The new document will be loaded when this has been completed.'
        };

        const confirmed = await this.showOkCancelModalAsync(this.$bvModal, okModalSettings);

        if (!confirmed) {
          return;
        }

        this.isLoading = true;

        const documentSearchModel = await DocumentVersionService.makeCurrentVersionAsync(
          version.currentVersionDocumentId,
          version.id
        );

        this.isLoading = false;

        this.setDocumentSearchModel(documentSearchModel);
        this.loadPage(1);

        await this.getDocumentVersions();
      },
      isViewButtonDisabled(row: DocumentVersionModel) {
        const currentlyViewedDocumentId: number = this.versionBeingViewed.documentId
          ? this.versionBeingViewed.documentId
          : this.documentSearchModel.documentId;

        return row.documentId === currentlyViewedDocumentId;
      },
      rowColor(row: DocumentVersionModel) {
        return row.documentId === row.currentVersionDocumentId ? 'table-success' : '';
      }
    },
    computed: {
      ...mapGetters('documentViewStore', ['documentSearchModel', 'versionBeingViewed'])
    },
    async mounted(this: any) {
      await this.getDocumentVersions();
    },
    components: {
      LoadingSpinner
    }
  });
</script>
