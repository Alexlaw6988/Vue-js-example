import { CabinetModel } from '@/types';
import { DocumentTypeModel } from '@/types';

export interface DocuSignTemplateAfterSignSettingUpdateModel {
  id: number;
  sourceDocumentType: DocumentTypeModel;
  targetCabinet: CabinetModel;
  targetDocumentType: DocumentTypeModel;
  indexAction: number;
  referenceMappings: object;
}
