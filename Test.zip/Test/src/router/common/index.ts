import { RouteHelpers } from '@/mixins';
import { Common } from '@/types';

const ErrorPage = () => import(/* webpackChunkName: "ErrorPage" */ '@/views/shared/ErrorPage.vue');
const AboutPage = () => import(/* webpackChunkName: "About" */ '@/views/About.vue');

export const CommonRoutes = [
  {
    ...Common.About,
    component: AboutPage
  },
  {
    ...Common.Error,
    component: ErrorPage,
    props: true,
    beforeEnter: RouteHelpers.beforeEnterCheckthePropsForErrorPage
  },
  {
    ...Common.PageNotFound,
    component: ErrorPage,
    props: {
      errorCode: 404,
      errorMessage: 'Page Not Found'
    }
  }
];
