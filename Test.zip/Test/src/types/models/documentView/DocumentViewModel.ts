import { DocumentModel, BaseDocumentSearchModel } from '@/types';
import { DocumentVersionModel } from '../documentVersion';
import { DocumentSearchModel } from '../document/DocumentSearchModel';

export interface DocumentViewModel {
  PageNumber: number;
  RelatedDocumentBeingViewed: DocumentSearchModel;
  VersionBeingViewed: DocumentVersionModel;
  DocumentModel: DocumentModel;
  DocumentSearchModel: BaseDocumentSearchModel;
  hasDocumentError: boolean;
  isPageLoading: boolean;
  hasDocumentLoaded: boolean;
}
