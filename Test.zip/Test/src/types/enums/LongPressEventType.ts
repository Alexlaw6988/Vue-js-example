export enum LongPressEventType {
  Press = 1,
  Click = 2,
  Release = 3
}
