import axios from 'axios';
import { LeaverCreateModel, LeaverModel } from '@/types';

const LeaverApiUrl = 'leaver/';

export const LeaversService = {
  async getAllAsync(): Promise<LeaverModel[]> {
    const response = await axios.get(LeaverApiUrl);
    return response.data;
  },
  async getAsync(id: number): Promise<LeaverModel> {
    const response = await axios.get(LeaverApiUrl + id);
    return response.data;
  },
  async createAsync(leaverCreateModel: LeaverCreateModel): Promise<number> {
    const response = await axios.post(LeaverApiUrl, leaverCreateModel);
    return response.data;
  }
};
