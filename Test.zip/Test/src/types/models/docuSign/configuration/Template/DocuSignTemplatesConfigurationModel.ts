import { DocuSignTemplateModel, DocumentTypeModel } from '@/types';

export interface DocuSignTemplatesConfigurationModel {
    documentTypeId: number | null;
    keyBusinessReferenceField: string;
    templates: DocuSignTemplateModel[];
    documentTypes: DocumentTypeModel[];
}