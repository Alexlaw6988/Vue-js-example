import {
  WorkflowKanbanJobState,
  RootState,
  SchemaModel,
  WorkflowKanbanJobMutationTypes,
  WorkflowKanbanPopupFieldsStatus,
  KanbanCardMoveModel
} from '@/types';
import { ActionTree } from 'vuex';

export const actions: ActionTree<WorkflowKanbanJobState, RootState> = {
  setPopupFieldsSchema({ commit }, schemaModels: SchemaModel[]) {
    commit(WorkflowKanbanJobMutationTypes.SetPopupFieldsSchema, schemaModels);
  },
  setCardMoveContext({ commit }, cardMoveContext: any) {
    commit(WorkflowKanbanJobMutationTypes.SetCardMoveContext, cardMoveContext);
  },
  setPopupFieldsStatus({ commit }, status: WorkflowKanbanPopupFieldsStatus) {
    commit(WorkflowKanbanJobMutationTypes.SetPopupFieldStatus, status);
  },
  setLastCardMove({ commit }, lastCardMove: KanbanCardMoveModel) {
    commit(WorkflowKanbanJobMutationTypes.SetLastCardMove, lastCardMove);
  },
  clearLastCardMove({ commit }) {
    commit(WorkflowKanbanJobMutationTypes.SetLastCardMove);
  }
};