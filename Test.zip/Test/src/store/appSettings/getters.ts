import { RootState, AppSettingsModel } from '@/types';
import { GetterTree } from 'vuex';

export const getters: GetterTree<any, RootState> = {
  appSettings(state): AppSettingsModel {
    return state.appSettings;
  }
};
