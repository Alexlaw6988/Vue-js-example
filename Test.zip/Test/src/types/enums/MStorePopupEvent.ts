export enum MStorePopupEvent {
  ShowModal = 'ShowModal',
  SetComponent = 'SetComponent',
  SetTitle = 'SetTitle'
}
