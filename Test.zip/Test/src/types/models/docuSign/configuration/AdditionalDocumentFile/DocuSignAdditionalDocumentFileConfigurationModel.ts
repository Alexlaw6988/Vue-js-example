import { DocuSignAdditionalDocumentFileModel } from '@/types';

export interface DocuSignAdditionalDocumentFileConfigurationModel {
  additionalDocumentFiles: DocuSignAdditionalDocumentFileModel[];
  fileUploadSizeLimitMb: number;
}
