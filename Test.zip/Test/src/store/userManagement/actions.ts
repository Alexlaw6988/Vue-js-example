import { UserManagementState, RootState } from '@/types';
import { ActionTree } from 'vuex';

export const actions: ActionTree<UserManagementState, RootState> = {
  resetUserManagementState({ commit }) {
    commit('RESET_USER_MANAGEMENT_STATE');
  },
  setUserManagementStateField({ commit }, userManagementStateField: any) {
    commit('SET_USER_MANAGEMENT_STATE_FIELD', userManagementStateField);
  }
};
