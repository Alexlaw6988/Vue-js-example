import Vue from 'vue';
import Router from 'vue-router';
import { vuexOidcCreateRouterMiddleware } from 'vuex-oidc';

import { WorkflowRoutes } from '@/router/workflow';
import { ConfigurationRoutes } from '@/router/configuration';
import { ToolsRoutes } from '@/router/tools';
import { OidcRoutes } from '@/router/oidc';
import { CommonRoutes } from '@/router/common';
import { DocumentsToStoreRoutes } from '@/router/documentsToStore';

import store from '@/store';
import { MStoreConstants, Workflow } from '@/types';

Vue.use(Router);

const router = new Router({
  mode: 'history',
  base: process.env.BASE_URL,
  routes: [
    {
      path: '/',
      name: 'DefaultRoute',
      redirect: Workflow.Base.name
    },
    ...WorkflowRoutes,
    ...ConfigurationRoutes,
    ...ToolsRoutes,
    ...OidcRoutes,
    ...CommonRoutes,
    ...DocumentsToStoreRoutes
  ]
});

router.beforeEach(vuexOidcCreateRouterMiddleware(store, 'oidcStore'));
router.beforeEach((to, from, next) => {
  const isApplicationDirty = store.getters['applicationDirtyStore/isApplicationDirty'];
  if (isApplicationDirty) {
    store.dispatch('applicationDirtyStore/setApplicationDirtyRouteNavigatedTo', to);
    store.dispatch('applicationDirtyStore/setShowApplicationDirtyModal', true);
  } else {
    next();
  }
});
router.beforeEach((to, from, next) => {
  store.dispatch('userStore/previousRoute', {
    name: from.name,
    params: from.params
  });
  next();
});
router.afterEach((to, from) => {
  store.dispatch('applicationDirtyStore/resetApplicationDirtyState');
  const isAppIdleOnAnotherTab = localStorage.getItem(MStoreConstants.LocalStorageKeys.IsApplicationDirty);
  if (isAppIdleOnAnotherTab?.toLowerCase() === 'true') {
    store.dispatch('applicationDirtyStore/setApplicationDirtyOnAnotherTab', true);
  }
});
export default router;
