import { DocuSignTemplateSignHereModel, DocuSignTemplateAdditionalDocumentModel } from '@/types';

export interface DocuSignTemplateModel {
    id: number;
    documentTypeId: number;
    keyBusinessReferenceField: string;
    template: string;
    templateSignHeres: DocuSignTemplateSignHereModel[];
    additionalDocuments: DocuSignTemplateAdditionalDocumentModel[];
}