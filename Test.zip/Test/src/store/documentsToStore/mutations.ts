import {
  DocumentsToStoreState,
  DocumentsToStoreMutationTypes,
} from '@/types';
import { MutationTree } from 'vuex';

export const mutations: MutationTree<DocumentsToStoreState> = {
  [DocumentsToStoreMutationTypes.SetShowNoDocumentNotification](state, payload: boolean) {
    state.showNoDocumentNotification = payload;
  },
};
