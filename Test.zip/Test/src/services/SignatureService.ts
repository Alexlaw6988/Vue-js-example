import axios from 'axios';
import { SignatureTemplateModel, BaseDocumentSearchModel, SignatureCreateModel } from '@/types';

const SignatureApiUrl = 'signature/';

export const SignatureService = {
  async getSignatureTemplateAsync(cabinetId: string, documentId: number): Promise<SignatureTemplateModel> {
    const response = await axios.get(SignatureApiUrl.concat(cabinetId, '/', documentId.toString()));
    return response.data;
  },
  async postSignatureAsync(
    cabinetId: string,
    documentId: number,
    signatureCreateModel: SignatureCreateModel
  ): Promise<BaseDocumentSearchModel> {
    const response = await axios.post(
      SignatureApiUrl.concat(cabinetId, '/', documentId.toString()),
      signatureCreateModel
    );
    return response.data;
  }
};
