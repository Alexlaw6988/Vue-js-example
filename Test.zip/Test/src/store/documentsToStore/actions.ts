
import { RootState } from '@/types';
import { DocumentsToStoreState, DocumentsToStoreMutationTypes } from '@/types';
import { ActionTree } from 'vuex';

export const actions: ActionTree<DocumentsToStoreState, RootState> = {

  setShowNoDocumentNotification(this: any, { commit }, payLoad: boolean) {
    commit(DocumentsToStoreMutationTypes.SetShowNoDocumentNotification, payLoad);
  }
};
