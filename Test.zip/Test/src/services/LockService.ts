import axios from 'axios';
import { LockModel } from '@/types';
import AxiosConfiguration from '@/classes/AxiosConfiguration';

const LockApiUrl = 'lock/';

export const LockService = {
  async extendLockAsync(id: number): Promise<LockModel> {
    const response = await AxiosConfiguration.axiosWithoutNotification.put(LockApiUrl + id);
    return response.data;
  },
  async releaseLockAsync(id: number) {
    await axios.delete(LockApiUrl.concat(id.toString()));
  }
};
