import { RootState } from '@/types';
import { DocumentToStoreState, DocumentToStoreMutationTypes } from '@/types';
import { ActionTree } from 'vuex';

export const actions: ActionTree<DocumentToStoreState, RootState> = {
  setDocumentToStoreView(this: any, { commit }, payLoad: boolean) {
    commit(DocumentToStoreMutationTypes.SetDocumentToStoreView, payLoad);
  }
};
