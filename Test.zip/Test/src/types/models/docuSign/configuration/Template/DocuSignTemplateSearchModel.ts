export interface DocuSignTemplateSearchModel {
    documentTypeId: number;
    templateId: number | null;
}