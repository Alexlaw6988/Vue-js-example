import IActionButtonHandler from '@/classes/interfaces/IActionButtonHandler';
import { FieldTooltipStateModel, TooltipActionButtonPropertiesModel } from '@/types/models';

export default class TooltipActioButtonHandler implements IActionButtonHandler {
  public getActionButtonState(
    this: any,
    actionButtonProperties: TooltipActionButtonPropertiesModel
  ): FieldTooltipStateModel {
    return {
      tooltip: actionButtonProperties.tooltip
    } as FieldTooltipStateModel;
  }

  public performButtonClick(actionButtonState: FieldTooltipStateModel): void {
    throw new Error('Method not implemented.');
  }
}
