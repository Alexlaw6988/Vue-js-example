import { DocumentModel, BaseDocumentSearchModel, DocumentActionsModel } from '@/types';

export const DocumentService = {
  getDocumentAsync(
    cabinetId: string,
    documentId: number,
    pageNumber: number,
    viewConversionId: number
  ): Promise<DocumentModel> {
    const documentModel = {
      cabinetId,
      id: documentId,
      totalPages: 100,
      documentData: 'Test'
    } as DocumentModel;

    return Promise.resolve(documentModel);
  },
  getDocumentActionsAsync(
    documentSearchModel: BaseDocumentSearchModel
  ): Promise<any> {
    const documentActionsModel = { Export: true } as DocumentActionsModel;
    return Promise.resolve(documentActionsModel);
  }
};
