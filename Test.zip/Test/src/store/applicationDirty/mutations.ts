import { MutationTree } from 'vuex';
import { ApplicationDirtyStateModel, ApplicationDirtyMutationTypes, MStoreConstants } from '@/types';
import { applicationDirty } from '../applicationDirty';
import { LocalStorage } from '@/utils';

export const mutations: MutationTree<ApplicationDirtyStateModel> = {
  [ApplicationDirtyMutationTypes.ResetApplicationDirtyState](state) {
    Object.assign(state, applicationDirty.defaultApplicationDirtyState());
  },
  [ApplicationDirtyMutationTypes.SetApplicationDirty](state, isDirty: boolean) {
    state.isDirty = isDirty;
    LocalStorage.emit(MStoreConstants.LocalStorageKeys.IsApplicationDirtyOnAnotherTab, isDirty);
    LocalStorage.set(MStoreConstants.LocalStorageKeys.IsApplicationDirty, isDirty);
  },
  [ApplicationDirtyMutationTypes.SetApplicationDirtyOnAnotherTab](state, isDirty: boolean) {
    state.isDirtyOnAnotherTab = isDirty;
    if (!isDirty && state.isDirty) {
      LocalStorage.emit(MStoreConstants.LocalStorageKeys.IsApplicationDirtyOnAnotherTab, true);
      LocalStorage.set(MStoreConstants.LocalStorageKeys.IsApplicationDirty, true);
    }
  },
  [ApplicationDirtyMutationTypes.SetShowApplicationDirtyModal](state, show: boolean) {
    state.showModal = show;
  },
  [ApplicationDirtyMutationTypes.SetApplicationDirtyRouteNavigateTo](state, to: any) {
    state.routeNavigatedTo = to;
  }
};
