import { WorkflowQueueState, TableStateModel, RootState, WorkflowQueueNextJobsModel } from '@/types';
import { workflowQueue } from '../workflowQueue';
import { GetterTree } from 'vuex';

export const getters: GetterTree<WorkflowQueueState, RootState> = {
  getTableStateField: (state) => (queueId: number, field: keyof TableStateModel): any => {
    if (state.queueId === queueId) {
      return state.tableState[field];
    }
    return workflowQueue.defaultWorkflowQueueState().tableState[field];
  },
  getNextJobsLists(state) {
    return {
      allJobsList: state.allJobsList,
      nextJobsList: state.nextJobsList
    } as WorkflowQueueNextJobsModel;
  },
  getLastSelectedWorkflowQueue(state) {
    return state.lastSelectedWorkflowQueue;
  }
};
