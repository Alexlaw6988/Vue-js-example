<template>
  <div>
    <div v-if="signersTab.hasNotification">
      <div class="alert alert-info fade show" role="alert">{{ signersTab.notification }}</div>
    </div>
    <div v-if="!signersTab.hasNotification">
      <div class="alert alert-info fade show" role="alert">
        Enter the name and email address for everyone who needs to sign the document
      </div>
      <LoadingSpinner :isLoading="isSignersTabLoading">
        <workflow-dynamic-form
          v-if="!isSignersTabLoading"
          storeNamespace="docuSignWorkflowJobStore"
          storeGetter="signersTabFieldValue"
          storeAction="setSignersTabFieldValue"
          v-bind:dynamic-form-model="signersTab.dynamicForm"
          :documentSearchModel="{}"
          class="w-100"
          :isLoading="isLoading"
        />
      </LoadingSpinner>
    </div>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  import { mapActions, mapGetters } from 'vuex';
  import { SignersTabModel, DynamicFormModel, WorkflowJobModel } from '@/types';
  import WorkflowDynamicForm from '@/components/workflow/WorkflowDynamicForm.vue';
  import LoadingSpinner from '@/components/shared/LoadingSpinner.vue';
  import { DocuSignWorkflowJob, ObjectHelper, TabsHelper } from '@/mixins';

  export default Vue.extend({
    name: 'DocuSignSignersTab',
    mixins: [DocuSignWorkflowJob, ObjectHelper, TabsHelper],
    props: {
      isLoading: {
        type: Boolean,
        default: false
      }
    },
    methods: {
      ...mapActions('docuSignWorkflowJobStore', ['getSignersTab']),
      getSignersTabData(this: any) {
        this.getSignersTab(this.workflowJob.jobId);
      }
    },
    computed: {
      ...mapGetters('workflowJobStore', ['workflowDataSourceField', 'workflowJob']),
      ...mapGetters('docuSignWorkflowJobStore', ['signersTab', 'isSignersTabLoading'])
    },
    watch: {
      isSignersTabLoading(this: any, value: boolean) {
        if (!value) {
          this.handleTabsLoaded();
        }
      }
    },
    mounted() {
      this.getSignersTabData();
    },
    components: {
      WorkflowDynamicForm,
      LoadingSpinner
    }
  });
</script>
