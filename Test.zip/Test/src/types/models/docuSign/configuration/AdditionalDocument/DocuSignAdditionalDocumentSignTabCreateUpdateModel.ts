export interface DocuSignAdditionalDocumentSignTabCreateUpdateModel {
  tabName: string;
  pageNumber: number;
  xCoord: number;
  yCoord: number;
}
