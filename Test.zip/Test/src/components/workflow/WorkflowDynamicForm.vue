<template>
  <m-form :id="dynamicFormModel.formId" :class="dynamicFormModel.formCssClass" :data-vv-scope="dynamicFormModel.formId">
    <validation-observer ref="validationObserver">
      <div
        :class="containerRow.containerRowCssClass"
        v-for="containerRow in dynamicFormModel.containerRows"
        :key="containerRow.containerRowId"
      >
        <div
          class="position-static"
          :class="containerColumn.containerColumnCssClass"
          v-for="containerColumn in containerRow.containerColumns"
          :key="containerColumn.containerColumnId"
        >
          <div
            :class="fieldRow.fieldRowCssClass"
            v-for="fieldRow in containerColumn.fieldRows"
            :key="fieldRow.fieldRowId"
          >
            <div
              class="position-static"
              :class="fieldColumn.fieldColumnCssClass"
              v-for="fieldColumn in fieldRow.fieldColumns"
              :key="fieldColumn.fieldColumnId"
            >
              <component
                v-for="(field, index) in fieldColumn.fields"
                :key="field.fieldId"
                :is="field.componentName"
                :documentSearchModel="documentSearchModel"
                v-bind:data="getDataField(field.properties.dataSourceKey, field.properties.fieldName)"
                v-on:update:data="setDataField(field.properties.dataSourceKey, field.properties.fieldName, $event)"
                v-on:update:field="onUpdateField($event)"
                v-bind:input-properties="field.properties"
                :ignoreIsRequired="ignoreRequiredFieldsValidation"
                :isDisabled="isLoading"
                :isLastElement="checkIsLastElement(index, fieldColumn.fields)"
              />
            </div>
          </div>
        </div>
      </div>
    </validation-observer>
  </m-form>
</template>

<script lang="ts">
  import Vue from 'vue';
  import WorkflowFormInput from '@/components/workflow/WorkflowFormInput.vue';
  import WorkflowTextArea from '@/components/workflow/WorkflowTextArea.vue';
  import WorkflowFormCheckbox from '@/components/workflow/WorkflowFormCheckbox.vue';
  import WorkflowFormDatePicker from '@/components/workflow/WorkflowFormDatePicker.vue';
  import WorkflowSignaturePad from '@/components/workflow/WorkflowSignaturePad.vue';
  import WorkflowFormSelect from '@/components/workflow/WorkflowFormSelect.vue';
  import WorkflowUnsupportedInput from '@/components/workflow/WorkflowUnsupportedInput.vue';
  import { BaseDocumentSearchModel, FieldUpdateModel, DynamicFormValidationModel } from '@/types';
  import { mapActions } from 'vuex';
  import { EventBus } from '@/classes/EventBus';

  export default Vue.extend({
    name: 'WorkflowDynamicForm',
    props: {
      storeNamespace: {
        type: String,
        required: true
      },
      storeGetter: {
        type: String,
        required: true
      },
      storeAction: {
        type: String,
        required: true
      },
      dynamicFormModel: {
        type: Object,
        required: true
      },
      documentSearchModel: {
        type: Object as () => BaseDocumentSearchModel,
        required: true
      },
      ignoreRequiredFieldsValidation: {
        type: Boolean,
        default: false
      },
      isLoading: {
        type: Boolean,
        default: false
      }
    },
    methods: {
      ...mapActions({
        _setDataField(dispatch, payload) {
          return dispatch(`${this.storeNamespace}/${this.storeAction}`, payload);
        }
      }),
      setDataField(this: any, dataSourceKey: string, fieldName: string, value: string) {
        const dataField = {
          dataSourceKey,
          fieldName,
          value
        } as FieldUpdateModel;
        this._setDataField(dataField);
      },
      onUpdateField(this: any, field: FieldUpdateModel) {
        this._setDataField(field);
      },
      getDataField(this: any, dataSourceKey: string, fieldName: string) {
        return this._getDataField(dataSourceKey, fieldName);
      },
      checkIsLastElement(this: any, index: any, controlList: any) {
        return controlList?.length > 2 && index === controlList?.length - 1;
      }
    },
    computed: {
      _getDataField(this: any): any {
        return this.$store.getters[`${this.storeNamespace}/${this.storeGetter}`];
      }
    },
    created(this: any) {
      EventBus.$on(`dynamic-form-submit-${this.dynamicFormModel.formId}`, () => {
        this.$refs.validationObserver.validate().then((valid: boolean) => {
          EventBus.$emit('dynamic-form-validated', {
            formId: this.dynamicFormModel.formId,
            valid,
            validated: true
          } as DynamicFormValidationModel);
        });
      });
    },
    beforeDestroy() {
      EventBus.$off(`dynamic-form-submit-${this.dynamicFormModel.formId}`);
    },
    components: {
      WorkflowFormInput,
      WorkflowTextArea,
      WorkflowFormCheckbox,
      WorkflowFormDatePicker,
      WorkflowSignaturePad,
      WorkflowFormSelect,
      WorkflowUnsupportedInput
    }
  });
</script>
