import axios, { AxiosInstance } from 'axios';
import Toast from '@/classes/SnotifyConfiguration';
import router from '@/router';

export default class AxiosConfiguration {
  public static axiosWithoutNotification: AxiosInstance = {} as AxiosInstance;
  public static axiosWithErrorPage: AxiosInstance = {} as AxiosInstance;

  public static configure() {
    this.configureDefaultInstance();
    this.configureWithoutNotificationInstance();
    this.configureErrorPageInstance();
  }

  private static axiosNotificationResponseInterceptor: any = null;
  private static axiosErrorPageResponseInterceptor: any = null;
  private static errorMessage = '';

  private static addNotificationInterceptor() {
    if (this.axiosNotificationResponseInterceptor) {
      return;
    }

    this.axiosNotificationResponseInterceptor = axios.interceptors.response.use(
      (response) => {
        if (response.data !== null && response.data.hasNotification && response.data.showToast) {
          Toast.showInformation(response.data.notification);
        }

        return response;
      },
      (error) => {
        if (this.handleErrorResponse(error)) {
          Toast.showError(this.errorMessage);
        }

        return Promise.reject(error);
      }
    );
  }

  private static addErrorPageInterceptor(this: any) {
    const vm = this;
    if (this.axiosErrorPageResponseInterceptor) {
      return;
    }

    this.axiosErrorPageResponseInterceptor = this.axiosWithErrorPage.interceptors.response.use(
      (response: any) => {
        return response;
      },
      (error: any) => {
        if (this.handleErrorResponse(error)) {
          router.push({
            name: 'errorPage',
            params: {
              errorCode: error.response.status,
              errorMessage: this.errorMessage
            }
          });
        }

        return Promise.reject(error);
      }
    );
  }

  private static configureDefaultInstance() {
    this.addAxiosDefaults(axios);
    this.addNotificationInterceptor();
  }

  private static configureWithoutNotificationInstance() {
    this.axiosWithoutNotification = axios.create();
    this.addAxiosDefaults(this.axiosWithoutNotification);
  }

  private static configureErrorPageInstance() {
    this.axiosWithErrorPage = axios.create();
    this.addAxiosDefaults(this.axiosWithErrorPage);
    this.addErrorPageInterceptor();
  }

  private static addAxiosDefaults(axiosInstance: AxiosInstance) {
    axiosInstance.defaults.headers.get.Pragma = 'no-cache';
    axiosInstance.defaults.baseURL = `${process.env.BASE_URL}api/`;
  }

  private static handleErrorResponse(error: any): boolean {
    this.errorMessage = 'Sorry an unknown error has occurred.';
    const handledHttpResponseCodes = [404, 401, 500];

    if (handledHttpResponseCodes.includes(error.response.status)) {
      this.errorMessage = error.response.data;
      return true;
    }

    if (error.response.status === 503) {
      window.location.href = '/';
    }
    return false;
  }
}
