import { JobTabStateModel, WorkflowJobButtonModel, WorkflowStandardProcessingAction } from '@/types';
import { SignersTabService } from '@/services/docuSign/SignersTabService';
import { DocuSignConstants } from '@/types';
import { EventBus } from '@/classes/EventBus';
import { mapActions, mapGetters } from 'vuex';

export const DocuSignWorkflowJob = {
  methods: {
    ...mapActions('workflowJobStore', ['setActiveHorizontalTab']),
    async processWorkflowJob(this: any) {
      this.isLoading = true;
      try {
        if (this.processingAction === WorkflowStandardProcessingAction.ProcessJob) {
          await this.saveSignersDataAsync();
        }
      } catch {
        this.isLoading = false;
        return;
      }
      await this.defaultProcessWorkflowJob();
    },
    validateWorkflowJobAsync(this: any, processButton: WorkflowJobButtonModel) {
      this.defaultValidateWorkflowJobAsync(processButton);
      this.$nextTick(() => {
        EventBus.$emit(`dynamic-form-submit-m-dfCustom-DocuSignSignersTab`);
      });
    },
    async saveSignersDataAsync(this: any) {
      const signersTabState = this.jobTabState(DocuSignConstants.CustomSignersTabKey) as JobTabStateModel;
      if (signersTabState) {
        await SignersTabService.updateSignersTabDataSourceAsync(
          this.workflowJob.jobId,
          this.signersTab.signersDataSource
        );
      }
    }
  },
  computed: {
    ...mapGetters('docuSignWorkflowJobStore', ['signersTab'])
  }
};
