import { ListState, RootState, ListModel } from '@/types';
import { GetterTree } from 'vuex';

export const getters: GetterTree<ListState, RootState> = {
  listById: (state) => (listId: number): ListModel | undefined => {
    return state.lists.find((x: ListModel) => x.id === listId);
  }
};
