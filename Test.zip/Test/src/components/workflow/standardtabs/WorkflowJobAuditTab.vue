<template>
  <div>
    <LoadingSpinner :isLoading="isLoading"></LoadingSpinner>
    <div v-show="!isLoading" class="container-fluid">
      <div class="row">
        <div class="col col-xl-3">
          <b-form-group>
            <m-store-filter v-model="searchQuery" placeholder="Start typing to search.." />
          </b-form-group>
        </div>
      </div>
      <b-table
        head-variant="primary"
        small
        sticky-header="230px"
        bordered
        :items="workflowJobAuditData.auditData"
        :fields="tableFilterFields(workflowJobAuditData.auditColumns)"
        :filter="searchQuery"
        :empty-text="emptytext"
        show-empty
        :filter-function="tableFilter"
      />
    </div>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  import { WorkflowJobService } from '@/services/WorkflowJobService';
  import { WorkflowJobAuditDataModel } from '@/types';
  import LoadingSpinner from '@/components/shared/LoadingSpinner.vue';
  import MStoreFilter from '@/components/shared/MStoreFilter.vue';
  import { WorkflowJobModel } from '@/types';
  import { BTableHelpers } from '@/mixins/bTable';

  export default Vue.extend({
    name: 'WorkflowJobAuditTab',
    mixins: [BTableHelpers],
    props: {
      workflowJobModel: {
        type: Object as () => WorkflowJobModel,
        required: true
      }
    },
    methods: {
      async getWorkflowJobAuditAsync(this: any, jobId: number) {
        this.isLoading = true;
        try {
          await WorkflowJobService.GetWorkflowJobAuditsAsync(jobId).then((result: WorkflowJobAuditDataModel) => {
            this.workflowJobAuditData = result;
            this.workflowJobAuditData.auditData = result.auditData.filter(
              (x: any) => String(x.oldValue).trim() !== String(x.newValue).trim()
            );
          });
          this.isLoading = false;
        } catch {
          this.isLoading = false;
        }
      }
    },
    data() {
      return {
        workflowJobAuditData: {} as WorkflowJobAuditDataModel,
        isLoading: false,
        searchQuery: '',
        emptytext: 'No Records to show'
      };
    },
    mounted() {
      this.getWorkflowJobAuditAsync(this.workflowJobModel.jobId);
    },
    components: {
      LoadingSpinner,
      MStoreFilter
    }
  });
</script>
