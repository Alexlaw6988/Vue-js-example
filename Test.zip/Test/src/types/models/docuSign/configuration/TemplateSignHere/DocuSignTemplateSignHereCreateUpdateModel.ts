export interface DocuSignTemplateSignHereCreateUpdateModel {
    templateId: number;
    signerRoleId: number;
    tabName: string;
    pageNumber: number;
    xCoord: number;
    yCoord: number;
}