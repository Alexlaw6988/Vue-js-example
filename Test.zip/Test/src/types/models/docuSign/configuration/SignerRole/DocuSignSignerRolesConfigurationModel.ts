import { BaseModel } from '../../../BaseModel';
import { DocumentTypeModel, DocuSignSignerRoleModel } from '@/types';

export interface DocuSignSignerRolesConfigurationModel extends BaseModel {
  documentTypeId: number | null;
  signerRoles: DocuSignSignerRoleModel[];
  documentTypes: DocumentTypeModel[];
}
