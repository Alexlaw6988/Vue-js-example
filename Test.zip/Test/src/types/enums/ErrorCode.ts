export enum ErrorCode {
  None = 0,
  UnsupportedFileType = 1,
  SqlTimeOutException = 2
}
