import { UserState, RootState } from '@/types';
import { GetterTree } from 'vuex';

export const getters: GetterTree<UserState, RootState> = {
  userState(state) {
    return state;
  },
  currentUser(state) {
    return state.currentUser;
  },
  postSignInIdleTime(state) {
    return state.postSignInIdleTime;
  },
  previousRoute(state) {
    return state.previousRoute;
  },
  errorPageRoute(state) {
    return state.errorPageRoute;
  },
  isUserAdministrator(state: any) {
    const roles = state.currentUser.profile.role;
    if (roles) {
      if (typeof roles === 'string') {
        return roles.toLowerCase() === 'administrator';
      } else {
        return roles.findIndex((x: any) => x.toLowerCase() === 'administrator') > -1 ? true : false;
      }
    }
    return false;
  }
};
