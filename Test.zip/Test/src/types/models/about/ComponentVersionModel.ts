export interface ComponentVersionModel {
  componentName: string;
  versionNumber: string;
  versionDate: string;
}
