export const SignaturePadHelpers = {
  data() {
    return {
      callback: null
    };
  },
  methods: {
    startSignaturePad(this: any, callback: any, height: number, width: number) {
      this.callback = callback;
      const message = {
        firstName: '',
        lastName: '',
        eMail: '',
        location: '',
        imageX: String(width),
        imageY: String(height),
        imageFormat: 2,
        imageTransparency: false,
        imageScaling: false,
        maxUpScalePercent: 0.0,
        rawDataFormat: 'ENC',
        minSigPoints: 1,
        penThickness: 3,
        penColor: '#000000'
      };
      let element;
      if (document.getElementsByTagName('SigCaptureWeb_ExtnDataElem')[0]) {
        element = document.getElementsByTagName('SigCaptureWeb_ExtnDataElem')[0];
      } else {
        document.addEventListener('SigCaptureWeb_SignResponse', this.initiateCallback, false);
        const messageData = JSON.stringify(message);
        element = document.createElement('SigCaptureWeb_ExtnDataElem');
        element.setAttribute('SigCaptureWeb_MsgAttribute', messageData);
        document.documentElement.appendChild(element);
      }
      const evt = document.createEvent('Events');
      evt.initEvent('SigCaptureWeb_SignStartEvent', true, false);
      element.dispatchEvent(evt);
    },
    initiateCallback(this: any, event: any) {
      const str = event.target.getAttribute('SigCaptureWeb_msgAttri');
      const obj = JSON.parse(str);
      this.callback(obj);
    }
  },
  beforeDestroy(this: any) {
    document.getElementsByTagName('SigCaptureWeb_ExtnDataElem')[0]?.remove();
    document.removeEventListener('SigCaptureWeb_SignResponse', this.initiateCallback, false);
  }
};
