export enum BuiltInUsers {
  Administrator = -1,
  ControllerUser = -5
}
