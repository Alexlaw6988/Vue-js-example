import { Configuration } from '@/types';
import ConfigurationTreeView from '@/components/configuration/TreeView.vue';

const DocusignEditDocumentTypes = () => import(/* webpackChunkName: "DocusignEditDocumentTypes" */
    '@/views/configuration/docusign/DocusignEditDocumentTypes.vue');

const meta = {
    layout: 'TreeView',
    treePath: 'docusigndocumenttypes'
};

export const DocumentTypeRoutes = [
    {
        ...Configuration.DocuSign.DocumentType.Management,
        components: {
            default: DocusignEditDocumentTypes,
            treeView: ConfigurationTreeView
        },
        meta
    }
];