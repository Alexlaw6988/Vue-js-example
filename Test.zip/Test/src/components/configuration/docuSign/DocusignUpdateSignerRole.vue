<template>
  <div v-if="!isLoading">
    <div>
      <b-alert variant="info" show dismissible>
        A Signer is a person that needs to sign documents or additional documents. Here we can configure options for
        pre-populating the signer's details.
      </b-alert>
    </div>

    <m-form @submit.prevent="onSubmit" v-slot="{ dirty }">
      <div class="row">
        <div class="col-10">
          <m-form-input
            id="description"
            type="text"
            v-model.trim="signerRole.description"
            :readonly="false"
            name="description"
            :state="validateInputState('description')"
            label="Signer Description"
            :validation="{ required: true, maxLength: 50 }"
          />
          <div>
            <b-form-checkbox
              class="float-left mt-2 ml-3 custom-switch"
              id="mustBeSameRecipientWithinEnvelope"
              name="mustBeSameRecipientWithinEnvelope"
              v-model="signerRole.mustBeSameRecipientWithinEnvelope"
              v-validate.disabled
            >
              <div class="mt-05">
                Enforce that this signer's name and email address is the same for all documents in an envelope.
              </div>
            </b-form-checkbox>
          </div>
        </div>
      </div>

      <div class="row mb-3">
        <div class="col">
          <div class="card min-h-100">
            <div class="card-header">
              Automatic pre-population of signer details
            </div>
            <div class="card-body">
              <div class="row">
                <div class="col">
                  <div>
                    <b-alert variant="info" show dismissible>
                      If the signer details are available in a workflow data-source, the name and email address can be
                      pre-populated.
                    </b-alert>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-6">
                  <div class="card min-h-100">
                    <div class="card-header">
                      Signer Name
                    </div>

                    <div class="card-body">
                      <div class="row">
                        <div class="col col-sm-8">
                          <b-form-group>
                            <b-form-checkbox
                              name="UseDataSourceForName"
                              v-model="signerRole.useDataSourceForName"
                              v-validate.disabled
                            >
                              Pre-populate name
                            </b-form-checkbox>
                          </b-form-group>
                        </div>
                      </div>

                      <div class="row">
                        <div class="col">
                          <b-form-group>
                            <m-form-select
                              id="nameDataSourceKey"
                              :selectOptionsData="signerRoleConfiguration.signerRoleDataSources"
                              v-model="signerRole.nameDataSourceKey"
                              v-validate.disabled
                              :disabled="!signerRole.useDataSourceForName"
                              displayFieldName="description"
                              valueFieldName="key"
                              fieldLabel="Data Source"
                            />
                          </b-form-group>
                        </div>
                      </div>

                      <div class="row">
                        <div class="col">
                          <b-form-group>
                            <m-form-select
                              id="nameDataFieldKey"
                              :selectOptionsData="selectedDataSourceFields(signerRole.nameDataSourceKey)"
                              v-model="signerRole.nameDataFieldKey"
                              v-validate.disabled
                              :disabled="!signerRole.useDataSourceForName"
                              displayFieldName="description"
                              valueFieldName="name"
                              fieldLabel="Data Field"
                            />
                          </b-form-group>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-6">
                  <div class="card min-h-100">
                    <div class="card-header">
                      Signer Email Address
                    </div>
                    <div class="card-body">
                      <div class="row">
                        <div class="col">
                          <b-form-group>
                            <b-form-checkbox
                              name="UseDataSourceForEmailAddress"
                              v-model="signerRole.useDataSourceForEmailAddress"
                              v-validate.disabled
                            >
                              Pre-populate email address
                            </b-form-checkbox>
                          </b-form-group>
                        </div>
                      </div>

                      <div class="row">
                        <div class="col">
                          <b-form-group>
                            <m-form-select
                              id="emailAddressDataSourceKey"
                              :selectOptionsData="signerRoleConfiguration.signerRoleDataSources"
                              v-model="signerRole.emailAddressDataSourceKey"
                              v-validate.disabled
                              :disable="!signerRole.useDataSourceForEmailAddress"
                              displayFieldName="description"
                              valueFieldName="key"
                              fieldLabel="Data Source"
                            />
                          </b-form-group>
                        </div>
                      </div>

                      <div class="row">
                        <div class="col">
                          <b-form-group>
                            <m-form-select
                              id="emailAddressDataFieldKey"
                              :selectOptionsData="selectedDataSourceFields(signerRole.emailAddressDataSourceKey)"
                              v-model="signerRole.emailAddressDataFieldKey"
                              v-validate.disabled
                              :disable="!signerRole.useDataSourceForEmailAddress"
                              displayFieldName="description"
                              valueFieldName="name"
                              fieldLabel="Data Field"
                            />
                          </b-form-group>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="row mb-3">
        <div class="col">
          <div class="card min-h-100">
            <div class="card-header">
              Manual selection of signer details from a list
            </div>

            <div class="card-body">
              <div class="row">
                <div class="col">
                  <div>
                    <b-alert variant="info" show dismissible>
                      Here you can also give the user the option to select the name and email address from a MAF list,
                      the selected list will need to be configured with fields call Name and Email. This can be used in
                      combination with pre-population.
                    </b-alert>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-6">
                  <b-form-group>
                    <b-form-checkbox
                      name="LookupList"
                      v-model="signerRole.useListForNameAndEmailAddress"
                      v-validate.disabled
                    >
                      Select signer details from a list
                    </b-form-checkbox>
                  </b-form-group>
                </div>
              </div>

              <div class="row">
                <div class="col-6 col-sm-8">
                  <b-form-group>
                    <m-form-select
                      id="listId"
                      :selectOptionsData="signerRoleConfiguration.signerRoleLists"
                      v-model="signerRole.listId"
                      v-validate.disabled
                      :disable="!signerRole.useListForNameAndEmailAddress"
                      displayFieldName="description"
                      valueFieldName="id"
                      fieldLabel="List"
                    />
                  </b-form-group>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <b-form-invalid-feedback id="formValidation-feedback" :force-show="true">
        {{ errors.first('validationErrors') }}
      </b-form-invalid-feedback>
      <b-form-group class="float-right">
        <b-button
          variant="danger"
          data-testid="cancel-additional-document-sign-tab-edit-button"
          class="mr-1"
          :disabled="submitIsLoading"
          @click="onCancel()"
        >
          Cancel
        </b-button>
        <b-button
          type="submit"
          data-testid="save-additional-document-sign-tab-edit-button"
          variant="primary"
          :disabled="submitIsLoading || (!isFormDirty() && !dirty)"
        >
          <b-spinner small class="mb-1 mr-1" v-if="submitIsLoading"></b-spinner>
          Save
        </b-button>
      </b-form-group>
    </m-form>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  import { FormFieldValidation, RouteHelpers, ObjectHelper } from '@/mixins';
  import {
    DocuSignSignerRoleConfigurationModel,
    DocuSignSignerRoleDataFieldModel,
    DocuSignSignerRoleDataSourceModel,
    DocuSignSignerRoleCreateUpdateModel
  } from '@/types';
  import MStoreFormSelect from '@/components/shared/MStoreFormSelect.vue';
  import LoadingSpinner from '@/components/shared/LoadingSpinner.vue';
  export default Vue.extend({
    name: 'ds-update-signer-role',
    mixins: [FormFieldValidation, RouteHelpers, ObjectHelper],
    props: {
      isLoading: {
        type: Boolean,
        required: true
      },
      submitIsLoading: {
        type: Boolean,
        required: true
      },
      signerRoleConfiguration: {
        type: Object as () => DocuSignSignerRoleConfigurationModel,
        required: true,
        default: {} as DocuSignSignerRoleConfigurationModel
      },
      signerRole: {
        type: Object as () => DocuSignSignerRoleCreateUpdateModel,
        required: true,
        default: {} as DocuSignSignerRoleCreateUpdateModel
      },
      serverValidationMessage: {
        type: String,
        required: true
      }
    },
    data() {
      return {
        hasError: false,
        errorMessage: ''
      };
    },
    methods: {
      async onSubmit(this: any) {
        this.resetFormValidation();
        try {
          const isValid = await this.$validator.validate();
          if (
            !isValid ||
            !this.validateNamePrePopulation() ||
            !this.validateEmailAddressPrePopulation() ||
            !this.validateNameAndEmailAddressList()
          ) {
            return;
          }
          this.$emit('submit', this.signerRole);
        } catch (error) {
          this.$log('Error updating signer role', error);
        } finally {
          this.submitIsLoading = false;
        }
      },

      async onCancel(this: any) {
        this.navigateToSignerRoleManagement();
      },
      navigateToSignerRoleManagement(this: any) {
        this.navigateToRoute('docusignSignerRoleManagement', this.documentTypeId);
      },
      selectedDataSourceFields(dataSourceKey: string): DocuSignSignerRoleDataFieldModel[] {
        if (
          !dataSourceKey ||
          !this.signerRoleConfiguration ||
          !this.signerRoleConfiguration.signerRoleDataSources ||
          !this.signerRole
        ) {
          return [] as DocuSignSignerRoleDataFieldModel[];
        }
        const selectedDataSource:
          | DocuSignSignerRoleDataSourceModel
          | undefined = this.signerRoleConfiguration.signerRoleDataSources.find((x) => x.key === dataSourceKey);
        if (!selectedDataSource) {
          return [] as DocuSignSignerRoleDataFieldModel[];
        }
        return selectedDataSource.fields;
      },
      validateNamePrePopulation(this: any): boolean {
        this.resetFormValidation();
        if (!this.signerRole.useDataSourceForName) {
          return true;
        }
        if (
          this.isNullOrEmpty(this.signerRole.nameDataSourceKey) ||
          this.isNullOrEmpty(this.signerRole.nameDataFieldKey)
        ) {
          this.addFormValidationError('Please select a data-source and data-field key for the name pre-population');
          return false;
        }
        return true;
      },
      validateEmailAddressPrePopulation(this: any): boolean {
        this.resetFormValidation();
        if (!this.signerRole.useDataSourceForEmailAddress) {
          return true;
        }
        if (
          this.isNullOrEmpty(this.signerRole.emailAddressDataSourceKey) ||
          this.isNullOrEmpty(this.signerRole.emailAddressDataFieldKey)
        ) {
          this.addFormValidationError(
            'Please select a data-source and data-field key for the email address pre-population'
          );
          return false;
        }
        return true;
      },
      validateNameAndEmailAddressList(this: any): boolean {
        this.resetFormValidation();
        if (!this.signerRole.useListForNameAndEmailAddress) {
          return true;
        }
        if (this.signerRole.listId == null) {
          this.addFormValidationError('Please select a MAF list for the name and email address');
          return false;
        }
        return true;
      }
    },
    computed: {
      nameDataFieldList(): DocuSignSignerRoleDataFieldModel[] {
        return this.signerRoleConfiguration.signerRoleDataSources[0].fields;
      },
      documentTypeId(): number {
        return Number(this.$route.params.documentTypeId);
      }
    },
    watch: {
      serverValidationMessage(this: any, value: string) {
        if (!this.isNullOrEmpty(value)) {
          this.addFormValidationError(value);
        }
      }
    },
    components: {
      'm-form-select': MStoreFormSelect,
      'loading-spinner': LoadingSpinner
    }
  });
</script>
