import axios from 'axios';
import { RoleModel, UserRoleModel, RoleUsersUpdateModel, RoleCopyModel } from '@/types';
import AxiosConfiguration from '@/classes/AxiosConfiguration';

const RoleApiUrl = 'roles';

export const RoleService = {
  async checkMaintenancePermissions(): Promise<any> {
    const response = await AxiosConfiguration.axiosWithErrorPage.get(`${RoleApiUrl}/CheckMaintenancePermissions`);
    return response.data;
  },
  async getRolesAsync(): Promise<RoleModel[]> {
    const response = await AxiosConfiguration.axiosWithErrorPage.get(RoleApiUrl);
    return response.data;
  },
  async getUsersAsync(id: number): Promise<UserRoleModel[]> {
    const response = await axios.get(`${RoleApiUrl}/${id}/Users`);
    return response.data;
  },
  async getRoleAsync(id: number): Promise<RoleModel> {
    const response = await AxiosConfiguration.axiosWithErrorPage.get(`${RoleApiUrl}/${id}`);
    return response.data;
  },
  async createRoleAsync(roleModel: RoleModel) {
    const response = await axios.post(RoleApiUrl, roleModel);
    return response.data;
  },
  async copyRoleAsync(roleCopyModel: RoleCopyModel) {
    const response = await axios.post(`${RoleApiUrl}/CopyRole`, roleCopyModel);
    return response.data;
  },
  async updateRoleAsync(id: number, roleModel: RoleModel) {
    const response = await axios.put(`${RoleApiUrl}/${id}`, roleModel);
    return response.data;
  },
  async deleteRoleAsync(id: number) {
    const response = await axios.delete(`${RoleApiUrl}/${id}`);
    return response.data;
  },
  async updateRoleUserssync(rolesUsersUpdateModel: RoleUsersUpdateModel): Promise<RoleModel> {
    const response = await axios.put(`${RoleApiUrl}/${rolesUsersUpdateModel.role.id}/Users`, rolesUsersUpdateModel);
    return response.data;
  }
};
