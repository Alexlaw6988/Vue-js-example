import { CabinetReferenceType } from '@/types/enums/CabinetReferenceType';
import { CabinetReferenceModel } from './CabinetReferenceModel';

export interface DocumentReferenceModel {
  Value: string;
  Type: CabinetReferenceType;
  ReferenceNumber: number;
  CabinetReferenceModel: CabinetReferenceModel;
}
