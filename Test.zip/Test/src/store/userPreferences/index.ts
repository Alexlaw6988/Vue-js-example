import { actions } from './actions';
import { getters } from './getters';
import { mutations } from './mutations';
import { UserPreferencesState, WorkflowJobPreference, WorkflowTreeView, Dictionary } from '@/types';
import { defaultMtableState } from '../mtable';

export function defaultverticalSider() {
  return { verticalTabWidth: 15, screenWidth: 0 };
}

export function defaultWorkflowJobPreference(
  queueId: any = 0,
  verticalSider: any = null,
  canGetNextJob: any = true,
  tableOptions: any = null
) {
  return {
    queueId,
    verticalSider: verticalSider || defaultverticalSider(),
    canGetNextJob: canGetNextJob || true,
    tableOptions: tableOptions || defaultMtableState()
  } as WorkflowJobPreference;
}

export function defaultUserPreferencesState() {
  return [
    {
      userId: 0,
      workflowJob: {
        workflowJobPreferences: [defaultWorkflowJobPreference()],
        SelectedWorkflowQueueID: 0
      },
      workflowTreeView: { verticalTabWidth: 20, screenWidth: 0 } as WorkflowTreeView,
      documentToStoreTargetDocumentTypes: {} as Dictionary<number>
    }
  ] as UserPreferencesState[];
}

const namespaced: boolean = true;

export const state: UserPreferencesState[] = [] as UserPreferencesState[];

export const userPreferences = {
  namespaced,
  state,
  actions,
  getters,
  mutations,
  defaultUserPreferencesState,
  defaultWorkflowJobPreference
};
