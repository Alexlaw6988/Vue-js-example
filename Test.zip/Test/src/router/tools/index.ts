import { RouteHelpers } from '@/mixins';
import { Tools } from '@/types';

const ToolsDashboard = () => import(/* webpackChunkName: "tools" */ '@/views/tools/ToolsDashboard.vue');
const ProcessLeaver = () =>
  import(
    /* webpackChunkName: "ProcessLeaver" */
    '@/views/tools/leaversTool/ProcessLeaver.vue'
  );
const LeaverHistoryLog = () =>
  import(
    /* webpackChunkName: "LeaverHistoryLog" */
    '@/views/tools/leaversTool/LeaverHistoryLog.vue'
  );
const ToolsTreeView = () => import(/* webpackChunkName: "tools-tree" */ '@/components/tools/TreeView.vue');
const ProcessLeaverHistory = () =>
  import(/* webpackChunkName: "ProcessLeaverHistory" */ '@/views/tools/leaversTool/ProcessLeaverHistory.vue');

const layout = 'TreeView';

export const ToolsRoutes = [
  {
    ...Tools.ProcessLeaver,
    components: {
      default: ProcessLeaver,
      treeView: ToolsTreeView
    },
    meta: {
      layout,
      treePath: 'processLeaver'
    }
  },
  {
    ...Tools.ProcessLeaverHistory,
    components: {
      default: ProcessLeaverHistory,
      treeView: ToolsTreeView
    },
    meta: {
      layout,
      treePath: 'processLeaverHistory'
    }
  },
  {
    ...Tools.LeaverHistoryLog,
    components: {
      default: LeaverHistoryLog,
      treeView: ToolsTreeView
    },
    props: {
      default: true
    },
    meta: {
      layout,
      treePath: 'leaverHistoryLog'
    },
    beforeEnter: (to: any, from: any, next: any) => {
      RouteHelpers.setErrorPageRedirect(Tools.LeaverHistoryLog.name);
      RouteHelpers.beforeEnterCheckRouteParamAsNumeric(to, from, next, ['leaverId']);
    }
  },
  {
    ...Tools.Base,
    components: {
      default: ToolsDashboard,
      treeView: ToolsTreeView
    },
    meta: {
      layout
    }
  }
];
