export const Oidc = {
  Callback: {
    path: '/oidc-callback',
    name: 'oidcCallback'
  },
  SilentRefresh: {
    path: '/silent-refresh-oidc',
    name: 'silent-refresh-oidc'
  },
  Error: {
    path: '/oidc-callback-error',
    name: 'oidcCallbackError'
  }
};
