declare module 'vue-debounce';
