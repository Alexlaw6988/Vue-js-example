export enum ReferenceValidationType {
  AnyValue = 1,
  Numeric = 2,
  Alphanumeric = 3,
  Date = 4
}
