import axios from 'axios';

import {
  DocuSignSettingsConfigurationModel,
  DocuSignSettingsSearchModel,
  DocuSignSettingsModel,
  DocuSignAdditionalDocumentFileCreateModel,
  BaseResultModel,
  DocuSignAdditionalDocumentFileConfigurationModel,
  DocuSignAdditionalDocumentFileUpdateModel,
  DocuSignAdditionalDocumentSignTabConfigurationModel,
  DocuSignAdditionalDocumentSignTabCreateUpdateModel,
  DocuSignAdditionalDocumentSignTabModel,
  DocuSignSignerRolesSearchModel,
  DocuSignSignerRoleSearchModel,
  DocuSignSignerRolesConfigurationModel,
  DocuSignSignerRoleConfigurationModel,
  DocuSignSignerRoleCreateUpdateModel,
  DocuSignTemplateAfterSignConfigurationModel,
  DocuSignTemplateAfterSignSettingModel,
  DocumentTypeModel,
  CabinetModel,
  DocuSignTemplateAfterSignSettingUpdateModel,
  DocuSignTemplatesSearchModel,
  DocuSignTemplatesConfigurationModel,
  DocuSignTemplateConfigurationModel,
  DocuSignTemplateSearchModel,
  DocuSignTemplateSignHereConfigurationModel,
  DocuSignTemplateAdditionalDocumentConfigurationModel,
  DocuSignDocumentTypeUpdateModel,
  DocuSignTemplateCreateUpdateModel,
  DocuSignTemplateSignHereCreateUpdateModel,
  DocuSignTemplateSignHereSearchModel,
  DocuSignTemplateAdditionalDocumentCreateUpdateModel,
  DocuSignTemplateAdditionalDocumentSearchModel,
  DocuSignTestResponseModel
} from '@/types';

import AxiosConfiguration from '@/classes/AxiosConfiguration';

const ConfigurationUrl = 'docusign/configuration/';

export const DocuSignConfigurationService = {
  async getSettingsConfigurationAsync(settingsSearchModel: DocuSignSettingsSearchModel):
    Promise<DocuSignSettingsConfigurationModel> {
    const response = await AxiosConfiguration.axiosWithErrorPage.get(`${ConfigurationUrl}settings`, {
      params: {
        documentTypeId: settingsSearchModel.documentTypeId
      }
    });
    return response.data;
  },
  async updateSettingsConfigurationAsync(documentTypeId: number, settings: DocuSignSettingsModel) {
    await axios.post(`${ConfigurationUrl}settings/${documentTypeId}`, settings);
  },
  async createAdditionalDocumentFileAsync(additionalDocumentFileCreateModel:
    DocuSignAdditionalDocumentFileCreateModel): Promise<BaseResultModel> {
    const formData = new FormData();
    formData.append('fileData', additionalDocumentFileCreateModel.fileData);
    formData.append('description', additionalDocumentFileCreateModel.description);
    const response = await axios({
      method: 'POST',
      url: `${ConfigurationUrl}additionalDocumentFiles`,
      data: formData,
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    });
    return response.data;
  },
  async getAdditionalDocumentFileAsync(id: number) {
    const response = await AxiosConfiguration.axiosWithErrorPage.
      get(`${ConfigurationUrl}additionalDocumentFiles/${id}`);
    return response.data;
  },
  async updateAdditionalDocumentFileAsync(
    additionalDocumentFileUpdateModel: DocuSignAdditionalDocumentFileUpdateModel): Promise<BaseResultModel> {
    const response =
      await axios.put(`${ConfigurationUrl}additionalDocumentFiles`, additionalDocumentFileUpdateModel);
    return response.data;
  },
  async deleteAdditionalDocumentFileAsync(id: number) {
    await axios.delete(`${ConfigurationUrl}additionalDocumentFiles/${id}`);
  },
  async getAdditionalDocumentFileConfigurationAsync(): Promise<DocuSignAdditionalDocumentFileConfigurationModel> {
    const response = await AxiosConfiguration.axiosWithErrorPage.get(`${ConfigurationUrl}additionalDocumentFiles`);
    return response.data;
  },
  async getAdditionalDocumentSignTabsAsync(
    additionalDocumentFileId: number): Promise<DocuSignAdditionalDocumentSignTabConfigurationModel> {
    const response = await AxiosConfiguration.axiosWithErrorPage.get(
      `${ConfigurationUrl}additionalDocumentFiles/${additionalDocumentFileId}/signtabs`
    );
    return response.data;
  },
  async getAdditionalDocumentSignTabAsync(
    additionalDocumentFileId: number, id: number): Promise<DocuSignAdditionalDocumentSignTabModel> {
    const response = await AxiosConfiguration.axiosWithErrorPage.get(
      `${ConfigurationUrl}additionalDocumentFiles/${additionalDocumentFileId}/signtabs/${id}`
    );
    return response.data;
  },
  async createAdditionalDocumentSignTabAsync(
    additionalDocumentFileId: number,
    additionalDocumentSignTabCreateModel: DocuSignAdditionalDocumentSignTabCreateUpdateModel
  ): Promise<BaseResultModel> {
    const response = await axios.post(
      `${ConfigurationUrl}additionalDocumentFiles/${additionalDocumentFileId}/signtabs`,
      additionalDocumentSignTabCreateModel
    );
    return response.data;
  },
  async updateAdditionalDocumentSignTabAsync(
    additionalDocumentFileId: number,
    id: number,
    additionalDocumentSignTabUpdateModel: DocuSignAdditionalDocumentSignTabCreateUpdateModel
  ): Promise<BaseResultModel> {
    const response = await axios.put(
      `${ConfigurationUrl}additionalDocumentFiles/${additionalDocumentFileId}/signtabs/${id}`,
      additionalDocumentSignTabUpdateModel
    );
    return response.data;
  },
  async deleteAdditionalDocumentsSignTabAsync(additionalDocumentFileId: number, id: number) {
    await axios.delete(`${ConfigurationUrl}additionalDocumentFiles/${additionalDocumentFileId}/signtabs/${id}`);
  },
  async getSignerRolesConfigurationAsync(
    docuSignSignerRolesSearchModel: DocuSignSignerRolesSearchModel
  ): Promise<DocuSignSignerRolesConfigurationModel> {
    const response = await AxiosConfiguration.axiosWithErrorPage.get(`${ConfigurationUrl}signerroles`, {
      params: {
        documentTypeId: docuSignSignerRolesSearchModel.documentTypeId
      }
    });
    return response.data;
  },
  async getSignerRoleConfigurationAsync(
    signerRoleSearchModel: DocuSignSignerRoleSearchModel): Promise<DocuSignSignerRoleConfigurationModel> {
    const response =
      await AxiosConfiguration.axiosWithErrorPage
        .get(`${ConfigurationUrl}${signerRoleSearchModel.documentTypeId}/signerRole`, {
          params: {
            documentTypeId: signerRoleSearchModel.documentTypeId,
            signerRoleId: signerRoleSearchModel.signerRoleId
          }
        });
    return response.data;
  },
  async updateSignerRoleAsync(
    documentTypeId: number,
    signerRoleId: number,
    docuSignSignerRoleUpdateModel: DocuSignSignerRoleCreateUpdateModel
  ): Promise<BaseResultModel> {
    const response =
      await axios.
        put(`${ConfigurationUrl}${documentTypeId}/signerRole/${signerRoleId}`, docuSignSignerRoleUpdateModel);
    return response.data;
  },
  async createSignerRoleAsync(
    documentTypeId: number,
    docuSignSignerRoleUpdateModel: DocuSignSignerRoleCreateUpdateModel): Promise<BaseResultModel> {
    const response =
      await axios.post(`${ConfigurationUrl}${documentTypeId}/signerRole`, docuSignSignerRoleUpdateModel);
    return response.data;
  },
  async deleteSignerRoleAsync(signerRoleId: number) {
    await axios.delete(`${ConfigurationUrl}signerRole/${signerRoleId}`);
  },
  async getTemplatesAfterSignConfigurationAsync(): Promise<DocuSignTemplateAfterSignSettingModel[]> {
    const response = await AxiosConfiguration.axiosWithErrorPage.get(`${ConfigurationUrl}templateAfterSignSetting`);
    return response.data;
  },
  async getTemplateAfterSignConfigurationAsync(id: number): Promise<DocuSignTemplateAfterSignConfigurationModel> {
    const response =
      await AxiosConfiguration.axiosWithErrorPage.get(`${ConfigurationUrl}templateAfterSignSetting/${id}`);
    return response.data;
  },
  async updateTemplateAfterSignSettingAsync(
    id: number,
    sourceDocumentType: DocumentTypeModel,
    targetCabinet: CabinetModel,
    targetDocumentType: DocumentTypeModel,
    indexAction: number,
    referenceMappings: object
  ): Promise<BaseResultModel> {
    const templateAfterSignSettingUpdateModel = {
      id,
      sourceDocumentType,
      targetCabinet,
      targetDocumentType,
      indexAction,
      referenceMappings
    } as DocuSignTemplateAfterSignSettingUpdateModel;
    const response =
      await axios.put(`${ConfigurationUrl}templateAfterSignSetting`, templateAfterSignSettingUpdateModel);
    return response.data;
  },
  async getTemplatesConfigurationAsync(
    docuSignTemplatesSearchModel: DocuSignTemplatesSearchModel): Promise<DocuSignTemplatesConfigurationModel> {
    const response = await AxiosConfiguration.axiosWithErrorPage
      .get(`${ConfigurationUrl}templates/configuration`,
        {
          params: {
            documentTypeId: docuSignTemplatesSearchModel.documentTypeId
          }
        }
      );
    return response.data;
  },
  async getTemplateConfigurationAsync(
    templateSearchModel: DocuSignTemplateSearchModel): Promise<DocuSignTemplateConfigurationModel> {

    const response = await AxiosConfiguration.axiosWithErrorPage
      .get(`${ConfigurationUrl}template/configuration`,
        {
          params: {
            documentTypeId: templateSearchModel.documentTypeId,
            templateId: templateSearchModel.templateId
          }
        }
      );
    return response.data;
  },
  async getTemplateSignHereConfiguration(
    docuSignTemplateSignHereSearchModel: DocuSignTemplateSignHereSearchModel
  ): Promise<DocuSignTemplateSignHereConfigurationModel> {
    const response = await AxiosConfiguration.axiosWithErrorPage
      .get(`${ConfigurationUrl}templateSignHere/configuration`,
        {
          params: {
            documentTypeId: docuSignTemplateSignHereSearchModel.documentTypeId,
            templateSignHereId: docuSignTemplateSignHereSearchModel.templateSignHereId
          }
        }
      );
    return response.data;

  },
  async getTemplateAdditionalDocumentConfiguration(
    templateAdditionalDocumentSearchModel: DocuSignTemplateAdditionalDocumentSearchModel
  ): Promise<DocuSignTemplateAdditionalDocumentConfigurationModel> {
    const response = await AxiosConfiguration.axiosWithErrorPage
      .get(`${ConfigurationUrl}templateAdditionalDocument/configuration`,
        {
          params: {
            documentTypeId: templateAdditionalDocumentSearchModel.documentTypeId,
            templateId: templateAdditionalDocumentSearchModel.templateId,
            templateAdditionalDocumentId: templateAdditionalDocumentSearchModel.templateAdditionalDocumentId
          }
        }
      );
    return response.data;
  },
  async updateDocumentTypeAsync(
    docuSignDocumentTypeUpdateModel: DocuSignDocumentTypeUpdateModel): Promise<BaseResultModel> {
    const response = await axios.put(
      `${ConfigurationUrl}documentType/${docuSignDocumentTypeUpdateModel.documentTypeId}`,
      docuSignDocumentTypeUpdateModel
    );
    return response.data;
  },
  async getPrivateKeyAsync(): Promise<string> {
    const response = await axios.get(`${ConfigurationUrl}privateKey`);
    return response.data;
  },
  async updatePrivateKeyAsync(privateKey: string): Promise<BaseResultModel> {
    const response = await axios.put(`${ConfigurationUrl}privateKey`, { privateKey });
    return response.data;
  },
  async sendTestDocuSignRequestAsync(): Promise<DocuSignTestResponseModel> {
    const response = await axios.get(`${ConfigurationUrl}testDocuSign`);
    return response.data;
  },
  async deleteTemplateAsync(templateId: number) {
    await axios.delete(`${ConfigurationUrl}template/${templateId}`);
  },
  async updateTemplateAsync(
    templateId: number,
    docuSignTemplateUpdateModel: DocuSignTemplateCreateUpdateModel
  ): Promise<BaseResultModel> {
    const response =
      await axios.
        put(`${ConfigurationUrl}template/${templateId}`, docuSignTemplateUpdateModel);
    return response.data;
  },
  async createTemplateAsync(
    docuSignTemplateUpdateModel: DocuSignTemplateCreateUpdateModel): Promise<BaseResultModel> {
    const response =
      await axios.post(`${ConfigurationUrl}template`, docuSignTemplateUpdateModel);
    return response.data;
  },
  async deleteTemplateSignHereAsync(id: number) {
    await axios.delete(`${ConfigurationUrl}templateSignHere/${id}`);
  },
  async updateTemplateSignHereAsync(
    templateSignHereId: number,
    docuSignTemplateSignHereUpdateModel: DocuSignTemplateSignHereCreateUpdateModel
  ): Promise<BaseResultModel> {
    const response =
      await axios.
        put(`${ConfigurationUrl}templateSignHere/${templateSignHereId}`, docuSignTemplateSignHereUpdateModel);
    return response.data;
  },
  async createTemplateSignHereAsync(
    docuSignTemplateSignHereUpdateModel: DocuSignTemplateSignHereCreateUpdateModel): Promise<BaseResultModel> {
    const response =
      await axios.post(`${ConfigurationUrl}templateSignHere`, docuSignTemplateSignHereUpdateModel);
    return response.data;
  },
  async updateTemplateAdditionalDocumentAsync(
    templateAdditionalDocumentId: number,
    templateAdditionalDocument: DocuSignTemplateAdditionalDocumentCreateUpdateModel): Promise<BaseResultModel> {
    const response =
      await axios.put(`${ConfigurationUrl}templateAdditionalDocument/${templateAdditionalDocumentId}`,
        templateAdditionalDocument);
    return response.data;
  },
  async createTemplateAdditionalDocumentAsync(
    templateAdditionalDocument: DocuSignTemplateAdditionalDocumentCreateUpdateModel): Promise<BaseResultModel> {
    const response =
      await axios.post(`${ConfigurationUrl}templateAdditionalDocument`, templateAdditionalDocument);
    return response.data;
  },
  async deleteTemplateAdditionalDocumenAsync(id: number) {
    await axios.delete(`${ConfigurationUrl}templateAdditionalDocument/${id}`);
  },
  async getFileTypeWhitelistAsync() {
    const response = await axios.get(`${ConfigurationUrl}getDocuSignFileTypeWhiteList`);
    return response.data;
  },
};
