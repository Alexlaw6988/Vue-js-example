<template>
  <div class="workflow-tab">
    <LoadingSpinner :isLoading="isLoading"></LoadingSpinner>
    <div v-if="!isLoading && relatedDocumentsModel.count > 0">
      <div v-for="relatedDocument in relatedDocumentsToDisplay" :key="relatedDocument.linkId" class="mb-2">
        <div class="card">
          <div class="card-body p-0 m-2">
            <font-awesome-icon icon="paperclip" size="lg" class="float-right" />
            <font-awesome-icon
              size="lg"
              :icon="getPanelIcon(relatedDocument.visible)"
              @click="relatedDocument.visible = !relatedDocument.visible"
              :v-b-toggle="`collapse-${relatedDocument.linkId}`"
              class="mr-2 pointer"
            />
            <b>
              {{ getDocumentTypeFromId(relatedDocument.targetDocumentTypeId).description }}
              {{ relatedDocument.criteria }} -
              {{ getCountText(relatedDocument) }}
            </b>
          </div>
          <b-collapse
            :id="`collapse-${relatedDocument.linkId}`"
            accordion
            v-model="relatedDocument.visible"
            @shown="collapseShown(relatedDocument.linkId)"
            @show="collapseShow"
          >
            <b-table
              small
              class="mb-0"
              head-variant="light"
              bordered
              :sort-compare="sortDocumentDate"
              :items="relatedDocument.data"
              :fields="getColumns(relatedDocument.columnIds)"
              :sort-by.sync="sortBy"
              :sort-desc.sync="sortDesc"
              :tbody-tr-class="selectedRowClass"
              :id="`relatedDocument-${relatedDocument.linkId}`"
              primary-key="cb_docid"
            >
              <template slot="cell(actions)" slot-scope="row">
                <b-button
                  v-if="relatedDocumentIsBeingViewed(row.item)"
                  class="w-100"
                  variant="info"
                  size="sm"
                  @click="getOriginalDocument()"
                  :disabled="isDocumentLoadingOrBeingConverted"
                >
                  <font-awesome-icon icon="file" class="mr-2" />
                  View Original
                </b-button>
                <b-button
                  v-else
                  class="w-100"
                  variant="primary"
                  size="sm"
                  @click="getRelatedDocument(row, relatedDocument.linkId)"
                  :disabled="isDocumentLoadingOrBeingConverted"
                >
                  <font-awesome-icon icon="file" class="mr-2" />
                  View
                </b-button>
              </template>
            </b-table>
          </b-collapse>
        </div>
      </div>
    </div>
    <div v-else-if="!isLoading" class="text-center text-dark mt-5">
      <font-awesome-icon icon="search" size="5x" class="mb-4" />
      <h5>Sorry, there are no matching related documents.</h5>
    </div>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  import { mapActions, mapGetters } from 'vuex';
  import LoadingSpinner from '@/components/shared/LoadingSpinner.vue';
  import {
    RelatedDocumentModel,
    BaseColumnsModel,
    RelatedDocumentViewModel,
    BaseDocumentSearchModel,
    DocumentTypeModel,
    DocumentDataModel,
    TabStateModel
  } from '@/types';
  import { BTableHelpers, TabsHelper } from '@/mixins';
  import store from '@/store';

  export default Vue.extend({
    name: 'WorkflowRelatedDocumentsTab',
    mixins: [BTableHelpers, TabsHelper],
    data() {
      return {
        sortBy: 'cb_docdate',
        sortDesc: true,
        collapseLoading: true,
        documentLinkId: 0
      };
    },
    methods: {
      ...mapActions('documentViewStore', ['loadPage', 'setDocumentSearchModel', 'setRelatedDocumentBeingViewed']),
      ...mapActions('relatedDocumentsStore', ['getRelatedDocuments', 'unloadRelatedDocuments']),
      getPanelIcon(visible: boolean): string {
        return visible ? 'chevron-down' : 'chevron-right';
      },
      getOriginalDocument(this: any) {
        this.setRelatedDocumentBeingViewed({} as RelatedDocumentViewModel);
      },
      getRelatedDocument(this: any, row: any, linkId: number) {
        this.setRelatedDocumentBeingViewed({
          linkId,
          documentSearchModel: {
            cabinetId: row.item.cabinetid,
            documentId: row.item.cb_docid,
            documentTypeId: row.item.cb_dtid
          } as BaseDocumentSearchModel,
          documentType: this.getDocumentType(linkId, row.item.cabinetid, row.item.cb_docid) as DocumentTypeModel
        } as RelatedDocumentViewModel);
      },
      getCountText(relatedDocument: RelatedDocumentModel) {
        return relatedDocument.documentCount === 1
          ? `${relatedDocument.documentCount} Document`
          : `${relatedDocument.documentCount} Documents`;
      },
      relatedDocumentIsBeingViewed(this: any, item: any): boolean {
        return (
          this.relatedDocumentBeingViewed.documentSearchModel &&
          this.relatedDocumentBeingViewed.documentSearchModel.documentId === item.cb_docid &&
          this.relatedDocumentBeingViewed.documentSearchModel.cabinetId.toString() === item.cabinetid.toString()
        );
      },
      getDocumentType(this: any, linkId: number, cabinetId: string, documentId: number): DocumentTypeModel | undefined {
        const relatedDocument = this.getRelatedDocumentByLinkId(linkId) as RelatedDocumentModel;

        const document = relatedDocument.documents.find(
          (x: DocumentDataModel) => x.id === documentId && x.cabinet.id === cabinetId.toString()
        ) as DocumentDataModel;

        return document.documentType;
      },
      sortDocumentDate(
        aRow: any,
        bRow: any,
        key: any,
        sortDesc: any,
        formatter: any,
        compareOptions: any,
        compareLocale: any
      ) {
        if (key !== 'cb_docdate') {
          return null;
        }
        const documentDateDiff = new Date(aRow?.cb_docdate).getTime() - new Date(bRow?.cb_docdate).getTime();

        return documentDateDiff || aRow?.cb_docid - bRow?.cb_docid;
      },
      selectedRowClass(item: any, type: any) {
        if (!item || type !== 'row') {
          return;
        }

        if (this.relatedDocumentIsBeingViewed(item)) {
          return 'table-success';
        }
      },
      collapseShown(relatedDocumentLinkId: any) {
        this.collapseLoading = false;
        this.documentLinkId = relatedDocumentLinkId;
      },
      collapseShow(this: any) {
        this.collapseLoading = true;
      },
      scrollToDocumentBeingViewed(this: any) {
        const relatedDocumentViewModel: RelatedDocumentViewModel = this.relatedDocumentBeingViewed;

        if (relatedDocumentViewModel && relatedDocumentViewModel.documentSearchModel) {
          const documentId = relatedDocumentViewModel.documentSearchModel.documentId;
          const element = this.$el.querySelector(
            `#relatedDocument-${relatedDocumentViewModel.linkId}__row_${documentId}`
          ) as HTMLElement;
          if (element) {
            this.$nextTick(() => element.scrollIntoView(false));
          }
        }
      },
      getColumns(columnIds: number[]) {
        const columns: BaseColumnsModel[] = [];
        columnIds.forEach((id) => {
          columns.push(this.relatedDocumentsModel.columns[id]);
        });
        return columns;
      },
      getDocumentTypeFromId(targetDocumentTypeId: number) {
        return this.relatedDocumentsModel.documentTypes[targetDocumentTypeId];
      }
    },
    computed: {
      ...mapGetters('documentViewStore', ['documentSearchModel', 'relatedDocumentBeingViewed']),
      ...mapGetters('relatedDocumentsStore', [
        'isLoading',
        'relatedDocumentsModel',
        'getRelatedDocumentByLinkId',
        'totalDocumentsCount'
      ]),
      relatedDocumentsToDisplay(this: any): RelatedDocumentModel[] {
        return this.relatedDocumentsModel.relatedDocuments
          .filter((x: RelatedDocumentModel) => x.documentCount > 0)
          .sort((x: RelatedDocumentModel) => this.getDocumentTypeFromId(x.targetDocumentTypeId));
      },
      readyToScroll(this: any) {
        const flag = this.collapseLoading;
        return this.relatedDocumentBeingViewed;
      },
      isDocumentLoadingOrBeingConverted(this: any) {
        return (
          store.getters['documentViewStore/document'].isBeingConverted ||
          store.getters['documentViewStore/isPageLoading']
        );
      }
    },
    watch: {
      totalDocumentsCount(this: any, value: number) {
        this.$emit('tabItemCountChanged', {
          key: 'RelatedDocuments',
          itemCount: value
        } as TabStateModel);
      },
      readyToScroll(newDocumentValue, oldDocumentValue) {
        if (this.documentLinkId === newDocumentValue.linkId && !this.collapseLoading) {
          this.scrollToDocumentBeingViewed();
        }
      },
      relatedDocumentsModel(this: any, value: number) {
        this.handleTabsLoaded();
      }
    },
    async mounted(this: any) {
      await this.getRelatedDocuments(this.documentSearchModel);
    },
    components: {
      LoadingSpinner
    },
    beforeDestroy(this: any) {
      this.unloadRelatedDocuments();
    }
  });
</script>
