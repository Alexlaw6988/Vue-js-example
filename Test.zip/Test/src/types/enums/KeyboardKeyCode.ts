export enum KeyboardKeyCode {
  'Esc' = 27,
  'Up' = 38,
  'Down' = 40,
  'Enter' = 13,
  'Backspace' = 8,
  'Tab' = 9
}
