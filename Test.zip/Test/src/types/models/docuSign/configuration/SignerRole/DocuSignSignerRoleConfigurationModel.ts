import { DocuSignSignerRoleModel, DocuSignSignerRoleDataSourceModel, DocuSignSignerRoleListModel } from '@/types';

export interface DocuSignSignerRoleConfigurationModel {
  signerRole: DocuSignSignerRoleModel;
  signerRoleDataSources: DocuSignSignerRoleDataSourceModel[];
  signerRoleLists: DocuSignSignerRoleListModel[];
}
