import { actions } from './actions';
import { getters } from './getters';
import { mutations } from './mutations';
import { GroupedTableStateModel } from '@/types';

export function defaultMGroupedTableState() {
  return {
    lastExpandedGroups: {}
  } as GroupedTableStateModel;
}

export const state: GroupedTableStateModel = defaultMGroupedTableState();

const namespaced: boolean = true;

export const mGroupedTable = {
  namespaced,
  state,
  actions,
  getters,
  mutations
};
