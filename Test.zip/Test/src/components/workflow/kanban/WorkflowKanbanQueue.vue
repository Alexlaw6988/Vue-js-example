<template>
  <div class="card w-100 h-100 workflowKanbanQueue">
    <Header
      :is-loading="isLoading"
      :show-hide-filters="true"
      :emit-filters="true"
      :show-filters="tableStateField('showFilters')"
      :show-items-per-page="false"
      :search-query="tableStateField('searchQuery')"
      :header-text="workflowQueueDataModel.queueName"
      :allow-wallboard-mode="workflowQueueDataModel.allowWallboardMode"
      :wallboard-refresh-interval-in-seconds="workflowQueueDataModel.wallboardRefreshIntervalInSeconds"
      :is-wallboard-mode.sync="isWallboardMode"
      @update:show-filters="onTableStateFieldUpdated('showFilters', $event)"
      @update:search-query="onTableStateFieldUpdated('searchQuery', $event)"
      @refresh-triggered="getWorkflowQueue()"
    >
      <template v-for="(value, slot) in $slots">
        <template :slot="slot">
          <slot :name="slot" />
        </template>
      </template>
    </Header>
    <div v-if="cardProcessing" class="loading-overlay">
      <loading-spinner :isLoading="true" textColourVariant="white" />
    </div>
    <MStoreKanbanLanes :data-source="laneData" :is-readonly="isWallboardMode" @cardDragEvent="onCardMoved">
      <template #dd-card="{ cardData }">
        <component
          :is="kanbanCardComponent"
          :cardDetails="cardData"
          @click.native="getWorkflowJob(cardData)"
          class="clickable"
        />
      </template>
    </MStoreKanbanLanes>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  import { mapGetters, mapActions } from 'vuex';
  import Header from '@/components/shared/Table/Header.vue';
  import MStoreDefaultKanbanCard from '@/components/kanban/MStoreDefaultKanbanCard.vue';
  import MStoreKanbanLanes from '@/components/kanban/MStoreKanbanLanes.vue';
  import LoadingSpinner from '@/components/shared/LoadingSpinner.vue';
  import { CardDragEventModel, KanbanCardOrderUpdateModel, KanbanLaneModel } from '@/types/models/kanban';
  import {
    WorkflowKanbanJobProcessResultStatus,
    WorkflowQueueDataModel,
    WorkflowKanbanPopupFieldsStatus,
    LockModel,
    RouteRegEx
  } from '@/types';
  import { WorkflowKanbanService } from '@/services';
  import { LockService } from '@/services/LockService';
  import SnotifyConfiguration from '@/classes/SnotifyConfiguration';
  import { WorkflowKanbanPopupFieldsHelper, RouteHelpers } from '@/mixins';
  import { ObjectUtils } from '@/utils/objectUtils';

  export default Vue.extend({
    name: 'WorkflowKanbanQueue',
    mixins: [WorkflowKanbanPopupFieldsHelper, RouteHelpers],
    props: {
      workflowQueueDataModel: {
        type: Object as () => WorkflowQueueDataModel,
        required: true
      },
      isLoading: {
        type: Boolean,
        required: true
      }
    },
    data() {
      return {
        kanbanCardComponent: 'MStoreDefaultKanbanCard',
        cardProcessing: false,
        isWallboardMode: false
      };
    },
    computed: {
      ...mapGetters('workflowQueueStore', ['getTableStateField']),
      ...mapGetters('workflowKanbanJobStore', ['getPopupFieldsStatus', 'getLock', 'getLastCardMove']),
      tableStateField(this: any) {
        return (field: string) => this.getTableStateField(this.workflowQueueDataModel.queueId, field);
      },
      searchQuery(this: any) {
        return this.tableStateField('searchQuery');
      },
      laneData(this: any) {
        if (!this.searchQuery) {
          return this.queueData;
        }
        const lanes = ObjectUtils.deepCloneObject(this.queueData);
        lanes.forEach((lane: any) => {
          lane.cards = lane.cards.filter((card: any) => {
            return card.fields.some((field: any) => {
              return field?.fieldValue
                ?.toString()
                ?.toLowerCase()
                .contains(this.searchQuery.toLowerCase());
            });
          });
        });
        return lanes;
      },
      queueData(this: any) {
        const queue = this.workflowQueueDataModel?.additionalConfigurations;
        this.kanbanCardComponent = queue?.cardComponent;
        const laneData = queue?.lanes?.map((lane: any) => {
          const cards = queue.cards.filter((card: any) => card.laneName === lane.laneName);
          return {
            laneName: lane.laneName,
            style: lane.style,
            saveCardOrder: lane.saveCardOrder,
            cards: cards.map((card: any) => {
              return {
                cardStyle: card.cardStyle,
                fields: card.fields,
                cardId: card.cardId,
                icons: card.icons,
                laneName: lane.laneName,
                readTime: card.readTime
              };
            })
          } as KanbanLaneModel;
        });
        return laneData;
      }
    },
    methods: {
      ...mapActions('workflowQueueStore', ['setTableStateField', 'resetWorkflowQueueState']),
      ...mapActions('workflowKanbanJobStore', [
        'setPopupFieldsSchema',
        'setCardMoveContext',
        'setLastCardMove',
        'clearLastCardMove'
      ]),
      onTableStateFieldUpdated(this: any, field: string, value: any) {
        this.setTableStateField({
          queueId: this.workflowQueueDataModel.queueId,
          field,
          value
        });
      },
      getWorkflowQueue() {
        this.$emit('get-workflow-queue', this.workflowQueueDataModel.queueId);
      },
      getWorkflowJob(item: any) {
        this.$emit('get-workflow-job', item.cardId);
      },
      initialise(this: any) {
        const canKeepState = this.canKeepState(RouteRegEx.WorkflowQueue);
        if (!canKeepState) {
          this.resetWorkflowQueueState(this.workflowQueueDataModel.queueId);
        }
      },
      async onCardMoved(this: any, event: CardDragEventModel) {
        const cardId: number = event.card.cardId;
        const toLane = event.toLaneName;
        const fromLane = event.fromLaneName;
        const toCardIndex = event.toLaneCardIndex;
        const fromCardIndex = event.fromLaneCardIndex;

        if (toLane === fromLane && toCardIndex === fromCardIndex) {
          return;
        }

        let cardMoved = false;

        try {
          this.cardProcessing = true;

          const moveResult = await this.moveCardAsync(cardId, toLane, fromLane, toCardIndex, fromCardIndex, false);

          cardMoved = moveResult.success;

          if (!moveResult.success) {
            if (moveResult.message) {
              SnotifyConfiguration.showInformation(moveResult.message);
            }
            return;
          }

          if (fromLane === toLane) {
            return;
          }
          const response = await WorkflowKanbanService.moveCardAsync(
            this.workflowQueueDataModel.queueId,
            cardId,
            fromLane,
            toLane,
            event.card.readTime
          );

          switch (parseInt(response.workflowKanbanJobProcessResultStatus, 10)) {
            case WorkflowKanbanJobProcessResultStatus.UnableToAcquireLock: {
              SnotifyConfiguration.showInformation(response.workflowJobProcessResult.message);
              await this.moveCardAsync(cardId, fromLane, toLane, fromCardIndex, toCardIndex, true);
              this.getWorkflowQueue();
              break;
            }
            case WorkflowKanbanJobProcessResultStatus.PopUpFieldsRequired: {
              this.setCardMoveContext({
                queueId: this.workflowQueueDataModel.queueId,
                jobId: event.card.cardId,
                sourceLane: event.fromLaneName,
                targetLane: event.toLaneName,
                readTime: event.card.readTime,
                lock: response.workflowKanbanJob.optimisticLock.lock,
                canProcess: response.workflowKanbanJob.mStoreDynamicForm.canProcess
              });
              this.setPopupFieldsSchema(response.workflowKanbanJob.mStoreDynamicForm.fields);
              this.showPopupFieldsModal();
              break;
            }
            case WorkflowKanbanJobProcessResultStatus.ProcessSuccessful: {
              SnotifyConfiguration.showSuccess('Card moved successfully');
              this.getWorkflowQueue();
              break;
            }
            case WorkflowKanbanJobProcessResultStatus.IllegalLaneMove: {
              SnotifyConfiguration.showInformation(`Cannot move items from ${fromLane} to ${toLane}, update failed.`);
              await this.moveCardAsync(cardId, fromLane, toLane, fromCardIndex, toCardIndex, true);
              break;
            }
          }
        } catch (ex) {
          if (cardMoved) {
            await this.moveCardAsync(cardId, fromLane, toLane, fromCardIndex, toCardIndex, true);
          }
          this.$log(ex);
          throw ex;
        } finally {
          this.cardProcessing = false;
        }
      },
      async moveCardAsync(
        cardId: number,
        toLaneName: string,
        fromLaneName: string,
        toLaneCardIndex: number,
        fromLaneCardIndex: number,
        isReverting: boolean
      ) {
        const cards = this.workflowQueueDataModel.additionalConfigurations.cards;
        const card = cards.find((x: any) => x.cardId === cardId);

        if (isReverting) {
          card.laneName = toLaneName;
          this.clearLastCardMove();
        }

        const sourceLaneCardIds = cards.filter((x: any) => x.laneName === fromLaneName).map((x: any) => x.cardId);
        const targetLaneCardIds = cards.filter((x: any) => x.laneName === toLaneName).map((x: any) => x.cardId);

        let response = {
          success: true,
          message: ''
        };

        if (toLaneCardIndex >= 0) {
          const lane = this.laneData.find((x: any) => x.laneName === toLaneName);

          if (!lane.saveCardOrder && toLaneName === fromLaneName) {
            return response;
          }

          const model = {
            sourceLane: fromLaneName,
            targetLane: toLaneName,
            sourceLaneCardIds,
            targetLaneCardIds,
            excludedCardIdFromTargetValidation: isReverting ? cardId : null
          } as KanbanCardOrderUpdateModel;

          if (lane.saveCardOrder) {
            model.sourceLaneCardIndex = fromLaneCardIndex;
            model.targetLaneCardIndex = toLaneCardIndex;
          } else {
            model.targetLaneCardIndex = -1;
          }

          try {
            response = await WorkflowKanbanService.updateCardOrderAsync(
              this.workflowQueueDataModel.queueId,
              cardId,
              model
            );

            if (response.success && toLaneCardIndex > -1) {
              if (!isReverting) {
                this.setLastCardMove({
                  cardId,
                  fromLaneName,
                  toLaneName,
                  fromLaneCardIndex,
                  toLaneCardIndex
                });
              }

              const existingCard = lane.cards[toLaneCardIndex];

              const fromIndex = cards.findIndex((x: any) => x.cardId === cardId);
              const toIndex = existingCard
                ? cards.findIndex((x: any) => x.cardId === existingCard.cardId)
                : cards.length - 1;

              cards.splice(toIndex, 0, cards.splice(fromIndex, 1)[0]);
            }
          } catch (ex) {
            this.$log(ex);
            response.success = false;
          }
        }

        if (response.success && !isReverting) {
          card.laneName = toLaneName;
        }

        return response;
      }
    },
    watch: {
      async getPopupFieldsStatus(this: any, newValue) {
        switch (newValue) {
          case WorkflowKanbanPopupFieldsStatus.ProcessSuccessful:
            SnotifyConfiguration.showSuccess('Card processed successfully');
            this.getWorkflowQueue();
            break;
          case WorkflowKanbanPopupFieldsStatus.ProcessCancelled:
            const jobLock: LockModel = this.getLock;
            if (jobLock) {
              try {
                await LockService.releaseLockAsync(jobLock.id);
              } catch (error) {
                this.$log(error);
              }
            }

            const lastCardMove = this.getLastCardMove;
            if (lastCardMove) {
              await this.moveCardAsync(
                lastCardMove.cardId,
                lastCardMove.fromLaneName,
                lastCardMove.toLaneName,
                lastCardMove.fromLaneCardIndex,
                lastCardMove.toLaneCardIndex,
                true
              );
            }

            this.getWorkflowQueue();
            break;
        }
      }
    },
    components: { Header, MStoreDefaultKanbanCard, MStoreKanbanLanes, LoadingSpinner },
    mounted() {
      this.initialise();
    },
    beforeDestroy() {
      const toRouteName = this.$route.name?.toLowerCase();
      if (!toRouteName?.match(RouteRegEx.WorkflowQueue)) {
        this.resetWorkflowQueueState(this.workflowQueueDataModel.queueId);
      }
    }
  });
</script>
