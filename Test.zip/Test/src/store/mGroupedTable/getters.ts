import { GroupedTableStateModel, RootState } from '@/types';
import { GetterTree } from 'vuex';

export const getters: GetterTree<GroupedTableStateModel, RootState> = {
  getExpandedGroups: (state) => (stateKey: string): any => {
    return state.lastExpandedGroups[stateKey];
  }
};
