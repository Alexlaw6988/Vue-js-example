import axios from 'axios';
import AxiosConfiguration from '@/classes/AxiosConfiguration';
import {
  WorkflowJobProcessResultModel,
  WorkflowJobProcessModel,
  WorkflowJobsEmailModel,
  WorkflowJobAuditDataModel,
  DocumentModel
} from '@/types';

const WorkflowJobApiUrl = 'workflowjob/';

export const WorkflowJobService = {
  async getWorkflowJobAsync(queueId: number, jobId: number): Promise<any> {
    const response = await AxiosConfiguration.axiosWithErrorPage.get(`${WorkflowJobApiUrl}${queueId}/${jobId}`);
    return response.data;
  },
  async getWorkflowDocumentAsync(
    jobId: number,
    page: number,
    viewConversionId: number | null = null
  ): Promise<DocumentModel> {
    const response = await AxiosConfiguration.axiosWithoutNotification.get(`${WorkflowJobApiUrl}document/${jobId}`, {
      params: {
        JobId: jobId,
        Page: page
      }
    });
    return response.data;
  },
  async getWorkflowJobHistoryAsync(jobId: number): Promise<any> {
    const response = await axios.get(`${WorkflowJobApiUrl}history/${jobId}`);
    return response.data;
  },
  async GetWorkflowJobAuditsAsync(jobId: number): Promise<WorkflowJobAuditDataModel> {
    const response = await axios.get(`${WorkflowJobApiUrl}audit/${jobId}`);
    return response.data;
  },
  async processWorkflowJobAsync(
    queueId: number,
    jobId: number,
    workflowJobProcessModel: WorkflowJobProcessModel
  ): Promise<WorkflowJobProcessResultModel> {
    const response = await axios.post(`${WorkflowJobApiUrl}${queueId}/${jobId}`, workflowJobProcessModel);
    return response.data;
  },
  async emailWorkflowJobsAsync(queueId: number, emailModel: WorkflowJobsEmailModel): Promise<any> {
    const response = await axios.post(`${WorkflowJobApiUrl}emailJobs/${queueId}`, emailModel);
    return response.data;
  }
};
