import { ArrayHelper } from './arrayHelper';
import { ObjectHelper } from './objectHelper';

export const ComponentHelper = {
  mixins: [ObjectHelper, ArrayHelper],
  methods: {
    getIndex(this: any, fromElement: any, element: any) {
      return !this.isNullOrEmpty(fromElement) ? fromElement.indexOf(element) : 0;
    },
    setFocusOnElement(this: any, element: any) {
      if (!this.isNullOrEmpty(element)) {
        element.focus();
      }
    },
    setFocusOnNextTick(this: any, element: any) {
      this.$nextTick(() => {
        this.setFocusOnElement(element);
      });
    },
    setScrollIntoViewOnNextTick(this: any, element: any) {
      if (element) {
        this.$nextTick(() => {
          this.setScrollIntoView();
        });
      }
    },
    setScrollIntoView(element: any) {
      element?.scrollIntoView(false);
    },
    removeCss(this: any, element: any, cssClass: string) {
      if (!this.isNullOrEmpty(element)) {
        element.classList.remove(cssClass);
      }
    },
    addCss(this: any, element: any, cssClass: string) {
      if (!this.isNullOrEmpty(element)) {
        element.classList.add(cssClass);
      }
    },
    getElementById(this: any, id: string) {
      return id ? this.getElement(`#${id}`) : null;
    },
    getElementByCss(this: any, cssClass: string) {
      return cssClass ? this.getElement(`.${cssClass}`) : null;
    },
    getAllElementsByCss(this: any, cssClass: string) {
      return cssClass ? this.getAllElements(`.${cssClass}`) : null;
    },
    getElement(this: any, searchString: string) {
      return this.$el?.querySelector(searchString);
    },
    getAllElements(this: any, searchString: string) {
      return this.$el?.querySelectorAll(searchString);
    },
    getUniqueId() {
      return Math.random().toString(36).substr(2, 10);
    }
  }
};
