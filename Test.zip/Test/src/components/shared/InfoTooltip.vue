<template>
  <span>
    <font-awesome-icon :id="id" icon="question-circle" class="mx-1" />
    <b-tooltip :target="id" placement="right">{{ tooltipText }}</b-tooltip>
  </span>
</template>

<script lang="ts">
  import Vue from 'vue';

  export default Vue.extend({
    name: 'InfoTooltip',
    props: {
      tooltipText: {
        type: String,
        required: true
      },
      id: {
        type: String,
        required: true
      }
    }
  });
</script>
