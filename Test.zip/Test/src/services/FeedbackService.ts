import axios from 'axios';
import { FeedbackModel } from '@/types';

const FeedbackApiUrl = 'feedback';

export const FeedbackService = {
  async getFeedbackSubjectsAsync() {
    const result = await axios.get(`${FeedbackApiUrl}/GetFeedbackSubjects`);
    return result.data;
  },
  async sendFeedbackEmailAsync(model: FeedbackModel) {
    return await axios.post(`${FeedbackApiUrl}/SendFeedbackEmail`, model);
  }
};
