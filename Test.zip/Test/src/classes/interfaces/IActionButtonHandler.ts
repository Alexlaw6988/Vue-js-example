export default interface IActionButtonHandler {
  getActionButtonState(this: any, actionButtonProperties: any): any;
  performButtonClick(actionButtonState: any): void;
}
