import { Configuration } from '@/types';
import ConfigurationTreeView from '@/components/configuration/TreeView.vue';
import { RouteHelpers } from '@/mixins';

const DocusignTemplateManagement = () =>
  import(
    /* webpackChunkName: "DocusignTemplates" */
    '@/views/configuration/docusign/DocusignTemplateManagement.vue'
  );

const DocusignEditTemplate = () =>
  import(
    /* webpackChunkName: "DocusignTemplates" */
    '@/views/configuration/docusign/DocusignEditTemplate.vue'
  );

const DocusignAddTemplate = () =>
  import(
    /* webpackChunkName: "DocusignTemplates" */
    '@/views/configuration/docusign/DocusignAddTemplate.vue'
  );

const DocuSignTemplateSignHereManagement = () =>
  import(
    /* webpackChunkName: "DocusignTemplates" */
    '@/views/configuration/docusign/DocuSignTemplateSignHereManagement.vue'
  );

const DocusignEditTemplateSignHere = () =>
  import(
    /* webpackChunkName: "DocusignTemplates" */
    '@/views/configuration/docusign/DocusignEditTemplateSignHere.vue'
  );

const DocusignAddTemplateSignHere = () =>
  import(
    /* webpackChunkName: "DocusignTemplates" */
    '@/views/configuration/docusign/DocusignAddTemplateSignHere.vue'
  );

const DocuSignTemplateAdditionalDocumentManagement = () =>
  import(
    /* webpackChunkName: "DocusignTemplates" */
    '@/views/configuration/docusign/DocuSignTemplateAdditionalDocumentManagement.vue'
  );

const DocusignEditTemplateAdditionalDocument = () =>
  import(
    /* webpackChunkName: "DocusignTemplates" */
    '@/views/configuration/docusign/DocusignEditTemplateAdditionalDocument.vue'
  );

const DocusignAddTemplateAdditionalDocument = () =>
  import(
    /* webpackChunkName: "DocusignTemplates" */
    '@/views/configuration/docusign/DocusignAddTemplateAdditionalDocument.vue'
  );

const meta = {
  layout: 'TreeView',
  treePath: 'docusigntemplates'
};

const treeView = {
  treeView: ConfigurationTreeView
};

export const TemplateRoutes = [
  {
    ...Configuration.DocuSign.Template.Management,
    components: {
      default: DocusignTemplateManagement,
      ...treeView
    },
    meta
  },
  {
    ...Configuration.DocuSign.Template.Edit,
    components: {
      default: DocusignEditTemplate,
      ...treeView
    },
    meta,
    beforeEnter: (to: any, from: any, next: any) => {
      RouteHelpers.setErrorPageRedirect(Configuration.DocuSign.Template.Management.name);
      RouteHelpers.beforeEnterCheckRouteParamAsNumeric(to, from, next, ['documentTypeId', 'id']);
    }
  },
  {
    ...Configuration.DocuSign.Template.Add,
    components: {
      default: DocusignAddTemplate,
      ...treeView
    },
    meta,
    beforeEnter: (to: any, from: any, next: any) => {
      RouteHelpers.setErrorPageRedirect(Configuration.DocuSign.Template.Management.name);
      RouteHelpers.beforeEnterCheckRouteParamAsNumeric(to, from, next, ['documentTypeId']);
    }
  },
  {
    ...Configuration.DocuSign.TemplateSignHere.Management,
    components: {
      default: DocuSignTemplateSignHereManagement,
      ...treeView
    },
    meta,
    beforeEnter: (to: any, from: any, next: any) => {
      RouteHelpers.setErrorPageRedirect(Configuration.DocuSign.Template.Management.name);
      RouteHelpers.beforeEnterCheckRouteParamAsNumeric(to, from, next, ['documentTypeId', 'templateId']);
    }
  },
  {
    ...Configuration.DocuSign.TemplateSignHere.Edit,
    components: {
      default: DocusignEditTemplateSignHere,
      ...treeView
    },
    meta,
    beforeEnter: (to: any, from: any, next: any) => {
      RouteHelpers.setErrorPageRedirect(Configuration.DocuSign.Template.Management.name);
      RouteHelpers.beforeEnterCheckRouteParamAsNumeric(to, from, next, ['documentTypeId', 'templateId', 'id']);
    }
  },
  {
    ...Configuration.DocuSign.TemplateSignHere.Add,
    components: {
      default: DocusignAddTemplateSignHere,
      ...treeView
    },
    meta,
    beforeEnter: (to: any, from: any, next: any) => {
      RouteHelpers.setErrorPageRedirect(Configuration.DocuSign.Template.Management.name);
      RouteHelpers.beforeEnterCheckRouteParamAsNumeric(to, from, next, ['documentTypeId', 'templateId']);
    }
  },
  {
    ...Configuration.DocuSign.TemplateAdditionalDocument.Management,
    components: {
      default: DocuSignTemplateAdditionalDocumentManagement,
      ...treeView
    },
    meta,
    beforeEnter: (to: any, from: any, next: any) => {
      RouteHelpers.setErrorPageRedirect(Configuration.DocuSign.Template.Management.name);
      RouteHelpers.beforeEnterCheckRouteParamAsNumeric(to, from, next, ['documentTypeId', 'templateId']);
    }
  },
  {
    ...Configuration.DocuSign.TemplateAdditionalDocument.Edit,
    components: {
      default: DocusignEditTemplateAdditionalDocument,
      ...treeView
    },
    meta,
    beforeEnter: (to: any, from: any, next: any) => {
      RouteHelpers.setErrorPageRedirect(Configuration.DocuSign.Template.Management.name);
      RouteHelpers.beforeEnterCheckRouteParamAsNumeric(to, from, next, ['documentTypeId', 'templateId', 'id']);
    }
  },
  {
    ...Configuration.DocuSign.TemplateAdditionalDocument.Add,
    components: {
      default: DocusignAddTemplateAdditionalDocument,
      ...treeView
    },
    meta,
    beforeEnter: (to: any, from: any, next: any) => {
      RouteHelpers.setErrorPageRedirect(Configuration.DocuSign.Template.Management.name);
      RouteHelpers.beforeEnterCheckRouteParamAsNumeric(to, from, next, ['documentTypeId', 'templateId']);
    }
  }
];
