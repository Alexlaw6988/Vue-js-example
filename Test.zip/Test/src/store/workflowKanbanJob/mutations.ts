import { MutationTree } from 'vuex';
import {
  WorkflowKanbanJobState,
  SchemaModel,
  WorkflowKanbanJobMutationTypes,
  WorkflowKanbanPopupFieldsStatus,
  KanbanCardMoveModel
} from '@/types';

export const mutations: MutationTree<WorkflowKanbanJobState> = {
  [WorkflowKanbanJobMutationTypes.SetPopupFieldsSchema](state, schemaModels: SchemaModel[]) {
    state.popupFieldsSchema = schemaModels;
  },
  [WorkflowKanbanJobMutationTypes.SetCardMoveContext](state, cardMoveContext: any) {
    state.queueId = cardMoveContext.queueId;
    state.jobId = cardMoveContext.jobId;
    state.sourceLane = cardMoveContext.sourceLane;
    state.targetLane = cardMoveContext.targetLane;
    state.readTime = cardMoveContext.readTime;
    state.lock = cardMoveContext.lock;
    state.canProcess = cardMoveContext.canProcess;
  },
  [WorkflowKanbanJobMutationTypes.SetPopupFieldStatus](state, status: WorkflowKanbanPopupFieldsStatus) {
    state.popupFieldsStatus = status;
  },
  [WorkflowKanbanJobMutationTypes.SetLastCardMove](state, lastCardMove: KanbanCardMoveModel) {
    state.lastCardMove = lastCardMove;
  }
};
