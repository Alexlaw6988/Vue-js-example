import {
  JobTabStateModel,
  WorkflowStandardProcessingAction,
  CancelDealModel,
  AutomotiveWorkflowJobModel,
  WorkflowJobButtonModel,
  StockNumberModel,
  WorkflowJobProcessResultModel
} from '@/types';
import { AutomotiveWorkflowJobService } from '@/services/automotive/AutomotiveWorkflowJobService';
import { ManufacturerTabService } from '@/services/automotive/ManufacturerTabService';
import Toast from '@/classes/SnotifyConfiguration';
import { EventBus } from '@/classes/EventBus';
import { mapActions, mapGetters } from 'vuex';
import { AutomotiveConstants } from '@/mixins/automotive/automotiveConstants';

export const AutomotiveWorkflowJob = {
  methods: {
    ...mapActions('workflowJobStore', ['setActiveHorizontalTab']),
    async processWorkflowJob(this: any) {
      this.isLoading = true;
      let performDefaultProcess = false;
      switch (this.processingAction) {
        case WorkflowStandardProcessingAction.ProcessJob: {
          performDefaultProcess = await this.automotiveProcessJob();
          break;
        }
        case WorkflowStandardProcessingAction.CancelJob: {
          performDefaultProcess = await this.automotiveCancelJob();
          break;
        }
        default: {
          performDefaultProcess = true;
          break;
        }
      }

      if (!performDefaultProcess) {
        this.isLoading = false;
        return;
      }

      try {
        await this.saveManufacturerDataAsync();
      } catch {
        this.isLoading = false;
        return;
      }
      await this.defaultProcessWorkflowJob();
    },
    async automotiveCancelJob(this: any): Promise<boolean> {
      if (this.cancellationValidationMessage !== undefined) {
        this.$bvModal.msgBoxOk(this.cancellationValidationMessage, {
          title: 'Cancel Validation',
          okVariant: 'danger',
          noCloseOnBackdrop: true
        });
        if (this.activeHorizontalTab?.key !== AutomotiveConstants.WorkflowTabKeys.WorkflowTabKey) {
          this.setActiveHorizontalTab(AutomotiveConstants.WorkflowTabKeys.WorkflowTabKey);
        }
        return false;
      }

      try {
        await this.saveManufacturerDataAsync();
      } catch {
        return false;
      }
      const cancelDealModel = {
        queueId: this.workflowJob.queueId,
        jobId: this.workflowJob.jobId,
        workflowDataSources: this.workflowJob.workflowDataSources
      } as CancelDealModel;
      try {
        const result: WorkflowJobProcessResultModel = await AutomotiveWorkflowJobService.cancelDealAsync(
          this.workflowJob.queueId,
          this.workflowJob.jobId,
          cancelDealModel
        );
        this.isLoading = false;
        if (!result.success) {
          Toast.showInformation(result.message);
        } else {
          this.setIsDirty(false);
          this.processGetNextJob();
        }
      } catch {
        this.isLoading = false;
      }
      return false;
    },
    async automotiveProcessJob(this: any): Promise<boolean> {
      if (this.automotiveWorkflowJobModel.jobInForwardOrderFreeReleaseQueue) {
        const newStockNumber: string = this.forwardOrderFreeReleaseStockNumber;
        if (newStockNumber) {
          let stockNumber: StockNumberModel;
          try {
            stockNumber = await AutomotiveWorkflowJobService.getStockNumberAsync(
              this.workflowJob.queueId,
              this.workflowJob.jobId,
              newStockNumber
            );
          } catch {
            return false;
          }
          if (stockNumber.isOnKerridge && stockNumber.workflowJobExists) {
            const confirmed = await this.confirmNewStockNumber(newStockNumber, stockNumber.workflowJobId);
            if (!confirmed) {
              return false;
            }
          }
        }
      }
      return true;
    },
    async confirmNewStockNumber(this: any, stockNumber: string, existingJobId: number): Promise<boolean> {
      try {
        const result: boolean = await this.showConfirmationHtmlModalAsync(
          this.$bvModal,
          `There is already a job for stock number ${stockNumber}.  <br /><br />
                        Click Yes to complete this job, make this order form a version of the existing one,
                        corresponding to stock number ${stockNumber},
                        and copy all other documents to existing job ${existingJobId}.`
        );
        return result;
      } catch {
        return false;
      }
    },
    async initialise(this: any) {
      try {
        this.automotiveWorkflowJobModel = await AutomotiveWorkflowJobService.getWorkflowJobAsync(
          this.workflowJob.queueId,
          this.workflowJob.jobId,
          this.manufacturer
        );
        this.hideTabsBasedOnSaleType();
      } catch (error) {
        this.automotiveWorkflowJobModel = {} as AutomotiveWorkflowJobModel;
        this.$log(`Error getting automotive workflow job ${error}`);
      } finally {
        this.automotiveJobIsLoading = false;
      }
    },
    hideTabsBasedOnSaleType(this: any) {
      const tabsToHideModel = this.workflowJobTabsToHideModel;
      if (!tabsToHideModel) {
        this.automotiveWorkflowJobModel.tabKeysHiddenBySaleType.forEach((x: string) => {
          this.setJobTabStateHidden(this.getHiddenTabStateModel(x, false));
        });
        return;
      }
      const tabsToShow = this.automotiveWorkflowJobModel.tabKeysHiddenBySaleType.filter(
        (x: string) =>
          !tabsToHideModel.tabKeysToHide.includes(x) && this.jobTabState(x) && this.jobTabState(x).hidden === true
      );
      tabsToShow.forEach((x: string) => {
        this.setJobTabStateHidden(this.getHiddenTabStateModel(x, false));
      });
      const tabsToHide = tabsToHideModel.tabKeysToHide.filter(
        (x: string) => this.jobTabState(x) && this.jobTabState(x).hidden === false
      );
      tabsToHide.forEach((x: string) => {
        this.setJobTabStateHidden(this.getHiddenTabStateModel(x, true));
      });
      this.setActiveVerticalTab(tabsToHideModel.tabKeyToShow);
      EventBus.$emit('tabs-loaded', 'vertical');
    },
    validateWorkflowJobAsync(this: any, processButton: WorkflowJobButtonModel) {
      const manufacturerTabState = this.jobTabState('Custom-ManufacturerTab') as JobTabStateModel;

      if (manufacturerTabState && !manufacturerTabState.hidden) {
        this.defaultValidateWorkflowJobAsync(processButton).then(() => {
          this.$nextTick(() => {
            EventBus.$emit(`dynamic-form-submit-m-dfCustom-ManufacturerTab`);
          });
        });
      } else {
        this.defaultValidateWorkflowJobAsync(processButton);
      }
    },
    async saveManufacturerDataAsync(this: any) {
      const manufacturerTabState = this.jobTabState('Custom-ManufacturerTab') as JobTabStateModel;
      if (manufacturerTabState && !manufacturerTabState.hidden) {
        await ManufacturerTabService.updateManufacturerTabDataSourceAsync(
          this.workflowJob.queueId,
          this.workflowJob.jobId,
          this.saleType,
          this.manufacturer,
          this.manufacturerTab.manufacturerDataSource
        );
      }
    }
  },
  computed: {
    ...mapGetters('workflowJobStore', ['activeHorizontalTab']),
    forwardOrderFreeReleaseStockNumber(this: any): string | undefined {
      return this.workflowDataSourceField('FOAndFR', 'StockNumber');
    }
  }
};
