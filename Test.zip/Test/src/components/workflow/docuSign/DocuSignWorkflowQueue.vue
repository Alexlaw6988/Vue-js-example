<template>
  <div class="w-100">
    <m-grouped-table
      :table-id="`docuSignWorkflowQueue${workflowQueueDataModel.queueId}`"
      class="mb-3 mh-100 min-h-100"
      :header-text="workflowQueueDataModel.queueName"
      :items="workflowQueueDataModel.queueData"
      :fields="workflowQueueDataModel.queueColumns"
      :is-loading="isLoading"
      :empty-text="emptyText"
      :show-hide-filters="true"
      :emit-filters="true"
      :group-columns="docuSignQueConfigurations.groupFields"
      :detail-columns="docuSignQueConfigurations.detailFields"
      :add-action-header="true"
      :group-by-field="docuSignQueConfigurations.groupByField"
      :multi-select="docuSignQueConfigurations.multiSelect"
      :actions="docuSignButtons"
      :select-all-rows-initially="true"
      pk-field="jobid"
      :show-filters="tableStateField('showFilters')"
      :current-page="tableStateField('currentPage')"
      :items-per-page="userPreferedTableStateField('itemsPerPage')"
      :search-query="tableStateField('searchQuery')"
      :sort-by="userPreferedTableStateField('sortBy')"
      :sort-desc="userPreferedTableStateField('sortDesc')"
      :allow-wallboard-mode="workflowQueueDataModel.allowWallboardMode"
      :wallboard-refresh-interval-in-seconds="workflowQueueDataModel.wallboardRefreshIntervalInSeconds"
      @update:show-filters="onTableStateFieldUpdated"
      @update:current-page="onTableStateFieldUpdated"
      @update:items-per-page="onUserPreferedTableStateFieldUpdated"
      @update:search-query="onTableStateFieldUpdated"
      @update:sort-by="onUserPreferedTableStateFieldUpdated"
      @update:sort-desc="onUserPreferedTableStateFieldUpdated"
      @update:filtered-items="onTableStateFieldUpdated"
      @refresh-clicked="getWorkflowQueue()"
      @row-clicked="getWorkflowJob"
      @group-action="onButtonClicked"
    ></m-grouped-table>
    <b-modal
      v-model="postIsLoading"
      :no-close-on-backdrop="true"
      :no-close-on-esc="true"
      :hide-header-close="true"
      centered
      :hide-header="!isVoidEnvelope"
      :hide-footer="true"
      :title="modalTitle"
    >
      <div class="d-flex align-items-center" v-if="!isVoidEnvelope">
        <LoadingSpinner :isLoading="postIsLoading" cssPositioning="inherit" loadingMessage="Please wait" />
      </div>
      <div v-else>
        <m-form
          data-vv-scope="voidForm"
          @submit.prevent="onVoidReasonSubmit"
          class="p-1 flex-fill align-self-center"
          v-slot="{ invalid }"
        >
          <m-form-group label="Please enter void reason" label-for="void reason" :isRequired="true">
            <b-form-group>
              <b-form-textarea
                id="voidReason"
                name="void reason"
                v-model="docuSignGroupActionModel.voidReason"
                v-validate="'required|max:4000'"
                :state="validateInputState('void reason', 'voidForm')"
              ></b-form-textarea>
              <b-form-invalid-feedback id="voidReason-feedback">
                {{ errors.first('void reason', 'voidForm') }}
              </b-form-invalid-feedback>
            </b-form-group>
          </m-form-group>
          <b-button
            type="cancel"
            @click="onCloseVoidReasonModal"
            variant="danger"
            class="btn btn-sm text-white flex-fill mr-2"
          >
            Cancel
          </b-button>
          <b-button
            type="submit"
            variant="primary"
            class="btn btn-sm text-white flex-fill ml-2"
            :disabled="!isFormValid() || invalid"
          >
            Submit
          </b-button>
        </m-form>
      </div>
    </b-modal>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  import DefaultWorkflowQueue from '@/components/workflow/DefaultWorkflowQueue.vue';
  import LoadingSpinner from '@/components/shared/LoadingSpinner.vue';
  import MStoreGroupedTable from '@/components/shared/Table/MStoreGroupedTable.vue';
  import { DocuSignWorkflowJobService } from '@/services';
  import SnotifyConfiguration from '@/classes/SnotifyConfiguration';
  import { FormFieldValidation } from '@/mixins';
  import { DocuSignConstants, DocuSignGroupActionModel, DocuSignStandardProcessingAction } from '@/types';
  export default Vue.extend({
    name: 'ds-workflow-queue',
    mixins: [DefaultWorkflowQueue, FormFieldValidation],
    props: {
      workflowQueueDataModel: {
        type: Object,
        required: true
      },
      isLoading: {
        type: Boolean,
        required: true
      }
    },
    data() {
      return {
        showModal: false,
        postIsLoading: false,
        docuSignGroupActionModel: {},
        isVoidEnvelope: false,
        modalTitle: 'Are you sure?'
      };
    },
    computed: {
      docuSignQueConfigurations(this: any) {
        return this.workflowQueueDataModel.additionalConfigurations;
      },
      docuSignButtons(this: any) {
        return this.docuSignQueConfigurations.docuSignButtons?.filter((x: any) => x.isConfigured);
      }
    },
    methods: {
      async onButtonClicked(this: any, event: any, jobs: any[]) {
        this.docuSignGroupActionModel = {
          processingAction: event.processingAction,
          jobIds: jobs.map((x: any) => x.jobid)
        } as DocuSignGroupActionModel;

        if (event.processingAction === DocuSignStandardProcessingAction.VoidEnvelope) {
          this.postIsLoading = true;
          this.isVoidEnvelope = true;
        } else {
          const hasSignerDetails = jobs.every((job: any) => job.valid);
          if (!hasSignerDetails && event.processingAction === DocuSignStandardProcessingAction.CreateEnvelope) {
            const jobsWithOutSigners = jobs
              .filter((job: any) => !job.valid)
              .map((job: any) => job.jobid)
              .join(', ');

            this.$bvModal.msgBoxOk(
              `The envelope is missing some signer details. Please update signer details for ${
                jobs.length > 1 ? 'Jobs:' : 'Job:'
              } ${jobsWithOutSigners}`,
              {
                title: 'Validation Error',
                okVariant: 'warning',
                noCloseOnEsc: true,
                noCloseOnBackdrop: true
              }
            );
            return;
          }
          const confirmationMessage = this.getConfirmationMessage(event, jobs);
          const userConfirmation = await this.$bvModal.msgBoxConfirm(confirmationMessage, {
            id: 'docuSignConfirmationModal',
            title: this.modalTitle,
            cancelVariant: 'danger',
            noCloseOnEsc: true,
            noCloseOnBackdrop: true
          });
          if (userConfirmation) {
            this.GroupActions(this.docuSignGroupActionModel);
          }
        }
      },
      onVoidReasonSubmit(this: any, event: any) {
        this.isVoidEnvelope = false;
        this.GroupActions(this.docuSignGroupActionModel);
      },
      onCloseVoidReasonModal(this: any) {
        this.isVoidEnvelope = false;
        this.postIsLoading = false;
        this.docuSignGroupActionModel = {};
      },
      async GroupActions(this: any, data: DocuSignGroupActionModel) {
        this.postIsLoading = true;
        try {
          await DocuSignWorkflowJobService.GroupActionsAsync(this.workflowQueueDataModel.queueId, data);
          SnotifyConfiguration.showSuccess(DocuSignConstants.SuccessMessage[data.processingAction!]);
        } catch (exception) {
          this.$log(exception);
        } finally {
          this.onCloseVoidReasonModal();
          this.getWorkflowQueue();
        }
      },
      getConfirmationMessage(this: any, event: any, jobs: any[]): string {
        const groupReference = jobs[0][this.docuSignQueConfigurations.groupByField];
        const selectedDocuments = jobs.length;
        const reference = this.workflowQueueDataModel.queueColumns.find(
          (x: any) => x.key === this.docuSignQueConfigurations.groupByField
        ).label;
        switch (event.processingAction) {
          case DocuSignStandardProcessingAction.CreateEnvelope: {
            return `You are about to create an envelope for ${selectedDocuments} document${
              selectedDocuments > 1 ? 's ' : ' '
            }for ${reference} ${groupReference}.`;
          }
          case DocuSignStandardProcessingAction.Cancel: {
            const totalDocuments = this.getDocumentCountForStockNumber(groupReference);
            return `You are about to cancel ${selectedDocuments} of ${totalDocuments} document${
              totalDocuments > 1 ? 's ' : ' '
            }for ${reference} ${groupReference}.`;
          }
          default: {
            return `You are about to ${event.caption} ${groupReference}.`;
          }
        }
      },
      getDocumentCountForStockNumber(this: any, stockNumber: string): number {
        return this.workflowQueueDataModel.queueData.filter(
          (x: any) => x[this.docuSignQueConfigurations.groupByField] === stockNumber
        ).length;
      }
    },
    components: {
      'm-grouped-table': MStoreGroupedTable,
      LoadingSpinner
    }
  });
</script>
