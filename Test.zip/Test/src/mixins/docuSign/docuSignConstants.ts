export const DocuSignConstants = {
  CustomSignersTabKey: 'Custom-DocuSignSignersTab'
};
