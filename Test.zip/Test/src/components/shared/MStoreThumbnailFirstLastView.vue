<template>
  <div data-testid="thumbnailsContainer" class="thumbnails-container h-100 p-0 pl-1 pr-1" :style="containerStyle">
    <slot />
    <MStoreThumbnailView :thumbnail="thumbnails[0]" :maximumImageHeight="maximumImageHeight" class="m-0 mb-3 p-0">
      {{ getLabelAndPageNumberText(firstPageText, thumbnails[0]) }}
    </MStoreThumbnailView>
    <div
      v-if="thumbnails.length > 2"
      class="middle-page-container m-0 mb-3 p-0"
      :class="{ 'has-more-pages': thumbnails.length > 3 }"
    >
      <MStoreThumbnailView :thumbnail="thumbnails[1]" :maximumImageHeight="maximumImageHeight" class="m-0 p-0">
        {{ getMiddlePagesText }}
      </MStoreThumbnailView>
    </div>
    <MStoreThumbnailView v-if="thumbnails.length > 1" :thumbnail="thumbnails[thumbnails.length - 1]" :maximumImageHeight="maximumImageHeight" class="m-0 p-0">
      {{ getLabelAndPageNumberText(lastPageText, thumbnails[thumbnails.length - 1]) }}
    </MStoreThumbnailView>
  </div>
</template>

<script lang="ts">
import Vue from 'vue';
import { ThumbnailViewModel } from '@/types';
import MStoreThumbnailView from '@/components/shared/MStoreThumbnailView.vue';
import { DocumentConstants } from '@/types/constants';
import { ArrayUtils } from '@/utils';

export default Vue.extend({
  name: 'MStoreThumbnailFirstLastView',
  components: {
    MStoreThumbnailView
  },
  props: {
    thumbnails: {
      type: Array as () => ThumbnailViewModel[],
      required: true
    },
    firstPageText: {
      type: String,
      default: 'First Page'
    },
    lastPageText: {
      type: String,
      default: 'Last Page'
    },
    middlePagesText: {
      type: String
    },
    maximumImageHeight: {
      type: Number,
      default: 150
    }
  },
  computed: {
    aSeriesPaperAspectRatio(): number {
      return DocumentConstants.ASeriesPaperAspectRatio;
    },
    containerStyle(): string {
      return `width: calc(${this.maximumImageHeight * this.aSeriesPaperAspectRatio}px + 2.1em);`;
    },
    getMiddlePagesText(): string {
      if (this.middlePagesText) {
        return this.middlePagesText;
      }

      if (this.thumbnails.length === 3) {
        return 'Page 2';
      }

      const allPages = this.thumbnails.map((x) => x.page);
      const middlePages = allPages.slice(1, allPages.length - 1);

      if (ArrayUtils.isContiguous(middlePages)) {
        return `Pages ${middlePages[0]}-${middlePages[middlePages.length - 1]}`;
      }

      return ArrayUtils.getContiguousText(middlePages);
    }
  },
  methods: {
    getLabelAndPageNumberText(text: string, thumbnail: ThumbnailViewModel): string {
      return `${text} (${thumbnail?.page})`;
    }
  }
});
</script>

<style scoped>
</style>