export interface DocuSignSignerRoleListModel {
  id: number;
  description: string;
}
