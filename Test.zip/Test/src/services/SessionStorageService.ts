import axios from 'axios';

export default class SessionStorageService {
  public static addSessionId(sessionId: string) {
    const storedSessionId = sessionStorage.getItem('sessionId');
    if (storedSessionId) {
      if (window.name === '') {
        SessionStorageService.setSessionId(sessionId);
      } else if (window.name === storedSessionId) {
        axios.defaults.headers.SessionId = storedSessionId;
      } else {
        SessionStorageService.setSessionId(sessionId);
      }
    } else {
      SessionStorageService.setSessionId(sessionId);
    }
  }
  public static removeSessionId() {
    sessionStorage.removeItem('sessionId');
  }
  private static setSessionId(sessionId: string) {
    sessionStorage.setItem('sessionId', sessionId);
    window.name = sessionId;
    axios.defaults.headers.SessionId = sessionId;
  }
}
