import { AppSettingsService } from '../services/AppSettingsService';

export const mstoreSettings = AppSettingsService.getAppStartSettings(`${process.env.BASE_URL}api/`);
