export const DeviceConstants = {
  TouchPointerEvents: {
    MouseDown: 'mousedown',
    TouchStart: 'touchstart',
    Click: 'click',
    MouseOut: 'mouseout',
    TouchEnd: 'touchend',
    TouchCancel: 'touchcancel'
  }
};
