import { DocuSignAdditionalDocumentSignTabModel, DocuSignSignerRoleModel } from '@/types';

export interface DocuSignTemplateAdditionalDocumentSignHereModel {
    id: number;
    templateAdditionalDocumentId: number;
    additionalDocumentSignTab: DocuSignAdditionalDocumentSignTabModel;
    signerRole: DocuSignSignerRoleModel;
}