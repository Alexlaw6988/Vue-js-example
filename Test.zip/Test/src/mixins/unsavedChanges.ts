import { ModalHelpers } from '@/mixins';

export const UnsavedChangesHelper = {
  mixins: [ModalHelpers],
  methods: {
    async hasUnsavedChangesToKeepAsync(this: any, modal: any, isDirty: boolean): Promise<boolean> {
      if (isDirty) {
        return !(await this.showUnsavedChangesModalAsync(modal));
      }
      return false;
    }
  }
};
