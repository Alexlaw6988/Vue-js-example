import axios from 'axios';
import { ListModel } from '@/types';
import AxiosConfiguration from '@/classes/AxiosConfiguration';

const ListApiUrl = 'list/';

export const ListService = {
  async getListAsync(id: number, searchText: string, getAllItems: boolean): Promise<ListModel> {
    const response = await axios.get(ListApiUrl, {
      params: {
        Id: id,
        SearchText: searchText,
        GetAllItems: getAllItems
      }
    });
    return response.data;
  },
  async getWorkflowDataFieldListAsync(jobId: number, dataSourceKey: string, dataFieldKey: string): Promise<any> {
    const response = await AxiosConfiguration.axiosWithoutNotification.get(ListApiUrl.concat('workflowDataFieldList'), {
      params: {
        DataSourceKey: dataSourceKey,
        DataFieldKey: dataFieldKey,
        JobId: jobId
      }
    });
    return response.data;
  }
};
