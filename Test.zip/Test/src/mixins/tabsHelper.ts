import { JobTabOrientation, EVENT_BUS } from '@/types';
import { EventBus } from '@/classes/EventBus';

export const TabsHelper = {
  props: {
    tabKey: {
      type: String,
      required: false
    },
    jobTabOrientation: {
      type: Number,
      required: false
    }
  },
  methods: {
    handleTabsLoaded(this: any) {
      const tabOrientation =
        JobTabOrientation.Horizontal === this.jobTabOrientation
          ? EVENT_BUS.HORIZONTAL_TABS_LOADED
          : EVENT_BUS.VERTICAL_TABS_LOADED;
      EventBus.$emit(tabOrientation, this.tabKey);
    }
  }
};
