import { BaseModel } from '../BaseModel';

export interface DocumentActionsModel extends BaseModel {
  Export: boolean;
}
