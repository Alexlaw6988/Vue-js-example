export interface DocuSignAdditionalDocumentSignTabModel {
  id: number;
  additionalDocumentFileId: number;
  tabName: string;
  pageNumber: number;
  xCoord: number;
  yCoord: number;
  canDelete: boolean;
}
