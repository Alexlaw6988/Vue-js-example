import { ListState, RootState, ListModel } from '@/types';
import { ActionTree } from 'vuex';
import { ListService } from '@/services/ListService';

export const actions: ActionTree<ListState, RootState> = {
  loadList({ commit, state }, listId: number) {
    const listRequested = state.requestedListIds.some((x: number) => x === listId) as boolean;
    if (!listRequested) {
      commit('REQUEST_LIST', listId);
      const list = state.lists.find((x: ListModel) => x.id === listId) as ListModel | undefined;
      if (!list) {
        ListService.getListAsync(listId, '', true).then(
          (response: ListModel) => {
            commit('ADD_LIST', response);
          },
          (error) => {
            commit('UPDATE_LIST_ERROR', error);
          }
        );
      }
    }
  }
};
