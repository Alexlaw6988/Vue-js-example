import { FieldActionButtonStateModel, ViewCurrentDocumentActionButtonPropertiesModel } from '@/types/models';
import IActionButtonHandler from '@/classes/interfaces/IActionButtonHandler';
import store from '@/store';
import { WorkflowJobTabModel } from '@/types';

export default class ViewCurrentDocumentActionButtonHandler implements IActionButtonHandler {
  public getActionButtonState(
    this: any,
    actionButtonProperties: ViewCurrentDocumentActionButtonPropertiesModel
  ): FieldActionButtonStateModel {
    return {
      icon: actionButtonProperties.showOriginalIcon,
      tooltip: actionButtonProperties.showOriginalTooltip,
      disabled: false,
      variant: actionButtonProperties.showOriginalVariant
    } as FieldActionButtonStateModel;
  }

  public performButtonClick(this: any, actionButtonState: FieldActionButtonStateModel): void {
    this.setCurrentDocumentTabActive();
    this.setCurrentDocumentBeingViewed();
  }

  private setCurrentDocumentTabActive(): void {
    const activeTab: WorkflowJobTabModel = store.getters['workflowJobStore/activeHorizontalTab'];
    if (!activeTab || activeTab.key !== 'WorkflowTab') {
      store.dispatch('workflowJobStore/setActiveHorizontalTab', 'WorkflowTab');
    }
  }

  private setCurrentDocumentBeingViewed(): void {
    store.dispatch('documentViewStore/setCurrentDocumentBeingViewed');
  }
}
