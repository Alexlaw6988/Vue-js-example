
import { BaseDocumentSearchModel } from './BaseDocumentSearchModel';

export interface ThumbnailSearchModel extends BaseDocumentSearchModel {
  page: number;
  maximumWidthInPixels: number | null;
  maximumHeightInPixels: number | null;
}