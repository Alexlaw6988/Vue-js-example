export interface DocuSignTemplateAfterSignReferenceMappingModel {
  afterSignSettingId: number;
  signedReferenceNumber: number;
  signedReferenceType: string;
  targetReferenceNumber: number;
  targetReferenceType: string;
}
