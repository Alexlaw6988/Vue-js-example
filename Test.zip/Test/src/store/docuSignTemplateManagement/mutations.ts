import { MutationTree } from 'vuex';
import { DocuSignTemplateManagementState, DocuSignTemplateManagementMutationTypes } from '@/types';
import { docuSignTemplateManagement } from '../docuSignTemplateManagement';

export const mutations: MutationTree<DocuSignTemplateManagementState> = {
    [DocuSignTemplateManagementMutationTypes.ResetState](state) {
        Object.assign(state, docuSignTemplateManagement.defaultTemplateManagementState());
    },
    [DocuSignTemplateManagementMutationTypes.SetTableStateField](state, tableStateField: any) {
        Object.assign(state.tableState, {
            [tableStateField.field]: tableStateField.value
        });
    },
    [DocuSignTemplateManagementMutationTypes.SetDocumentType](state, documentTypeId: number) {
        state.documentTypeId = documentTypeId;
    }
};