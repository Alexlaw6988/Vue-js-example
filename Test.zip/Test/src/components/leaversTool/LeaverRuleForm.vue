<template>
  <m-form @submit.prevent="handleSubmit">
    <div class="row">
      <b-list-group flush class="col-12 pr-0">
        <b-list-group-item>
          <div class="row">
            <div class="col-12 col-md-6 col-lg-4 col-xl-3">
              <MStoreFormSelect
                v-model="rule.currentDocumentTypeId"
                :selectOptionsData="configuration.configurableCurrentDocumentTypes"
                displayFieldName="description"
                valueFieldName="id"
                fieldLabel="Current Document Type"
                v-on:input="currentDocumentTypeChanged"
                v-validate.disabled
                name="CurrentDocumentType"
              />
            </div>
            <div class="col-12 col-md-6 col-lg-4 col-xl-3">
              <MStoreFormSelect
                :selectOptionsData="configuration.configurableDestinationDocumentTypes"
                v-model="rule.destinationDocumentTypeId"
                displayFieldName="description"
                valueFieldName="id"
                fieldLabel="Destination Document Type"
                v-validate.disabled
                name="DestinationDocumentType"
              />
            </div>
            <div class="col-12 col-md-6 col-lg-4 col-xl-3">
              <MStoreFormSelect
                :selectOptionsData="retentionPeriodTypes"
                v-model="rule.retentionPeriodType"
                displayFieldName="value"
                valueFieldName="key"
                fieldLabel="Retention Type"
                v-on:input="retentionPeriodTypeChanged"
                v-validate.disabled
                name="RetentionPeriodType"
              />
            </div>
            <div class="col-12 col-md-6 col-lg-4 col-xl-3">
              <b-form-group label="Retention Period" label-for="retentionPeriod">
                <b-form-input
                  autocomplete="off"
                  id="retentionPeriod"
                  type="number"
                  :readonly="isLoading"
                  :disabled="disableRetentionPeriod"
                  v-model="rule.retentionPeriod"
                  v-validate="'required|min_value:1|max_value:2147483647|integer'"
                  name="RetentionPeriod"
                  :state="validateInputState('RetentionPeriod')"
                ></b-form-input>
                <b-form-invalid-feedback id="retentionPeriod-feedback">
                  {{ errors.first('RetentionPeriod') }}
                </b-form-invalid-feedback>
              </b-form-group>
            </div>
          </div>
        </b-list-group-item>
        <b-list-group-item>
          <div class="row">
            <div class="col-12 col-md-6 col-lg-4 col-xl-3">
              <b-form-group>
                <template v-slot:label>
                  Filter Rule By Reference
                  <info-tooltip
                    tooltipText="The rule will only apply to the documents within the selected Current Document Type where the selected Reference is equal to the Reference Value"
                    id="info-icon-1"
                  />
                </template>
                <b-form-checkbox
                  class="mt-2"
                  v-model="filterRuleByReference"
                  name="check-button"
                  switch
                  size="lg"
                  :disabled="!currentDocumentTypeSelected"
                  @change="byReferenceToggled"
                  v-validate.disabled
                ></b-form-checkbox>
              </b-form-group>
            </div>
            <div class="col-12 col-md-6 col-lg-4 col-xl-3">
              <MStoreFormSelect
                :disabled="!currentDocumentTypeSelected || !filterRuleByReference"
                :selectOptionsData="currentDocumentTypeReferences"
                v-model="rule.referenceId"
                displayFieldName="referenceDescription"
                valueFieldName="id"
                fieldLabel="Reference"
                v-validate.disabled
                name="ReferenceDescription"
              />
            </div>
            <div class="col-12 col-md-6 col-lg-4 col-xl-3">
              <m-form-input
                id="referenceValue"
                type="text"
                :disabled="!currentDocumentTypeSelected || !filterRuleByReference"
                :readonly="isLoading"
                :value="rule.referenceValue"
                @input="($event) => updateRuleModel('referenceValue', $event)"
                name="ReferenceValue"
                :state="validateInputState('ReferenceValue')"
                :validation="{ required: filterRuleByReference }"
                label="Reference Value"
              />
            </div>
          </div>
        </b-list-group-item>
        <b-list-group-item>
          <div class="row">
            <div class="col-12 col-md-6 col-lg-4 col-xl-3">
              <b-form-group
                description="This option will only be available if the selected current document type has at least one date reference"
              >
                <template v-slot:label>
                  Calculate Retention From Reference
                  <info-tooltip
                    tooltipText="The retention date will be set to the value of the selected Date Reference plus the Retention Period"
                    id="info-icon-2"
                  />
                </template>
                <b-form-checkbox
                  class="mb-3 mt-2"
                  v-model="calcRetentionFromReference"
                  name="check-button"
                  switch
                  size="lg"
                  :disabled="!currentDocumentTypeSelected || dateCurrentDocumentTypeReferences.length == 0"
                  @change="fromReferenceToggled"
                  v-validate.disabled
                ></b-form-checkbox>
              </b-form-group>
            </div>
            <div class="col-12 col-md-6 col-lg-4 col-xl-3">
              <MStoreFormSelect
                :disabled="!currentDocumentTypeSelected || !calcRetentionFromReference"
                :selectOptionsData="dateCurrentDocumentTypeReferences"
                v-model="rule.calculateFromReferenceId"
                displayFieldName="referenceDescription"
                valueFieldName="id"
                fieldLabel="Date Reference"
                v-validate.disabled
                name="DateReference"
              />
            </div>
          </div>
        </b-list-group-item>
      </b-list-group>
    </div>
    <b-form-invalid-feedback id="validation-feedback" :force-show="true">
      <h6>{{ errors.first('validationErrors') }}</h6>
    </b-form-invalid-feedback>
    <b-form-invalid-feedback id="serverValidation-feedback" :force-show="true">
      <h6>{{ errors.first('serverValidationErrors') }}</h6>
    </b-form-invalid-feedback>
    <b-form-group class="float-right">
      <b-button variant="danger" class="mr-1" :disabled="isLoading" @click="cancel()">Cancel</b-button>
      <b-button type="submit" variant="primary" :disabled="isLoading">
        <b-spinner small class="mb-1 mr-1" v-if="isLoading"></b-spinner>
        {{ this.ruleId ? 'Update' : 'Add' }}
      </b-button>
    </b-form-group>
  </m-form>
</template>

<script lang="ts">
  import Vue from 'vue';
  import MStoreFormSelect from '@/components/shared/MStoreFormSelect.vue';
  import InfoTooltip from '@/components/shared/InfoTooltip.vue';
  import { LeaverRulesService } from '@/services/LeaversTool/LeaverRulesService';
  import {
    EntityType,
    RetentionPeriodType,
    CabinetReferenceType,
    ReferenceValidationType,
    DocumentTypeModel,
    CabinetReferenceModel,
    LeaversToolConfigurationModel,
    LeaverRuleCreateUpdateModel
  } from '@/types';
  import SnotifyConfiguration from '@/classes/SnotifyConfiguration';
  import { FormFieldValidation, ModalHelpers } from '@/mixins';
  import { EnumHelper } from '@/mixins/enumHelper';

  export default Vue.extend({
    name: 'LeaverRuleForm',
    mixins: [FormFieldValidation, ModalHelpers],
    props: {
      ruleId: {
        required: false
      },
      configuration: {
        type: Object as () => LeaversToolConfigurationModel,
        required: true
      },
      rule: {
        type: Object as () => LeaverRuleCreateUpdateModel,
        required: true
      }
    },
    data() {
      return {
        isLoading: false,
        filterRuleByReference: !!this.rule.referenceId,
        calcRetentionFromReference: !!this.rule.calculateFromReferenceId,
        disableRetentionPeriod: this.rule.retentionPeriodType === RetentionPeriodType.None
      };
    },
    methods: {
      handleSubmit(this: any) {
        if (
          !this.validateAllDropdownsPopulated() ||
          !this.validateDifferentDocumentTypes() ||
          !this.validateDocumentReferencesMatch()
        ) {
          return;
        }
        this.$validator.validate().then((valid: any) => {
          if (valid) {
            this.isLoading = true;

            if (this.ruleId) {
              this.updateRule();
            } else {
              this.createRule();
            }

            this.isLoading = false;
          }
        });
      },
      validateAllDropdownsPopulated(this: any): boolean {
        if (
          this.rule.currentDocumentTypeId == null ||
          this.rule.destinationDocumentTypeId == null ||
          this.rule.retentionPeriodType == null ||
          (this.calcRetentionFromReference && !this.rule.calculateFromReferenceId)
        ) {
          this.$validator.errors.add({
            field: 'validationErrors',
            msg: 'A value must be selected in all dropdowns'
          });
          return false;
        } else {
          this.$validator.errors.remove('validationErrors');
          return true;
        }
      },
      validateDifferentDocumentTypes(): boolean {
        const different = this.rule.currentDocumentTypeId !== this.rule.destinationDocumentTypeId;

        if (different) {
          this.$validator.errors.remove('validationErrors');
        } else {
          this.$validator.errors.add({
            field: 'validationErrors',
            msg: 'The current document type and the destination document type cannot be the same'
          });
        }

        return different;
      },
      validateDocumentReferencesMatch(): boolean {
        const currentDocumentType = this.configuration.configurableCurrentDocumentTypes.find(
          (x) => x.id === this.rule.currentDocumentTypeId
        );

        const destinationDocumentType = this.configuration.configurableDestinationDocumentTypes.find(
          (x) => x.id === this.rule.destinationDocumentTypeId
        );

        let sameReferences: boolean = false;

        if (currentDocumentType !== undefined && destinationDocumentType !== undefined) {
          const currentDocumentReferences = currentDocumentType.references.filter(
            (x) => x.type === CabinetReferenceType.Document
          );

          const destinationDocumentReferences = destinationDocumentType.references.filter(
            (x) => x.type === CabinetReferenceType.Document
          );

          sameReferences = currentDocumentReferences.length === destinationDocumentReferences.length;

          if (sameReferences) {
            currentDocumentReferences.forEach((currentRef) => {
              if (
                !destinationDocumentReferences.find(
                  (x) =>
                    x.referenceDescription.trim().toLowerCase() === currentRef.referenceDescription.trim().toLowerCase()
                )
              ) {
                sameReferences = false;
              }
            });
          }
        }

        if (!sameReferences) {
          this.$validator.errors.add({
            field: 'validationErrors',
            msg:
              'The document references for the current document type and the destination document type must be the same'
          });
        } else {
          this.$validator.errors.remove('validationErrors');
        }

        return sameReferences;
      },
      createRule(this: any) {
        LeaverRulesService.createAsync(this.configuration.id, this.rule)
          .then((response: any) => {
            SnotifyConfiguration.showSuccess('Rule added successfully.');
            this.setApplicationDirty(false);
            this.$router.push({ name: 'leaverRules' });
          })
          .catch((error: any) => {
            this.$validator.errors.add({
              field: 'serverValidationErrors',
              msg: error.response.data
            });
          });
      },
      updateRule(this: any) {
        LeaverRulesService.updateAsync(this.configuration.id, this.ruleId, this.rule)
          .then((response: any) => {
            SnotifyConfiguration.showSuccess('Rule updated successfully.');
            this.setApplicationDirty(false);
            this.$router.push({ name: 'leaverRules' });
          })
          .catch((error: any) => {
            this.$validator.errors.add({
              field: 'serverValidationErrors',
              msg: error.response.data
            });
          });
      },
      async cancel(this: any) {
        this.$router.back();
      },
      byReferenceToggled(checked: boolean) {
        if (!checked) {
          this.rule.referenceId = undefined;
        }
      },
      fromReferenceToggled(checked: boolean) {
        if (!checked) {
          this.rule.calculateFromReferenceId = undefined;
        }
      },
      currentDocumentTypeChanged(value: any) {
        this.filterRuleByReference = false;
        this.calcRetentionFromReference = false;
        this.rule.referenceId = undefined;
        this.rule.calculateFromReferenceId = undefined;
        this.rule.referenceValue = undefined;
      },
      retentionPeriodTypeChanged(value: any) {
        this.rule.retentionPeriodType = value;
        this.disableRetentionPeriod = value === RetentionPeriodType.None;

        if (value === RetentionPeriodType.None) {
          this.rule.retentionPeriod = null as any;
        }
      },
      updateRuleModel(this: any, fieldKey: string, newValue: any) {
        this.computedRule = { ...this.computedRule, [fieldKey]: newValue };
      }
    },
    computed: {
      computedRule: {
        get(this: any) {
          return this.rule;
        },
        set(this: any, newValue) {
          this.$emit('update:rule', newValue);
        }
      },
      retentionPeriodTypes() {
        return EnumHelper.methods.convertNumberBasedEnumToArray(RetentionPeriodType);
      },
      currentDocumentTypeSelected(this: any): boolean {
        return this.rule.currentDocumentTypeId !== undefined;
      },
      currentDocumentTypeReferences(this: any): CabinetReferenceModel[] {
        if (this.currentDocumentTypeSelected) {
          const currentDocumentType: DocumentTypeModel = this.configuration.configurableCurrentDocumentTypes.find(
            (x: any) => x.id === this.rule.currentDocumentTypeId
          ) as DocumentTypeModel;
          return currentDocumentType.references;
        }
        return [] as CabinetReferenceModel[];
      },
      dateCurrentDocumentTypeReferences(this: any): CabinetReferenceModel[] {
        return this.currentDocumentTypeReferences.filter(
          (x: any) => x.referenceValidationType === ReferenceValidationType.Date
        );
      }
    },
    components: {
      MStoreFormSelect,
      InfoTooltip
    }
  });
</script>
