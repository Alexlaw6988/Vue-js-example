import axios from 'axios';
import { AutomotiveWorkflowJobModel, CancelDealModel, WorkflowJobProcessResultModel, StockNumberModel } from '@/types';

const WorkflowJobApiUrl = 'automotive/workflowjob/';

export const AutomotiveWorkflowJobService = {
  async getWorkflowJobAsync(queueId: number, jobId: number, manufacturer: string): Promise<AutomotiveWorkflowJobModel> {
    const response = await axios.get(`${WorkflowJobApiUrl}${queueId}/${jobId}/${manufacturer}`);
    return response.data;
  },
  async cancelDealAsync(
    queueId: number,
    jobId: number,
    cancelDealModel: CancelDealModel
  ): Promise<WorkflowJobProcessResultModel> {
    const response = await axios.post(`${WorkflowJobApiUrl}${queueId}/${jobId}/cancelledDeal`, cancelDealModel);
    return response.data;
  },
  async getStockNumberAsync(queueId: number, jobId: number, stockNumber: string): Promise<StockNumberModel> {
    const response = await axios.get(`${WorkflowJobApiUrl}${queueId}/${jobId}/stockNumber/${stockNumber}`);
    return response.data;
  }
};
