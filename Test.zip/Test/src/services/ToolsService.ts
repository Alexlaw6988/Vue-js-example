import axios from 'axios';
import { ToolsModel } from '@/types';

const ToolsApiUrl = 'tools';

export const ToolsService = {
  async getToolsAsync(): Promise<ToolsModel> {
    const response = await axios.get(`${ToolsApiUrl}`);
    return response.data;
  }
};
