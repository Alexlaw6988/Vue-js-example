<template>
  <div>
    <WorkflowUnsupportedInput
      v-if="this.inputProperties.additionalProperties.unsupportedMessage"
      :inputProperties="inputProperties"
      :data="data"
    ></WorkflowUnsupportedInput>
    <MStoreFormLookup
      v-else-if="isMafListType(this.inputProperties.additionalProperties.listType)"
      :fieldId="inputProperties.htmlElementId"
      :fieldLabel="inputProperties.fieldLabel"
      :isReadonly="inputProperties.isReadonly || isDisabled"
      :formId="inputProperties.formId"
      :actionButtonComponentName="inputProperties.additionalProperties.actionButtonComponent"
      :listId="inputProperties.additionalProperties.listId"
      :hasInitialList="inputProperties.additionalProperties.hasInitialList"
      :filterDisabled="!inputProperties.filterEnabled"
      :data="data"
      :intialList="dataFieldList"
      v-on:update:data="onUpdateData"
      v-on:row-selected="onRowSelected($event)"
      @actionButtonClicked="onActionButtonClicked"
      :actionButtonState="actionButtonState"
      :isActionButtonDisabled="isDisabled"
      :validation="{
        required: !ignoreIsRequired && inputProperties.isRequired,
        maxLength: inputProperties.additionalProperties.maxLength
      }"
    ></MStoreFormLookup>
    <MStoreFormSelectTable
      v-else
      :fieldId="inputProperties.htmlElementId"
      :fieldLabel="inputProperties.fieldLabel"
      :isReadonly="inputProperties.isReadonly || isDisabled"
      :formId="inputProperties.formId"
      :actionButtonComponentName="inputProperties.additionalProperties.actionButtonComponent"
      :isLoading="isLoading"
      :filterDisabled="!inputProperties.filterEnabled"
      :data="data"
      :list="dataFieldList"
      v-on:update:data="onUpdateData($event)"
      v-on:row-selected="onRowSelected($event)"
      @actionButtonClicked="onActionButtonClicked"
      :actionButtonState="actionButtonState"
      :isActionButtonDisabled="isDisabled"
      :validation="{
        required: !ignoreIsRequired && inputProperties.isRequired,
        maxLength: inputProperties.additionalProperties.maxLength
      }"
    ></MStoreFormSelectTable>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  import MStoreFormLookup from '@/components/shared/MStoreFormLookup.vue';
  import MStoreFormSelectTable from '@/components/shared/MStoreFormSelectTable.vue';
  import WorkflowUnsupportedInput from '@/components/workflow/WorkflowUnsupportedInput.vue';
  import { WorkflowFormValidation, ObjectHelper, ActionButtonHandler } from '@/mixins';
  import { ListService } from '@/services/ListService';
  import { WorkflowDataSourceFieldListType, ActionButtonType } from '@/types/enums';
  import { AdditionalListFieldUpdate, FieldUpdateModel } from '@/types';

  export default Vue.extend({
    name: 'WorkflowFormSelect',
    mixins: [WorkflowFormValidation, ActionButtonHandler, ObjectHelper],
    props: {
      inputProperties: {
        type: Object,
        required: true
      },
      data: {
        required: true
      },
      ignoreIsRequired: {
        type: Boolean,
        default: false
      },
      isDisabled: {
        type: Boolean,
        default: false
      }
    },
    data() {
      return {
        dataFieldList: {},
        isLoading: false
      };
    },
    methods: {
      async getWorkflowDataFieldListAsync(this: any) {
        this.isLoading = true;
        try {
          await ListService.getWorkflowDataFieldListAsync(
            this.inputProperties.additionalProperties.jobId,
            this.inputProperties.dataSourceKey,
            this.inputProperties.fieldName
          ).then((result: any) => {
            this.dataFieldList = result;
            this.isLoading = false;
          });
        } catch (error) {
          this.$log(`Error getting data-field list ${error}`);
          this.isLoading = false;
        }
      },
      onUpdateData(value: any) {
        this.$emit('update:data', value);
      },
      onRowSelected(this: any, row: any) {
        const additionalListFieldUpdates = this.inputProperties.additionalProperties.additionalListFieldUpdates;
        if (
          this.isNullOrEmpty(additionalListFieldUpdates) ||
          additionalListFieldUpdates.length === 0 ||
          this.isNullOrEmpty(row) ||
          row.length === 0
        ) {
          return;
        }
        Object.keys(row).forEach((field: string) => {
          const additionalListFieldUpdate = additionalListFieldUpdates.find(
            (x: AdditionalListFieldUpdate) => x.listField.toLowerCase() === field.toLowerCase()
          );
          if (additionalListFieldUpdate) {
            const fieldUpdate = {
              dataSourceKey: additionalListFieldUpdate.dataSourceKey,
              fieldName: additionalListFieldUpdate.fieldName,
              value: row[field]
            } as FieldUpdateModel;
            this.$emit('update:field', fieldUpdate);
          }
        });
      },
      initialise(this: any) {
        if (this.isSqlListType(this.inputProperties.additionalProperties.listType)) {
          this.getWorkflowDataFieldListAsync();
        }
      },
      isMafListType(listType: WorkflowDataSourceFieldListType) {
        return listType === WorkflowDataSourceFieldListType.Maf;
      },
      isSqlListType(listType: WorkflowDataSourceFieldListType) {
        return listType === WorkflowDataSourceFieldListType.Sql;
      },
      onActionButtonClicked(this: any) {
        this.performButtonClick(this.actionButtonType, this.actionButtonState);
      }
    },
    computed: {
      actionButtonData(): object {
        return {};
      },
      actionButtonType(this: any): ActionButtonType {
        return this.inputProperties.additionalProperties.actionButtonType
          ? (this.inputProperties.additionalProperties.actionButtonType as ActionButtonType)
          : ActionButtonType.None;
      },
      actionButtonState(this: any): any {
        if (this.actionButtonType === ActionButtonType.None) {
          return {};
        }
        const state = this.getActionButtonState(
          this.actionButtonType,
          this.inputProperties.additionalProperties.actionButtonProperties
        );
        return state;
      }
    },
    mounted(this: any) {
      this.initialise();
    },
    components: {
      MStoreFormLookup,
      MStoreFormSelectTable,
      WorkflowUnsupportedInput
    }
  });
</script>
