import axios from 'axios';
import { LeaverRuleModel, LeaverRuleCreateUpdateModel } from '@/types';

const LeaverRulesApiUrl = 'leaverrules/';

export const LeaverRulesService = {
  async getAsync(ruleId: any): Promise<LeaverRuleModel> {
    const response = await axios.get(LeaverRulesApiUrl + ruleId);
    return response.data;
  },
  async createAsync(configurationId: any, leaverRuleCreateModel: LeaverRuleCreateUpdateModel): Promise<number> {
    const response = await axios.post(LeaverRulesApiUrl + configurationId, leaverRuleCreateModel);
    return response.data;
  },
  async updateAsync(
    configurationId: any,
    ruleId: any,
    leaverRuleCreateModel: LeaverRuleCreateUpdateModel
  ): Promise<number> {
    const response = await axios.put(LeaverRulesApiUrl + configurationId + '/' + ruleId, leaverRuleCreateModel);
    return response.data;
  },
  async deleteAsync(ruleId: number) {
    await axios.delete(LeaverRulesApiUrl + ruleId);
  }
};
