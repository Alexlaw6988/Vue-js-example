import { BaseModel } from '../../../BaseModel';
import { DocuSignSettingsModel, DocumentTypeModel } from '@/types';

export interface DocuSignSettingsConfigurationModel extends BaseModel {
    documentTypeId: number | null;
    settings: DocuSignSettingsModel;
    documentTypes: DocumentTypeModel[];
}