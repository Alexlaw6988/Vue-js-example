export interface StockNumberModel {
  isOnKerridge: boolean;
  workflowJobId: number | undefined;
  workflowJobExists: boolean;
}
