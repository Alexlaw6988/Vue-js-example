<template>
  <b-card class="kanban-card">
    <div class="cardBody" :class="cardBodyCss">
      <div
        v-if="fieldConfig.CardFieldLeftCorner"
        class="arrow-left"
        :class="fieldConfig.CardFieldLeftCorner.style"
        :title="fieldConfig.CardFieldLeftCorner.caption"
      >
        <span>{{ fieldConfig.CardFieldLeftCorner.fieldValue }}</span>
      </div>
      <div
        v-if="fieldConfig.CardFieldRightCorner"
        class="arrow-right"
        :class="fieldConfig.CardFieldRightCorner.style"
        :title="fieldConfig.CardFieldRightCorner.caption"
      >
        <span>{{ fieldConfig.CardFieldRightCorner.fieldValue }}</span>
      </div>
      <div align="center" class="headerIcon">
        <b-button v-if="icons.CardIconLeft" size="sm" class="m-2 leftIcon icon" :variant="icons.CardIconLeft.style">
          <font-awesome-icon :icon="icons.CardIconLeft.icon" />
        </b-button>
        <b-button v-if="icons.CardIconRight" size="sm" class="m-2 rightIcon icon" :variant="icons.CardIconRight.style">
          <font-awesome-icon :icon="icons.CardIconRight.icon" />
        </b-button>
      </div>
      <div align="center" class="fields">
        <div v-for="(field, index) in fields" :key="index + field.fieldValue">
          <label class="m-0 p-0 align-items-left">
            <strong v-if="field.caption">{{ field.caption }} :</strong>
          </label>
          <span :class="field.style">{{ field.fieldValue }}.</span>
          <br />
        </div>
      </div>
    </div>
  </b-card>
</template>
<script lang="ts">
  import { KanbanCardFieldModel, DefaultKanbanCardModel } from '@/types/models/kanban';
  export default {
    name: 'MStoreDefaultKanbanCard',
    props: {
      cardDetails: {
        type: Object as () => DefaultKanbanCardModel,
        required: true
      }
    },
    computed: {
      fieldConfig(this: any) {
        return this.cardDetails?.fields?.reduce((config: any, field: KanbanCardFieldModel) => {
          if (['CardFieldLeftCorner', 'CardFieldRightCorner'].includes(field.fieldName)) {
            config[field.fieldName] = field;
          }
          return config;
        }, {});
      },
      fields(this: any) {
        return this.cardDetails?.fields?.filter(
          (field: KanbanCardFieldModel) => !['CardFieldLeftCorner', 'CardFieldRightCorner'].includes(field.fieldName)
        );
      },
      icons(this: any) {
        return this.cardDetails?.icons?.reduce((config: any, field: any) => {
          if (field?.icon) {
            config[field.fieldName] = field;
          }
          return config;
        }, {});
      },
      cardBodyCss(this: any) {
        return this.cardDetails?.cardStyle;
      }
    }
  };
</script>
