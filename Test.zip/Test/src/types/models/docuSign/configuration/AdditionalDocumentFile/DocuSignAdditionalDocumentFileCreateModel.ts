export interface DocuSignAdditionalDocumentFileCreateModel {
  fileData: File;
  description: string;
}
