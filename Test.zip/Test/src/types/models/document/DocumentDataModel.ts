import { CabinetModel } from '../cabinet';
import { DocumentTypeModel } from '../documentType';

export interface DocumentDataModel {
  id: number;
  pages: number;
  batchNumber: number;
  fileName: number;
  documentDate: Date;
  cabinet: CabinetModel;
  documentType: DocumentTypeModel;
}
