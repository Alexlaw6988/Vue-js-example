export const Configuration = {
  Base: {
    path: '/configuration',
    name: 'configuration',
  },
  Organisation: {
    Management: {
      path: '/configuration/organisations',
      name: 'organisationManagement',
    },
    Add: {
      path: '/configuration/organisations/add',
      name: 'addOrganisation',
    },
    View: {
      path: '/configuration/organisations/:id',
      name: 'viewOrganisation',
    },
    Edit: {
      path: '/configuration/organisations/edit/:id',
      name: 'editOrganisation',
    }
  },
  User: {
    Management: {
      path: '/configuration/users',
      name: 'userManagement',
    },
    Add: {
      path: '/configuration/users/add',
      name: 'addUser',
    },
    View: {
      path: '/configuration/users/:id',
      name: 'viewUser',
    },
    Edit: {
      path: '/configuration/users/edit/:id',
      name: 'editUser',
    },
    Copy: {
      path: '/configuration/users/add',
      name: 'copyUser',
    }
  },
  Role: {
    Management: {
      path: '/configuration/roles',
      name: 'roleManagement',
    },
    Add: {
      path: '/configuration/roles/add',
      name: 'addRole',
    },
    View: {
      path: '/configuration/roles/:id',
      name: 'viewRole',
    },
    Edit: {
      path: '/configuration/roles/edit/:id',
      name: 'editRole',
    },
    Copy: {
      path: '/configuration/roles/add',
      name: 'copyRole',
    }
  },
  LeaversTool: {
    Base: {
      path: '/configuration/leaverstool',
      name: 'leaversToolConfiguration',
    }
  },
  LeaverRule: {
    Management: {
      path: '/configuration/leaverrules',
      name: 'leaverRules',
    },
    Add: {
      path: '/configuration/leaverrules/add/:configurationId',
      name: 'addLeaverRule',
    },
    Edit: {
      path: '/configuration/leaverrules/edit/:configurationId/:ruleId',
      name: 'editLeaverRule',
    }
  },
  DocuSign: {
    AdditionalDocument: {
      Management: {
        path: '/configuration/docusign/additionaldocuments',
        name: 'docusignAdditionalDocumentManagement',
      },
      Add: {
        path: '/configuration/docusign/additionaldocuments/add',
        name: 'docusignAddAdditionalDocument',
      },
      Edit: {
        path: '/configuration/docusign/additionaldocuments/edit/:id',
        name: 'docusignEditAdditionalDocument',
      }
    },
    AdditionalDocumentSignTab: {
      Management: {
        path: '/configuration/docusign/additionaldocuments/:id/signtabs',
        name: 'docusignAdditionalDocumentSignTabManagement',
      },
      Add: {
        path: '/configuration/docusign/additionaldocuments/:id/signtabs/add',
        name: 'docusignAddAdditionalDocumentSignTab',
      },
      Edit: {
        path: '/configuration/docusign/additionaldocuments/:additionalDocumentId/signtabs/edit/:id',
        name: 'docusignEditAdditionalDocumentSignTab',
      }
    },
    AfterSignMapping: {
      Management: {
        path: '/configuration/docusign/aftersignmappings',
        name: 'docusignAfterSignMappingsManagement',
      },
      Edit: {
        path: '/configuration/docusign/aftersignmappings/edit/:id',
        name: 'docusignEditTemplateAfterSignMappings',
      }
    },
    SignerRole: {
      Management: {
        path: '/configuration/docusign/signerroles',
        name: 'docusignSignerRoleManagement',
      },
      Add: {
        path: '/configuration/docusign/:documentTypeId/signerroles/add',
        name: 'docusignAddSignerRole',
      },
      Edit: {
        path: '/configuration/docusign/:documentTypeId/signerroles/edit/:id',
        name: 'docusignEditSignerRole',
      }
    },
    Settings: {
      Base: {
        path: '/configuration/docusign/settings',
        name: 'docusignSettings',
      }
    },
    Template: {
      Management: {
        path: '/configuration/docusign/templates',
        name: 'docusignTemplateManagement',
      },
      Edit: {
        path: '/configuration/docusign/:documentTypeId/templates/edit/:id',
        name: 'docusignEditTemplate'
      },
      Add: {
        path: '/configuration/docusign/:documentTypeId/templates/add',
        name: 'docusignAddTemplate'
      }
    },
    TemplateSignHere: {
      Management: {
        path: '/configuration/docusign/:documentTypeId/templates/:templateId/signheres',
        name: 'docuSignTemplateSignHereManagement'
      },
      Edit: {
        path: '/configuration/docusign/:documentTypeId/templates/:templateId/signheres/edit/:id',
        name: 'docusignEditTemplateSignHere'
      },
      Add: {
        path: '/configuration/docusign/:documentTypeId/templates/:templateId/signheres/add',
        name: 'docusignAddTemplateSignHere'
      }
    },
    TemplateAdditionalDocument: {
      Management: {
        path: '/configuration/docusign/:documentTypeId/templates/:templateId/additionaldocuments',
        name: 'docuSignTemplateAdditionalDocumentManagement'
      },
      Edit: {
        path: '/configuration/docusign/:documentTypeId/templates/:templateId/additionalDocuments/edit/:id',
        name: 'docusignEditTemplateAdditionalDocument'
      },
      Add: {
        path: '/configuration/docusign/:documentTypeId/templates/:templateId/additionalDocuments/add',
        name: 'docusignAddTemplateAdditionalDocument'
      }
    },
    DocumentType: {
      Management: {
        path: '/configuration/docusign/documenttypes',
        name: 'docusignEditDocumentTypes'
      }
    },
    AccountMangement: {
      Base: {
        path: '/configuration/docusign/accountconfiguration',
        name: 'docusignAccountConfiguration'
      }
    }
  }
};