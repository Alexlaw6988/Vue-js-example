import { BaseModel } from '../BaseModel';
import { UserModel } from '../user';
import { CabinetModel } from '../cabinet';
import { DocumentTypeModel } from '../documentType';
import { DocumentVersionType } from '@/types/enums/DocumentVersionType';

export interface DocumentVersionModel extends BaseModel {
  id: number;
  currentVersionDocumentId: number;
  documentId: number;
  documentType: DocumentTypeModel;
  cabinet: CabinetModel;
  type: DocumentVersionType;
  number: number;
  details: string;
  user: UserModel;
  date: Date;
  currentUserCanEdit: boolean;
}
