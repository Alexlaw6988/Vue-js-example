import axios from 'axios';
import {
  UserModel,
  UserSearchModel,
  UserCreateModel,
  UserCopyModel,
  UserRolesUpdateModel,
  UserWindowsAutoLogInModel
} from '@/types';
import AxiosConfiguration from '@/classes/AxiosConfiguration';

const UserApiUrl = 'users';

export const UserService = {
  async checkMaintenancePermissions(): Promise<any> {
    const response = await AxiosConfiguration.axiosWithErrorPage.get(`${UserApiUrl}/CheckMaintenancePermissions`);
    return response.data;
  },
  async getCurrentUserAsync(): Promise<UserModel> {
    const response = await axios.get(`${UserApiUrl}/CurrentUser`);
    return response.data;
  },
  async getUsersAsync(userSearchModel: UserSearchModel): Promise<UserModel[]> {
    const users = await AxiosConfiguration.axiosWithErrorPage.get(UserApiUrl, {
      params: {
        organisationId: userSearchModel.organisationId,
        isDeactivated: userSearchModel.isDeactivated
      }
    });
    return users.data;
  },
  async getUserAsync(id: number): Promise<UserModel> {
    const response = await AxiosConfiguration.axiosWithErrorPage.get(`${UserApiUrl}/${id}`);
    return response.data;
  },
  async createUserAsync(userCreateModel: UserCreateModel) {
    const response = await axios.post(UserApiUrl, userCreateModel);
    return response.data;
  },
  async copyUserAsync(userCopyModel: UserCopyModel) {
    const response = await axios.post(`${UserApiUrl}/CopyUser`, userCopyModel);
    return response.data;
  },
  async updateUserAsync(id: number, userModel: UserModel) {
    const result = await axios.put(UserApiUrl.concat(`/${id}`), userModel);
    return result.data;
  },
  async sendUserEmailAsync(id: number, methodName: string) {
    const response = await axios.post(`${UserApiUrl}/${methodName}/${id}`);
    return response.data;
  },
  async updateUserRolesAsync(userRolesUpdateModel: UserRolesUpdateModel) {
    const response = await axios.put(`${UserApiUrl}/${userRolesUpdateModel.user.id}/Roles`, userRolesUpdateModel);
    return response.data;
  },
  async removeAccessLockAsync(id: number) {
    const response = await axios.post(`${UserApiUrl}/RemoveAccessLock/${id}`);
    return response.data;
  },
  async disableWindowsAutoLogInForCurrentUserAsync() {
    const response = await axios.put(`${UserApiUrl}/CurrentUser/WindowsAutoLogIn`, {
      enabled: false
    } as UserWindowsAutoLogInModel);
    return response.data;
  }
};
