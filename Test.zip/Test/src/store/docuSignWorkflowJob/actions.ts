import {
  DocuSignWorkflowJobState,
  DocuSignWorkflowJobMutationTypes,
  CustomTabDynamicFormUpdateModel,
  FieldUpdateModel,
  SignersTabModel,
  RootState
} from '@/types';
import { ActionTree } from 'vuex';
import { SignersTabService } from '@/services/docuSign/SignersTabService';
import store from '../index';
import { DocuSignConstants } from '@/types';

export const actions: ActionTree<DocuSignWorkflowJobState, RootState> = {
  getSignersTab(this: any, { commit, getters }: any, jobId: number) {
    commit(DocuSignWorkflowJobMutationTypes.SetIsSignersTabLoading, true);
    SignersTabService.getSignersTabAsync(jobId)
      .then((response: SignersTabModel) => {
        commit(DocuSignWorkflowJobMutationTypes.SignersTabLoaded, response);
        store.dispatch('workflowJobStore/addCustomFormsDynamicFormValidationModel', response.dynamicForm.formId);
        store.dispatch('workflowJobStore/addDynamicFormModelToCustomJobTab', {
          key: DocuSignConstants.CustomSignersTabKey,
          dynamicForm: response.dynamicForm
        } as CustomTabDynamicFormUpdateModel);
      })
      .catch((error: any) => {
        commit(DocuSignWorkflowJobMutationTypes.SignersTabError, error);
      });
  },
  setSignersTabFieldValue(this: any, { commit }, fieldUpdateModel: FieldUpdateModel) {
    store.dispatch('workflowJobStore/setIsDirty', true);
    commit(DocuSignWorkflowJobMutationTypes.UpdateSignersDataSourceFieldValue, fieldUpdateModel);
  },
  unloadDocuSignWorkflowJob({ commit }) {
    commit(DocuSignWorkflowJobMutationTypes.UnloadSignersWorkflowJob);
  }
};
