import {
  UserPreferencesState,
  RootState,
  UserPreferencesMutationTypes,
  DocumentToStoreTargetDocumentTypeModel
} from '@/types';
import { ActionTree } from 'vuex';

export const actions: ActionTree<UserPreferencesState[], RootState> = {
  setJobVerticalSlider({ commit, rootState }, workflowJobPreference) {
    const root: any = rootState;
    const userId = root.oidcStore.user.id;
    commit(UserPreferencesMutationTypes.SetJobVerticalSlider, { userId, workflowJobPreference });
  },

  setWorkflowTreeView({ commit, rootState }, workflowTreeView) {
    const root: any = rootState;
    const userId = root.oidcStore.user.id;
    commit(UserPreferencesMutationTypes.SetWorkflowTreeView, { userId, workflowTreeView });
  },

  setCanGetNextJob({ commit, rootState }, workflowJobPreference) {
    const root: any = rootState;
    const userId = root.oidcStore.user.id;
    commit(UserPreferencesMutationTypes.SetCanGetNextJob, { userId, workflowJobPreference });
  },
  setSelectedWorkFlowQueueId({ commit, rootState }, selectedQueueId) {
    const root: any = rootState;
    const userId = root.oidcStore.user.id;
    commit(UserPreferencesMutationTypes.SetLastSelectedWorkflowQueue, { userId, selectedQueueId });
  },
  setUserPreferedWorkflowQueueTableOptions({ commit, rootState }, workflowQueueTableStatePreference) {
    const root: any = rootState;
    const userId = root.oidcStore.user.id;
    commit(UserPreferencesMutationTypes.SetWorkflowQueueTableStateField, { userId, workflowQueueTableStatePreference });
  },
  setDocumentToStoreTargetDocumentType(
    { commit, rootState },
    documentToStoreTargetDocumentType: DocumentToStoreTargetDocumentTypeModel
  ) {
    const root: any = rootState;
    const userId = root.oidcStore.user.id;
    commit(UserPreferencesMutationTypes.SetDocumentToStoreTargetDocumentType, {
      userId,
      documentToStoreTargetDocumentType
    });
  }
};
