import { mapGetters } from 'vuex';

export const AutomotiveHelper = {
  computed: {
    ...mapGetters('workflowJobStore', ['workflowDataSourceField']),
    saleType(this: any): string {
      return this.workflowDataSourceField('SalesCheckList', 'SC_SaleType') || String.prototype.empty();
    },
    manufacturer(this: any): string {
      return this.workflowDataSourceField('Manufacturer', 'Manufacturer');
    }
  }
};
