import { JobTabOrientation, EVENT_BUS, WorkflowJobTabModel } from '@/types';
import { EventBus } from '@/classes/EventBus';

export const workflowTabsHelper = {
  data() {
    return {
      tabs: []
    };
  },
  computed: {
    tabOrientation(this: any) {
      return this.jobTabOrientation === 'horizontal'
        ? EVENT_BUS.HORIZONTAL_TABS_LOADED
        : EVENT_BUS.VERTICAL_TABS_LOADED;
    }
  },
  methods: {
    handleLoadedTabs(this: any, key: string) {
      const index = this.tabs.indexOf(key);
      if (index > -1) {
        this.tabs.splice(index, 1);
      }
      if (this.tabs.length === 0) {
        EventBus.$emit(EVENT_BUS.TABS_LOADED, this.jobTabOrientation);
      }
    }
  },
  created(this: any) {
    EventBus.$on(this.tabOrientation, (key: string) => this.handleLoadedTabs(key));
  },
  mounted(this: any) {
    if (this.preloadTabs.length < 1) {
      EventBus.$emit(EVENT_BUS.TABS_LOADED, this.jobTabOrientation);
    } else {
      this.tabs = [...this.preloadTabs.map((tab: WorkflowJobTabModel) => tab.key)];
    }
  },
  beforeDestroy(this: any) {
    EventBus.$off(this.tabOrientation);
  }
};
