<template>
  <div class="d-flex flex-column h-100 w-100 overflow-hidden" ref="viewerContainer" id="viewerContainer">
    <DocumentViewerToolbar
      v-if="!hideToolbar && (!hasDocumentError || (document.hasNotification && document.viewConversionId))"
      :totalPages="document.totalPages"
      :imageLoaded="imageLoaded"
      v-bind:imageProperties.sync="imageProperties"
      v-on:exportDocument="exportDocument"
      :documentActions="documentActions"
      :exportPending="exportPending"
      :toolOptions="toolbarOptions"
    ></DocumentViewerToolbar>
    <div class="flex-1 overflow-hidden d-flex flex-row">
      <div id="imageContainer" class="flex-1 text-center bg-dark overflow-auto" ref="imageContainer" v-dragscroll>
        <LoadingSpinner
          :isLoading="isPageLoading && !document.isBeingConverted && showLoadingSpinner && !document.hasNotification"
          textColourVariant="light"
        ></LoadingSpinner>

        <img
          v-show="isPageLoaded"
          :src="documentPage.documentData"
          :alt="document.fileName"
          ref="image"
          @load="setImageProperties(true)"
          @mousedown="imageClicked = true"
          @mouseup="imageClicked = false"
          :class="imageClicked ? 'cursor-grabbing' : 'cursor-grab'"
          :style="imageStyles"
        />

        <div v-show="document.hasNotification || document.isBeingConverted" class="h-100">
          <span
            v-if="isUnsupportedFileType || document.isBeingConverted || document.viewConversionId"
            class="h-100 d-inline-flex flex-column"
          >
            <b-card class="m-auto" border-variant="light">
              <div v-if="document.isBeingConverted">
                <LoadingSpinner
                  :isLoading="true"
                  loadingMessage="Converting document"
                  textColourVariant="dark"
                  cssPositioning="unset"
                />
              </div>
              <div v-else>{{ document.notification }}</div>
              <div v-show="documentActions.export && !isIpad()" class="pt-2">
                <div v-if="document.isBeingConverted && conversionHasTakenLongerThanConfiguredPeriod" class="pb-3">
                  <hr />
                  <div>It is taking a while to convert the document,</div>
                  <div>you can download it instead by clicking Export</div>
                </div>
                <div v-else-if="!document.isBeingConverted" class="pb-3">
                  You can download the document by clicking Export
                </div>
                <button
                  v-if="!document.isBeingConverted || conversionHasTakenLongerThanConfiguredPeriod"
                  variant="primary"
                  class="btn btn-primary btn-sm ml-2"
                  @click="exportDocument"
                  :disabled="exportPending"
                  title="Export"
                >
                  <font-awesome-icon icon="download" class="mr-2" />
                  Export
                  <font-awesome-icon :hidden="!exportPending" size="sm" class="ml-2" icon="spinner" spin />
                </button>
              </div>
            </b-card>
          </span>
          <div v-else class="alert alert-danger rounded-0 font-weight-bold">{{ document.notification }}</div>
        </div>
      </div>

      <MStoreThumbnailViewList
        v-show="document.totalPages > 1 && !isPageConverted"
        :document="document"
        :selectedPage="currentPage"
        @pageClick="loadPage($event)"
      />

      <div
        v-show="hasImageFooterSlot && showImageFooter && isPageLoaded"
        class="position-absolute"
        :style="imageFooterStyles"
        ref="imageFooter"
        data-testid="image-footer"
      >
        <b-alert show dismissible :variant="imageFooterVariant" class="mb-0">
          <slot name="imageFooter"></slot>
        </b-alert>
      </div>

      <div
        class="alert alert-danger rounded-0 font-weight-bold"
        v-if="document.hasDocumentError && document.hasNotification"
      >
        {{ document.notification }}
      </div>
    </div>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  import { mapActions, mapGetters } from 'vuex';
  import { DocumentModel } from '@/types/models/document/DocumentModel';
  import { BaseDocumentSearchModel } from '@/types/models/document/BaseDocumentSearchModel';
  import { DocumentActionsModel } from '@/types/models/document/DocumentActionsModel';
  import { ErrorCode } from '@/types/enums/ErrorCode';
  import { AppSettingsModel } from '@/types/models/appSettings';
  import { DocumentViewerToolbarOptionsModel } from '@/types/models/documentView/DocumentViewerToolbarOptionsModel';
  import { DocumentService } from '@/services/DocumentService';
  import LoadingSpinner from '@/components/shared/LoadingSpinner.vue';
  import DocumentViewerToolbar from '@/components/shared/DocumentViewerToolbar.vue';
  import MStoreThumbnailViewList from '@/components/shared/MStoreThumbnailViewList.vue';
  import moment from 'moment';
  import { dragscroll } from 'vue-dragscroll';
  import SnotifyConfiguration from '@/classes/SnotifyConfiguration';
  import { DeviceHelper } from '@/mixins/deviceHelper';
  import { AppSettingsHelper } from '@/mixins/appSettingsHelper';
  import ResizeObserver from 'resize-observer-polyfill';

  export default Vue.extend({
    name: 'DocumentViewer',
    mixins: [DeviceHelper, AppSettingsHelper],
    props: {
      hideToolbar: {
        type: Boolean,
        default: false
      },
      loadFirstPage: {
        type: Boolean,
        default: true
      },
      imageFooterVariant: {
        type: String,
        default: 'secondary'
      },
      showImageFooter: {
        type: Boolean,
        default: true
      },
      toolOptions: {
        type: Object as () => DocumentViewerToolbarOptionsModel
      }
    },
    data() {
      return {
        imageLoaded: '',
        imageClicked: false,
        imageProperties: {
          width: 0,
          height: 0,
          marginTop: 0,
          marginBottom: 0,
          marginLeft: 0,
          marginRight: 0,
          rotationDegrees: 0,
          originalWidth: 0,
          originalHeight: 0,
          containerWidth: 0,
          containerHeight: 0,
          containerPadding: 10
        },

        imageFooterProperties: {
          viewerContainerHeight: 0,
          imageFooterHeight: 0,
          imageFooterWidth: 0,
          imageContainerOffsetHeight: 0,
          imageContainerHeight: 0,
          imageContainerWidth: 0
        },

        documentActions: {} as DocumentActionsModel,
        exportPending: false,
        originalDocumentRotation: 0,
        nowIntervalId: 0,
        now: moment(),
        isFirstLoad: true
      };
    },
    methods: {
      ...mapActions('documentViewStore', ['loadPage']),
      setImageProperties(this: any, setImageLoaded: boolean) {
        const image = this.$refs.image as HTMLImageElement;
        const imageContainer = this.$refs.imageContainer as HTMLDivElement;
        this.imageProperties.originalWidth = image.naturalWidth;
        this.imageProperties.originalHeight = image.naturalHeight;
        this.imageProperties.containerWidth = imageContainer.clientWidth;
        this.imageProperties.containerHeight = imageContainer.clientHeight;
        if (setImageLoaded && this.isFirstLoad) {
          this.isFirstLoad = false;
          this.imageLoaded = moment()
            .format()
            .toString();
        }
        this.$nextTick(() => {
          this.setImageFooterProperties();
        });
      },
      setImageFooterProperties(this: any) {
        const imageContainer = this.$refs.imageContainer as HTMLDivElement;
        this.imageFooterProperties.imageContainerOffsetHeight = imageContainer.offsetHeight;
        this.imageFooterProperties.imageContainerHeight = imageContainer.clientHeight;
        this.imageFooterProperties.imageContainerWidth = imageContainer.clientWidth;
        const imageFooter = this.$refs.imageFooter as HTMLDivElement;
        this.imageFooterProperties.imageFooterHeight = imageFooter.clientHeight;
        this.imageFooterProperties.imageFooterWidth = imageFooter.clientWidth;
        const viewerContainer = this.$refs.viewerContainer as HTMLDivElement;
        this.imageFooterProperties.viewerContainerHeight = viewerContainer.clientHeight;
      },
      async getDocumentActions(this: any) {
        this.documentActions = await DocumentService.getDocumentActionsAsync(this.documentSearchModel).catch(
          (reason: any) => {
            this.documentActions = {} as DocumentActionsModel;
          }
        );
      },
      async exportDocument(this: any) {
        this.exportPending = true;
        await DocumentService.exportDocumentAsync(
          this.documentSearchModel.cabinetId,
          this.document?.id ? this.document.id : this.documentSearchModel.documentId
        )
          .then((response) => {
            const contentDisposition = response.headers['content-disposition'];
            const blobObject = new Blob([response.data]);
            let fileName = 'unknown';
            if (contentDisposition) {
              const fileNameMatch = contentDisposition.match(/filename=(.+);/);
              if (fileNameMatch.length === 2) {
                fileName = fileNameMatch[1];
              }
            }
            if (window.navigator && window.navigator.msSaveOrOpenBlob) {
              window.navigator.msSaveOrOpenBlob(blobObject, fileName);
              this.exportPending = false;
              return;
            }
            const url = window.URL.createObjectURL(new Blob([response.data]));
            const link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', fileName);
            document.body.appendChild(link);
            link.click();
            this.exportPending = false;
          })
          .catch((error: any) => {
            const reader = new FileReader();
            const { data } = error.response.data;
            reader.readAsText(error.response.data);
            reader.onload = () => {
              SnotifyConfiguration.showError(reader.result as string);
            };
            this.exportPending = false;
          });
      },
      setNowToNow(this: any) {
        this.now = moment();
      },
      onViewerContainerResize(this: any, tab: HTMLElement) {
        this.$nextTick(() => {
          this.setImageProperties(false);
        });
      },
      onImageContainerResize(this: any, tab: HTMLElement) {
        this.$nextTick(() => {
          this.setImageFooterProperties(false);
        });
      }
    },
    computed: {
      ...mapGetters('documentViewStore', [
        'document',
        'hasDocumentError',
        'isPageLoading',
        'hasDocumentLoaded',
        'documentSearchModel',
        'documentPage',
        'showLoadingSpinner',
        'currentPage'
      ]),
      imageStyles(this: any): string {
        return `width: ${this.imageProperties.width}px;
      height: ${this.imageProperties.height}px;
      transform: rotate(${this.imageProperties.rotationDegrees}deg);
      padding: ${this.imageProperties.containerPadding}px;
      marginTop: ${this.imageProperties.marginTop}px;
      marginBottom: ${this.imageProperties.marginBottom}px;
      marginLeft: ${this.imageProperties.marginLeft}px;
      marginRight: ${this.imageProperties.marginRight}px;`;
      },
      isUnsupportedFileType(this: any): boolean {
        return this.document.errorCode === ErrorCode.UnsupportedFileType;
      },
      conversionHasTakenLongerThanConfiguredPeriod(this: any) {
        const requestedDate = moment(this.document.conversionRequestedDate);
        return (
          requestedDate.diff(this.now, 's') < -this.appSettings.presentExportOptionWhenConvertingDocumentAfterSeconds
        );
      },
      imageFooterStyles(this: any): string {
        const imageFooterBottomMargin = 2;
        const left = Math.floor(
          (this.imageFooterProperties.imageContainerWidth - this.imageFooterProperties.imageFooterWidth) / 2
        );
        const maxWidth = Math.floor(this.imageFooterProperties.imageContainerWidth / 2);
        const imageHorizontalScrollbarHeight =
          this.imageFooterProperties.imageContainerOffsetHeight - this.imageFooterProperties.imageContainerHeight;
        const top =
          this.imageFooterProperties.viewerContainerHeight -
          (this.imageFooterProperties.imageFooterHeight + imageHorizontalScrollbarHeight + imageFooterBottomMargin);
        return `left: ${left}px; top: ${top}px; max-width: ${maxWidth}px`;
      },
      hasImageFooterSlot() {
        return !!this.$slots.imageFooter;
      },
      isPageLoaded(): boolean {
        return !this.isPageLoading && !this.document.hasNotification && !this.document.isBeingConverted;
      },
      toolbarOptions(): DocumentViewerToolbarOptionsModel {
        const defaultToolOptions: DocumentViewerToolbarOptionsModel = {
          allowPageNavigation: true
        };
        return this.toolOptions ? this.toolOptions : defaultToolOptions;
      },
      isPageConverted(): boolean {
        return !this.document.hasNotification && this.document.viewConversionId;
      }
    },
    watch: {
      isPageLoading(this: any) {
        if (this.isPageLoading) {
          if (this.document.id === this.documentSearchModel.documentId) {
            this.originalDocumentRotation = this.imageProperties.rotationDegrees;
          }
          if (!this.document.id) {
            this.originalDocumentRotation = 0;
          }
        } else {
          if (this.document.id === this.documentSearchModel.documentId) {
            this.imageProperties.rotationDegrees = this.originalDocumentRotation;
          } else {
            this.imageProperties.rotationDegrees = 0;
          }
        }
      }
    },
    async mounted(this: any) {
      if (this.loadFirstPage) {
        this.loadPage(1);
      }
      this.getDocumentActions();
      this.nowIntervalId = setInterval(this.setNowToNow, 1000);

      const viewerContainer = document.getElementById('viewerContainer') as HTMLElement;
      this.viewerResizeObserver = new ResizeObserver(() => this.onViewerContainerResize(viewerContainer));
      this.viewerResizeObserver.observe(viewerContainer);

      const imageContainer = document.getElementById('imageContainer') as HTMLElement;
      this.imageResizeObserver = new ResizeObserver(() => this.onImageContainerResize(imageContainer));
      this.imageResizeObserver.observe(imageContainer);
    },
    beforeDestroy(this: any) {
      clearInterval(this.nowIntervalId);
      this.viewerResizeObserver.disconnect();
      this.imageResizeObserver.disconnect();
    },
    components: {
      LoadingSpinner,
      DocumentViewerToolbar,
      MStoreThumbnailViewList
    },
    directives: {
      dragscroll
    }
  });
</script>
