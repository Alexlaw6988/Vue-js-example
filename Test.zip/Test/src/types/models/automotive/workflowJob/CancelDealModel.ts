import { WorkflowDataSourceModel } from '@/types';

export interface CancelDealModel {
  jobId: number;
  queueId: number;
  workflowDataSources: WorkflowDataSourceModel[];
}
