import IActionButtonHandler from '@/classes/interfaces/IActionButtonHandler';
import { ActionButtonType } from '@/types/enums/ActionButtonType';
import ViewRelatedDocumentActionButtonHandler from '@/classes/ViewRelatedDocumentActionButtonHandler';
import TooltipActionButtonHandler from '@/classes/TooltipActionButtonHandler';
import ViewCurrentDocumentActionButtonHandler from '@/classes/ViewCurrentDocumentActionButtonHandler';

export const ActionButtonHandler = {
  methods: {
    getActionButtonState(actionButtonType: ActionButtonType, actionButtonProperties: any) {
      const handler = this.makeHandler(actionButtonType);
      return handler.getActionButtonState(actionButtonProperties);
    },
    performButtonClick(actionButtonType: ActionButtonType, actionButtonState: any) {
      const handler = this.makeHandler(actionButtonType);
      handler.performButtonClick(actionButtonState);
    },
    makeHandler(actionButtonType: ActionButtonType): IActionButtonHandler {
      switch (actionButtonType) {
        case ActionButtonType.ViewRelatedDocument: {
          return new ViewRelatedDocumentActionButtonHandler();
        }
        case ActionButtonType.Tooltip: {
          return new TooltipActionButtonHandler();
        }
        case ActionButtonType.CurrentDocument: {
          return new ViewCurrentDocumentActionButtonHandler();
        }
        default: {
          return {} as IActionButtonHandler;
        }
      }
    }
  }
};
