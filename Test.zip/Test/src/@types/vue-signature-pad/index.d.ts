declare module 'vue-signature-pad';
