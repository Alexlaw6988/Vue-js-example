import { Oidc } from '@/types';

const OidcCallback = () => import(/* webpackChunkName: "OidcCallback" */ '@/views/OidcCallback.vue');
const OidcSilentRefresh = () => import(/* webpackChunkName: "OidcSilentRefresh" */ '@/views/OidcSilentRefresh.vue');
const OidcCallbackError = () => import(/* webpackChunkName: "OidcCallbackError" */ '@/views/OidcCallbackError.vue');

const layout = 'Loading';

const isOidcCallback = true;

const isPublic = true;

export const OidcRoutes = [
  {
    ...Oidc.Callback,
    component: OidcCallback,
    meta: {
      isOidcCallback,
      isPublic,
      layout
    }
  },
  {
    ...Oidc.SilentRefresh,
    component: OidcSilentRefresh,
    meta: {
      isVuexOidcCallback: true,
      isOidcCallback,
      isPublic
    }
  },
  {
    ...Oidc.Error,
    component: OidcCallbackError,
    meta: {
      isPublic,
      layout
    }
  }
];
