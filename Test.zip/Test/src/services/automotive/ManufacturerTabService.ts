import axios from 'axios';
import { ManufacturerTabModel, WorkflowDataSourceModel } from '@/types';

const ManufacturerTabApiUrl = 'automotive/manufacturertab/';

export const ManufacturerTabService = {
  async getManufacturerTabAsync(
    queueId: number,
    jobId: number,
    saleType: string,
    manufacturer: string
  ): Promise<ManufacturerTabModel> {
    const response = await axios.get(`${ManufacturerTabApiUrl}${queueId}/${jobId}/${saleType}/${manufacturer}`);
    return response.data;
  },
  async updateManufacturerTabDataSourceAsync(
    queueId: number,
    jobId: number,
    saleType: string,
    manufacturer: string,
    manufacturerDataSource: WorkflowDataSourceModel
  ) {
    await axios.post(`${ManufacturerTabApiUrl}${queueId}/${jobId}/${saleType}/${manufacturer}`, manufacturerDataSource);
  }
};
