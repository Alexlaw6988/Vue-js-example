<template>
  <div class="form-group">
    <label v-if="label" :for="labelFor">
      {{ label }}
      <span v-if="isRequired" class="text-danger">*</span>
    </label>
    <slot></slot>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  export default Vue.extend({
    name: 'm-form-group',
    props: {
      label: {
        type: String,
        required: true
      },
      labelFor: {
        type: String
      },
      isRequired: {
        type: Boolean,
        required: false
      }
    }
  });
</script>
