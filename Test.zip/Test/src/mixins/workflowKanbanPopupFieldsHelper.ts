import { MStorePopupHelper } from './mStorePopupHelper';

export const WorkflowKanbanPopupFieldsHelper = {
  methods: {
    showPopupFieldsModal() {
      MStorePopupHelper.methods.setComponent('WorkflowKanbanPopupFields');
      MStorePopupHelper.methods.openModal();
    },
    closeModal() {
      MStorePopupHelper.methods.closeModal();
    }
  }
};
