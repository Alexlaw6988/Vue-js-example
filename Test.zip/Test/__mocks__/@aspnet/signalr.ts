let SignalR = jest.genMockFromModule('@aspnet/signalr');

class HubConnection {
  public on(methodName: string, callback: () => string): Promise<void> {
    this.successCallback = callback;
    return Promise.resolve();
  }

  public start(): Promise<void> {
    return Promise.resolve();
  }

  public successCallback: () => string = () => 'failure';

  public onclose(...args: any[]) {
    return Promise.resolve();
  }
}

class HubConnectionBuilder {
  constructor(...args: any[]) {}

  public withUrl() {
    return {
      configureLogging: () => {
        return {
          build: () => hubConnection
        };
      }
    };
  }
}

let hubConnection = new HubConnection();

enum LogLevel {
  Information
}

SignalR = {
  HubConnectionBuilder,
  HubConnection: hubConnection,
  LogLevel
};

module.exports = SignalR;
