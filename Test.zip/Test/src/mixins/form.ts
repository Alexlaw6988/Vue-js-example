import { mapActions } from 'vuex';

export const Form = {
  methods: {
    ...mapActions('applicationDirtyStore', ['setApplicationDirty']),
    handleSubmit(this: any) {
      this.$validator.validate().then((valid: any) => {
        if (valid) {
          this.setApplicationDirty(false);
          this.submit();
        }
      });
    }
  }
};
