import axios from 'axios';
import { OrganisationModel, OrganisationSearchModel } from '@/types';
import AxiosConfiguration from '@/classes/AxiosConfiguration';

const OrganisationApiUrl = 'organisations';

export const OrganisationService = {
  async checkMaintenancePermissions(): Promise<any> {
    const response = await AxiosConfiguration.axiosWithErrorPage.get(
      `${OrganisationApiUrl}/CheckMaintenancePermissions`
    );
    return response.data;
  },
  async getOrganisationsAsync(organisationSearchModel: OrganisationSearchModel): Promise<OrganisationModel[]> {
    const response = await AxiosConfiguration.axiosWithErrorPage.get(`${OrganisationApiUrl}`, {
      params: {
        isDeactivated: organisationSearchModel.isDeactivated
      }
    });
    return response.data;
  },
  async getOrganisationAsync(id: number): Promise<OrganisationModel> {
    const response = await AxiosConfiguration.axiosWithErrorPage.get(`${OrganisationApiUrl}/${id}`);
    return response.data;
  },
  async createOrganisationAsync(organisationModel: OrganisationModel) {
    const response = await axios.post(OrganisationApiUrl, organisationModel);
    return response.data;
  },
  async updateOrganisationAsync(id: number, organisationModel: OrganisationModel) {
    const response = await axios.put(OrganisationApiUrl.concat(`/${id}`), organisationModel);
    return response.data;
  }
};
