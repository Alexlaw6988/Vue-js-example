import { BaseModel } from '../BaseModel';
import { DocumentReferenceModel } from '../documentReference/DocumentReferenceModel';

export interface DocumentInformationModel extends BaseModel {
  documentFields: [];
  referenceFields: DocumentReferenceModel[];
}
