import { SourceDocumentTypeSettingsModel, LockModel } from '@/types';

export interface DocumentToStoreModel {
  sourceDocumentTypeSettings: SourceDocumentTypeSettingsModel;
  lock: LockModel;
}