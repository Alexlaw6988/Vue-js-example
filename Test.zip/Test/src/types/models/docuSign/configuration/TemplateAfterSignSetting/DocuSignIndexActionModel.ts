export interface DocuSignIndexActionModel {
  id: number;
  description: string;
}
