import axios from 'axios';
import { NavBarAccessModel } from '@/types';

export const NavBarAccessService = {
  async getNavBarAccessAsync(): Promise<NavBarAccessModel> {
    const response = await axios.get('navbaraccess/');
    return response.data;
  }
};
