import { BaseModel } from '../../BaseModel';
import { DynamicFormModel, WorkflowDataSourceModel } from '@/types';

export interface SignersTabModel extends BaseModel {
  signersDataSource: WorkflowDataSourceModel;
  dynamicForm: DynamicFormModel;
}
