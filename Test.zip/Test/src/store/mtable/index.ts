import { actions } from './actions';
import { getters } from './getters';
import { mutations } from './mutations';
import { TableStateModel } from '@/types';

export function defaultMtableState() {
  return {
    stateKey: '',
    showFilters: false,
    currentPage: 1,
    itemsPerPage: 10,
    searchQuery: '',
    sortBy: '',
    sortDesc: false,
    selectedPk: '',
    filteredItems: []
  } as TableStateModel;
}

function initialMtableState() {
  return [
    {
      stateKey: '',
      showFilters: false,
      currentPage: 1,
      itemsPerPage: 10,
      searchQuery: '',
      sortBy: '',
      sortDesc: false,
      selectedPk: '',
      filteredItems: []
    }
  ] as TableStateModel[];
}

export const state: TableStateModel[] = initialMtableState();

const namespaced: boolean = true;

export const mTable = {
  namespaced,
  state,
  actions,
  getters,
  mutations,
  defaultMtableState
};
