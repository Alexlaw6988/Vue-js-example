export interface ManufacturerTabSearchModel {
  queueId: number;
  jobId: number;
  saleType: string;
  manufacturer: string;
}
