<template>
  <div :class="`h-100 ${backgroundColor}`">
    <splitpanes watch-slots class="default-theme" v-show="!isLoading" @resized="onResized">
      <div
        :splitpanes-size="leftPaneSize"
        :splitpanes-min="minPaneSize"
        :splitpanes-max="maxPaneSize"
        class="sidebarWrapper"
      >
        <router-view name="treeView" v-bind:loading.sync="isLoading" :key="$route.fullPath" />
      </div>
      <div :splitpanes-size="rightPaneSize" class="contentWrapper" v-if="!isLoading">
        <slot />
      </div>
    </splitpanes>
    <loading-spinner v-if="isLoading" :isLoading="isLoading" />
  </div>
</template>

<script lang="ts">
  import { Vue } from 'vue-property-decorator';
  import Splitpanes from 'splitpanes';
  import 'splitpanes/dist/splitpanes.css';
  import LoadingSpinner from '@/components/shared/LoadingSpinner.vue';
  import { mapActions, mapGetters } from 'vuex';
  import { WorkflowTreeView } from '@/types/store/userPreferences';

  export default Vue.extend({
    name: 'TreeViewLayout',
    data() {
      return {
        isLoading: false,
        leftPaneSize: 20,
        rightPaneSize: 0,
        minPaneSize: 15,
        maxPaneSize: 25
      };
    },
    methods: {
      ...mapActions('userPreferencesStore', ['setWorkflowTreeView']),
      initializePaneSize(this: any) {
        this.leftPaneSize = 20;
        const workflowTreeViewPreferences = this.getWorkflowTreeViewPreferences();

        if (workflowTreeViewPreferences) {
          if (window.innerWidth >= workflowTreeViewPreferences.screenWidth) {
            this.leftPaneSize = workflowTreeViewPreferences.verticalTabWidth;
          }
        }
        this.rightPaneSize = 100 - this.leftPaneSize;
      },
      onResized(this: any, panes: any) {
        this.setWorkflowTreeView({
          verticalTabWidth: panes[0].width,
          screenWidth: window.innerWidth
        } as WorkflowTreeView);
      }
    },
    computed: {
      backgroundColor(this: any): string {
        return this.isLoading ? 'bg-light-gray' : '';
      },
      currentTreeViewVerticalTabWidth(this: any) {
        return this.getWorkflowTreeViewPreferences().verticalTabWidth;
      },
      ...mapGetters('userPreferencesStore', ['getWorkflowTreeViewPreferences'])
    },
    watch: {
      currentTreeViewVerticalTabWidth() {
        this.initializePaneSize();
      }
    },
    created() {
      this.initializePaneSize();
    },
    components: {
      Splitpanes,
      LoadingSpinner
    }
  });
</script>
