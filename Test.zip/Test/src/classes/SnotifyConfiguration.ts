import { SnotifyToast } from 'vue-snotify';
import Clipboard from 'clipboard';

export default class SnotifyConfiguration {
  public static configure(vm: any) {
    this.vm = vm;
  }

  public static showError(message: string) {
    const toast = this.vm.$snotify.error(message, 'Error', {
      timeout: 0,
      closeOnClick: false,
      buttons: [
        { text: 'Copy to clipboard', className: 'btnCopyToClipboard', action: () => true },
        { text: 'Close', action: (toast: SnotifyToast) => this.vm.$snotify.remove(toast.id) }
      ]
    });
    toast.on('mounted', (toast: SnotifyToast) => {
      const clipboard = new Clipboard(document.getElementsByClassName('btnCopyToClipboard')[0], {
        text: () => {
          return toast.body;
        },
        container: document.getElementsByClassName('snotifyToast')[0] as Element
      });
      clipboard.on('error', (error) => {
        alert('Failed to copy to clipboard, please manually copy the error code.');
        this.vm.$log(error);
      });
    });
  }

  public static showInformation(message: string) {
    this.vm.$snotify.warning(message, {
      timeout: 0,
      closeOnClick: false,
      buttons: [{ text: 'Close', action: (toast: SnotifyToast) => this.vm.$snotify.remove(toast.id) }]
    });
  }

  public static showSuccess(message: string) {
    this.vm.$snotify.success(message, {
      timeout: 3000
    });
  }

  public static clear() {
    this.vm.$snotify.clear();
  }

  private static vm: any;
}
