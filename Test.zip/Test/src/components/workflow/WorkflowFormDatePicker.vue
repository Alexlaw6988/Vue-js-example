<template>
  <m-store-form-date-picker
    :id="inputProperties.htmlElementId"
    :label="inputProperties.fieldLabel"
    v-model="inputValue"
    :lang="inputProperties.additionalProperties.lang"
    :placeholder="inputProperties.additionalProperties.placeholder"
    :input-attr="{ id: inputProperties.htmlElementId }"
    :name="inputProperties.fieldLabel"
    :append-to-body="true"
    :popup-style="popupStyle"
    :editable="!inputProperties.isReadonly"
    :clearable="!inputProperties.isReadonly"
    :disabled="isDisabled"
    :validation="validationRule"
    format="DD/MM/YYYY"
    width="100%"
    @keypress.enter.native.prevent.self
  />
</template>

<script lang="ts">
  import Vue from 'vue';
  import moment from 'moment';
  import { FormFieldValidation } from '@/mixins/formValidation';
  import MStoreFormDatePicker from '@/components/shared/MStoreFormDatePicker.vue';
  import { ValidationModel } from '@/types/models/validation';

  export default Vue.extend({
    name: 'WorkflowFormDatePicker',
    mixins: [FormFieldValidation],
    props: {
      inputProperties: {
        type: Object,
        required: true
      },
      data: {
        required: true
      },
      ignoreIsRequired: {
        type: Boolean,
        default: false
      },
      isDisabled: {
        type: Boolean,
        default: false
      }
    },
    computed: {
      validationRule(this: any): ValidationModel {
        return {
          required: this.inputProperties.isRequired && !this.ignoreIsRequired
        } as ValidationModel;
      },
      inputValue: {
        get(this: any) {
          return this.data;
        },
        set(this: any, value: string) {
          this.$emit(
            'update:data',
            value
              ? moment(value)
                  .locale('en-gb')
                  .format('YYYY-MM-DDTHH:mm:SS')
              : null
          );
        }
      },
      popupStyle(this: any): object {
        const styles = {} as any;
        if (this.inputProperties.isReadonly) {
          styles.visibility = 'hidden';
        }
        return styles;
      }
    },
    components: {
      MStoreFormDatePicker
    }
  });
</script>
