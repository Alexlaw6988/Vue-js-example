import { actions } from './actions';
import { getters } from './getters';
import { mutations } from './mutations';
import { AutomotiveWorkflowJobState, ManufacturerTabModel } from '@/types';

export const state: AutomotiveWorkflowJobState = {
  manufacturerTab: {} as ManufacturerTabModel,
  isManufacturerTabLoading: true,
  isLoading: false,
  error: false,
  errorMessage: ''
};

const namespaced: boolean = true;

export const automotiveWorklowJob = {
  namespaced,
  state,
  actions,
  getters,
  mutations
};
