import { MutationTree } from 'vuex';
import { GroupedTableStateModel, GroupedTableMutationTypes, Dictionary } from '@/types';

export const mutations: MutationTree<GroupedTableStateModel> = {
  [GroupedTableMutationTypes.updateLastExpandedGroups](state, expandedGroups: Dictionary<string[]>) {
    state.lastExpandedGroups = expandedGroups;
  }
};
