<template>
  <div class="card-header">
    <slot name="before-row"></slot>
    <div class="row">
      <slot name="before-search-box"></slot>
      <div class="col col-xl-3">
        <m-store-filter
          data-testid="searchbox-input"
          v-model="localSearchQuery"
          placeholder="Start typing to search.."
          label="Search"
        />
      </div>
      <slot name="after-search-box"></slot>
      <div class="col col-xl-2" v-if="showItemsPerPage">
        <b-form-group :label="`Show ${localItemsPerPage} items`">
          <b-form-select
            data-testid="items-per-page-select"
            size="md"
            :options="localPageOptions"
            v-model="localItemsPerPage"
            class="w-auto"
          />
        </b-form-group>
      </div>
      <slot name="after-items-per-page" v-if="showItemsPerPage"></slot>
    </div>
    <slot name="after-row"></slot>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  import MStoreFilter from '@/components/shared/MStoreFilter.vue';
  import { AppSettingsHelper } from '@/mixins/appSettingsHelper';
  export default Vue.extend({
    name: 'HeaderFilters',
    mixins: [AppSettingsHelper],
    props: {
      itemsPerPage: {
        type: Number,
        required: false
      },
      searchQuery: {
        type: String,
        default: ''
      },
      showItemsPerPage: {
        type: Boolean,
        default: true
      }
    },
    data() {
      return {
        pageOptions: null
      };
    },
    methods: {
      initializePageOptions(this: any) {
        if (!this.itemsPerPage || this.localPageOptions.indexOf(this.itemsPerPage) === -1) {
          this.localItemsPerPage = this.paginationOptions?.defaultValue;
        }
      }
    },
    computed: {
      localItemsPerPage: {
        get(this: any) {
          return this.itemsPerPage;
        },
        set(this: any, value: any) {
          this.$emit('update:itemsPerPage', value);
        }
      },
      localSearchQuery: {
        get(this: any) {
          return this.searchQuery;
        },
        set(this: any, value: any) {
          this.$emit('update:searchQuery', value);
        }
      },
      localPageOptions(this: any) {
        if (this.pageOptions) {
          return this.pageOptions;
        }
        const PAGE_OPTIONS = [];
        for (
          let i = this.paginationOptions?.minValue;
          i <= this.paginationOptions?.maxValue;
          i = i + this.paginationOptions?.incrementBy
        ) {
          PAGE_OPTIONS.push(i);
        }
        return PAGE_OPTIONS;
      }
    },
    mounted(this: any) {
      this.initializePageOptions();
    },
    components: { MStoreFilter }
  });
</script>
