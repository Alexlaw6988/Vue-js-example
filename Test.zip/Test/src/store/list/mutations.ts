import { MutationTree } from 'vuex';
import { ListState, ListModel } from '@/types';

export const mutations: MutationTree<ListState> = {
  REQUEST_LIST(state, listId: number) {
    state.requestedListIds.push(listId);
  },
  ADD_LIST(state, list: ListModel) {
    state.lists.push(list);
    state.error = false;
  },
  UPDATE_LIST(state, list: ListModel) {
    const index = state.lists.findIndex((x: ListModel) => x.id === list.id);
    if (index) {
      Object.assign(state.lists[index], list);
    }
    state.error = false;
  },
  REMOVE_LIST(state, list: ListModel) {
    const index = state.lists.findIndex((x: ListModel) => x.id === list.id);
    if (index) {
      state.lists.splice(index, 1);
    }
  },
  UPDATE_LIST_ERROR(state, payload: any) {
    state.error = true;
    state.errorMessage = JSON.stringify(payload);
  }
};
