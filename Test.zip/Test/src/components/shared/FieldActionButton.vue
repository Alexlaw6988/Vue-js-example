<template>
  <div class="fieldActionButton">
    <div :id="actionButtonId" @hover="show != show">
      <b-button
        class="ml-1"
        @click="onActionButtonClicked"
        :disabled="actionButtonState.disabled || isDisabled"
        :variant="actionButtonState.variant"
      >
        <font-awesome-icon :icon="actionButtonState.icon" />
      </b-button>
    </div>
    <b-tooltip :show="showTooltip" :target="actionButtonId" placement="bottom">
      {{ actionButtonStateTooltip }}
    </b-tooltip>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  import { FieldActionButtonStateModel } from '@/types/models';

  export default Vue.extend({
    name: 'FieldActionButton',
    data() {
      return {
        show: false
      };
    },
    props: {
      actionButtonState: {
        type: Object as () => FieldActionButtonStateModel,
        required: true
      },
      buttonId: {
        type: String,
        required: true
      },
      isDisabled: {
        type: Boolean,
        default: false
      }
    },
    methods: {
      onActionButtonClicked() {
        this.$emit('actionButtonClicked');
      }
    },
    computed: {
      actionButtonId(this: any) {
        return `${'actionButton-'}${this.buttonId}`;
      },
      showTooltip(this: any) {
        return !this.actionButtonState.disabled && !this.isDisabled && this.show;
      },
      actionButtonStateTooltip(this: any) {
        return this.actionButtonState.disabled || this.isDisabled ? 'No Document' : this.actionButtonState.tooltip;
      }
    }
  });
</script>
