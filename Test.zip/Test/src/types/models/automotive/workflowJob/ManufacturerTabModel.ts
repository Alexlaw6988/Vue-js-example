import { DynamicFormModel, WorkflowDataSourceModel } from '@/types';

export interface ManufacturerTabModel {
  manufacturerDataSource: WorkflowDataSourceModel;
  dynamicForm: DynamicFormModel;
}
