import SessionStorageService from '@/services/SessionStorageService';
import { mstoreSettings } from './mstoreSettings';

SessionStorageService.addSessionId(mstoreSettings.sessionId);

export const oidcSettings = {
  authority: mstoreSettings.authServerAuthority,
  client_id: 'AP03T3S6HFVHERFKEW4KWP4MHA10SS08',
  redirect_uri: `${mstoreSettings.baseUrl}/oidc-callback`,
  response_type: 'id_token token',
  scope: 'openid profile mstoreV5 IdentityServerApi',
  automaticSilentRenew: true,
  silent_redirect_uri: `${mstoreSettings.baseUrl}/silent-refresh-oidc`,
  post_logout_redirect_uri: mstoreSettings.baseUrl
};
