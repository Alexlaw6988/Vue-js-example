import {
    DocuSignDocumentTypesState, RootState 
} from '@/types';
import { GetterTree } from 'vuex';

export const getters: GetterTree<DocuSignDocumentTypesState, RootState> = {
    getDocumentTypeId(state) {
        return state.documentTypeId;
    }
};
