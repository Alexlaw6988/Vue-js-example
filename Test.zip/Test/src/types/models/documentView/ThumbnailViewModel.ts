import { BaseModel } from '../BaseModel';

export interface ThumbnailViewModel extends BaseModel {
  documentData: string;
  page: number;
}