export enum StandardRole {
  Administrator = -1,
  Arena = -2,
  Everyone = -3,
  DefaultRole = -4,
  Controllers = -5
}
