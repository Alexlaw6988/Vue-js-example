export interface DocuSignTemplatesSearchModel {
    documentTypeId: number | null;
}