<template>
  <ExpiryModal
    :showModal="expiresInLessThanFortySeconds"
    @extend="extendLock"
    @expired="expired"
    :buttons="buttons"
    @buttonClicked="buttonClicked"
    title="Your job lock is about to expire"
    caption="Your lock on this job will expire in"
    instruction="You can extend the lock if you want to continue working on it"
    extendButtonCaption="Extend Lock"
    :expirySecondsLeft="expirySecondsLeft"
  ></ExpiryModal>
</template>

<script lang="ts">
  import Vue from 'vue';
  import moment from 'moment';
  moment.locale('en-gb');
  import { ButtonModel, ErrorModel } from '@/types';
  import ExpiryModal from '@/components/shared/ExpiryModal.vue';
  import { mapActions, mapGetters } from 'vuex';

  export default Vue.extend({
    props: {
      lastActivity: {
        type: Date,
        required: true
      }
    },
    data() {
      return {
        now: moment(),
        nowIntervalId: 0,
        buttons: [
          {
            caption: 'Return to queue',
            id: 'returnToQueue',
            class: 'mr-2',
            icon: 'undo-alt',
            variant: 'primary'
          }
        ] as ButtonModel[]
      };
    },
    methods: {
      ...mapActions('workflowJobStore', [
        'extendWorkflowJobLock',
        'setExtendingWorkflowJobLock',
        'setJobComponentName',
        'setJobErrorModel',
        'setIsDirty'
      ]),
      extendLock(this: any) {
        this.extendWorkflowJobLock();
      },
      buttonClicked(this: any, button: ButtonModel) {
        this.$emit('buttonClicked', button.id);
      },
      userActivity(this: any) {
        if (this.expiresInLessThanOneMinute && !this.expiresInLessThanFortySeconds && !this.extendingWorkflowJobLock) {
          this.setExtendingWorkflowJobLock(true);
          this.extendLock();
        }
      },
      expired() {
        clearInterval(this.nowIntervalId);
        this.setIsDirty(false);
        this.showErrorComponent(
          'Your lock on this job has expired',
          'If you need to work on this job, you can return to the queue and reopen the job'
        );
      },
      showErrorComponent(this: any, header: string, message: string) {
        this.setJobErrorModel({
          header,
          showHeader: true,
          message,
          icon: 'stopwatch',
          iconTheme: 'text-primary',
          showButton: true,
          buttonRouteName: 'WorkflowQueue',
          buttonRouteParams: {
            id: this.workflowJob.queueId.toString()
          },
          buttonText: 'Return to queue'
        } as ErrorModel);
        this.setJobComponentName('ErrorNotification');
      },
      setNowToNow() {
        this.now = moment();
      }
    },
    watch: {
      expirySecondsLeft(value: number) {
        if (value <= 0) {
          this.expired();
        }
      },
      lastActivity() {
        this.userActivity();
      }
    },
    computed: {
      ...mapGetters('workflowJobStore', ['workflowJob', 'extendingWorkflowJobLock', 'workflowJobLock']),
      expiresInLessThanOneMinute(): boolean {
        return this.expirySecondsLeft <= 60;
      },
      expiresInLessThanFortySeconds(): boolean {
        return this.expirySecondsLeft <= 40;
      },
      expirySecondsLeft(this: any): number {
        const expiryDate = moment(this.workflowJobLock.expires);
        const diff = expiryDate.diff(this.now);
        return Math.ceil(diff / 1000);
      }
    },
    mounted(this: any) {
      this.nowIntervalId = setInterval(this.setNowToNow, 1000);
    },
    beforeDestroy(this: any) {
      clearInterval(this.nowIntervalId);
    },
    components: {
      ExpiryModal
    }
  });
</script>
