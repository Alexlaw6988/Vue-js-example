<template>
  <LoadingSpinner :isLoading="automotiveJobIsLoading">
    <div v-if="!automotiveJobIsLoading" class="splitWrapper flex-fill w-100">
      <splitpanes watch-slots class="default-theme" @resize="onResize" @resized="onResized">
        <div
          v-if="hasVerticalJobTabs"
          :splitpanes-size="leftPaneSize"
          splitpanes-min="15"
          splitpanes-max="25"
          class="vertical-tabs overflow-y-auto"
        >
          <div @mouseover="userActivity" @touchstart="userActivity">
            <VerticalWorkflowJobTabs
              :processingAction="processingAction"
              :isLoading="isLoading || automotiveJobIsLoading || isDocumentLoadingOrBeingConverted"
            />
          </div>
        </div>
        <div
          :splitpanes-size="rightPaneSize"
          :class="`d-flex flex-column h-100 position-relative ${hasVerticalJobTabs ? 'w-100' : ''}`"
        >
          <div class="flex-1 overflow-hidden" @mouseover="userActivity" @touchstart="userActivity">
            <DocumentViewer :loadFirstPage="false" />
          </div>
          <div @mouseover="userActivity" @touchstart="userActivity">
            <HorizontalWorkflowJobTabs
              v-if="hasHorizontalJobTabs"
              :processingAction="processingAction"
              :isLoading="isLoading || automotiveJobIsLoading || isDocumentLoadingOrBeingConverted"
            />
          </div>
          <div @mouseover="userActivity" @touchstart="userActivity">
            <div title="Automatically open the next available job after processing the current job">
              <b-form-checkbox
                v-if="workflowJob.canGetNextJob"
                @input="setCanGetNextJobforCurrentQueue"
                class="float-left mt-2 ml-3 custom-switch"
                v-model="getNextJob"
              >
                <div class="mt-05">Automatically open the next job</div>
              </b-form-checkbox>
            </div>
            <WorkflowButtons
              :buttons="workflowQueueConfiguration.workflowJobButtons"
              :isLoading="isLoading || automotiveJobIsLoading"
              @close-button-clicked="closeWorkflowJobAsync"
              @process-button-clicked="onProcessButtonClickedAsync"
              @return-button-clicked="onProcessButtonClickedAsync"
              @cancel-job-button-clicked="onProcessButtonClickedAsync"
              @exception-button-clicked="onProcessButtonClickedAsync"
            />
          </div>
          <WorkflowJobLock
            v-if="workflowJob.canProcess"
            @buttonClicked="expiryModalButtonClicked"
            :lastActivity="lastActivity"
          />
        </div>
      </splitpanes>
    </div>
  </LoadingSpinner>
</template>

<script lang="ts">
  import Vue from 'vue';
  import { mapActions, mapGetters } from 'vuex';
  import DefaultWorkflowJob from '@/components/workflow/DefaultWorkflowJob.vue';
  import {
    JobTabStateModel,
    AutomotiveWorkflowJobModel,
    WorkflowJobTabsToHideModel,
    TabStateModel,
    FieldUpdateModel,
    WorkflowJobButtonModel,
    ManufacturerTabDataSourceUpdateModel,
    WorkflowStandardProcessingAction,
    WorkflowJobTabModel
  } from '@/types';
  import { AutomotiveWorkflowJobService } from '@/services/automotive/AutomotiveWorkflowJobService';
  import { ManufacturerTabService } from '@/services/automotive/ManufacturerTabService';
  import { EventBus } from '@/classes/EventBus';
  import { AutomotiveHelper, AutomotiveWorkflowJob, ObjectHelper } from '@/mixins';
  import LoadingSpinner from '@/components/shared/LoadingSpinner.vue';
  import store from '@/store';

  export default Vue.extend({
    name: 'AutomotiveWorkflowJob',
    mixins: [DefaultWorkflowJob, AutomotiveHelper, AutomotiveWorkflowJob, ObjectHelper],
    data() {
      return {
        leftPaneSize: 0,
        rightPaneSize: 0,
        automotiveWorkflowJobModel: {} as AutomotiveWorkflowJobModel,
        automotiveJobIsLoading: true
      };
    },
    methods: {
      ...mapActions('workflowJobStore', ['setJobTabStateHidden', 'setIsLoading']),
      ...mapActions('automotiveWorkflowJobStore', ['unloadAutomotiveWorkflowJob'])
    },
    computed: {
      ...mapGetters('workflowJobStore', ['workflowDataSourceField', 'jobTabState']),
      ...mapGetters('automotiveWorkflowJobStore', ['manufacturerTab']),
      cancelReason(this: any): string | undefined {
        return this.workflowDataSourceField('DealAction', 'DA_CancelReason');
      },
      cancellationValidationMessage(this: any): string | undefined {
        const requireSaleType = this.isNullOrEmpty(this.saleType);

        const requireReason = this.isNullOrEmpty(this.cancelReason);
        if (!requireSaleType && !requireReason) {
          return undefined;
        }
        if (requireSaleType && requireReason) {
          return 'Please select a Sale Type and enter a reason before cancelling.';
        }
        if (requireSaleType) {
          return 'Please select a Sale Type before cancelling.';
        }
        return 'Please enter a reason before cancelling.';
      },
      workflowJobTabsToHideModel(this: any): WorkflowJobTabsToHideModel | undefined {
        const model = this.automotiveWorkflowJobModel as AutomotiveWorkflowJobModel;
        return model.jobTabsToHide.find((x: WorkflowJobTabsToHideModel) => x.saleType === this.saleType);
      },
      getHiddenTabStateModel: () => (tabKey: string, hidden: boolean): TabStateModel => {
        return { key: tabKey, hidden } as TabStateModel;
      },
      isDocumentLoadingOrBeingConverted(this: any) {
        return (
          store.getters['documentViewStore/document'].isBeingConverted ||
          store.getters['documentViewStore/isPageLoading']
        );
      }
    },
    watch: {
      saleType(this: any) {
        this.hideTabsBasedOnSaleType();
      }
    },
    mounted(this: any) {
      this.initialise();
      this.initializeCanGetNextJob();
    },
    beforeDestroy(this: any) {
      this.unloadAutomotiveWorkflowJob();
    },
    components: {
      LoadingSpinner
    }
  });
</script>
