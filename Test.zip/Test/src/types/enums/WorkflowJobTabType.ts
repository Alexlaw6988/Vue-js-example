export enum WorkflowJobTabType {
  Standard = 1,
  Workflow = 2,
  Custom = 3
}
