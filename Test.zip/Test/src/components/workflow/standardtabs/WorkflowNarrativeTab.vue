<template>
  <div class="container-fluid narrative-tab">
    <div class="row">
      <div class="col-8">
        <div class="narrative-messages border rounded p-2 bg-light-gray">
          <LoadingSpinner v-if="isLoading" :isLoading="isLoading" />
          <div v-else>
            <div v-if="notesCount === 0" class="text-center mt-3">There are no notes yet..</div>
            <div v-else v-for="note in notes" v-bind:key="note.Id">
              <div class="card mb-1">
                <div class="card-header bg-transparent row">
                  <h6 class="col-md-8">{{ note.subject }}</h6>
                  <div class="narrative-time-and-name col-md-4">
                    <small class="float-right font-weight-bold">
                      {{ note.user }}
                    </small>
                    <br />
                    <small class="float-right mb-1">
                      <timeago :datetime="note.modifiedDate" :auto-update="60"></timeago>
                      <span v-if="note.modifiedDate > note.createdDate">&nbsp;(updated)</span>
                    </small>
                  </div>
                </div>
                <div class="card-body row">
                  <p class="mb-0 pt-2 col-md-10">{{ note.message }}</p>
                  <span v-if="note.userId === parseInt(oidcUser.id) || isUserAdministrator" class="col-md-2">
                    <button
                      variant="primary"
                      @click="deleteNote(note)"
                      :class="{
                        'btn-primary text-white': currentEditNote.id == note.id && !isEditMode
                      }"
                      class="float-right btn btn-sm btn-outline-primary mx-1"
                      title="Delete"
                    >
                      <font-awesome-icon icon="trash" style="width: 1em" />
                    </button>
                    <button
                      variant="primary"
                      @click="editNote(note)"
                      :class="{
                        'btn-primary text-white': currentEditNote.id == note.id && isEditMode
                      }"
                      class="float-right btn btn-sm btn-outline-primary mx-1"
                      title="Edit"
                    >
                      <font-awesome-icon icon="edit" style="width: 1em" />
                    </button>
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-4">
        <div class="narrative-form d-flex align-items-center">
          <m-form @submit.prevent="onSubmit" class="p-1 flex-fill align-self-center" data-vv-scope="narrativeForm">
            <b-form-group>
              <b-form-input
                id="subject"
                name="subject"
                placeholder="Subject"
                v-model="subject"
                v-validate="'required|max:100'"
                :state="validateInputState('subject', 'narrativeForm')"
                :disabled="isLoading || isCreating"
                class="m-0"
              />
              <b-form-invalid-feedback id="subject-feedback">
                {{ errors.first('subject', 'narrativeForm') }}
              </b-form-invalid-feedback>
            </b-form-group>
            <b-form-group>
              <b-form-textarea
                id="message"
                name="message"
                placeholder="Message"
                v-model="message"
                v-validate="'required|max:65536'"
                :state="validateInputState('message', 'narrativeForm')"
                :disabled="isLoading || isCreating"
                rows="4"
              ></b-form-textarea>
              <b-form-invalid-feedback id="message-feedback">
                {{ errors.first('message', 'narrativeForm') }}
              </b-form-invalid-feedback>
            </b-form-group>
            <div class="d-flex">
              <b-button
                type="submit"
                variant="primary"
                class="btn btn-sm text-white flex-fill mr-2"
                :disabled="disabled"
              >
                <font-awesome-icon :icon="`${isEditMode ? 'check' : 'envelope'}`" size="sm" class="mr-2" />
                {{ isEditMode ? 'Update' : 'Add' }}
                <font-awesome-icon icon="spinner" size="sm" class="ml-2" :hidden="!isCreating" spin />
              </b-button>
              <b-button
                type="reset"
                @click="onReset()"
                variant="danger"
                class="btn btn-sm text-white flex-fill ml-2"
                :disabled="this.isLoading || this.isCreating"
              >
                <font-awesome-icon :icon="`${isEditMode ? 'times' : 'trash'}`" size="sm" class="mr-2" />
                {{ isEditMode ? 'Cancel Update' : 'Clear' }}
              </b-button>
            </div>
          </m-form>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  import { NoteService } from '@/services/NoteService';
  import { mapGetters, mapActions } from 'vuex';
  import LoadingSpinner from '@/components/shared/LoadingSpinner.vue';
  import { WorkflowJobModel, NoteModel, NoteCreateModel, EntityType, TabStateModel, EVENT_BUS } from '@/types';
  import { FormFieldValidation } from '@/mixins/formValidation';
  import { ModalHelpers, TabsHelper } from '@/mixins';
  import { EventBus } from '@/classes/EventBus';

  export default Vue.extend({
    name: 'WorkflowNarrativeTab',
    mixins: [FormFieldValidation, ModalHelpers, TabsHelper],
    props: {
      workflowJobModel: {
        type: Object as () => WorkflowJobModel,
        required: true
      }
    },
    data() {
      return {
        isLoading: false,
        isCreating: false,
        isEditing: false,
        subject: '',
        message: '',
        notes: {} as NoteModel[],
        isEditMode: false,
        currentEditNote: {} as NoteModel,
        isUserAdmin: false
      };
    },
    mounted() {
      this.getNotesAsync(this.workflowJobModel.jobId);
      EventBus.$on(EVENT_BUS.RESET_TAB_DIRTY, () => this.onReset());
    },
    methods: {
      getNotesAsync(this: any, jobId: number) {
        this.isLoading = true;
        NoteService.getNotesAsync(EntityType.WorkflowJob, jobId.toString())
          .then((result: NoteModel[]) => {
            this.notes = result;
            this.$emit('tabItemCountChanged', {
              key: 'Narrative',
              itemCount: this.notesCount
            } as TabStateModel);
            this.handleTabsLoaded();
            this.isLoading = false;
          })
          .catch((reason: any) => {
            this.isLoading = false;
            return {} as NoteModel[];
          });
        this.isEditMode = false;
      },
      async createNoteAsync(jobId: number) {
        this.isCreating = true;
        await NoteService.createNoteAsync(EntityType.WorkflowJob, jobId.toString(), {
          subject: this.subject,
          message: this.message
        } as NoteCreateModel).catch((reason: any) => {
          this.isCreating = false;
        });
        this.isCreating = false;
      },
      async updateNoteAsync(jobId: number, editNote: NoteModel) {
        this.isEditing = true;
        await NoteService.updateNoteAsync(EntityType.WorkflowJob, jobId.toString(), {
          subject: this.subject,
          message: this.message,
          id: editNote.id,
          userId: editNote.userId
        } as NoteModel).catch((reason: any) => {
          this.isEditing = false;
        });
        this.isEditing = false;
        this.isEditMode = false;
      },
      async deleteNoteAsync(jobId: number, deleteNoteId: number) {
        await ModalHelpers.methods
          .showDeleteModalAsync(this.$bvModal, 'Are you sure you want to delete this note?')
          .then(async (result: boolean) => {
            if (result) {
              await NoteService.deleteNoteAsync(EntityType.WorkflowJob, jobId.toString(), deleteNoteId)
                .then((result: any) => {
                  this.getNotesAsync(this.workflowJobModel.jobId);
                })
                .catch((reason: any) => {
                  this.isEditing = false;
                });
            }
            this.setFieldsToEmpty();
          });
      },
      async onSubmit(this: any) {
        const isValid = await this.validateFormAsync('narrativeForm');
        if (isValid) {
          if (!this.isEditMode) {
            await this.createNoteAsync(this.workflowJobModel.jobId);
          } else {
            await this.updateNoteAsync(this.workflowJobModel.jobId, this.currentEditNote);
          }
          this.setFieldsToEmpty();
          this.$validator.reset();
          await this.getNotesAsync(this.workflowJobModel.jobId);
        }
      },
      onReset() {
        this.setFieldsToEmpty();
        this.$validator.reset();
      },
      setFieldsToEmpty() {
        this.subject = '';
        this.message = '';
        if (this.currentEditNote) {
          this.currentEditNote = {} as NoteModel;
        }
        this.isEditMode = false;
        this.isEditing = false;
      },
      editNote(this: any, note: NoteModel) {
        this.isEditMode = true;
        this.subject = note.subject;
        this.message = note.message;
        this.currentEditNote = note;
        const subjectTextArea = this.$el.querySelector('#subject') as HTMLElement;
        if (subjectTextArea) {
          subjectTextArea.focus();
        }
      },
      async deleteNote(this: any, note: NoteModel) {
        this.onReset();
        this.currentEditNote = note;
        await this.deleteNoteAsync(this.workflowJobModel.jobId, this.currentEditNote.id);
      }
    },

    watch: {
      isDirty(value: boolean) {
        this.$emit('tabIsDirtyChanged', {
          key: 'Narrative',
          isDirty: value
        } as TabStateModel);
      }
    },
    computed: {
      ...mapGetters('oidcStore', ['oidcUser']),
      ...mapGetters('userStore', ['isUserAdministrator']),
      notesCount(): number {
        if (!this.notes.length) {
          return 0;
        }
        return this.notes.length;
      },
      isDirty(this: any): boolean {
        return this.hasFormChanged();
      },
      disabled(this: any) {
        return (
          (this.message === this.currentEditNote.message && this.subject === this.currentEditNote.subject) ||
          this.isLoading ||
          this.isCreating ||
          this.errors.any()
        );
      }
    },
    beforeDestroy() {
      EventBus.$off(EVENT_BUS.RESET_TAB_DIRTY);
    },
    components: {
      LoadingSpinner
    }
  });
</script>
