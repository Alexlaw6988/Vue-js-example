export interface ConfigurationModel {
  canConfigureSecurity: boolean;
  canConfigureHr: boolean;
  canMaintainAllUsers: boolean;
  canMaintainAllRoles: boolean;
  canMaintainMyRoles: boolean;
  canMaintainUserClientMaintenance: boolean;
  CanConfigureMStoreClassic: boolean;
  canConfigureLeaversTool: boolean;
  canConfigureDocuSign: boolean;
}
