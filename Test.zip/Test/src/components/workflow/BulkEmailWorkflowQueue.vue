<template>
  <div class="w-100">
    <m-grouped-table
      table-id="bulkEmailWorkflowQueue"
      class="mb-3 mh-100 min-h-100"
      :header-text="workflowQueueDataModel.queueName"
      :items="workflowQueueDataModel.queueData"
      :fields="workflowQueueDataModel.queueColumns"
      :is-loading="isLoading"
      :empty-text="emptyText"
      :show-hide-filters="true"
      :emit-filters="true"
      :detail-columns="detailFields"
      :add-action-header="true"
      group-by-field="emailaddress"
      pk-field="jobid"
      :show-filters="tableStateField('showFilters')"
      :current-page="tableStateField('currentPage')"
      :items-per-page="userPreferedTableStateField('itemsPerPage')"
      :search-query="tableStateField('searchQuery')"
      :sort-by="userPreferedTableStateField('sortBy')"
      :sort-desc="userPreferedTableStateField('sortDesc')"
      :allow-wallboard-mode="workflowQueueDataModel.allowWallboardMode"
      :wallboard-refresh-interval-in-seconds="workflowQueueDataModel.wallboardRefreshIntervalInSeconds"
      @update:show-filters="onTableStateFieldUpdated"
      @update:current-page="onTableStateFieldUpdated"
      @update:items-per-page="onUserPreferedTableStateFieldUpdated"
      @update:search-query="onTableStateFieldUpdated"
      @update:sort-by="onUserPreferedTableStateFieldUpdated"
      @update:sort-desc="onUserPreferedTableStateFieldUpdated"
      @update:filtered-items="onTableStateFieldUpdated"
      @refresh-clicked="getWorkflowQueue()"
      @row-clicked="getWorkflowJob"
    >
      <template slot="row-details" slot-scope="row">
        <ul class="list-group list-group-flush">
          <a
            @click="getWorkflowJob(job)"
            v-for="job in row.item.childRows"
            :key="job.jobid"
            class="list-group-item list-group-item-action"
          >
            {{ job.jobid }} - {{ job.documenttype }}
          </a>
        </ul>
      </template>
      <template slot="cell(actions)" slot-scope="row" class="p-0">
        <b-button @click="sendDocumentsAsync($event, row.item.childRows)" class="w-100" variant="primary" size="sm" :disabled="isFullscreen">
          <font-awesome-icon icon="paper-plane" class="mr-2" />
          {{ getSendButtonText(row.item.childRows) }}
        </b-button>
      </template>
    </m-grouped-table>
    <b-modal
      v-model="postIsLoading"
      :no-close-on-backdrop="true"
      :no-close-on-esc="true"
      :hide-header-close="true"
      centered
      hide-header
      hide-footer
    >
      <div class="d-flex align-items-center">
        <LoadingSpinner :isLoading="postIsLoading" cssPositioning="inherit" loadingMessage="Please wait" />
      </div>
    </b-modal>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  import DefaultWorkflowQueue from './DefaultWorkflowQueue.vue';
  import { ColumnsModel } from '@/types/models/table/ColumnsModel';
  import { WorkflowJobService } from '@/services/WorkflowJobService';
  import { WorkflowJobsEmailModel } from '@/types';
  import LoadingSpinner from '@/components/shared/LoadingSpinner.vue';
  import MStoreGroupedTable from '@/components/shared/Table/MStoreGroupedTable.vue';
  import { Fullscreen } from '@/utils';

  export default Vue.extend({
    name: 'BulkEmailWorkflowQueue',
    mixins: [DefaultWorkflowQueue],
    data() {
      return {
        showModal: false,
        postIsLoading: false,
        detailFields: ['jobid', 'documenttype'],
        isFullscreen: false
      };
    },
    methods: {
      getSendButtonText(jobs: any) {
        const numberOfJobs = jobs.length;
        return `Send ${numberOfJobs} ${numberOfJobs > 1 ? 'Documents' : 'Document'}`;
      },
      async sendDocumentsAsync(this: any, event: any, jobs: any) {
        this.$bvModal
          .msgBoxConfirm(
            `You are about to ${this.getSendButtonText(jobs).toLowerCase()} to "${jobs[0].emailaddress}".`,
            {
              id: 'bulkEmailConfirmationModal',
              title: 'Are you sure?',
              cancelVariant: 'danger',
              noCloseOnEsc: true,
              noCloseOnBackdrop: true
            }
          )
          .then(async (result: boolean) => {
            if (result) {
              this.postIsLoading = true;
              try {
                await WorkflowJobService.emailWorkflowJobsAsync(this.workflowQueueDataModel.queueId, {
                  jobIds: jobs.map((x: any) => x.jobid)
                } as WorkflowJobsEmailModel);
              } catch (exception) {
                this.$log(exception);
              } finally {
                this.postIsLoading = false;
                this.getWorkflowQueue();
              }
            }
          });
      },
      handleOnFullscreenChange(this: any) {
        this.isFullscreen = Fullscreen.isFullscreen();
      }
    },
    components: {
      'm-grouped-table': MStoreGroupedTable,
      LoadingSpinner
    },
    created() {
      Fullscreen.registerFullscreenChange(this.handleOnFullscreenChange);
    },
    beforeDestroy() {
      Fullscreen.removeFullscreenChange(this.handleOnFullscreenChange);
  },
  });
</script>
