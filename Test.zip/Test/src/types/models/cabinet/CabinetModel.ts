import { DocumentTypeModel } from '../documentType';
import { CabinetReferenceModel } from '../documentReference';

export interface CabinetModel {
  id: string;
  description: string;
  documentTypes: DocumentTypeModel[];
  references: CabinetReferenceModel[];
}
