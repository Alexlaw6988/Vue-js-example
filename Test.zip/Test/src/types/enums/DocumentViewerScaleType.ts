export enum DocumentViewerScaleType {
  FitWithin = 1,
  FitWidth = 2,
  FitHeight = 3,
  ZoomOut = 4,
  ZoomIn = 5,
  None = 6
}
