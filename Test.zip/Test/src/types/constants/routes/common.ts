export const Common = {
  About: {
    path: '/about',
    name: 'about'
  },
  Error: {
    path: '/errorpage',
    name: 'errorPage'
  },
  PageNotFound: {
    path: '*',
    name: 'pageNotFound'
  }
};
