export const DocumentsToStore = {
  DocumentsToStore: {
    path: '/documentsToStore/:documentTypeId/:documentId',
    name: 'documentsToStore'
  },
  Base: {
    path: '/documentsToStore',
    name: 'storeDocuments'
  }
};
