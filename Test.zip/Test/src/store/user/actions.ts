import { UserState, RootState, UserModel } from '@/types';
import { ActionTree } from 'vuex';
import { UserService } from '@/services/UserService';
import { UserMutationTypes } from '@/types/store/user';

export const actions: ActionTree<UserState, RootState> = {
  getCurrentUser({ commit }) {
    commit(UserMutationTypes.Loading);
    UserService.getCurrentUserAsync().then(
      (response) => {
        const payload: UserModel = response;
        commit(UserMutationTypes.CurrentUserLoaded, payload);
      },
      (error) => {
        commit(UserMutationTypes.CurrentUserError, error);
      }
    );
  },
  currentUserAuthenticated({ commit }) {
    commit(UserMutationTypes.CurrentUserAuthenticated);
  },
  clearPostSignInIdleTime({ commit }) {
    commit(UserMutationTypes.AppActivityWhileSignedIn);
  },
  previousRoute({ commit }, payload) {
    commit(UserMutationTypes.PreviousRoute, payload);
  },
  errorPageRoute({ commit }, payload) {
    commit(UserMutationTypes.ErrorPageRoute, payload);
  },
  updateCurrentUser({ commit }, payload) {
    commit(UserMutationTypes.CurrentUserLoaded, payload);
  }
};
