<template>
  <div class="workflow-tab container-fluid">
    <LoadingSpinner :isLoading="isLoading"></LoadingSpinner>
    <div class="row" v-show="!isLoading">
      <div class="col-6">
        <div class="card mb-3">
          <div class="card-header bg-primary text-white font-weight-bold">Information</div>
          <div class="card-body pt-2">
            <div
              class="card-text row pb-1"
              v-for="fieldKey in getInformationKeys(documentInformationModel.documentFields)"
              v-bind:key="fieldKey"
            >
              <div class="col-6 font-weight-bold">{{ fieldKey }}</div>
              <div class="col-6">{{ documentInformationModel.documentFields[fieldKey] }}</div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-6">
        <div class="card mb-3">
          <div class="card-header bg-primary text-white font-weight-bold">References</div>
          <div class="card-body pt-2">
            <div
              class="card-text row pb-1"
              v-for="reference in documentInformationModel.referenceFields"
              v-bind:key="reference.cabinetReferenceModel.fieldKey"
            >
              <div class="col-6 font-weight-bold">{{ reference.cabinetReferenceModel.referenceDescription }}</div>
              <div class="col-6">{{ reference.value }}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';
  import { DocumentService } from '@/services/DocumentService';
  import LoadingSpinner from '@/components/shared/LoadingSpinner.vue';
  import { DocumentInformationModel } from '@/types';
  import { mapGetters } from 'vuex';

  export default Vue.extend({
    name: 'WorkflowDocumentInformationTab',
    data() {
      return {
        isLoading: false,
        documentInformationModel: {} as DocumentInformationModel
      };
    },
    methods: {
      getInformationKeys(obj: any) {
        if (!obj) {
          return [];
        }
        return Object.keys(obj);
      },
      async getDocumentInformation() {
        this.isLoading = true;
        this.documentInformationModel = await DocumentService.getDocumentInformationAsync(
          this.documentSearchModel.cabinetId,
          this.documentSearchModel.documentId
        ).catch((reason: any) => {
          return {
            notification: reason.response.data,
            hasNotification: true
          } as DocumentInformationModel;
          this.isLoading = false;
        });
        this.isLoading = false;
      }
    },
    computed: {
      ...mapGetters('documentViewStore', ['documentSearchModel'])
    },
    mounted() {
      this.getDocumentInformation();
    },
    components: {
      LoadingSpinner
    }
  });
</script>
