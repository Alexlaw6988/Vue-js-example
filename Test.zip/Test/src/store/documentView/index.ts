import { actions } from './actions';
import { getters } from './getters';
import { mutations } from './mutations';
import { mstoreSettings } from '@/settings/mstoreSettings';
import {
  DocumentViewState,
  DocumentVersionModel,
  BaseDocumentSearchModel,
  DocumentModel,
  RelatedDocumentViewModel,
  DocumentPageModel
} from '@/types';

export const state: DocumentViewState = {
  PageNumber: 1,
  ViewConversionId: null,
  RelatedDocumentBeingViewed: {} as RelatedDocumentViewModel,
  VersionBeingViewed: {} as DocumentVersionModel,
  DocumentModel: { contentType: '', fileName: '', documentData: '', totalPages: 0 } as DocumentModel,
  DocumentSearchModel: {} as BaseDocumentSearchModel,
  hasDocumentError: false,
  isPageLoading: false,
  hasDocumentLoaded: false,
  documentPageCache: [] as DocumentPageModel[],
  documentPage: {} as DocumentPageModel,
  maximumNumberOfPagesToCache: mstoreSettings.maximumNumberOfPagesToCache,
  showLoadingSpinner: true
};

const namespaced: boolean = true;

export const documentView = {
  namespaced,
  state,
  actions,
  getters,
  mutations
};
