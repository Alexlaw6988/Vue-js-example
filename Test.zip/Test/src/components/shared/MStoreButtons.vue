<template>
  <div>
    <div v-for="button in buttons" :key="button.caption">
      <span class="float-left" v-if="button.isConfigured">
        <b-button
          :id="button.id"
          variant="primary"
          size="sm"
          class="float-left ml-2 mb-1"
          :disabled="disabled || isLoading"
          @click="$emit('click', button)"
        >
          <font-awesome-icon size="sm" icon="spinner" class="mr-1" spin v-if="isLoading" />
          {{ button.caption }}
        </b-button>
      </span>
    </div>
  </div>
</template>

<script lang="ts">
  import Vue from 'vue';

  export default Vue.extend({
    name: 'm-buttons',
    props: {
      buttons: {
        type: Array,
        required: true
      },
      isLoading: {
        type: Boolean,
        required: true
      },
      disabled: {
        type: Boolean,
        default: false
      }
    }
  });
</script>
