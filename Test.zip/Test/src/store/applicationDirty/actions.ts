import { RootState, ApplicationDirtyStateModel, ApplicationDirtyMutationTypes } from '@/types';
import { ActionTree } from 'vuex';

export const actions: ActionTree<ApplicationDirtyStateModel, RootState> = {
  resetApplicationDirtyState({ commit }) {
    commit(ApplicationDirtyMutationTypes.ResetApplicationDirtyState);
  },
  setApplicationDirty({ commit }, isApplicationDirty: boolean) {
    commit(ApplicationDirtyMutationTypes.SetApplicationDirty, isApplicationDirty);
  },
  setApplicationDirtyOnAnotherTab({ commit }, isApplicationDirty: boolean) {
    commit(ApplicationDirtyMutationTypes.SetApplicationDirtyOnAnotherTab, isApplicationDirty);
  },
  setShowApplicationDirtyModal({ commit }, show: boolean) {
    commit(ApplicationDirtyMutationTypes.SetShowApplicationDirtyModal, show);
  },
  setApplicationDirtyRouteNavigatedTo({ commit }, to: any) {
    commit(ApplicationDirtyMutationTypes.SetApplicationDirtyRouteNavigateTo, to);
  }
};
