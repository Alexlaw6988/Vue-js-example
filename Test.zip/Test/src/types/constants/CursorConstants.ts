export const Cursor = {
  default: 'default',
  webkitGrabbing: '-webkit-grabbing'
};
